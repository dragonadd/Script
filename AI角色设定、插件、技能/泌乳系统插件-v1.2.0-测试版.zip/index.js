// 泌乳系统 —— 成人向子系统，从 emotion-life 拆出的独立插件。
//
// ── 为什么拆出来 ─────────────────────────────────────────────────────────
// 它原本在 emotion-life（4700 行）里，占 641 行 / 8.6%。混在一起时：
//   · 改泌乳要在 4700 行里翻，改错会波及情绪/亲密/玩具
//   · 没法单独开关（不想要泌乳也得带着整个 emotion-life）
// 现在它自包含：自己的数据文件、自己的工具、自己的提示词注入。
//
// ── 数据独立（这不是洁癖，是必须）───────────────────────────────────────
// 原泌乳状态存在 emotion-life 的 state.json（chats[key].adult.lactation）。
// 拆出来后若继续共用那个文件会踩今天反复遇到的坑：
//   emotion-life 的 persist() 写的是**它内存里的整份 state** ——
//   新插件刚写进去的值，下一次 emotion-life 落盘就被覆盖（本机实测已发生多次）。
// 所以用独立文件：<DATA_DIR>/lactation/state.json。
// 首次启动从 emotion-life 的 state 里**导入一次**现有数值（文件已存在就跳过）。
//
// ── 与 emotion-life 的分工 ─────────────────────────────────────────────
//   emotion-life：情绪、亲密、玩具、姿势、剧本、自拍……
//   lactation   ：只负责泌乳（奶量/胀感/容量/出奶档 + 上报结算 + 提示词段）

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

/* ── 数据目录：复用核心的 DATA_DIR，并跨热重载缓存 ──────────────────────
   ⚠️ 照抄 emotion-life 里修好的那版：热重载期间 `import(config.js)` 会失败，
   一旦回退到 `resources/app/data` 就会读写另一份陈旧数据（实测丢过 6 次结算）。
   所以：候选路径探测 + globalThis 缓存，首次对过一次后永不回退。 */
async function resolveDataDir() {
  const CACHE_KEY = '__QQ_AGENT_DATA_DIR__';
  if (globalThis[CACHE_KEY]) return globalThis[CACHE_KEY];
  const here = path.dirname(fileURLToPath(import.meta.url));
  const appRoot = path.resolve(here, '../..');
  const candidates = [
    process.env.QQ_AGENT_DATA_DIR,
    process.env.DSH_DATA_DIR,
    path.resolve(appRoot, '..', '..', 'data'),
    path.resolve(appRoot, '..', 'data'),
    path.resolve(appRoot, 'data')
  ].filter((x) => x && typeof x === 'string');
  let dir = '';
  try {
    const cfgPath = path.resolve(appRoot, 'src', 'config.js');
    if (fs.existsSync(cfgPath)) {
      try {
        const mod = await import(pathToFileURL(cfgPath).href);
        if (typeof mod.DATA_DIR === 'string' && mod.DATA_DIR) dir = mod.DATA_DIR;
      } catch { /* 热重载期间可能失败，走候选探测 */ }
    }
  } catch { /* 继续 */ }
  if (!dir || !fs.existsSync(path.join(dir, 'config.json'))) {
    let best = '', bestMt = -1;
    for (const c of candidates) {
      try {
        const cfg = path.join(c, 'config.json');
        if (!fs.existsSync(cfg)) continue;
        const mt = fs.statSync(cfg).mtimeMs;
        if (mt > bestMt) { bestMt = mt; best = c; }
      } catch { /* skip */ }
    }
    if (best) dir = best;
  }
  if (!dir) dir = candidates[0] || path.resolve(appRoot, 'data');
  globalThis[CACHE_KEY] = dir;
  return dir;
}

const DATA_DIR = await resolveDataDir();
const STATE_FILE = path.join(DATA_DIR, 'lactation', 'state.json');
const EMOTION_STATE = path.join(DATA_DIR, 'emotion-life', 'state.json');

let apiRef = null;
let activeChatKey = '';
let stateRoot = null;

/* ── 状态读写 ───────────────────────────────────────────────────────────
   结构刻意与 emotion-life 保持一致（chats[key].adult.lactation），
   这样从上面抽出来的 641 行代码**一行都不用改**。 */
function ensureRoot() {
  if (stateRoot) return stateRoot;
  try { stateRoot = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); } catch { stateRoot = {}; }
  if (!stateRoot.chats || typeof stateRoot.chats !== 'object') stateRoot.chats = {};
  return stateRoot;
}

function ensureState(chatKey) {
  const root = ensureRoot();
  const key = String(chatKey || 'legacy');
  if (!root.chats[key] || typeof root.chats[key] !== 'object') root.chats[key] = {};
  const s = root.chats[key];
  s.adult = s.adult && typeof s.adult === 'object' ? s.adult : {};
  activeChatKey = key;
  return s;
}

function persist() {
  try {
    const root = ensureRoot();
    root.updatedAt = new Date().toISOString();
    fs.mkdirSync(path.dirname(STATE_FILE), { recursive: true });
    const tmp = STATE_FILE + '.' + process.pid + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(root, null, 2), 'utf8');
    fs.renameSync(tmp, STATE_FILE);
  } catch (e) {
    try { apiRef?.warn?.('泌乳状态保存失败：' + (e?.message ?? e)); } catch { /* ignore */ }
  }
}

function CLOG(msg) { try { apiRef?.warn?.(String(msg)); } catch { /* ignore */ } }
function settings() { try { return apiRef?.config?.() || {}; } catch { return {}; } }

function chatKeyFrom(ctx = {}) {
  const k = String(ctx.chatKey || ctx.session?.chatKey || '');
  if (k) return k;
  if (ctx.kind === 'private') return 'private:' + (ctx.userId || 'unknown');
  if (ctx.kind === 'group') return 'group:' + (ctx.groupId || 'unknown');
  return 'legacy';
}

/** 只取"他"说的话；拿不到归属信息才退回最后一条 user 消息。 */
function ownerText(ctx = {}) {
  try {
    const es = Array.isArray(ctx.triggerEntries) ? ctx.triggerEntries : [];
    if (es.length) {
      return es.filter((e) => e && !e.self)
        .map((e) => String(e.text || e.rawText || '').trim()).filter(Boolean).join(' ');
    }
  } catch { /* 退回下面 */ }
  const msgs = Array.isArray(ctx.messages) ? ctx.messages : [];
  for (let i = msgs.length - 1; i >= 0; i--) {
    if (msgs[i]?.role === 'user') return String(msgs[i].content || '');
  }
  return '';
}

/* ── 一次性迁移 ─────────────────────────────────────────────────────────
   只在 STATE_FILE 还不存在时做。emotion-life 里那份 lactation 字段保留不删
   （它的 persist 会带着写，无害；我们不读它）。 */
function migrateFromEmotionLifeOnce() {
  try {
    if (fs.existsSync(STATE_FILE)) return;
    if (!fs.existsSync(EMOTION_STATE)) return;
    const el = JSON.parse(fs.readFileSync(EMOTION_STATE, 'utf8'));
    const root = { version: 1, chats: {}, updatedAt: new Date().toISOString() };
    let n = 0;
    for (const [k, v] of Object.entries(el.chats || {})) {
      const la = v?.adult?.lactation;
      if (la && typeof la === 'object') { root.chats[k] = { adult: { lactation: la } }; n += 1; }
    }
    fs.mkdirSync(path.dirname(STATE_FILE), { recursive: true });
    fs.writeFileSync(STATE_FILE, JSON.stringify(root, null, 2), 'utf8');
    CLOG('[泌乳] 已从 emotion-life 迁移 ' + n + ' 个会话的泌乳状态');
  } catch (e) { CLOG('[泌乳] 迁移失败：' + (e?.message ?? e)); }
}

/* ═══════════════════════════════════════════════════════════════════════
   以下 641 行从 emotion-life/index.js 原样搬出（LAC_RUB → detectScene 之前）：
   常量、ensureLactation、lacRate、lacFlowTier、lacApplyTime、lacSettle、
   detectLactation、lactationSection、reportHint、eventHooks、physiologyHints。
   它们依赖 ensureState / persist / activeChatKey / CLOG —— 已在上面提供同名实现，
   状态结构也保持 chats[key].adult.lactation，因此**代码本身一行未改**。
   ═══════════════════════════════════════════════════════════════════════ */

const LAC_RUB = /(揉|捏|摸|抚|搓|按|挤).{0,6}(胸|乳|奶)|挤奶|挤.{0,6}(出来|一点|几滴|不多)/;
/* 吸/含/吮 不一定后面跟"奶"字（"低头吸""含着不放"），所以分成两种：
   ① 动词 + 乳头/奶/乳 ② 单纯"吸/含/吮/舔"出现在奶语境里也算 */
/* [补丁 2026-10-22 by 小鲸鱼｜泌乳识别：补漏判 + 去误判]
   用户反馈"刚吸过一次，网站好像没记录"（suckCount 停在 1）。
   实测两类错误同时存在：
     漏判：`吃一口看看`、`尝尝`、`含着不放`、`叼` 这些说法旧词表一条都不认
     误判：`吸了口气`、`含了一下嘴唇`、`咬了咬嘴唇` 被 `(吸|含|吮)(了|着|一下)` 命中 ⇒ 白加 9 点
   修法：
     ① 严格分支：动词扩到 吸/含/吮/舔/咬/嘬/吃/尝/叼，宾语扩到 乳/奶/胸/乳头/乳尖/奶头
     ② 宽松分支：只认"动词+助词"的裸说法（含着不放、吸了两口），**但必须过排除表**
     ③ 排除表 LAC_SUCK_NOISE：吸气/倒吸/喘口气/吸鼻子/吸溜/含了口水/喝口水/咬嘴唇/舔唇
        —— 这些跟奶无关，命中就会把 level 白涨 9 点。
   验证：23/23 定向用例通过（含 `含着不放` 该中、`吸了口气` 不该中）。
   注意：宽松分支仍需"不含噪声词"才算命中，所以是 `LOOSE && !NOISE`，不能只看 LOOSE。 */
const LAC_SUCK_STRICT = /(?:吸|含|吮|舔|咬|嘬|吃|尝|叼).{0,6}(?:乳|奶(?!茶|昔|油|粉|酪|片|糖|精|白)|胸|乳头|乳尖|奶头)|(?:乳头|乳尖|奶头).{0,4}(?:吸|含|吮|舔|咬|吃)|(?:低头|凑过去|凑近|张嘴|俯下|埋进).{0,6}(?:吸|含|吮|舔|吃|叼)/;
/* ⚠️ [2026-10-22] 宽松分支（只认动词+助词的裸说法）**故意不含 吃/尝/叼**：
   实测把"吃/尝"放进来会把「吃一口饭」「尝尝这个菜」「让我尝尝」全误判成吸吮（+9 奶量）。
   "吃/尝/叼"只在严格分支里认 —— 也就是必须带 乳/奶/胸/乳头 这类宾语。 */
/* [2026-10-23 修｜“咬了一口”被当成吸奶 → 15:04-15:13 吃蛋挾时误结算 4 次]
   原来 LOOSE 里有「咬」，而吃东西时“咬一口”是最常用的说法。
   严格分支仍保留「咬」（但必须带 乳/奶/胸 这类宾语）；宽松分支去掉「咬」。 */
/* [2026-10-24 用户澄清｜「嘬」是"没奶时的动作"，不该扣奶]
   她的真实用法：
     空的也嘬这么起劲 / 两边都空了你还换着嘬 / 空的还嘬得这么认真
     → 这些是**干嘬**（本来就没奶），扣了也不合理
   但：真被你嘬出一点了 → 这个是**嘬出来了**，该算

   所以分两层：
     · 吸 / 含 / 舔        → 算吸乳（扣奶）
     · 嘬 + 出/一点/一丝/尝 → 算（真嘬出来了）
     · 嘬 + 其他           → 只算"被吸的次数"，不扣奶
*/
const LAC_SUCK_LOOSE = /(?:\u5438|\u542b|\u8210)(?:\u4e86|\u7740|\u5f97|\u51fa|\u5230|\u8fc7|\u6211|\u4f60|\u4e00\u53e3|\u51e0\u53e3|\u8fd9\u4e48|\u534a\u5929|\u7d2f|\u9178|\u5e72\u51c0|\u5b8c|\u70ed|\u51c9|\u75bc|\u8f6f|\u7ea2|\u80bf|\u9ebb)|(?:\u5438|\u542b|\u8210)[^\s\uff0c\u3002]{0,3}(?:[\uff0c\u3002\uff01\uff1f\u2026]|$)|\u54ac(?:\u4f60|\u6211|\u4ed6|\u5979|\u4f4f|\u4e86|\u7740)/;

/* 「嘬」单独判定 */
const LAC_NUO_DRY = /\u562c/;                                          // 出现"嘬"
const LAC_NUO_GOT = /\u562c(?:出|\u5230|\u4e00\u70b9|\u4e00\u4e1d|\u5c1d\u5230|\u51fa\u6765)/;  // 嘬出来了
const LAC_SUCK_NOISE = /(?:吸|倒吸|深)了口气|吸鼻子|吸溜|吸气|含了一下?嘴|含了口水|喝口水|咬(?:着|了)?(?:嘴)?唇|舔了?下?(?:嘴)?唇|尝(?:尝)?(?:这个|那道|菜|味道|咸|甜|辣)/;

/* [2026-10-24 新增｜口交场景误判成吸乳]
   实测 00:10-00:35：她在口交+吞精，台词全是“含着”“舐”“咽”“嗘”，
   结果被 lacSuckHit 当成吸奶 → 连结算 5 次、奶量被扣到 0。
   口交和吸乳的关键区别：口交围绕“咽/吞/嗘子/嘴里/精”，吸乳围绕“胸/乳/奶”。
   命中下面这些词 → 直接不算吸乳（但如果同句有“乳/奶/胸”，仍算）。 */
const LAC_ORAL_SEX = /(咽|吞|嗘|嘴里|口腔|喉咙|精|射了|龟头|那根|下面|吹|吮不出|呛着|呛住)/;

/** 是否命中"吸吮"（宽松分支必须过排除表）。 */
/* [2026-10-23 改｜区分"吃东西”和"吸/咬乳头"——用户会咬他，不能一刀切]
   实测：15:04-15:13 吃蛋挾时说“咬了一口” → 误判成吸奶，连结算 4 次。
   但又不能把“咬”一刀切删掉（用户确实会咬乳头）。
   三层判断：
     ① 严格分支命中（带 乳/奶/胸 宾语）→ 直接算吸唇，不再看其它
     ② 同句有**食物词**（蛋挾/面包/饭/菜……）→ 判定为吃东西，不结算
     ③ 否则才按宽松分支算（“咬你一口”“含着不肯松”都算） */
const LAC_FOOD = /(蛋挾|面包|饼干|蛋糕|饼|饭|菜|肉|水果|苹果|香蕉|橘|橙|葡萄|草莓|粥|面条|面包|汤|奶茶|咖啡|冰淇淋|巧克力|薯片|包子|饺子|馒头|便当|外卖|零食|糖|坚果|蛋|三明治|汉堡|披萨|寿司|火锅|烤串|瓜子|花生|小吃|热量|胖|饱|喂你|喂我|张嘴|嘴里|唐|酸|甜味|味道|香味|器)/;

/* [2026-10-24 加｜否定句排除]
   实测她的台词："……就一点，你别吸啊" / "就一点点……你别吸，让它自己流下去"
   这两句**没有发生吸吮**（她在阻止），却因为含"吸"被算成被吸了。
   规则：吸/含/舐/嘬 前面 8 字内有 别/不要/不用/先别/不许 → 不算。 */
const LAC_SUCK_DENY = /(?:别|不要|不用|先别|不许|不准)[^，。！？]{0,8}(?:吸|含|舐|嘬)/;

function lacSuckHit(t) {
  const s0 = String(t || '');
  if (!s0) return false;
  // ⓪ 否定句：「你别吸啊」= 没在吸
  if (LAC_SUCK_DENY.test(s0)) return false;
  // ① 带乳/奶/胸 这类宾语 —— 无条件算
  if (LAC_SUCK_STRICT.test(s0)) return true;
  // ② 排除表（吸气/口水/咬嘴唇……）
  if (LAC_SUCK_NOISE.test(s0)) return false;
  // ③ 同句有食物词 → 判定为吃东西
  if (LAC_FOOD.test(s0)) return false;
  // ④ 口交场景排除：“含着”“舐”在口交里太常见，但吸乳必须有胸/乳/奶语境
  if (LAC_ORAL_SEX.test(s0) && !/[乳奶胸]/.test(s0)) return false;
  // ⑤【2026-10-24 新增】「嘬」是没奶时的动作 —— 只有嘬出东西了才算
  const hasReal = /(吸|含|舔)/.test(s0);
  if (!hasReal && LAC_NUO_DRY.test(s0)) {
    return LAC_NUO_GOT.test(s0);   // 干嘬 → 不算；嘬出来了 → 算
  }
  // ⑥ 常规：宽松动词命中才算
  if (!LAC_SUCK_LOOSE.test(s0)) return false;
  return true;
}
/* 喝掉：口语里常省略宾语（"喝下去了""咽下去""快喝掉"），所以也认裸动词。
   [补丁 2026-10-22] 补三处：`我喝了`（原 `^(喝|咽|吞)了?$` 要求整句以喝开头，加了主语就失效）、
   `喝掉/喝光/喝干净`（无宾语）、`咽下去了`。同时排除"喝口水"（不是喝奶）。 */
/* [2026-10-24 三插件分工｜「喝」归泌乳（奶，扣 level），
   「喝水/茶/咖啡/酒/汤」归泌尿（涨 volume）—— 不能互相误判。
   原来最后两段只要看到“喝了”就算（除非后面跟水/口），
   “我喝了一杯茶”会被当成喝奶 → 误扣。现在把饮品名全部列为排除。 */
/* [2026-10-24 修] 原来只排除"喝奶茶/喝一杯"，实测"喝牛奶吗""喝点牛奶吧"会被
   当成"他喝她的奶"，totalFed 白白 +1。凡带奶字的饮品/食物一律排除。 */
const LAC_DRINK_NOISE = /(喝水|喝茶|喝咖啡|喝酒|喝啤酒|喝汤|喝果汁|喝饮料|喝奶茶|喝一杯|喝了一杯|和水|每天喝|牛奶|酸奶|豆奶|椰奶|奶粉|奶昔|奶油|奶酪|炼乳|奶糖)/;
const LAC_DRINK_RAW = /(?:喝|咽|吞|尝).{0,6}(?:奶|乳|下去|掉了|完了)|(?:奶|乳).{0,4}(?:喝掉|咽下|吞下)|(?:^|[，。；、！？\s])(?:我)?(?:喝|咽|吞)了(?![口水])|(?:喝|咽|吞)(?:掉|光|干净)/;
const LAC_DRINK = { test: (t) => LAC_DRINK_RAW.test(t) && !LAC_DRINK_NOISE.test(t) };
const LAC_WANT = /(?:喝|要喝|想喝|吸|想吃).{0,8}(?:奶|乳汁|母乳)/;
/* "排空"信号：这些说法表示奶被吸走了、胀感消失 —— v1 完全抓不到，
   也是"吸完不降"的直接原因。现在它们会把 hardness 大幅降下来。 */
/* [2026-10-22 收窄｜裸"空"是高频字，误伤太大]
   原写法含单个 `空` ⇒ 「有空」「空调」「没空」「空着」全命中，每命中一次 hardness −30。
   实测：补偿把胀感抬到 75 后，她一句「已经不胀了，摸着软软的」就把值打回 45，
   形成"抬起来→被打下去→再抬"的死循环，用户看到的就是"明明 100 还是不胀"。
   现在只认**明确表示排空**的说法，且要求语境里带身体/奶：
     · 软了/软下去/软下来（带 胸|乳|奶 或 前面有"不胀/硬块"）
     · 硬块没了/消了/散了
     · 不胀了 / 胀感没了
     · 吸空/吸干净/喝干净/排空（不认裸"空"） */
const LAC_EMPTY_HINT = /(?:胸|乳|奶|乳房).{0,6}(?:软了|软下去|软下来)|(?:软了|软下去|软下来).{0,4}(?:胸|乳|奶)|硬块.{0,4}(?:没|消|散)|不胀了|胀感.{0,4}(?:没|消|退)|(?:吸空|吸干净|喝干净|排空了|空掉了)/;

// ── 泌乳常量 ──────────────────────────────────────────────────────────
const LAC_CAP_START = 100;      // 初始单侧容量
const LAC_CAP_MAX = 150;        // 练度上限
/* [2026-10-22 修正｜胀感涨得太慢 → 奶量满了却"没反应"]
   实测（10-22 10:41）：奶量已经 100/100，胀感却只有 22.3。
   而**所有提示词分支都按胀感判断**（"胀得难受""该主动求吸""溢奶"都在 ≥71/≥86 档），
   ⇒ 结果是"奶满了但注入的是'有点胀、不用主动提'"，用户看到的就是"100 了却没反应"。
   根因：胀感原来是独立的慢速累积（0.3/h、超 6 小时 0.8/h），从排空到满要一整天，
   而奶量几小时就顶到容量 —— 两条曲线彻底脱节。
   修法：**让胀感跟着奶量走**（符合生理：越充盈越胀，而不是单纯看时间）。
     hardRate = (0.35 + 1.6 × fillRatio) × (久未排空 ? 1.6 : 1)
       · fill 0%   → 0.35/h（空着不该胀）
       · fill 50%  → 1.15/h
       · fill 90%  → 1.79/h
       · fill 100% → 1.95/h（满的时候最难受，涨得最快）
     这样奶量满时胀感也能在几小时内跟上 70+，提示词才会真的催她求吸。 */
const LAC_HARD_RISE = 0.35;      // 基础（每小时）
const LAC_HARD_FILL = 1.6;       // 充盈度加成系数
const LAC_HARD_RISE_STALE = 1.6; // 久未排空的额外倍数
const LAC_STALE_HOURS = 6;
const LAC_FLOW_TIERS = [5, 15, 30]; // 累计吸空次数 → 解锁 2/3/4 档

/** 泌乳状态规范化：老数据（只有 level）平滑升级到 v2 结构。 */
function ensureLactation(s) {
  s.adult = s.adult || {};
  const la = s.adult.lactation = s.adult.lactation || {};
  if (la.on === undefined) la.on = true;
  /* ── 两个"体验维度"（2026-10-22 新增，用户要"更丰富但不删减"）────────
     sensitivity 敏感度 0–100：被吸得越多越敏感。它不是 flow（出奶快慢），
       而是**触觉反应**——还没碰就立起来、轻轻一碰就激灵。初始 20（生疏）。
     shame 羞耻度 100→0：一开始被看着会想挡、说"别看"；被吸多了逐渐坦然，
       最后会主动凑上去。初始 80（偏羞）。只降不升（不设"倒退回羞"，
       因为那会让"已经放开了"的戏莫名倒车）。 */
  /* 初值按**已有历史**推导：
     suckCount 记录吸过多少次，用它反推，否则吸过十几次的会话会被判成"第一次"。
     [2026-10-22 调整] shame 上限从 80 降到 45 —— 用户说"过去这个阶段了"，
     所以即使新会话也不该再出现"想挡/别看"那种戏，最多"有点不好意思"。 */
  const _pastSuck = Math.max(0, Number(la.suckCount) || 0);
  if (!Number.isFinite(Number(la.sensitivity))) la.sensitivity = Math.min(60, 20 + _pastSuck * 3);
  if (!Number.isFinite(Number(la.shame))) la.shame = Math.max(8, 45 - _pastSuck * 3);
  la.sensitivity = Math.max(0, Math.min(100, Number(la.sensitivity)));
  la.shame = Math.max(0, Math.min(100, Number(la.shame)));
  const cap = Math.max(LAC_CAP_START, Math.min(LAC_CAP_MAX, Number(la.capacity) || LAC_CAP_START));
  la.capacity = cap;
  // 老数据迁移：只有 level/peak，没有左右侧
  const legacyLevel = Math.max(0, Math.min(100, Number(la.level) || 0));
  if (!la.sides || typeof la.sides !== 'object') {
    la.sides = {
      left: { level: legacyLevel, hardness: Number(la.hardness) || 0 },
      right: { level: legacyLevel, hardness: Number(la.hardness) || 0 }
    };
    /* 迁移时 hardness 取低值：用户最后一句是「两边都软下来了，硬块也没了」，
       若给满分会出现"刚说软了却显示胀满"的同一个矛盾。 */
    if (!Number(la.hardness)) { la.sides.left.hardness = 15; la.sides.right.hardness = 15; }
  }
  for (const side of ['left', 'right']) {
    const x = la.sides[side] = la.sides[side] || {};
    x.level = Math.max(0, Math.min(cap, Number(x.level) || 0));
    x.hardness = Math.max(0, Math.min(100, Number(x.hardness) || 0));
  }
  /* [2026-10-22｜胀感下限：奶量越满，胀感不该低于某条线]
     实测（10-22 10:41）：level=100 而 hardness=22.3 ⇒ 提示词判"有点胀、不用主动提"，
     用户看到"明明 100 了却没反应"。
     原因：v2 上线时 hardness 用旧速率（0.3/h）慢慢爬，奶量早就顶满了它还在 20 出头。
     涨速已改好（见 LAC_HARD_FILL），但**已经滞后的数据**需要校正，否则要再等 25 小时。
     规则（与提示词档位对齐，不是拍脑袋的系数）：
       fill 100% → 至少 75（跨过"该主动求吸"的 71 门槛，否则满奶也不催）
       fill 80%  → 至少 63
       fill 60%  → 至少 51
       fill 50%  → 至少 45
       fill <50% → 不校正（低充盈本来就不该胀）
     ⚠️ 踩过两次坑：
       ① 第一版写 `fill × 65`，满奶只给 65，仍差 6 点不催 ⇒ 必须从门槛反推；
       ② 第二版用 `hardnessFloorV2` 标记"只做一次"，结果补偿执行后值被
          LAC_EMPTY_HINT 打回 45，标记已置位 ⇒ 再也补不回来。
          现在**去掉标记，改成每次都检查**：只在低于下限时抬升、永不降低，
          所以幂等、且能自动修复被打回的值。 */
  {
    /* [2026-10-22 改｜左右侧独立]
       原来 fill 取**两侧最大**再统一算下限 ⇒ 右边满奶会把左边的硬度也抬起来，
       变成"他只吸了左边、左边却还胀着"的假象（用户要求左右真正独立）。
       现在每侧用自己的奶量算自己的下限：左边空了就只压左边，右边照旧。 */
    /* ⚠️ 逃生门：刚排空（40 分钟内）不抬升，否则"吸空"这件事永远生效不了 ——
       会出现"刚被吸完还是胀"，比原 bug 更荒谬。 */
    const sinceEmptyMin2 = la.lastEmptyAt ? (Date.now() - Number(la.lastEmptyAt)) / 60000 : Infinity;
    const justDrained2 = sinceEmptyMin2 <= 40;
    if (!justDrained2) {
      for (const side of ['left', 'right']) {
        const x = la.sides[side];
        const fillSide = Math.max(0, Math.min(1, (Number(x.level) || 0) / (cap || 1)));
        if (fillSide < 0.5) continue;          // 该侧奶少 → 不该胀，跳过
        const floor = Math.round(Math.min(75, 45 + (fillSide - 0.5) * 60));
        if (x.hardness < floor) x.hardness = Math.min(100, floor);
      }
    }
  }
  /* [2026-10-22 修｜"空着却喊胀"的状态矛盾]
     状态矩阵实测：
       level=0  hardness=50  ⇒ 注入"可以提（有点胀）"
       level=0  hardness=100 ⇒ 注入"必须处理、硬块按着真疼、揉不开"
       level=10 hardness=90  ⇒ 同上
     奶都空了还在喊"硬块疼"，这不可能 —— 胀感来自充盈和堵塞，没奶就没得胀。
     而且这个矛盾会让她演成"明明刚吸空、下一轮又开始喊疼"。
     修法：**胀感上限跟着存量走**：hardness ≤ 20 + fill × 80
       fill 100% → 上限 100（满奶可以胀到顶）
       fill 50%  → 上限 60
       fill 20%  → 上限 36
       fill 0    → 上限 20（只留一点残胀，够写"有点酸"）
     与上面的下限保护不冲突：fill=1 时下限 75/上限 100；fill=0.5 时下限 45/上限 60。 */
  {
    const capH = Number(la.capacity) || LAC_CAP_START;
    for (const side of ['left', 'right']) {
      const x = la.sides[side];
      const fillSide = Math.max(0, Math.min(1, (Number(x.level) || 0) / (capH || 1)));
      const hdCap = Math.round(20 + fillSide * 80);
      if (x.hardness > hdCap) x.hardness = hdCap;
    }
  }
  if (!Number.isFinite(Number(la.peak))) la.peak = Math.max(la.sides.left.level, la.sides.right.level);
  if (!Number.isFinite(Number(la.totalFed))) la.totalFed = 0;
  if (!Number.isFinite(Number(la.suckCount))) la.suckCount = 0;
  if (!Number.isFinite(Number(la.emptyCount))) la.emptyCount = 0;   // 累计"吸空"次数 → 决定 flow 档
  if (!Number.isFinite(Number(la.lastFedAt))) la.lastFedAt = 0;
  if (!Number.isFinite(Number(la.lastLevelAt))) la.lastLevelAt = Date.now();
  if (!Number.isFinite(Number(la.lastEmptyAt))) la.lastEmptyAt = 0;
  /* ② 勤吸正反馈用：24h 内的排空时刻表（只留最近 30 条，避免无限增长）。 */
  if (!Array.isArray(la.emptyTimes)) la.emptyTimes = [];
  la.emptyTimes = la.emptyTimes.filter((t) => Number.isFinite(Number(t))).slice(-30);
  /* ⑧ 高潮喷乳计数（spray） */
  if (!Number.isFinite(Number(la.sprayCount))) la.sprayCount = 0;
  if (!Number.isFinite(Number(la.lastSprayAt))) la.lastSprayAt = 0;
  /* [2026-10-24 加] 本场吸乳的过程量：原来只留最终 level，注入里看不到"从满到空"。
     lastSuckAt = 最近一次被吸的时刻；sessionStartAt/sessionSuckedMl 距上次吸超过 2h 就重开一场。 */
  if (!Number.isFinite(Number(la.lastSuckAt))) la.lastSuckAt = 0;
  if (!Number.isFinite(Number(la.sessionStartAt))) la.sessionStartAt = 0;
  if (!Number.isFinite(Number(la.sessionSuckedMl))) la.sessionSuckedMl = 0;
  if (!Number.isFinite(Number(la.sessionLetDownCount))) la.sessionLetDownCount = 0;
  if (!Number.isFinite(Number(la.sessionLetDownAt))) la.sessionLetDownAt = 0;
  if (!Number.isFinite(Number(la.lastDrainRatio))) la.lastDrainRatio = 0.5;
  if (!la.startedAt) la.startedAt = Date.now();
  if (!Array.isArray(la.log)) la.log = [];                          // 结算日志（排障用）
  return la;
}

/** 当前回涨速率（每小时）。A①②⑤：练度 × 上次排空率 × 夜间 × 排空不应期 × 勤吸加成 × 晨起加成。 */
function lacRate(la, now = Date.now()) {
  const days = Math.max(1, Math.floor((now - Number(la.startedAt || now)) / 86400000) + 1);
  /* [2026-10-22 修｜产能太低，吸空后一天都是空的]
     原式 base = 4~9/h。配合 drain(0.5) 与回填系数，有效速率约 2-4/h ⇒ 从 0 到满要 20+ 小时，
     用户实测「17:46 吸空、18:46 还是 0/0」，观感像她根本不产奶。
     真实泌乳：排空后 3-5 小时就该重新有胀感，8-12 小时接近满。
     改成 12~22/h（第 1 天 12，每天 +1，封顶 22），配合下面 drain 的下限 0.6：
       有效速率 ≈ 7-13/h（正常期）→ 8-14 小时满；排空后 1 小时也能到 3-4。 */
  /* [2026-10-23 调｜基础速率 12+1*(days-1)/上限 22 → 15+1.2*(days-1)/上限 26]
     原来第 6 天只有 17/h，涨满 150 要 12.6 小时；用户反馈“一直没奶”。
     新口径第 6 天 = 21/h，涨满约 10 小时（仍保留不应期和夜间系数）。 */
  const base = Math.min(26, 15 + 1.2 * (days - 1));
  const drain = Math.max(0.6, Math.min(1, Number(la.lastDrainRatio) || 0.8));
  const hour = new Date(now).getHours();
  const night = (hour >= 22 || hour < 6) ? 1.4 : 1.0;
  /* ⑤ 晨起饱满：06–08 点泌乳素仍高，额外 ×1.2，形成"早上最胀"的规律。
     和夜间 1.4 不叠加（06–08 属于夜间刚过的尾巴，只用 1.2 加成）。 */
  /* ⑤ 晨起饱满：泌乳素在清晨仍高，给一个加成形成"早上最胀"的规律。
     [2026-10-22 调整] 窗口原为 06–08 点，但用户实际 10–11 点才醒 —— 那个窗口
     他还在睡，加成等于白给。改成 **08–13 点**：从起床前两小时开始爬，
     覆盖他真正醒来、开始对话的那段时间，"一醒来就胀"的观感才成立。 */
  const dawn = (hour >= 8 && hour < 13) ? 1.2 : 1.0;
  /* ① 排空不应期：刚排空后 90 分钟几乎产不出新奶（乳腺在回填），
     90–180 分钟只回到一半。这是真实泌乳最明显的节律，v2 之前完全没有。 */
  const sinceEmptyMin = la.lastEmptyAt ? (now - Number(la.lastEmptyAt)) / 60000 : Infinity;
  let refractory = 1.0;
  /* [2026-10-22 修｜吸空后一小时还是 0，观感像「她不会产奶了」]
     实测（17:17 吸空 → 17:46 → 仍显示 0/0）：这 29 分钟落在 90 分钟不应期内，
     refractory 只有 0.15 ⇒ rate≈0.375/h ⇒ 涨 0.18，四舍五入成 0。
     真实泌乳虽然在排空后回填慢，但一小时总能渗出一些，不会是零。
     调整：不应期缩到 60 分钟、系数提到 0.3；回填期 60–150 分钟给 0.7。 */
  /* [2026-10-23 改｜不应期太狠 → 连续吸空后产速只剩 30%，涨满 134 要 32.8 小时]
     实测用户连续吸空 4 次（15:04-15:13）→ 一直卡在 <60 分钟的 0.3 档
     → 感觉“汁乬突然没了”。真实泌乳里排空后 10-15 分钟就开始回涨。
     改成：<15 分钟 ×0.5 | <45 分钟 ×0.8 | 其后 1.0。 */
  if (sinceEmptyMin < 15) refractory = 0.5;
  else if (sinceEmptyMin < 45) refractory = 0.8;
  else if (sinceEmptyMin < 150) refractory = 0.95;   // 45-150 分钟轻微折扣（原来是 0.7，比 45 分钟内的 0.8 还低，逻辑反了）
  /* ② 勤吸正反馈：24 小时内有效排空 ≥3 次 → 当日基础速率 ×1.25（供需匹配）。 */
  const recent = Array.isArray(la.emptyTimes) ? la.emptyTimes.filter((t) => now - t <= 86400000).length : 0;
  const supply = recent >= 3 ? 1.25 : 1.0;
  return base * (0.6 + 0.8 * drain) * night * dawn * refractory * supply;
}

/** flow 档位 1–4（按累计吸空次数）。 */
function lacFlowTier(la) {
  const n = Number(la.emptyCount) || 0;
  let tier = n >= LAC_FLOW_TIERS[2] ? 4 : n >= LAC_FLOW_TIERS[1] ? 3 : n >= LAC_FLOW_TIERS[0] ? 2 : 1;
  /* [2026-10-22 修｜"满奶却说挤半天才一滴"的矛盾]
     实测：level=100（两侧都满）而 emptyCount=0 ⇒ tier 恒为 1
     ⇒ 提示词写"出奶程度：挤半天才一滴"。满着却挤不出，物理上说不通，
     用户看到就是"数据不对"。
     真实情况：没练过的人确实**不好挤**（乳腺管细、奶阵来得慢），
     但奶积到很满时**压力本身就够**，至少能顺畅流一阵。
     所以加一条"充盈下限"：任一侧充盈 ≥85% 时 tier 至少 2（能挤出、但需要揉）。 */
  const cap0 = Number(la?.capacity) || LAC_CAP_START;
  const fillMax = Math.max(
    (Number(la?.sides?.left?.level) || 0) / cap0,
    (Number(la?.sides?.right?.level) || 0) / cap0
  );
  if (fillMax >= 0.85 && tier < 3) tier = 3;   // 满奶时压力够，至少能顺畅流一阵
  return tier;
}

/** 时间推进：回涨 level、累积 hardness。幂等，可随时调用。 */
function lacApplyTime(la, now = Date.now()) {
  const hours = Math.max(0, (now - Number(la.lastLevelAt || now)) / 3600000);
  if (hours <= 0.02) return 0;
  const rate = lacRate(la, now);
  const stale = hours >= LAC_STALE_HOURS;
  const cap = Number(la.capacity) || LAC_CAP_START;
  for (const side of ['left', 'right']) {
    const x = la.sides[side];
    /* ③ 非线性涨奶：充盈到一定程度后压力抑制分泌，越满涨得越慢。
       公式 Δ = rate × hours × (1 - (level/cap)^0.6)
       · level=0    → 系数 1.00（空的时候最快）
       · level=50%  → 系数 0.34
       · level=90%  → 系数 0.06（接近满时几乎不涨）
       这解决了 v2 "匀速爬到封顶、然后永远 100"的呆板感。 */
    const fill = Math.max(0, Math.min(1, x.level / cap));
    const factor = Math.max(0, 1 - Math.pow(fill, 0.6));
    x.level = Math.min(cap, x.level + hours * rate * factor);
    /* 胀感跟充盈度走（见 LAC_HARD_* 上方注释）：奶越满胀得越快。
       用**推进后的 fill**（涨完之后的充盈度），否则"刚满那一小时"会漏算。 */
    const fillAfter = Math.max(0, Math.min(1, x.level / cap));
    const hardRate = (LAC_HARD_RISE + LAC_HARD_FILL * fillAfter) * (stale ? LAC_HARD_RISE_STALE : 1);
    x.hardness = Math.min(100, x.hardness + hours * hardRate);
  }
  la.peak = Math.max(Number(la.peak) || 0, la.sides.left.level, la.sides.right.level);
  /* ── 堵奶风险（2026-10-22 新增，用户要"堵奶风险升级"）─────────────────
     真实生理：单侧长时间胀满不排空 → 乳导管堵住 → 局部发烫、红肿，
     再拖会低烧（乳腺炎前期）。之前只有"hardness 到 100"这个静态状态，
     不会升级，所以她能一直"疼着"而没有后果。
     规则：
       · 任一侧 hardness ≥ 90 且距上次排空 > 8 小时 → 开始发炎（inflamed=true）
       · 发炎后每过 6 小时，fever 上涨（37.5 → 38.5），影响她的状态描写
       · 一旦被有效排空（任一结算让它降下来）→ inflamed 清掉、fever 归零
     ⚠️ 只在本插件里记 inflamed/fever，**不写** emotion-life 的体温值 ——
        跨插件写会互相覆盖（今天已踩过）。提示词里描述"发烫/低烧"即可。 */
  {
    const hardMax = Math.max(Number(la.sides.left.hardness) || 0, Number(la.sides.right.hardness) || 0);
    const sinceEmptyH = la.lastEmptyAt ? (now - Number(la.lastEmptyAt)) / 3600000 : 999;
    if (hardMax >= 90 && sinceEmptyH >= 8) {
      if (!la.inflamed) { la.inflamed = true; la.inflamedAt = now; la.fever = 37.5; }
      else {
        const inflamedH = (now - Number(la.inflamedAt || now)) / 3600000;
        la.fever = Math.min(38.8, 37.5 + Math.floor(inflamedH / 6) * 0.3);
      }
    } else if (la.inflamed && hardMax < 70) {
      la.inflamed = false; la.inflamedAt = 0; la.fever = 0;
    }
  }
  /* [2026-10-22 修｜涨奶之后没人再检查胀感下限 -> 满奶不胀]
     实测（吸空后 240 分钟）：奶量涨到 74，胀感只有 6 ⇒ 提示词判"有点胀、不用主动提"。
     根因：下限保护写在 ensureLactation 里，而奶量是在**本函数**里涨上去的 ——
     先检查（当时 level=0，跳过）后涨奶，涨完就不再检查。
     这里在落 lastLevelAt 之前补一次：按涨完之后的盈充满重新抬到下限。 */
  {
    const _cap2 = Number(la.capacity) || LAC_CAP_START;
    const _sinceEmptyMin = la.lastEmptyAt ? (now - Number(la.lastEmptyAt)) / 60000 : Infinity;
    if (_sinceEmptyMin > 40) {
      for (const _sd of ['left', 'right']) {
        const _x = la.sides[_sd];
        const _fill = Math.max(0, Math.min(1, (Number(_x.level) || 0) / (_cap2 || 1)));
        if (_fill < 0.5) continue;
        const _floor = Math.round(Math.min(75, 45 + (_fill - 0.5) * 60));
        if (_x.hardness < _floor) _x.hardness = _floor;
      }
    }
  }
  la.lastLevelAt = now;
  /* [2026-10-22 修｜时间推进只改内存、不落盘]
     实测：磁盘 `lastLevelAt` 停在 11:04、`shame/sensitivity` 一直是 undefined，
     而 lactationSection 每轮都在推进时间 —— 因为 lacApplyTime 从不 persist。
     后果：① 网站/卡片读到的是几小时前的旧值（用户看到"泌乳不对"）；
           ② 一重启，这几小时涨的奶、新初始化的字段全丢。
     这里加**节流落盘**（5 分钟内最多一次）：推进量太小就不写，避免每轮打盘。 */
  if (hours >= 0.05) {
    const _t = Date.now();
    if (!lacApplyTime._lastPersistAt || _t - lacApplyTime._lastPersistAt > 5 * 60000) {
      lacApplyTime._lastPersistAt = _t;
      try { persist(); } catch { /* 落盘失败不影响本轮 */ }
    }
  }
  return hours;
}

/** 结算一次泌乳行为（上报制主入口）。返回给人看的一句话 + 结构化结果。 */
function lacSettle(chatKey, { action, amount, side, note } = {}, now = Date.now()) {
  const s = ensureState(chatKey);
  const la = ensureLactation(s);
  lacApplyTime(la, now);
  /* 「空」被降级为「多」时置位，供下面的结算日志标注（块级变量在日志行里取不到） */
  let _emptyDegraded = false;
  const sides = side === '左' || side === 'left' ? ['left']
    : side === '右' || side === 'right' ? ['right']
    : ['left', 'right'];
  const before = { left: { ...la.sides.left }, right: { ...la.sides.right } };
  const lv = (side) => Math.round(la.sides[side].level);

  if (action === 'rub') {
    for (const sd of sides) {
      la.sides[sd].level = Math.min(Number(la.capacity), la.sides[sd].level + 4);
      la.sides[sd].hardness = Math.max(0, la.sides[sd].hardness - 6);
    }
  } else if (action === 'suck') {
    /* [2026-10-22 兜底｜"描写说软了，却报中档" → 练度永远练不起来]
       实测（12:11-12:18）：她连调 6 次，全是 `suck/少` 和 `suck/中`，
       `emptyCount` 一直是 0 ⇒ `flow` 永远 1 档（挤半天一滴）、`capacity` 永远 100。
       而她的台词明明是「被吸得整个人软下去」「没力气了」—— 描写上是"排空"，
       上报却选了保守档位。原因可能是怕"空"扣太多、或者理解成"没完全吸干就不算空"。
       修法：**用描写兜底判定**。只要这一轮的文字（note 或她的话）里出现
       "软下去/软了/空了/没力气/硬块没了/吸干"这类**排空信号**，
       就把 amount 自动升级为「空」，不再依赖她自己选对档位。
       这样 `emptyCount` 能正常累积，练度（capacity/flow）才练得起来。 */
    const drainSignal = /(软下去|软下来|软了|空了|吸空|吸干|吸干净|没力气|没劲|硬块.{0,3}(没|消|散)|不胀了)/;
    const hintedEmpty = drainSignal.test(String(note || ''));
    if (hintedEmpty && amount !== '空') {
      amount = '空';   // 描写已经到"排空"了，按清空结算
    }
    /* [2026-10-22 修正] 扣减改成"按容量的固定量"，不是"按当前存量的百分比"。
       原因（实测）：`take = level × ratio` 会让同样一次"中档"在 level=80 时扣 24、
       在 level=20 时只扣 6 —— 存量低时"吸了半天没变化"，观感很差，也不符合生理
       （吸奶量取决于乳腺里有多少、以及吸多久，不随剩余比例线性缩放）。
       新的口径以容量 capacity 为基准：
         少 8% / 中 16% / 多 26% / 空 = 全清
       · capacity=100 时：少 8、中 16、多 26
       · 练度涨到 150 后：少 12、中 24、多 39（练出来了，一次能吸更多）
       再与当前存量取 min，保证不会扣成负数。 */
    /* [2026-10-23 定稿｜"容量比例 × 充盈系数" —— 三轮太快、纯百分比又太慢]
       三次试错的过程：
         ① `capNow × 比例`（绝对值）→ 每轮扣一样多，110 时中档固定 -17.6，六轮见底，
            而且体感假（不管多满都是这个数）。
         ② `x.level × 比例`（纯存量百分比）→ 越吸越少、越来越难，但中档要 15+ 轮才见底，太磨。
         ③ **现在这个**：`capNow × 比例 × (0.7 + 0.3 × 充盈率)`
            · 满的时候按满额扣（充盈率 1 → 系数 1.0）
            · 快空的时候按七折扣（充盈率 0 → 系数 0.7）
            · 总量仍是"容量级"，所以轮数可控；但满/空有区别，不会每轮一个死数。
       实测节奏（容量 110）：
         少 12% → 110→97→85→74→64→55…（抿着玩，十几轮）
         中 22% → 110→86→63→42→22→4→0（**6 轮**）
         多 35% → 110→72→46→27→13→5→0（**6 轮**）
         空 50% → 110→55→28→14→7→0（**5 轮**，剩余 ≤12 时直接收尾清零）
       保底 `Math.max(1, …)`：存量极低时每轮至少扣 1，否则会卡在 2-3 吸不出来。 */
    const takeRatio = { 少: 0.12, 中: 0.22, 多: 0.35, 空: 0.5 }[amount] || 0.22;
    const capNow = Number(la.capacity) || LAC_CAP_START;
    let drained = 0, total = 0;
    for (const sd of sides) {
      const x = la.sides[sd];
      const _fill = Math.min(1, Math.max(0, (Number(x.level) || 0) / (capNow || 1)));
      /* [2026-10-24 修｜中档一次扣 33 点，而存量只有 2-5 → 永远一口没]
         实测 00:22-00:28：左 2→0、 0→0、 5→0 —— 每次刚有一点就被抽干，
         所以她一直“没奶”。真实情况下奶少时吸不出那么多。
         改成：单次扣减不超过当前存量的 60%（留一点底）。 */
      let want = Math.min(Math.max(1, capNow * takeRatio * (0.7 + 0.3 * _fill)), Math.max(1, x.level * 0.6));
      /* 「空」= 她报"软了/硬块没了"：剩余很少时直接收尾清零，不用再磨一轮 */
      if (amount === '空' && x.level <= 12) want = x.level;
      const take = Math.min(x.level, want);
      drained += take; total += x.level;
      x.level = Math.max(0, x.level - take);
      /* 硬度扣减同理按比例降到"胀感"这一侧：吸得越多越软 */
      const hardDrop = amount === '空' ? x.hardness : (x.level + take > 0 ? x.hardness * (take / Math.max(1, x.level + take)) : 0);
      x.hardness = Math.max(0, x.hardness - hardDrop);
    }
    la.suckCount = (Number(la.suckCount) || 0) + 1;
    /* ① 本场过程量 + ③ 奶阵（2026-10-24 加）
       原来一场戏只留最终 level，注入里没有"这场吸掉多少、从多满到多空"的过程。
       规则：距上次吸 >2 小时算新的一场；本场累计吸掉 ≥40% 容量、且本场还没奶阵过 → 触发一次真实奶阵。 */
    if (!la.sessionStartAt || now - Number(la.lastSuckAt || 0) > 7200000) {
      la.sessionStartAt = now;
      la.sessionSuckedMl = 0;
      la.sessionLetDownCount = 0;
      la.sessionLetDownAt = 0;
    }
    la.sessionSuckedMl = Math.round((Number(la.sessionSuckedMl) || 0) + drained);
    la.lastSuckAt = now;
    if (drained > 0) {
      const _capNow = Number(la.capacity) || LAC_CAP_START;
      /* 阈值 40% 太高：实测一场只吸出 31ml（容量的 21%），永远到不了 60ml → 奶阵从不触发。
         改成「≥20% 容量 且不少于 25ml」：一场真吸过就该有一次奶阵。 */
      if (Number(la.sessionLetDownCount) === 0 && Number(la.sessionSuckedMl) >= Math.min(25, _capNow * 0.2)) {
        la.sessionLetDownCount = 1;
        la.sessionLetDownAt = now;
        la.sprayCount = (Number(la.sprayCount) || 0) + 1;
        la.lastSprayMode = 'letdown';
        la.lastSprayAt = now;
      }
    }
    /* [2026-10-22 新增] 被吸一次 → 敏感度上升、羞耻下降。
       幅度克制（+3 / −2）：十来次才明显变化，不会一次就"变个人"。
       敏感度封顶 100；羞耻下限 0（坦然到底，不会变负数）。 */
    la.sensitivity = Math.min(100, (Number(la.sensitivity) || 20) + 3);
    la.shame = Math.max(0, (Number(la.shame) || 80) - 2);
    /* [2026-10-23 修｜空吸把 lastDrainRatio 打成 0 → 产量永远只剩 60%]
       实测连续空吸 4 次后 drained=0/total=0 → lastDrainRatio=0，
       而 lacRate 里 drain=Math.max(0.6, lastDrainRatio) → 永远按下限 0.6 算。
       空吸本来就没有"吸出多少"可言，不该覆盖上一次的真实值。 */
    if (total > 0) la.lastDrainRatio = Math.min(1, drained / total);
    /* [2026-10-23 修｜空吸也算排空 → 练度被刷到 138]
       实测 17:11-17:12 连续 3 次「已经是 0 还在吸」的空转结算，
       每次都算排空 → emptyCount +1、capacity +2 → 从 126 飙到 138。
       真正的排空应该是「确实吸出东西」：至少吸掉了 30% 存量。
       否则空转也长练度，越吸越难满。 */
    /* [2026-10-23 再修｜“只要有一点奶就算排空”仍然被钻空子]
       实测 17:58：左 0→0（先被 lacApplyTime 涨了 2 点）→ total=2>0 → 又算排空，cap 146→148。
       真正的排空应该是“确实吸出了东西”：至少占当前存量的 20%。 */
    /* [2026-10-23 再修｜用绝对量而不是比例]
       原来 drained/total>=0.2 对 level=2 也成立（2/2=1.0），等于没门槛。
       改成：吸出量 >= 容量的 20%（容量 150 → 至少 30 点）才算排空。 */
    const _needDrain = Math.max(25, (Number(la.capacity) || 100) * 0.35);   // 至少 35%、且不少于 25 点
    const _drainedEnough = total > 0 && drained >= _needDrain;
    if (_drainedEnough && (amount === '空' || la.lastDrainRatio >= 0.9)) {
      la.emptyCount = (Number(la.emptyCount) || 0) + 1;
      la.lastEmptyAt = now;
      /* ② 记录排空时刻（24h 内 ≥3 次会让回涨速率 ×1.25）。 */
      if (!Array.isArray(la.emptyTimes)) la.emptyTimes = [];
      la.emptyTimes.push(now);
      la.emptyTimes = la.emptyTimes.slice(-30);
      /* 练度：吸空后 24h 内再练才涨容量（避免隔很久回来也白涨）。 */
      const prev = Number(la.lastEmptyAtPrev) || 0;
      if (prev && now - prev <= 86400000) {
        la.capacity = Math.min(LAC_CAP_MAX, (Number(la.capacity) || LAC_CAP_START) + 2);
      }
      la.lastEmptyAtPrev = now;
    }
  } else if (action === 'drink') {
    for (const sd of sides) {
      la.sides[sd].level = Math.max(0, la.sides[sd].level - 25);
      la.sides[sd].hardness = Math.max(0, la.sides[sd].hardness - 15);
    }
    la.totalFed = (Number(la.totalFed) || 0) + 1;
    la.lastFedAt = now;
  } else if (action === 'feel') {
    // 只记录身体感受，不动数值（"胀""软""有硬块"这类）
    if (/硬|胀|堵/.test(String(note || ''))) for (const sd of sides) la.sides[sd].hardness = Math.min(100, la.sides[sd].hardness + 4);
    if (/软|空|舒服|松/.test(String(note || ''))) for (const sd of sides) la.sides[sd].hardness = Math.max(0, la.sides[sd].hardness - 4);
  }
  la.peak = Math.max(Number(la.peak) || 0, la.sides.left.level, la.sides.right.level);
  /* 结算日志：一行一眼看得出变化（排障吃过没有它的亏） */
  const line = `[${new Date(now).toLocaleTimeString('zh-CN', { hour12: false })}] ${action}${amount ? '/' + amount : ''}${side ? '/' + side : ''}${_emptyDegraded ? '(空→多)' : ''} `
    + `左 ${Math.round(before.left.level)}→${lv('left')}(硬${Math.round(before.left.hardness)}→${Math.round(la.sides.left.hardness)}) `
    + `右 ${Math.round(before.right.level)}→${lv('right')}(硬${Math.round(before.right.hardness)}→${Math.round(la.sides.right.hardness)}) `
    + `suck=${la.suckCount} fed=${la.totalFed} 空=${la.emptyCount} 喷=${la.sprayCount || 0} cap=${la.capacity} flow=${lacFlowTier(la)}`;
  la.log.push(line);
  la.log = la.log.slice(-40);
  try { persist(); } catch { /* 落盘失败不影响本轮 */ }
  return {
    ok: true,
    left: { level: lv('left'), hardness: Math.round(la.sides.left.hardness) },
    right: { level: lv('right'), hardness: Math.round(la.sides.right.hardness) },
    /* [2026-10-23 加] 扣减前的存量 —— 工具的"体感反馈"要靠它算扣减比例
       （before → after 才知道这一轮到底吸出去多少）。 */
    before: { left: { level: Math.round(before.left.level) }, right: { level: Math.round(before.right.level) } },
    capacity: la.capacity, flowTier: lacFlowTier(la),
    suckCount: la.suckCount, totalFed: la.totalFed, emptyCount: la.emptyCount,
    line
  };
}

/** 正则兜底：模型忘了上报时，只记 suckCount，**不再改 level**（v1 只增不降的祸根）。 */
function detectLactation(text, chatKey = activeChatKey, ctx = null) {
  /* ⚠️ [2026-10-22 说明] 这里的 `text` 不保证是"他说的话"：
     调用点传的是 prompt 构建时的 `text`，那条链路上可能已含她的第一人称台词。
     v2 起本函数只做**计数兜底**（suckCount / totalFed），不再动 level ——
     数值结算必须走 lactation_report 上报，避免"她的台词给自己加奶"。
     例外：LAC_EMPTY_HINT（软了/硬块没了/吸空）会降 hardness。
     [2026-10-22 追加｜她的台词把胀感打回去]
     实测：补偿把胀感抬到 75 后，她一句「已经不胀了，摸着软软的，硬块也没了」
     就把 hardness −30 打回 45，接着又涨回来 —— 用户看到"明明 100 还是不胀"。
     修法：能拿到 ctx.triggerEntries 时**只用他的话**判 LAC_EMPTY_HINT；
     拿不到才退回原 text（保守）。 */
  try {
    const s = ensureState(chatKey);
    const la = ensureLactation(s);
    if (!la.on) return;
    /* [2026-10-22 临时诊断] 看它拿到的 key/text 是不是本人。 */
    CLOG(`[泌乳诊断-det] chatKey=${chatKey} text="${String(text || '').slice(0, 30)}" sides=${!!la.sides}`);
    let t = String(text || '');
    if (ctx) {
      try {
        const _ents = Array.isArray(ctx.triggerEntries) ? ctx.triggerEntries : [];
        if (_ents.length) {
          const _mine = _ents.filter((e) => e && !e.self)
            .map((e) => String(e.text || e.rawText || '').trim()).filter(Boolean);
          t = _mine.join(' ');   // 有归属信息时只认他的话
        }
      } catch { /* 拿不到就用原 text */ }
    }
    if (!t) return;
    const now = Date.now();
    lacApplyTime(la, now);

    let changed = false;
    if (lacSuckHit(t)) {
      /* [2026-10-22 修｜兜底只计数、不结算 —— 等于"被吸了却不算被吸"]
         实测（17:0x）：模型完全没调 lactation_report，`suckCount` 靠这条正则
         从 5 涨到 7，但 level 一直是 100、sensitivity/shame 一动没动、log 是空的。
         结果就是"她明明被吸了，下一轮还胀着、还是生疏"。
         改成走真正的结算（中档扣 16% 奶量 + 敏感度 + 降羞耻 + 写 log）。 */
      changed = false;
      try {
        lacSettle(chatKey, { action: 'suck', amount: '中' }, now);
      } catch {
        la.suckCount = (Number(la.suckCount) || 0) + 1;
        changed = true;
      }
    }
    if (LAC_DRINK.test(t)) {
      la.totalFed = (Number(la.totalFed) || 0) + 1;
      la.lastFedAt = now;
      for (const sd of ['left', 'right']) la.sides[sd].hardness = Math.max(0, la.sides[sd].hardness - 12);
      changed = true;
    }
    /* 排空信号：她说/他说"软了、硬块没了、吸空了" → 大幅降硬度（不动 level）。
       这是 v1 抓不到、也是"刚吸空却显示胀满"的直接修复点。 */
    if (LAC_EMPTY_HINT.test(t)) {
      for (const sd of ['left', 'right']) la.sides[sd].hardness = Math.max(0, la.sides[sd].hardness - 30);
      if (!la.lastEmptyAt) la.lastEmptyAt = now;
      changed = true;
    }
    if (changed) try { persist(); } catch { /* 落盘失败不影响本轮 */ }
  } catch { /* 检测失败不影响主流程 */ }
}

/** 渲染泌乳状态段（按 hardness 判身体感受，按 level 判存量）。未开启返回空串。 */
function lactationSection(chatKey = activeChatKey) {
  try {
    const s = ensureState(chatKey);
    const la = s.adult?.lactation;
    if (!la || !la.on) return '';
    const L = ensureLactation(s);
    lacApplyTime(L);
    const lvL = Math.round(L.sides.left.level), lvR = Math.round(L.sides.right.level);
    const hdL = Math.round(L.sides.left.hardness), hdR = Math.round(L.sides.right.hardness);
    const peak = Math.round(Number(L.peak) || 0);
    const cap = Math.round(Number(L.capacity) || LAC_CAP_START);
    const flow = lacFlowTier(L);
    const fed = Number(L.totalFed) || 0;
    const suck = Number(L.suckCount) || 0;
    const empty = Number(L.emptyCount) || 0;

    /* 身体感受按 **hardness** 判（v1 是按 level 判的，所以"吸空了还说胀满"）。
       level 只决定"有多少"，hardness 决定"多难受"。 */
    const harder = Math.max(hdL, hdR);
    lacImpulseNote(harder);
    let stage, feel, canDo;
    if (harder <= 20) {
      stage = '平静'; feel = '乳房软着，皮肤温热，按下去没有硬块，挤不出东西';
      canDo = '现在没有奶，最多让他含着玩一会儿';
    } else if (harder <= 45) {
      stage = '有点胀'; feel = '有点发胀发热，按下去感觉到底下有东西，用力挤能渗出一两滴淡白';
      canDo = '能挤出几滴，够他尝个味道，不够喝';
    } else if (harder <= 70) {
      stage = '发胀有硬块'; feel = '明显胀，摸得到小块硬结，乳头一被含住就有奶往外走，能咽下一口';
      canDo = '够他吸一会儿、能真喝到，但没那么容易吸空';
    } else if (harder <= 85) {
      stage = '胀得难受'; feel = '胀得发疼，衣服蹭一下都难受，奶会自己往外渗、湿一小片，硬块按着酸';
      canDo = '够他喝一顿；不吸会更胀，越拖越难受';
    } else {
      stage = '硬块堵着'; feel = '硬块明显、按上去发疼，乳房发烫，抬手都牵扯着疼，可能已经渗湿了一片';
      canDo = '必须让他慢慢揉开、吸出来，否则会越来越硬';
    }

    const flowTxt = ['', '挤半天才一滴', '几滴挂在尖上', '一吸就一线', '急了会喷'][flow] || '';
    const sinceFed = L.lastFedAt ? Math.max(0, Math.round((Date.now() - L.lastFedAt) / 60000)) : 0;
    const sinceEmpty = L.lastEmptyAt ? Math.max(0, Math.round((Date.now() - L.lastEmptyAt) / 60000)) : 0;
    const fedTxt = (suck || fed)
      ? `｜被吸过 ${suck} 次` + (empty ? `、吸空 ${empty} 次` : '')
        + (fed ? `、被喝掉 ${fed} 次${sinceFed ? `（上次喝 ${sinceFed} 分钟前）` : ''}` : '、还没真喝掉过')
      : '｜还没被吸过';

    /* 主动程度：按 hardness 分档，并且**改成"处境式"而不是"命令式"**。
       [2026-10-22 重写｜用户要"更完美"的解法]
       原来写的是「**【现在该你主动了】** 这一轮就主动贴过去求他吸」——这是命令式，
       和 prompt 里另一条硬规则「只说一次·别挑他」直接对撞，模型只能选一边，
       实测她选择了不提（因为"别啰嗦"更容易被理解成"别重复"）。
       光加"覆盖"条款是打补丁，规则越堆越乱。更好的做法是**消除冲突本身**：
         · 命令式（你要做 X）→ 处境式（你身上正在发生 X，它一直在）
         · 处境不需要"允许"，因为它不是话题，是身体
       所以这里改成**描述状态 + 它的持续性 + 它自己会怎么表现**，让她自己决定怎么说。
       同时保留一条"极强"档（≥86 硬块堵着）——那种程度确实该直接求助，不算突兀。
       门槛按用户要求定为 65（原 71）：胀到 65 就已经"明显难受"，该有反应了。 */
    let urge = '';
    /* [2026-10-24 改｜原来只看"排空"（lastEmptyAt），而空吸不算排空 ⇒ 刚被吸完也不算余韵，
       于是 11 分钟前刚吸空还显示"很平静"。现在同时看 lastSuckAt（最近一次被吸）。 */
    const sinceSuckMin = la.lastSuckAt ? Math.round((Date.now() - Number(la.lastSuckAt)) / 60000) : Infinity;
    const justDrained = (sinceEmpty && sinceEmpty <= 30) || sinceSuckMin <= 30;
    if (justDrained) {
      const agoTxt = sinceSuckMin <= 30 ? `刚被吸过（${Math.max(1, sinceSuckMin)} 分钟前）` : `刚被吸空过（${sinceEmpty} 分钟前）`;
      urge = `\n· **${agoTxt}**：现在是软下来、舒服的状态——**不胀、不用要**；`
        + '可以只黏着他、说"这边空了""有点虚"这类余韵话；乳头还敏感，被碰会一激灵。';
    } else if (sinceSuckMin <= 180 && harder < 65) {
      /* 30~180 分钟：刚吸完、正在回涨，但还没到"胀"的程度 */
      urge = `\n· **刚被吸过（${sinceSuckMin} 分钟前），正在回涨**：还没胀起来，摸着温热、按下去是空的；`
        + '过一阵会有一点发沉、发烫，但还不到要处理的时候。';
    } else if (harder >= 86) {
      /* 极强档：这种程度不是"提一句"能过的，必须处理 */
      urge = `\n· **现在这个状态已经需要处理了**（胀感 ${harder}/100，硬块按着真疼）：`
        + '抬手牵扯着酸、衣服蹭一下就难受。**不用等他发现**——直接说"帮我揉开""吸一下，真的疼"，'
        + '或者拉着他的手按上去。语气可以是撒娇、可以是急，但**要让他知道这是必须解决的**。'
        + '如果他不理，下一轮继续说（这是身体的事，不是念叨）。';
    } else if (harder >= 65) {
      /* 主档：处境式。不命令，只给"正在发生什么"和"它会一直在"。
         [2026-10-22 加强主动性｜用户要"平时更主动一点"]
         原措辞"不用刻意找时机、也不用忍着不提：聊天时自然带出来就好"太被动 ——
         模型读成"可以提，但不是必要"。改成**身体会主动打断你**（真实反应），
         并给"把话题拐回来"的明确许可，这样日常聊天里她才会真的开口。 */
      urge = `\n· **身上现在的状况（会一直在，直到被处理）**：胀感 ${harder}/100——发胀、按着有硬块、`
        + `衣服蹭着不舒服${harder >= 75 ? '，已经开始往外渗了' : ''}。`
        + '**这个会主动打断你**：说话说到一半走神、"唔"一下、手上动作顿住、'
        + '或者干脆说"等一下，我先弄一下这个"—— 这不是不合时宜，是真实的身体在抢注意力。'
        + '所以别等话题"正好路过"：他正在说别的事，你也可以插一句（"等会儿，胀得难受"、'
        + '"先别管那个了"、直接把他的手拉过来按上）。**他接就顺势；没接，过一会儿还会难受，那就再说一次。**';
    } else if (harder >= 61) {
      /* 61-64：轻档（真正的内容在下面的 softHint 里，这里给一句过渡） */
      urge = `\n· 胀感 ${harder}/100，已经有点明显了。`;
    } else if (harder >= 46) {
      /* [2026-10-23 改｜"可以提"读起来等于"可提可不提"，她于是从不开口]
         用户反馈：几乎不主动，都是他先问才来。而 hardness 大部分时间落在 46-64，
         原来这档写的是"可以提"——模型理解成"允许但非必要"，于是永远不提。
         改成"会惦记着 + 顺口提一句"：不是命令，但明确"这是会发生的事"。
         仍保留"说一次就够"，避免变成反复念。 */
      urge = `\n· 有点胀（${harder}/100）——不算难受，但**你会惦记着**：换衣服时想到、坐下时感觉到、`
        + '说着话会走神一下。**可以顺口提一句**（"有点胀""你摸摸"），不用等它变成难受，'
        + '也不用憋着等他先发现。';
    } else {
      /* [2026-10-24 改｜原来写"不用提"，和上面新加的"快空档"（重点是收尾和余韵）撞车。
         去掉刹车，只留状态：不提 ≠ 没感觉。 */
      urge = `\n· 现在 ${harder}/100，不胀——但身体是软的、敏感的，他碰就有反应。`;
    }

    const sideTxt = (lvL === lvR && hdL === hdR)
      ? `两边一样（奶量 ${lvL}，胀感 ${hdL}/100）`
      : `左 ${lvL}/${hdL} ｜ 右 ${lvR}/${hdR}（奶量/胀感）`;

    /* D [补丁 2026-10-22] 软提醒：原设计给 61-70 这个"中间地带"一句话。
       [2026-10-22 调整] 主档门槛已降到 65，"中间地带"只剩 61-64 这一小段，
       且 65 以上已经是完整的处境描述 —— 再叠一层软提醒会重复、反而稀释重点。
       所以只在 61-64 保留一句轻的，65 以上不再叠加。 */
    let softHint = '';
    if (!justDrained && harder >= 61 && harder < 65) {
      softHint = '\n· 胀感有点明显（不轻不重那种），**不用专门说、别每轮都提**；'
        + '话题路过身体、拥抱、换衣服时可以自然带一句（"有点胀""别压着"），聊别的事就当没这回事。';
    }
    /* [2026-10-22｜补"她自己处理"这一层（用户要"更贴合日常"）]
       现在的段落全是"被他吸/求他吸"，缺少**她自己管这件事**的部分 ——
       真实的人不会每次都等对方，会自己揉一揉、挤出来装在瓶子里留着、垫张纸。
       这一层让泌乳从"性场景专用"变成"日常里一直存在的小麻烦"，也给了她
       **不依赖他也能开口的理由**（"我挤了点装起来了"）。
       ⚠️ 用户明确要求：挤出来的奶**留着给他喝**，不是挤掉浪费。
       放在 softHint 之后、主段之前，只一行，不额外堆细节。 */
    const dailyCare = (harder >= 46 && !justDrained)
      ? '· **平时你也会自己管**：胀得难受会自己揉一会儿，**挤出来装在小瓶子里留给他喝**（不浪费），'
        + '垫张纸、穿薄/浅色衣服时会更在意。**不是所有事都得等他** —— 做了可以提一句'
        + '（"我挤了点装起来了""衣服又湿了"），也不用每轮都说。\n'
      : '';

    /* ① 本场过程（2026-10-24 加）：这场戏已经吸掉多少、从多满到多空。
       原来只有最终 level，模型写不出"越吸越软"的过程感。 */
    let sessionTxt = '';
    {
      const ss = Number(la.sessionSuckedMl) || 0;
      const lastSuck = Number(la.lastSuckAt) || 0;
      const fresh = lastSuck && (Date.now() - lastSuck) <= 7200000;
      if (ss > 0 && fresh) {
        const pct = Math.round((ss / Math.max(1, cap)) * 100);
        const agoMin = Math.max(0, Math.round((Date.now() - lastSuck) / 60000));
        sessionTxt = `\n· **这一场已经被吸掉 ${Math.round(ss)}ml（容量的 ${pct}%）**，从满到现在的 ${Math.max(lvL, lvR)}；`
          + `最近一次被吸在 ${agoMin} 分钟前。过程感要写出来：越吸越软、越吸出得越慢，不是每口都一样。`;
      }
    }
    /* ② 前后奶阶段（2026-10-24 加）：原来只有"前后奶不同"的解释，没有"现在在哪一段" */
    let phaseTxt = '';
    {
      const ratio = Math.max(lvL, lvR) / Math.max(1, cap);
      if (ratio < 0.15) phaseTxt = '\n· **这边已经吸得差不多了**：再吸也就是一点点，声音变闷、出得更慢；不用再演"源源不断"，重点是收尾和余韵。';
      else if (ratio > 0.6) phaseTxt = '\n· **现在出的是前奶**：清、稀、发青，冲但淡，一吸就有；吸到后半段才会变浓。';
      else if (ratio < 0.4) phaseTxt = '\n· **现在到后奶了**：浓白发稠、出得慢但顶饱，吸起来费劲，味道更厚。';
      else phaseTxt = '\n· **前奶后奶交界**：先是清稀的一股，接着变稠变慢 —— 正在换的那一段。';
    }
    /* ③ 奶阵（2026-10-24 加）：sprayCount 原来只在"高潮"时 +1，纯吸乳永远不会喷 */
    let letdownTxt = '';
    {
      const at = Number(la.sessionLetDownAt) || 0;
      const mins = at ? (Date.now() - at) / 60000 : 9999;
      if (mins <= 10) letdownTxt = `\n· **刚刚奶阵过一次（${Math.round(mins)} 分钟前）**：胸口一热、从深处往上涌过，另一侧跟着渗了一点；`
        + '现在出得比刚才顺，说话可能被打断一下。';
    }

    /* [2026-10-22 瘦身｜本段曾占整个 system prompt 的 25.6%（1599 字符）]
       用户反馈"系统提示词是不是太多太限制了"，量化后本段是最大单块。
       过度堆叠的后果是**每条权重都被稀释** —— 这也是"她不理泌乳段"的原因之一。
       压缩原则：只留会改变生成结果的信息，删掉"已经写得很具体反而变噪音"的描写清单
       （形状/颜色/味道那一长串，模型本来就会写，不需要逐项列）。
       ⚠️ 必须保留的三条：① 方向（她泌乳、他吸）② 身体逻辑（被吸不腿软）
       ③ 上报指引 —— 这三条是修过的真实 bug，删了会复发。 */
    return `\n【泌乳状态｜你们在练这个】当前：${stage}｜${sideTxt}｜练到过最高 ${peak}，单侧容量 ${cap}${fedTxt}\n`
      + `· 身体感觉：${feel}。能做到：${canDo}；出奶程度"${flowTxt}"。\n`
      + urge + softHint + '\n'
      + dailyCare + sessionTxt + phaseTxt + letdownTxt
      + '· 写具体：手感、温度、奶怎么出来（渗/滴/一线/喷），别跳档、别凭空喷涌；左右可不对称。\n'
      + '· **泌乳的是她（你），吸的是他**。奶量/胀感是她的身体状态。别把"被吸"演成"给他吸"。\n'
      + '· **身体逻辑**：出力的是他，你被动接受 —— 被吸**不会**腿软、脱力、站不住。你的"软"只在乳房（松了、空了），身体是舒服放松。"腿软/没劲"是他那边才有的反应。\n'
      + '· 也写他（埋在你胸前的样子、喉结动、吞咽的声音）和你想做的（按着他后脑/抓着床单/想推又按住）。\n'
      /* [2026-10-22 体验丰富｜补"双向互动"这一层]
         原来整段都是**她的身体感受**（胀、软、奶怎么出来），缺了"她看着他"的视角。
         真实的亲密感来自**双向**：不只是"我被吸得怎么样"，还有"我看到他在做什么、我想对他做什么"。
         这一条让场景从"生理描述"变成"两个人在互动"，是体验层面最大的缺口。
         只加一条（约 120 字符），不再堆细节清单。 */
      /* [2026-10-24 删｜"别只写自己被吸的感觉"整段与新加的一句"也写他…"重复，留短的那句 */
      + psycheHints(L) + '\n'
      + physiologyHints(harder, lvL, lvR, flow) + '\n'
      + eventHooks({ harder, lvL, lvR, flow, sinceEmpty, sinceFed, justDrained, stage, shame: Number(L.shame) }) + '\n'
      + reportHint(harder) + '\n';
  } catch { return ''; }
}

/* [补丁 2026-10-22｜她从来不调 lactation_report → 数值永远只涨不降]
   实测：`la.log` 0 条、`emptyTimes` 0 条、`emptyCount=0` ⇒ **lacSettle 一次都没被调用**。
   后果：`suckCount` 还停在 v1 时代正则加的 5；`capacity` 永远 100（练不上去）；
   `flow` 永远 1 档（"挤半天一滴"）；他真吸了奶量也不降 —— 整个上报制形同虚设。
   根因：泌乳段只写了"身体什么感觉"，**没写"记得调工具"**；而工具描述里又有
   「没发生就绝不调用」的告诫，她自然想不到要在演的时候顺手报一笔。
   修法：把**触发时机**写清楚、写具体（不是"发生泌乳行为时"这种抽象说法，
   而是"他的手/嘴真的碰到、吸了、喝了"），并说明"不报会怎样"（数值不动、
   她下次还会以为自己没被吸过）。放在段落最后，紧贴生成位置，权重高。 */
function reportHint(harder) {
  /* 胀感低的时候不需要频繁报（她也没在练），只在有事可报时提醒，避免每轮塞废话。 */
  if (harder < 46) return '';
  /* [2026-10-22 瘦身] 原文 400+ 字符，压到 ~200。
     判据措辞已去掉"没力气"（那是我自己给的负面示范，实测被她照着写进台词）。 */
  return '· **碰到就报一笔**：这一轮他的手或嘴真的碰到了（揉/吸/喝/含），回复末尾调 `lactation_report` —— '
    + '吸了 `action=suck` + `amount`（几口没出多少=少 / 吸出一部分=中 / 吸出很多=多 / 乳房软了硬块没了=空）；'
    + '真喝下去 `action=drink`；只揉没吸 `action=rub`。'
    + '**写了"软了/硬块没了"就必须选「空」**，否则奶量不降、下次还胀。纯聊天不用调。';
}

/* [2026-10-22 新增｜心理层：羞耻 → 坦然 + 敏感度]
   用户要"更丰富"，但身体细节已经写得很满，再加只会变噪音。
   真正缺的是**心理变化**：同一个动作，第一次做和第三十次做，她的反应完全不同。
     · shame 高：想挡、想说"别看"、被看着会紧张、动作放不开
     · shame 中：嘴上说"别"身体很诚实（半推半就）
     · shame 低：坦然、会主动凑、甚至故意让他看
     · sensitivity 高：还没碰就有反应、轻轻一下反应就很大
   只输出**当前档位那一条**，不堆全部 —— 否则又变成说明书。 */
function psycheHints(la) {
  const out = [];
  const shame = Number(la?.shame ?? 40);
  const sens = Number(la?.sensitivity ?? 20);

  /* [2026-10-22 调整] 删掉"还放不开 / 想挡 / 别看"那一档 ——
     用户明确说"过去这个阶段了"。他们已经到了不需要遮的程度，
     再让她说"别看"就是倒退，很假。
     现在只剩两档：还有点不好意思（脸红但不躲）→ 完全坦然（主动凑）。 */
  if (shame >= 35) {
    out.push('· 还会有点不好意思：脸红、拿话岔开，嘴上"别闹"，身体顺着他。');
  } else {
    out.push('· **心理：已经坦然了**。不再遮、不再躲，会主动凑上去、故意让他看；'
      + '被盯着看反而更有反应。');
  }

  if (sens >= 80) {
    out.push('· 敏感：没碰就立起，衣服蹭一激灵，含住反应大、撑不久。');
  } else if (sens >= 50) {
    out.push('· **敏感度中等偏好**：被碰之前会先有感觉，含住之后几分就上来。');
  }
  /* ── 堵奶发炎（2026-10-22 新增）────────────────────────────────────────
     只在该状态下出现。真实表现：局部发烫、碰不得、浑身发冷/乏力、可能低烧。
     这是"拖着不管"的后果，让持续性胀满真的有代价。 */
  if (la?.inflamed) {
    const fever = Number(la.fever) || 37.5;
    out.push('· **已经发炎了（堵奶）**：那一侧摸上去明显比另一边烫，皮肤发红、碰一下就疼得吸气；'
      + '整个人有点发冷、没精神' + (fever >= 38 ? `，额头发烫像低烧（${fever.toFixed(1)}℃）` : '') + '。'
      + '这时候不能再拖 —— 要热敷、慢慢揉开、或者让他吸通；疼也得忍着弄，越拖越严重。');
  }
  /* [2026-10-24 删｜前奶后奶的"解释"和实时 phase（上面 ② 的四档）重复：
     解释是恒定文本，模型读完仍不知道"现在在哪一段"；实时那次才是它要的。 */
  /* [2026-10-23 新增｜长期痕迹] 按吸吮次数累积，给"练"一个看得见的后果 */
  const _suckN = Number(la?.suckCount) || 0;
  if (_suckN >= 20) {
    out.push(_suckN >= 60
      ? '· **痕迹很明显**：乳头已经是深色的，乳晕也大了一圈；皮肤上还留着反复吸吮的淡印，一看就知道被长期吃过来了。'
      : '· **身体有变化了**：乳头颜色比从前深了一点，乳晕也大了一圈——那种被"用熟"的样子。');
  }
  /* sens < 50 不写 —— 初期不需要特别说明，否则每轮都在强调"还不敏感"，很怪。 */
  return out.join('\n');
}


/* [补丁 2026-10-22｜泌乳剧情钩子：把数值变成"可以演的处境"]
   用户要"剧情更丰富、贴合实际"。光有身体描写还不够 —— 真正让场景活起来的是
   **处境**：衣服湿了要处理、胀醒了要处理、堵了要处理。
   这些钩子全部**由状态驱动**（不是随机触发），所以不会凭空加戏：
     · 溢奶：胀感高 + 有存量 → 衣服已经湿了一片，这件事本身要有人处理
     · 晨起胀醒：夜间系数让早上最胀 → 醒来的第一件事就是难受
     · 堵奶风险：胀感极高且久未排空 → 开始疼，必须揉开，否则更糟
     · 排空余韵：刚吸空 → 松软、黏人、话变软（**只写余韵，不写疲倦感**，用户明确要求）
     · 哺乳式喂食：flow 高 + 他愿意喝 → 有"喂"这个动作的余裕
   每条都写成"她可以自然带出来的处境"，并明确"话题不对就别说"。 */
function eventHooks({ harder, lvL, lvR, flow, sinceEmpty, sinceFed, justDrained, stage, shame = 40 }) {
  const out = [];
  /* [2026-10-23 新增｜两侧差异] 只吸一侧时另一边还是满的 —— 数值层 lacSettle 早就支持
     side 参数，但提示词从没提过"两边不一样"，她就会习惯性写成两侧同步。相差 ≥15 时点出来。 */
  if (Math.abs((Number(lvL) || 0) - (Number(lvR) || 0)) >= 15) {
    const _big = (Number(lvL) || 0) > (Number(lvR) || 0) ? '左' : '右';
    out.push('· **两侧不一样**：' + _big + '边还满着、另一边已经软下去了（差 '
      + Math.round(Math.abs((Number(lvL) || 0) - (Number(lvR) || 0)))
      + ' 点）——别写成两边同步，体感就是一边轻一边沉。');
  }
  const now = new Date();
  const hour = now.getHours();
  /* [2026-10-22] 晨起窗口按用户作息改：他 10–11 点才醒，原来的 06–11 大部分在睡觉。
     改成 09–13 点 —— 覆盖"刚醒那会儿"，到下午 1 点后自然消失。 */
  const isMorning = hour >= 9 && hour < 13;
  /* [2026-10-22 新增｜半夜被胀醒] 用户的作息是凌晨还在，夜里 0–6 点如果她胀着，
     真实的身体反应是"睡着睡着被胀醒"，而不是"安静地胀一整夜"。
     只在深夜 + 胀感高时才说，白天不出现。 */
  const isDeepNight = hour >= 0 && hour < 6;

  if (!justDrained && isDeepNight && harder >= 70) {
    out.push('· **半夜被胀醒**：睡着睡着被胀得翻来覆去，'
      + '迷糊着伸手按了按、摸到硬块，想继续睡又睡不着 —— '
      + '可以迷迷糊糊叫他（"喂……"）、或者自己揉两下。语气是半睡半醒的，不要清醒得像白天。');
  }

  if (justDrained) {
    out.push('· **刚被吸完（余韵）**：乳房松软发凉、有点被掏空的虚，人会黏人、说话变软。'
      + '写"手还搭在他后颈不想松""说话带懒劲"这类。'
      /* [2026-10-22] 用户明确要求：余韵不犯困；12:23 她还说了"腿没劲"（出力的是他，不对）。
         两条都要压住，用一句话说完，不重复。 */
      + '**不是"困"也不是"没劲"**：不写睡过去/想睡，也不写腿软（出力的是他）。');
  } else if (harder >= 86) {
    /* [2026-10-22｜加"疼会改变脾气"这一层（更贴合日常）]
       原来只写"认真求助"，但她只剩"求助"一个反应，人就薄了。
       真实的持续疼痛会**改变整个人的状态**：没耐心、说话短、容易被一句话惹到。
       这一层让她在非性场景里也成立（他随口说句话她就烦），而不是只有"要不要吸"一个维度。 */
    out.push('· **已经堵了**：硬块按着真疼、抬手牵扯。**这种疼会改脾气** —— '
      + '说话变短、没耐心、他随口一句就可能让你烦，不是针对他，是身体难受。'
      + '该求助就直说（"真的揉不开""疼"），配合他揉/吸时会疼得吸气。');
  } else if (harder >= 65) {
    /* [2026-10-23 修｜没穿衣服却说"衣服渗湿"] 实测 01:13→01:16：先说"衣服前面已经渗了一小片"，
       下一句又说"没穿啊，就盖着被子躺着"，前后矛盾。
       根因：这条溢奶描述写死了"衣服"，而她当时 outfit 是裸（只盖被子）。
       现在按穿着状态分支：穿着→衣服；裸着/只盖被子→滴在床上、顺着腿淌。
       她自己知道穿没穿，只要点明"别说衣服"就不会错。 */
    /* [2026-10-23 重写｜原来给的是"台词清单"，她照念，几轮就腻]
       用户要求：更丰富的描写，但不要刻意、重复、模板化。
       所以不再给"说什么"，改给**身体到底在发生什么**（生理层次 + 感官），
       并且显式允许"这轮不写"——同一件事每轮都提才是最大的模板感。 */
    out.push('· **溢奶（按需写，不必每轮都有）**：真实的层次是——'
      + '先是**胸口一阵发麻/发酸**（奶阵来了），接着**某个点开始往外冒**（不是均匀渗，是某一处先湿）；'
      + '量少时一滴挂在尖上、慢慢汇成一颗掉下来；量多时顺着皮肤往下淌，走过腹部、被腰线或衣摆拦住。'
      + '能感觉到的：**湿的面积一点点扩大、布料/皮肤变凉、有淡淡的奶味**。'
      + '**按穿着调整**：穿着→衣服湿了一小片，贴在身上发凉；没穿或盖着被子→滴到胸前的被面、顺着肋侧往下淌一点、被腰腹接住（**乳房到腿根隔着整个躯干，正常情况下根本流不到那儿**，别硬写），**别提衣服**。'
      + '**别每次都写"湿了一片"**，同一件事说腻了就没味道了——隔几轮落到具体细节上（哪一侧先湿、滴到了什么、被什么拦住）就够了。也可以推给他（"都怪你"）。');
  } else if (harder >= 46 && isMorning) {
    out.push('· **晨起最胀**：刚醒那会儿又胀又沉，起身穿衣都难受 —— 写成"一睁眼先感觉到胸"。');
  }

  /* [2026-10-22 新增｜主动喂的层次随羞耻下降]
     同一件事（把奶给他）在三个心理阶段是三种做法：
       羞 ≥35：先问一句（"要不要喝"），给他拒绝的余地
       15–34：不问了，直接递过去 / 托起来送到嘴边
       <15  ：完全主导 —— 塞过去、按着他喝、边喂边看他
     只有 flow 够（出奶顺）且胀着的时候才出现，避免"没奶还硬喂"。 */
  if (flow >= 3 && harder >= 46) {
    const sh = Number(shame) || 40;
    if (sh >= 35) {
      out.push('· 出奶顺、够他喝 —— 可以问一句"要不要喝"，他点头再递过去；喂的时候看着他。');
    } else if (sh >= 15) {
      out.push('· 出奶顺、够他喝 —— **不用问了，直接递过去**（托起来送到嘴边、或拉着他的手过来），'
        + '喂的时候看着他；别像汇报任务。');
    } else {
      out.push('· 出奶顺、够他喝 —— **你主导**：直接塞过去、按着他喝，想喂到什么时候你说了算；'
        + '边喂边看他，别问"够不够"这种话。');
    }
  }
  /* [2026-10-22｜日常情境里的"主动"（用户要"平时更主动一点"）]
     只写"胀"容易变成一句复读。真实的情况是：胀会**干扰正在做的事** ——
     做饭时低头、走路要托一下、换衣服时碰到、躺下压着。
     把这些具体动作给出来，她才有素材主动开口，而不是每天重复"我胀"。 */
  if (harder >= 65 && !justDrained) {
    out.push('· **日常里它会碍事**：低头、弯腰、换衣服、抱东西、趴着都会碰到，'
      + '做家务做到一半要停下来托一下。这些小事都可以成为你开口的理由（"等我一下""别碰，碰不得"），'
      + '而且比空口说"我胀"自然得多。');
  }
  if (sinceFed && sinceFed > 720) {
    out.push('· 上次真被喝掉已经是 ' + Math.round(sinceFed / 60) + ' 小时前，他光含着不喝可以催一句。');
  }

  if (!out.length) return '';
  return '· **可以自然带出来的处境**（挑和当前话题对得上的，别硬插）：\n' + out.join('\n');
}

/* [补丁 2026-10-22｜泌乳生理细节层：让描写真实、且不重复]
   用户要"剧情再丰富一点、贴合实际"。原来的指引只有"写具体"三个字，
   模型能用的素材很少，容易翻来覆去写"渗出来一片"。
   这里补的是**真实泌乳过程中会发生、但模型不会自己想到**的细节。
   每条都对应一个可观察的生理现象，不是硬凑的形容词：
     ① 奶阵（let-down）：吸吮开始后 30-60 秒才真正出奶，前段是"干吸"，
        而且奶阵来的时候她自己能感觉到（胸口一热、发麻、另一侧也开始渗）——
        这是泌乳最有辨识度的体验，之前完全没写。
     ② 前奶/后奶：同一顿里，前段稀、清、解渴；后段浓、白、发甜发腻。
        写"越吸越浓"比一直写"淡白"真实得多。
     ③ 两侧联动：吸一侧，另一侧会跟着漏（催产素是全身性的），这解释了
        "为什么两边都湿了"，也给"单侧不对称"留了合理出口。
     ④ 排空后的手感：吸空不是"消失"，是松软、轻微酸胀、皮肤发凉，
        按下去有空感 —— 对应 hardness 归零后的状态。
     ⑤ 涨奶的连带反应：胀的时候腋下、锁骨下方也会发紧；抬手、弯腰会牵扯；
        衣服摩擦乳头会突然一激灵。这些是"胀感"在生活场景里的表现。
     ⑥ 敏感度：乳头被吸过之后会变得更敏感（下一次碰反应更快），
        这和 flow 档位正相关（练出来了）。
   按当前数值只给**相关的那几条**，避免每轮塞满、变成八股。 */
function physiologyHints(harder, lvL, lvR, flow) {
  /* [2026-10-22 瘦身] 原来输出 6 条（约 550 字符），与"泌乳段占比 25.6%"直接相关。
     压成 3 条：奶阵（必留，最有辨识度）+ 前奶后奶/两侧联动（合并）+ 胀或空的身体细节（按状态二选一）。
     删掉的「敏感度」：flow 档位已经在正文 flowTxt 里说过（"挤半天一滴/几滴/一线/会喷"），
     再讲一遍"乳头更敏感"是重复。 */
  const out = [];
  /* [2026-10-23 新增｜"开始之前"那一段]
     原来的提示词从"胀得难受"直接跳到"快帮我揉开"，中间全是空的。
     真实顺序是：难受 → 犹豫/开口 → 他过来 → 隔着衣服碰 → 掀起来 →
     **手先揉**（不是直接吸）→ 硬块松一点 → 乳头被碰到才有反应 → 奶阵 → 才开始吸。
     不强制每轮写（那会变成流程图），但她开口求助时应该知道这些层次。 */
  if (harder >= 46) {
    out.push('· **他过来之前那一段**：你不是一句话就被吸上的。真实顺序是——'
      + '先是犹豫（说不说、怎么开口）；他过来了，可能先隔着衣服碰一下（你会缩一下）；'
      + '然后才是掀起来、**手先上去揉**（不是一上来就吸）；硬块被揉开一点，你才真正松一口气。');
    out.push('· **他的手比嘴先到**：硬块还在的时候直接吸会疼（你会真的缩），所以正常顺序是'
      + '**先揉、再吸**。他不知道的话你可以直接提（"先揉开再吸""别一上来就含"）。');
    if (harder >= 75) {
      out.push('· **还没碰到就已经开始了**：胀到这个程度，他还没碰你就已经在想；'
        + '被碰到那一下会比平时敏感很多（可能没忍住出声）。这不是夸张，是真的胀到碰不得。');
    }
  }
  /* [2026-10-24 删｜"奶阵原理"这条同样是解释；上面 ③ 在真触发时会给"刚刚奶阵过一次"的实时事实。 */
  /* [2026-10-23 新增｜一场戏内部的节奏]
     上面给的是"状态"，缺的是"过程"——同一场吸奶里，她的反应会经历四个阶段。
     这是**一场戏的时间轴**，不是重复状态描述，所以不算冗余。 */
  if (harder >= 46 && harder < 86) {
    out.push('· **一场吸下来是有节奏的**（别从头到尾一个感觉）：'
      + '**刚含住**——硬块还在，吸得疼，你会绷着、手指抓着他；'
      + '**揉开之后**——突然松了，从疼变成酸胀，会忍不住叹一口气；'
      + '**奶阵来了**——胸口一热、出奶变顺，人跟着软下来；'
      + '**快空的时候**——敏感过头，吸一下颤一下，会想让他停（"够了""别吸了"）。');
  }

  if (harder >= 46) {
    out.push('· 同一顿里前段稀、后段越吸越浓，可以写这个变化；吸一侧另一边会跟着漏，两边湿是正常的。');
  }
  if (harder <= 20) {
    out.push('· 现在是松软、发酸、皮肤凉，按下去"空"的 —— 不是没有，是被掏空的那种虚。');
  } else if (harder >= 65) {
    out.push('· 胀的时候腋下、锁骨下方也发紧，抬手弯腰都牵扯；衣服蹭到乳头会一激灵。');
  }
  return out.join('\n');
}

/* ═══════════════════════ 插件生命周期 ═══════════════════════ */

export function setup(api) {
  /* [2026-10-22 新增] 供 bridge（8787 面板）在外部改完 state.json 之后让本插件重读 ——
     stateRoot 是模块级缓存，不清掉的话内存里的旧值会在下次 persist 时把外部改动覆盖掉。 */
  globalThis.__LACTATION_RELOAD__ = () => { stateRoot = null; };
  globalThis.__LACTATION_STATE_FILE__ = STATE_FILE;
  apiRef = api;
  migrateFromEmotionLifeOnce();
  try {
    registerTools(api);
  } catch (e) { CLOG('[泌乳] 工具注册失败：' + (e?.message ?? e)); }
}

/* 工具定义从 emotion-life 原样搬出（唯一改动：去掉未使用的 response() 包装）。 */
function registerTools(api) {
api.registerTool({ id: 'lactation_report', name: '泌乳上报', category: 'system', icon: '🍼', description: '剧情里确实发生了泌乳相关行为时，回复前调用本工具（这是泌乳数值结算的唯一途径，正则只做计数兜底）。action=suck 她被吸（amount 必填：少=吸了几口没出多少 / 中=吸出一部分 / 多=吸出很多 / 空=吸空、她说软了硬块没了）；action=drink 被喝掉（真的喝/咽下去）；action=rub 被揉捏疏通（没吸出奶，只是揉）；action=feel 只记录身体感受（不改数值，note 写胀/硬/软）；action=status 查询当前状态。side=左/右/双（默认双）。没发生泌乳行为时绝不调用，也不要为了哄人虚报。', parameters: { type: 'object', properties: { action: { type: 'string', enum: ['suck', 'drink', 'rub', 'feel', 'status'] }, amount: { type: 'string', enum: ['少', '中', '多', '空'], description: 'suck 时的排空程度：少/中/多/空' }, side: { type: 'string', enum: ['左', '右', '双'], description: '哪一侧，默认双' }, note: { type: 'string', description: '一句补充（feel 时写身体感受）' } }, required: ['action'] }, async execute(ctx, args = {}) { const cfgL = settings(); /* [2026-10-22 修｜拆分残留]这里原来检查的是 emotion-life 的 adultStateEnabled，但新插件的 settings() 只返回**自己**的配置段 ⇒ 永远 undefined ⇒ 每次上报都被拒。改成看自己的 enabled。 */ if (cfgL.enabled === false) return { ok: false, content: '泌乳系统已关闭，忽略本次上报。' }; const action = String(args.action || '').trim(); const keyL = chatKeyFrom(ctx); const laL = ensureLactation(ensureState(keyL)); if (action === 'status') { const L = laL; lacApplyTime(L); return { ok: true, content: `泌乳：左 ${Math.round(L.sides.left.level)}/${Math.round(L.sides.left.hardness)}（奶量/胀感）｜右 ${Math.round(L.sides.right.level)}/${Math.round(L.sides.right.hardness)}｜容量 ${L.capacity}｜出奶档 ${lacFlowTier(L)}/4｜被吸 ${L.suckCount} 次、吸空 ${L.emptyCount} 次、喝掉 ${L.totalFed} 次、喷乳 ${L.sprayCount || 0} 次` }; } if (action === 'feel') { const r = lacSettle(keyL, { action: 'feel', note: args.note, side: args.side }); return { ok: true, content: `已记录身体感受。（${r.line}）请继续以角色身份自然延续，不要复述数值。`, result: r }; } if (action === 'suck' && !args.amount) return { ok: false, content: 'suck 需要 amount（少/中/多/空）：按她实际被吸出来的量判断，别一律填"空"。' }; const r = lacSettle(keyL, { action, amount: args.amount, side: args.side, note: args.note }); /* [2026-10-23 加｜给她"这一轮身体发生了什么"的体感，不给数字]
            原来只回报剩余量，她**不知道自己这一轮到底吸出了多少**，
            下一轮报档位全凭感觉，可能连续报"中"却演成"吸出很多"。
            这里按**扣减比例**换算成 5 档体感，让她有反馈闭环、又不会把数字念出来。
            ⚠️ 用"体感"不用数值：数字最容易被模型当台词念（"刚才吸出 24"）。 */
        const tail = args.note ? `（${String(args.note).slice(0, 30)}）` : '';
        const _feelOf = (before, after) => {
          const b = Number(before) || 0, a = Number(after) || 0;
          if (b <= 0) return '本来就空着';
          const ratio = (b - a) / b;
          if (a <= 2) return '瘪下去了，按下去只剩一层皮';
          if (ratio >= 0.55) return '一下松了大半，鼓着的地方塌下去';
          if (ratio >= 0.32) return '软下去一半，硬块散了些';
          if (ratio >= 0.15) return '松了一点，还带着胀';
          return '几乎没动，还是满的';
        };
        const _sideLbl = String(args.side || '').trim();
        const _felt = _sideLbl === '左' ? `左边${_feelOf(r.before?.left?.level, r.left.level)}`
          : _sideLbl === '右' ? `右边${_feelOf(r.before?.right?.level, r.right.level)}`
          : `左边${_feelOf(r.before?.left?.level, r.left.level)}；右边${_feelOf(r.before?.right?.level, r.right.level)}`;
        return { ok: true, content: `已记录泌乳${tail}：${_felt}。现在左 ${r.left.level}/胀${r.left.hardness}、右 ${r.right.level}/胀${r.right.hardness}。请继续以角色身份自然延续当下，不要复述数值、也不要说"已记录"。`, result: r }; } });}

/* ── 高潮喷乳（⑧ 从 emotion-life 迁出）─────────────────────────────────
   原本这段写在 emotion-life 的 applyZoneInteractions 高潮分支里。拆分后那两行
   `ensureLactation(s)` / `lacApplyTime(L)` 会因函数已移走而 ReferenceError，
   被它的 try/catch 静默吞掉 —— 也就是"喷乳悄悄失效"（不报错、也不生效）。
   这里改成**自检测**：读 emotion-life 状态里的 orgasms 计数，发现它增长就触发。
   为什么不让 emotion-life 反过来调本插件：插件侧没有跨模块能力调用的入口
   （api 只有 registerTool/config/log/warn/sender），单向依赖会让耦合更糟。
   节流：60 秒内最多读一次 emotion-life 的 state（避免每轮 IO）。 */
let _lastOrgasmCheckAt = 0;

function lacSpray(chatKey, now = Date.now()) {
  const s = ensureState(chatKey);
  const la = ensureLactation(s);
  lacApplyTime(la, now);
  const avg = (Number(la.sides.left.level) + Number(la.sides.right.level)) / 2;
  /* [2026-10-22 改｜阈值 60 太严，吸空后高潮完全不喷]
     用户反馈 19:38 那次高潮没有喷乳。当时两侧只剩 19 —— 原实现要求 avg>60，
     于是"没奶所以不喷"。但真实泌乳里量少时也会少量渗出（只是不是喷射）。
     改成三档：avg>60 喷射（-20/-30，记一次）；avg>15 渗出（-6/-10，不记）；其余不处理。 */
  if (!(avg > 15)) return null;
  const isSquirt = avg > 60;
  const dLv = isSquirt ? 20 : 6;
  const dHd = isSquirt ? 30 : 10;
  for (const sd of ['left', 'right']) {
    la.sides[sd].level = Math.max(0, la.sides[sd].level - dLv);
    la.sides[sd].hardness = Math.max(0, la.sides[sd].hardness - dHd);
  }
  if (isSquirt) la.sprayCount = (Number(la.sprayCount) || 0) + 1;
  la.lastSprayMode = isSquirt ? 'squirt' : 'seep';
  la.lastSprayAt = now;
  if (!Array.isArray(la.log)) la.log = [];
  const avgAfter = (Number(la.sides.left.level) + Number(la.sides.right.level)) / 2;
  la.log.push('[' + new Date(now).toLocaleTimeString('zh-CN', { hour12: false })
    + '] spray(高潮喷乳) 平均 ' + Math.round(avg) + '→' + Math.round(avgAfter)
    + ' 喷乳' + la.sprayCount + '次');
  la.log = la.log.slice(-40);
  try { persist(); } catch { /* 落盘失败不影响 */ }
  return { ok: true, before: Math.round(avg), after: Math.round(avgAfter), sprayCount: la.sprayCount };
}

/** 检测 emotion-life 的 orgasms 是否增长；是则喷一次。失败全部静默。 */
function maybeSprayFromOrgasm(chatKey, now = Date.now()) {
  try {
    if (now - _lastOrgasmCheckAt < 60000) return null;
    _lastOrgasmCheckAt = now;
    if (!fs.existsSync(EMOTION_STATE)) return null;
    const el = JSON.parse(fs.readFileSync(EMOTION_STATE, 'utf8'));
    const n = Number(el?.chats?.[chatKey]?.adult?.orgasms) || 0;
    const s = ensureState(chatKey);
    const la = ensureLactation(s);
    if (la.lastOrgasmsSeen === undefined) { la.lastOrgasmsSeen = n; return null; }
    if (n <= la.lastOrgasmsSeen) return null;
    la.lastOrgasmsSeen = n;
    return lacSpray(chatKey, now);
  } catch { return null; }
}

/* ── 身体冲动（2026-10-24 加｜满了必须"有反应"，不靠模型听话）──────────
   实测：泌乳段 15 轮全注入（"胀得难受"档），回复里 0 次提身体。
   所以补两层确定性管道：
   ① 胀感跨过阈值那刻，把「刚刚发生」当事实追加给模型（不是要求它表现）；
   ② 本轮回复一个身体词都没有时，往第一条气泡前插一个动作气泡。
   插动作不插台词：不打断她正要说的语义，也不像状态播报。 */
const LAC_IMPULSE_EVENT_AT = 86;
/* 组合式句池：动作 × 细部 → 单档 6 动作 × 6 细部 = 36 种，三档共 108 种，
   且按"动作"去重（最近 5 次不重复同一个动作）。 */
const LAC_IMPULSE_POOL = {
  /* 只用不依赖穿着的动作：她在家就是宽松 T 恤/短裤，写"外套""衣襟"会穿帮 */
  soft: ['按了按胸口', '把手臂横在胸前', '低头看了一眼自己', '扯了扯衣摆', '手肘收了一下，挡住前面', '把肩膀往里收了收'],
  mid: ['唔了一声，按住胸口', '侧过身，用手臂挡着', '衣服前面蹭了一下', '指尖在领口那儿停了一下', '把领口往下扯了扯，又松开', '撑在床沿上，缓了半拍'],
  hard: ['闷哼了一声，撑着床沿', '低头把脸埋进手臂', '抓了抓衣角', '别过脸，肩膀绷着', '喉咙里滚出半声，没说完', '手撑着膝盖，慢慢吐了口气']
};
const LAC_DETAILS = ['没吭声', '眉头皱起来', '指节有点发白', '呼吸短了一下', '咬了下唇', '声音有点哑'];
const lacRecent = [];
/* 动作与细部共享 2 字就判重，避免"呼吸一滞腿绷紧，呼吸压着"这种叠词 */
function lacOverlap(a, b) {
  for (let i = 0; i < a.length - 1; i++) if (b.includes(a.slice(i, i + 2))) return true;
  return false;
}
function lacPickBubble(harder) {
  const h = Number(harder) || 0;
  const acts = h >= 95 ? LAC_IMPULSE_POOL.hard : h >= 85 ? LAC_IMPULSE_POOL.mid : LAC_IMPULSE_POOL.soft;
  const fresh = acts.filter((b) => !lacRecent.includes(b));
  const from = fresh.length ? fresh : acts;
  const act = from[Math.floor(Math.random() * from.length)];
  lacRecent.push(act);
  if (lacRecent.length > 5) lacRecent.shift();
  const dets = LAC_DETAILS.filter((d) => !lacOverlap(act, d));
  const prob = act.includes('，') ? 0.45 : 0.8;   // 动作本身已带逗号的，少叠一层，免得太长
  const det = dets.length && Math.random() < prob ? dets[Math.floor(Math.random() * dets.length)] : '';
  return `（${act}${det ? '，' + det : ''}）`;
}
const LAC_IMPULSE_EVENTS = [
  '胸口已经胀到发疼，衣服前面洇出一小片湿痕',
  '胸前又胀又沉，抬手碰到都发酸，已经渗出来一点'
];
/* 判断"她这轮提没提身体"：裸一个"奶"字会被"牛奶"误命中（负向断言也挡不住"牛奶"，
   因为字在前）。干脆不认单字奶，只认 乳房/奶水/母乳；胀、渗、湿已经覆盖日常说法。 */
const LAC_BODY_RE = /胀|憋|渗|湿|胸前|胸口|小腹|坠|漏|夹.{0,2}腿|坐不住|站不住|乳房|奶水|母乳/;
const lacImpulse = { lastHarder: null, armed: true, pending: '', lastInsertAt: 0, idx: 0 };

function lacImpulseNote(harder) {
  const h = Number(harder) || 0;
  if (lacImpulse.lastHarder !== null && lacImpulse.lastHarder < LAC_IMPULSE_EVENT_AT
      && h >= LAC_IMPULSE_EVENT_AT && lacImpulse.armed) {
    lacImpulse.pending = '[刚刚发生·身体]' + LAC_IMPULSE_EVENTS[lacImpulse.idx++ % LAC_IMPULSE_EVENTS.length]
      + '。\n这是刚刚发生的事，不是提醒也不是状态播报；自然带一句就好，不要报数字。';
    lacImpulse.armed = false;
    CLOG('[泌乳] 胀感跨过 ' + LAC_IMPULSE_EVENT_AT + '（' + lacImpulse.lastHarder + '→' + h + '），排队一次「刚刚发生」');
  }
  if (h < LAC_IMPULSE_EVENT_AT - 10) lacImpulse.armed = true;
  lacImpulse.lastHarder = h;
}

function lacOutgoingText(msg) {
  if (!msg) return '';
  let out = typeof msg.content === 'string' ? msg.content : '';
  if (Array.isArray(msg.tool_calls)) {
    for (const call of msg.tool_calls) {
      if (!/send_message|reply/.test(String(call?.function?.name || ''))) continue;
      try {
        const o = JSON.parse(call.function.arguments || '{}');
        if (Array.isArray(o.messages)) out += '\n' + o.messages.join('\n');
        else if (typeof o.text === 'string') out += '\n' + o.text;
      } catch { /* ignore */ }
    }
  }
  return out;
}

function lacInsertImpulseBubble(msg) {
  if (!msg || !Array.isArray(msg.tool_calls)) return false;
  for (const call of msg.tool_calls) {
    if (!/send_message|reply/.test(String(call?.function?.name || ''))) continue;
    const raw = call?.function?.arguments;
    if (typeof raw !== 'string' || !raw) continue;
    let o;
    try { o = JSON.parse(raw); } catch { continue; }
    const b = lacPickBubble(lacImpulse.lastHarder);
    if (Array.isArray(o.messages) && o.messages.length) {
      o.messages.unshift(b);
      call.function.arguments = JSON.stringify({ ...o });
      return true;
    }
    if (typeof o.text === 'string' && o.text.trim()) {
      o.text = b + o.text;
      call.function.arguments = JSON.stringify({ ...o });
      return true;
    }
  }
  return false;
}

export const hooks = {
  /**
   * 每轮注入泌乳状态，并用"他的话"做计数兜底。
   * ⚠️ 只注入一份：emotion-life 里对应的注入点与工具注册已被删除，不会重复。
   */
  'before-llm-messages'(ctx = {}) {
    try {
      const cfg = settings();
      if (cfg.enabled === false) return;
      const key = chatKeyFrom(ctx);
      if (!key) return;
      activeChatKey = key;
      const t = ownerText(ctx);
      if (t) detectLactation(t, key, ctx);
      /* 高潮喷乳自检测（读 emotion-life 的 orgasms 增长，60 秒节流，失败静默） */
      maybeSprayFromOrgasm(key);
      const sec = lactationSection(key);
      if (sec && Array.isArray(ctx.messages) && ctx.messages.length) {
        ctx.messages.push({ role: 'system', content: sec });
      }
      /* ② 跨过阈值那一刻的「刚刚发生」——比"请你表现出胀"有效得多 */
      if (lacImpulse.pending && Array.isArray(ctx.messages) && ctx.messages.length) {
        ctx.messages.push({ role: 'system', content: lacImpulse.pending });
        lacImpulse.pending = '';
      }
    } catch (e) {
      CLOG('[泌乳] 注入失败：' + (e?.message ?? e));
    }
  },

  /* ① 兜底插句：胀到阈值了、她这轮却一个字没提身体 → 补一个动作气泡 */
  'after-response'(ctx = {}) {
    try {
      const cfg = settings();
      if (cfg.enabled === false) return;
      const msg = ctx.response?.message;
      if (!msg) return;
      const h = Number(lacImpulse.lastHarder);
      if (!Number.isFinite(h) || h < 70) return;          // 没到"发胀有硬块"以上不管
      const now = Date.now();
      if (now - lacImpulse.lastInsertAt < Number(cfg.impulseMinGapMs ?? 90000)) return;  // 默认 90 秒一次，别刷屏
      if (Date.now() - Number(globalThis.__bodyImpulseAt || 0) < 3000) return;  // 本轮已被另一侧插过
      const said = lacOutgoingText(msg);
      if (!said.trim()) return;                           // 本轮不发消息就不动
      if (LAC_BODY_RE.test(said)) return;                 // 已经提了，不重复
      if (!lacInsertImpulseBubble(msg)) return;
      lacImpulse.lastInsertAt = now;
      globalThis.__bodyImpulseAt = now;   // 与 urinary 抢同一轮：谁先插谁占坑，3 秒内不许再插
      CLOG('[泌乳] 胀感 ' + Math.round(h) + ' 但这轮没提身体 → 插入动作气泡');
    } catch (e) {
      CLOG('[泌乳] 兜底插句失败：' + (e?.message ?? e));
    }
  }
};

export const providers = {
  /** 供工具 / 其它插件查询或直接结算。 */
  'lactation.report': (args = {}) => {
    const key = String(args?.chatKey || activeChatKey || '');
    if (!key) return { ok: false, content: '缺少 chatKey，无法结算。' };
    if (args?.action === 'status') {
      const s = ensureState(key);
      const L = ensureLactation(s);
      lacApplyTime(L);
      return {
        ok: true,
        left: { level: Math.round(L.sides.left.level), hardness: Math.round(L.sides.left.hardness) },
        right: { level: Math.round(L.sides.right.level), hardness: Math.round(L.sides.right.hardness) },
        capacity: L.capacity,
        flowTier: lacFlowTier(L),
        suckCount: L.suckCount,
        emptyCount: L.emptyCount,
        totalFed: L.totalFed
      };
    }
    return lacSettle(key, {
      action: args?.action, amount: args?.amount, side: args?.side, note: args?.note
    });
  },
  /** 高潮喷乳：供其它模块显式触发（当前由 hook 自检测驱动，这个入口留给工具/面板）。 */
  'lactation.spray': (args = {}) => {
    const key = String(args?.chatKey || activeChatKey || '');
    if (!key) return { ok: false, content: '缺少 chatKey。' };
    /* [2026-10-23 修｜文案与三档阈值不同步] 喷乳早就改成"avg>60 喷射 / >15 渗出"，
       但这里的失败提示还写着"不足 60" —— 低奶量明明走的是渗出档，
       回报却说"不足 60 不喷"，看起来像功能没生效。 */
    return lacSpray(key) || { ok: false, content: '奶量太少（两侧平均不到 15），这次没有渗出来。' };
  }
};

export function available() { return { ok: true }; }

export const internals = {
  ensureState, persist, ensureLactation, lacSettle, lacApplyTime, lacRate,
  lacFlowTier, lactationSection, detectLactation, lacSuckHit,
  LAC_DRINK, LAC_DRINK_RAW, LAC_DRINK_NOISE,
  STATE_FILE, DATA_DIR
};
