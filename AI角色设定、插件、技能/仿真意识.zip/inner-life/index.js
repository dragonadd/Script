// ============================================================================
//  意识模拟（inner-life）v0.2
//
//  四层，按图实现：
//
//    启动器（纯开关，每 N 小时一次；聊天进行中不点火）
//       ├─ 触发 自我：本我(人设) + 对话 → 1~3 条"想开口说的话"
//       └─ 触发 超我（待命）
//                ↑ 等自我输出
//    超我：自我输出 AND 启动器激活 → 三选一
//       └─ 行动：开启对话 / 调用插件 / 不行动
//
//  硬约束：
//    · 只在私聊生效（群聊不记录、不注入、不主动）
//    · 聊天进行中不点火（以对话内容为准）
//    · 超我没有自我输出就不动（AND）
//    · 一次点火最多产生一个行动；宁可不做
// ============================================================================

import fs from 'node:fs';
import path from 'node:path';
import { DATA_DIR, getConfig } from '../../src/config.js';
import { chatCompletion } from '../../src/llm.js';

const PLUGIN_ID = 'inner-life';
const DIR = path.join(DATA_DIR, PLUGIN_ID);
const STATE_FILE = path.join(DIR, 'state.json');
const RECENT_FILE = path.join(DIR, 'recent.jsonl');

const DEFAULTS = {
  enabled: false,
  starterHours: 2,
  activeWindowMinutes: 10,
  maxThoughts: 3,
  maxThoughtChars: 30,
  maxLineChars: 60,
  dailyMaxActions: 3,
  cooldownMinutes: 120,
  targetIdleMinutes: 10,
  dailyMaxTotal: 0,   // 0 = 不限制；填了就加一道全局安全阀
  maxTargetsPerCycle: 2,
  quietRange: '',
  verbose: false
};

let apiRef = null;
let timer = null;
let lastTickMinute = '';
let busy = false;

function settings() { return { ...DEFAULTS, ...(apiRef?.config?.() || {}) }; }
function log(...a) { try { apiRef?.log?.(`[inner-life] ${a.join(' ')}`); } catch { /* ignore */ } }
function warn(...a) { try { apiRef?.warn?.(`[inner-life] ${a.join(' ')}`); } catch { /* ignore */ } }

const ADULT_WORDS = [
  '性交', '口交', '肛交', '自慰', '射精', '精液', '阴茎', '阴道', '龟头', '睾丸',
  '乳头', '阴蒂', '阴唇', '肛门', '色情', '做爱', '内射', '调教', '情趣', '跳蛋',
  '按摩棒', '肛塞', '淫', '裸体', '裸露', '脱衣', '下体', '性器'
];
const hasAdult = (t) => ADULT_WORDS.some((w) => String(t || '').includes(w));

// ── 时间与状态 ────────────────────────────────────────────────────────────
const dayStr = (d = new Date()) => {
  const x = new Date(d);
  return `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, '0')}-${String(x.getDate()).padStart(2, '0')}`;
};
const hhmm = (d = new Date()) => `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;

function ensureDir() { try { fs.mkdirSync(DIR, { recursive: true }); } catch { /* ignore */ } }

function loadState() {
  try {
    const s = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')) || {};
    return {
      lastStarterAt: 0,
      lastSelf: null,
      lastAction: null,
      counts: {},
      lastSentAt: {},
      ...s
    };
  } catch {
    return { lastStarterAt: 0, lastSelf: null, lastAction: null, counts: {}, lastSentAt: {} };
  }
}
function saveState(s) {
  try { ensureDir(); fs.writeFileSync(STATE_FILE, JSON.stringify(s, null, 1), 'utf8'); } catch (e) { warn('状态写入失败', e?.message ?? e); }
}
/** 今天对某个会话主动过几次；不传会话则返回今天总数。 */
function todayCount(state, chatKey = '') {
  const day = state.counts?.[dayStr()];
  if (!day || typeof day !== 'object') return 0;
  if (chatKey) return Number(day[chatKey] || 0);
  return Object.values(day).reduce((a, b) => a + Number(b || 0), 0);
}
function bumpCount(state, chatKey = '') {
  const d = dayStr();
  const day = state.counts?.[d] && typeof state.counts[d] === 'object' ? state.counts[d] : {};
  const key = chatKey || 'unknown';
  state.counts = { ...(state.counts || {}), [d]: { ...day, [key]: Number(day[key] || 0) + 1 } };
  const days = Object.keys(state.counts).sort().slice(-14);
  state.counts = Object.fromEntries(days.map((k) => [k, state.counts[k]]));
}

// ── 近况记录（只记私聊）────────────────────────────────────────────────────
function appendRecent(rec) {
  try { ensureDir(); fs.appendFileSync(RECENT_FILE, JSON.stringify(rec) + '\n', 'utf8'); } catch { /* ignore */ }
}
function readRecent(sinceMs, chatKey = '') {
  const out = [];
  try {
    const txt = fs.readFileSync(RECENT_FILE, 'utf8');
    for (const line of txt.split(/\r?\n/)) {
      if (!line.trim()) continue;
      try {
        const r = JSON.parse(line);
        if (Number(r.ts) < sinceMs) continue;
        if (chatKey && r.chatKey !== chatKey) continue;
        out.push(r);
      } catch { /* 坏行 */ }
    }
  } catch { /* 无文件 */ }
  return out.sort((a, b) => a.ts - b.ts);
}
function trimRecent(keepMs = 72 * 3600000) {
  try {
    const cut = Date.now() - keepMs;
    const txt = fs.readFileSync(RECENT_FILE, 'utf8');
    const kept = txt.split(/\r?\n/).filter((l) => {
      if (!l.trim()) return false;
      try { return Number(JSON.parse(l).ts) >= cut; } catch { return false; }
    });
    fs.writeFileSync(RECENT_FILE, kept.join('\n') + (kept.length ? '\n' : ''), 'utf8');
  } catch { /* ignore */ }
}

// ── 判断：正在聊 / 免打扰 / 该点火 ────────────────────────────────────────
function lastMessageAt(chatKey = '') {
  const recent = readRecent(Date.now() - 24 * 3600000, chatKey);
  return recent.length ? Number(recent[recent.length - 1].ts) : 0;
}

function isConversationActive(now = Date.now(), chatKey = '') {
  const last = lastMessageAt(chatKey);
  if (!last) return false;
  return now - last < Math.max(1, Number(settings().activeWindowMinutes) || 10) * 60000;
}

function inQuietHours(now = new Date()) {
  const range = String(settings().quietRange || '').trim();
  if (!range) return false;
  const m = range.match(/^(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})$/);
  if (!m) return false;
  const cur = now.getHours() * 60 + now.getMinutes();
  const s = Number(m[1]) * 60 + Number(m[2]);
  const e = Number(m[3]) * 60 + Number(m[4]);
  return s <= e ? (cur >= s && cur < e) : (cur >= s || cur < e);
}

function starterDue(state, now = Date.now()) {
  const cfg = settings();
  if (cfg.enabled === false) return false;
  const interval = Math.max(1, Number(cfg.starterHours) || 2) * 3600000;
  if (now - Number(state.lastStarterAt || 0) < interval) return false;
  if (inQuietHours(new Date(now))) return false;
  const totalCap = Number(cfg.dailyMaxTotal) || 0;
  if (totalCap > 0 && todayCount(state) >= totalCap) return false;   // 全局安全阀
  if (!pickTargets(state, now).length) return false;   // 没有可考虑的人（都在聊/冷却/满额）
  return true;
}

// ── 目标选择：最近说话的那条私聊 ──────────────────────────────────────────
/** 这一轮可以考虑的人：每个人各自独立判断，互不影响。 */
function pickTargets(state, now = Date.now()) {
  const cfg = settings();
  const recent = readRecent(now - 7 * 86400000).filter((r) => String(r.chatKey || '').startsWith('private:'));
  if (!recent.length) return [];
  const lastByChat = new Map();
  for (const r of recent) lastByChat.set(r.chatKey, Number(r.ts));
  const cooldown = Math.max(1, Number(cfg.cooldownMinutes) || 120) * 60000;
  return [...lastByChat.entries()]
    .filter(([, ts]) => now - ts >= Math.max(1, Number(cfg.targetIdleMinutes) || 10) * 60000)
    .filter(([k]) => now - Number(state.lastSentAt?.[k] || 0) >= cooldown)
    .filter(([k]) => todayCount(state, k) < (Number(cfg.dailyMaxActions) || 3))
    .sort((a, b) => b[1] - a[1])
    .map(([k]) => k)
    .slice(0, Math.max(1, Number(cfg.maxTargetsPerCycle) || 2));
}

/** 兼容旧调用：取第一个。 */
function pickTarget(state, now = Date.now()) {
  return pickTargets(state, now)[0] || '';
}

// ── 自我：本我 + 对话 → 想法 ──────────────────────────────────────────────
function personaText() {
  try { return String(getConfig()?.persona?.roleText || '').slice(0, 1400); } catch { return ''; }
}

function buildSelfMessages(lines, chatKey, prevThoughts = []) {
  const cfg = settings();
  const sys = [
    personaText(),
    '【你在做什么】你不是在回消息，你在自己待着，想事情。',
    `【任务】根据下面这段最近的对话，想 1~${Number(cfg.maxThoughts) || 3} 句"你有点想开口说的话"。`,
    '要求：',
    `  · 每句不超过 ${Number(cfg.maxThoughtChars) || 30} 个字，要像人话，能直接当开场白`,
    '  · 是你自己的念头，不是复述对方说过的事，不是总结，不是问候套话',
    '  · 可以是有感而发、可以有立场、可以是突然想到的',
    '  · 不要写叮嘱（记得/别忘了/应该/注意），那是说教，不是想法',
    '  · 下面会给你"上一轮想的"，还成立就接着想，已经说过了/解决了/不相干就丢掉',
    '  · 没有想说的就返回空数组',
    '  · 只输出 JSON：{"thoughts":["…","…"]}'
  ].filter(Boolean).join('\n');
  const raw = lines.map((r) => `[${hhmm(new Date(r.ts))}] ${r.text}`).join('\n').slice(0, 2500);
  const prev = (Array.isArray(prevThoughts) ? prevThoughts : []).filter(Boolean);
  const prevBlock = prev.length
    ? `【上一轮你想的】\n${prev.map((t) => '- ' + t).join('\n')}\n（还成立的可以继续，已经过去的就不要再提）`
    : '';

  const user = [
    chatKey ? `【最近和这个人的对话】\n${raw}` : `【最近的对话】\n${raw || '（这段时间没人说话）'}`,
    prevBlock,
    chatKey ? '' : '没人说话也可以想点自己的事。'
  ].filter(Boolean).join('\n\n');
  return [{ role: 'system', content: sys }, { role: 'user', content: user }];
}

/** 叮嘱、建议、总结类句子不算"想法"。 */
function looksLikeAdvice(text) {
  return /(记得|别忘了|应该|最好|建议|要不|可以试|注意|小心)/.test(String(text || ''));
}

function parseSelf(text, cfg, prev = []) {
  const raw = String(text || '');
  const a = raw.indexOf('{');
  const b = raw.lastIndexOf('}');
  if (a < 0 || b <= a) return [];
  try {
    const o = JSON.parse(raw.slice(a, b + 1));
    const arr = Array.isArray(o.thoughts) ? o.thoughts : [];
    return arr
      .map((x) => String(x || '').trim())
      .filter((x) => x.length >= 2 && x.length <= Math.max(4, Number(cfg.maxThoughtChars) || 30) * 2)
      .filter((x) => !hasAdult(x))
      .filter((x) => !looksLikeAdvice(x))
      .filter((x) => !prev.includes(x))
      .slice(0, Math.max(1, Number(cfg.maxThoughts) || 3));
  } catch { return []; }
}

async function runSelf(state, now = Date.now()) {
  const cfg = settings();
  const lines = readRecent(now - 6 * 3600000).filter((r) => !hasAdult(r.text)).slice(-40);
  const prev = state.lastSelf?.thoughts || [];
  const res = await chatCompletion({
    messages: buildSelfMessages(lines, '', prev),
    temperature: 0.9,
    maxTokens: 300,
    skillContext: { thinkingMode: 'off' }
  });
  const thoughts = parseSelf(res?.message?.content, cfg, prev);
  state.lastSelf = { at: now, thoughts };
  saveState(state);
  log(`自我：产出 ${thoughts.length} 条想法${thoughts.length ? '：' + thoughts.join(' / ') : ''}`);
  return thoughts;
}

// ── 超我：想法 AND 激活 → 三选一 ──────────────────────────────────────────
function buildSuperegoMessages(state, target, now = Date.now()) {
  const cfg = settings();
  const thoughts = (state.lastSelf?.thoughts || []).map((t, i) => `${i + 1}. ${t}`).join('\n') || '（这次没想出什么）';
  const last = lastMessageAt(target);
  const gapMin = last ? Math.round((now - last) / 60000) : -1;
  const sys = [
    personaText(),
    '【你在做什么】决定要不要动。宁可不做，也不要勉强找话。',
    '【三种行动】',
    '  talk   主动开口说一句（会直接发到私聊）',
    '  plugin 先调用插件做点事（目前没有可用的，写了也会被忽略）',
    '  none   什么都不做（最常见，是正常结果）',
    '【判断依据】',
    '  · 现在几点、对方多久没说话、今天主动过几次',
    '  · 想说的这句话是不是"现在说正合适"，还是"什么时候说都行"',
    '  · 如果只是想打个招呼、没有具体内容，选 none',
    '【输出】只输出 JSON：{"act":"talk|plugin|none","line":"要说的话","plugin":"插件名","say_after":true,"why":"一句话理由"}'
  ].filter(Boolean).join('\n');

  const user = [
    `【刚才想到的】\n${thoughts}`,
    `【现在】${hhmm(new Date(now))}｜对方最近一条消息：${gapMin < 0 ? '很久没说话' : gapMin + ' 分钟前'}｜今天已主动 ${todayCount(state)} 次（上限 ${Number(cfg.dailyMaxActions) || 3}）`,
    `【目标】${target || '（没有合适的对象）'}`
  ].join('\n\n');
  return [{ role: 'system', content: sys }, { role: 'user', content: user }];
}

const ACTIONS = new Set(['talk', 'plugin', 'none']);

function parseAction(text, cfg) {
  const raw = String(text || '');
  const a = raw.indexOf('{');
  const b = raw.lastIndexOf('}');
  if (a < 0 || b <= a) return { act: 'none', why: '没解析出 JSON' };
  try {
    const o = JSON.parse(raw.slice(a, b + 1));
    const act = ACTIONS.has(String(o.act)) ? String(o.act) : 'none';
    const line = String(o.line || '').trim().slice(0, Math.max(10, Number(cfg.maxLineChars) || 60));
    return {
      act,
      line: act === 'talk' ? line : '',
      plugin: String(o.plugin || '').trim().slice(0, 30),
      sayAfter: o.say_after !== false,
      why: String(o.why || '').trim().slice(0, 80)
    };
  } catch { return { act: 'none', why: 'JSON 解析失败' }; }
}

async function runSuperego(state, target, now = Date.now()) {
  const cfg = settings();
  if (!state.lastSelf || !Array.isArray(state.lastSelf.thoughts) || !state.lastSelf.thoughts.length) {
    log('超我：没有自我输出，不动');
    return null;
  }
  if (Date.now() - Number(state.lastStarterAt || 0) > 5 * 60000) {
    log('超我：没有启动器激活，不动');
    return null;
  }
  const res = await chatCompletion({
    messages: buildSuperegoMessages(state, target, now),
    temperature: 0.5,
    maxTokens: 250,
    skillContext: { thinkingMode: 'off' }
  });
  const action = parseAction(res?.message?.content, cfg);
  log(`超我：${action.act}${action.act === 'talk' ? `（${action.line}）` : ''}｜${action.why}`);
  return action;
}

// ── 行动：执行 ────────────────────────────────────────────────────────────
function onebotEndpoint() {
  let conf = null;
  try { conf = getConfig(); } catch { /* 默认 */ }
  const s = conf?.snowluma || {};
  return {
    httpUrl: String(s.httpUrl || 'http://127.0.0.1:3000').replace(/\/+$/, ''),
    token: String(s.httpAccessToken || s.accessToken || '')
  };
}

async function sendPrivate(uin, text) {
  const id = Number(String(uin).split(':').pop());
  if (!Number.isFinite(id) || !id) throw new Error(`目标无效：${uin}`);
  const { httpUrl, token } = onebotEndpoint();
  const res = await fetch(`${httpUrl}/send_private_msg`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) },
    body: JSON.stringify({ user_id: id, message: [{ type: 'text', data: { text } }] }),
    signal: AbortSignal.timeout(8000)
  });
  const body = await res.json().catch(() => ({}));
  if (body.status && body.status !== 'ok') throw new Error(body.wording || '发送失败');
  return body;
}

async function executeAction(state, action, target, now = Date.now()) {
  if (!action || action.act === 'none') return { done: false, kind: 'none' };

  if (action.act === 'plugin') {
    log(`超我想调用插件「${action.plugin || '?'}」，但暂未接入，按不行动处理`);
    return { done: false, kind: 'plugin-unsupported' };
  }

  if (action.act === 'talk') {
    const line = String(action.line || '').trim();
    if (!line) return { done: false, kind: 'talk-empty' };
    if (hasAdult(line)) return { done: false, kind: 'talk-blocked' };
    if (!target) return { done: false, kind: 'no-target' };
    await sendPrivate(target, line);
    state.lastSentAt = { ...(state.lastSentAt || {}), [target]: now };
    bumpCount(state, target);
    state.lastAction = { at: now, kind: 'talk', line, why: action.why || '', target };
    state.actions = [...(state.actions || []), state.lastAction].slice(-20);
    saveState(state);
    log(`已开口：${line}（→ ${target}）`);
    return { done: true, kind: 'talk', line, target };
  }

  return { done: false, kind: 'unknown' };
}

// ── 主流程 ────────────────────────────────────────────────────────────────
async function cycle(force = false) {
  const cfg = settings();
  const state = loadState();
  const now = Date.now();
  if (!force && !starterDue(state, now)) {
    return { ok: false, reason: '启动器条件不满足' };
  }

  state.lastStarterAt = now;
  saveState(state);

  const targets = pickTargets(state, now);
  const thoughts = await runSelf(state, now);
  if (!thoughts.length && !force) {
    log('自我没产出，停下来');
    return { ok: true, thoughts: 0, targets: targets.length };
  }

  // 逐人判断：超我只决定"对这个人说不说"，不是"和谁说话"
  const results = [];
  for (const target of targets) {
    const action = await runSuperego(state, target, Date.now());
    const result = await executeAction(state, action, target, Date.now());
    results.push({ target, action, result });
  }
  trimRecent();
  return { ok: true, thoughts: thoughts.length, targets: targets.length, results };
}

// ── 定时器 ────────────────────────────────────────────────────────────────
async function timerTick() {
  try {
    const now = new Date();
    const mark = `${hhmm(now)}`;
    if (mark === lastTickMinute) return;
    lastTickMinute = mark;
    if (busy) return;
    const state = loadState();
    if (!starterDue(state, Date.now())) return;
    busy = true;
    try { await cycle(false); } finally { busy = false; }
  } catch (e) { warn('定时流程失败', e?.message ?? e); }
}

// ── 钩子：只记私聊 ────────────────────────────────────────────────────────
function entriesOf(ctx = {}) {
  if (Array.isArray(ctx.triggerEntries)) return ctx.triggerEntries;
  if (Array.isArray(ctx.session?.trigger)) return ctx.session.trigger;
  return [];
}

export const hooks = {
  'before-context'(ctx = {}) {
    try {
      const cfg = settings();
      if (cfg.enabled === false) return;
      const chatKey = String(ctx.chatKey || '');
      if (!chatKey.startsWith('private:')) return;
      for (const e of entriesOf(ctx)) {
        if (!e || e.self) continue;
        const text = String(e.text || '').trim();
        if (!text || hasAdult(text)) continue;
        appendRecent({ ts: Number(e.ts) || Date.now(), chatKey, text: text.slice(0, 200) });
      }
    } catch (e) { warn('before-context 失败', e?.message ?? e); }
  }
};

// ── 工具 ──────────────────────────────────────────────────────────────────
export function setup(api) {
  apiRef = api;
  ensureDir();

  api.registerTool({
    id: 'inner_thoughts',
    name: '看看自己在想什么',
    category: 'message',
    icon: '💭',
    description: '查看"自我"最近想出来的几句话，以及上一次行动的结果。被问"你最近在想什么"时可以用。',
    parameters: { type: 'object', properties: {} },
    async execute() {
      const s = loadState();
      const thoughts = (s.lastSelf?.thoughts || []).map((t) => `- ${t}`);
      const last = s.lastAction
        ? `\n上次行动：${new Date(s.lastAction.at).toLocaleString('zh-CN', { hour12: false })}｜${s.lastAction.kind}${s.lastAction.line ? '｜' + s.lastAction.line : ''}`
        : '';
      if (!thoughts.length) return { content: '现在脑子里没什么话。' + last };
      return { content: `${thoughts.join('\n')}${last}` };
    }
  });

  api.registerTool({
    id: 'inner_cycle',
    name: '现在想一次',
    category: 'message',
    icon: '🌀',
    description: '立刻走一遍"自我思考 → 超我判断"（测试用）。dry 为 true 时只思考不发消息。',
    parameters: {
      type: 'object',
      properties: { dry: { type: 'boolean', description: '只思考不发消息，默认 true' } }
    },
    async execute(ctx, args = {}) {
      try {
        const dry = args?.dry !== false;
        const state = loadState();
        const target = pickTarget(state);
        const thoughts = await runSelf(state);
        if (dry) {
          return { content: `想到 ${thoughts.length} 句：\n${thoughts.map((t) => '- ' + t).join('\n') || '（空）'}\n（dry 模式，没有行动）` };
        }
        state.lastStarterAt = Date.now();
        saveState(state);
        const action = await runSuperego(state, target);
        const result = await executeAction(state, action, target);
        return { content: `想法 ${thoughts.length} 条；超我决定 ${action?.act || 'none'}；执行结果 ${result.kind}${result.line ? '：' + result.line : ''}` };
      } catch (e) {
        return { content: `失败：${e?.message ?? e}`, isError: true };
      }
    }
  });

  const cfg = settings();
  api.log?.(`意识模拟已加载：启动器每 ${cfg.starterHours} 小时，每天最多主动 ${cfg.dailyMaxActions} 次，仅私聊`);
  if (cfg.enabled !== false) {
    try { if (globalThis.__innerLifeTimer) clearInterval(globalThis.__innerLifeTimer); } catch { /* ignore */ }
    timer = setInterval(timerTick, 60 * 1000);
    timer?.unref?.();
    globalThis.__innerLifeTimer = timer;
  }
}

export function dispose() {
  if (timer) clearInterval(timer);
  try { if (globalThis.__innerLifeTimer === timer) globalThis.__innerLifeTimer = null; } catch { /* ignore */ }
  timer = null;
  apiRef = null;
}

export const providers = {
  'inner-life.state': () => {
    const s = loadState();
    return {
      lastSelfAt: s.lastSelf?.at || 0,
      thoughts: s.lastSelf?.thoughts || [],
      lastAction: s.lastAction || null,
      lastActions: (s.actions || []).slice(-5),
      todayActions: todayCount(s),
      todayByChat: (s.counts?.[dayStr()] && typeof s.counts[dayStr()] === 'object') ? s.counts[dayStr()] : {}
    };
  }
};

export const internals = {
  settings, dayStr, hhmm, hasAdult,
  readRecent, appendRecent, trimRecent,
  isConversationActive, inQuietHours, starterDue, pickTarget, pickTargets,
  buildSelfMessages, parseSelf, looksLikeAdvice, buildSuperegoMessages, parseAction, ACTIONS,
  runSelf, runSuperego, executeAction, cycle, loadState, saveState, todayCount, bumpCount,
  __reset: () => {
    saveState({ lastStarterAt: 0, lastSelf: null, lastAction: null, counts: {}, lastSentAt: {} });
    try { fs.rmSync(RECENT_FILE, { force: true }); } catch { /* ignore */ }
  }
};
