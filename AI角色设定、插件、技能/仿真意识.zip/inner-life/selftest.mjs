// 自测：node selftest.mjs
import fs from 'node:fs';
import path from 'node:path';
import { internals, setup, hooks } from './index.js';

let cfg = {
  enabled: true, starterHours: 2, activeWindowMinutes: 10, maxThoughts: 3, maxThoughtChars: 30,
  maxLineChars: 60, dailyMaxActions: 3, cooldownMinutes: 120, targetIdleMinutes: 10,
  quietRange: '', verbose: false
};
setup({ config: () => cfg, log: () => {}, warn: () => {}, registerTool: () => 'ok' });

let pass = 0, fail = 0;
const check = (n, c, extra = '') => { c ? (pass++, console.log(`  ok   ${n}`)) : (fail++, console.log(`  FAIL ${n} ${extra}`)); };

function seed(lines) {
  internals.__reset();
  for (const [minAgo, text, chatKey] of lines) {
    internals.appendRecent({ ts: Date.now() - minAgo * 60000, chatKey: chatKey || 'private:1', text });
  }
}

console.log('[1] 正在聊判断');
{
  seed([[2, '在吗']]);
  check('2 分钟前有消息 → 正在聊', internals.isConversationActive() === true);
  cfg.activeWindowMinutes = 1;
  check('窗口 1 分钟 → 不算正在聊', internals.isConversationActive() === false);
  cfg.activeWindowMinutes = 10;
  internals.__reset();
  check('没消息 → 不算正在聊', internals.isConversationActive() === false);
}

console.log('[2] 免打扰时段');
{
  const at = (h, m) => new Date(2026, 9, 23, h, m, 0);
  cfg.quietRange = '23:00-08:00';
  check('23:30 在免打扰', internals.inQuietHours(at(23, 30)) === true);
  check('03:00 在免打扰', internals.inQuietHours(at(3, 0)) === true);
  check('12:00 不在', internals.inQuietHours(at(12, 0)) === false);
  cfg.quietRange = '09:00-18:00';
  check('10:00 在', internals.inQuietHours(at(10, 0)) === true);
  check('19:00 不在', internals.inQuietHours(at(19, 0)) === false);
  cfg.quietRange = '';
  check('留空 → 永不免打扰', internals.inQuietHours(at(3, 0)) === false);
  cfg.quietRange = '乱写';
  check('格式错误 → 忽略', internals.inQuietHours(at(3, 0)) === false);
}

console.log('[3] 启动器条件');
{
  internals.__reset();
  seed([[30, '半小时前聊的']]);
  const state = internals.loadState();
  check('有闲置对象 → 到点', internals.starterDue(state) === true);

  state.lastStarterAt = Date.now() - 30 * 60000;
  check('30 分钟前点火过 → 不到点', internals.starterDue(state) === false);

  state.lastStarterAt = Date.now() - 3 * 3600000;
  check('3 小时前 → 到点', internals.starterDue(state) === true);

  seed([[1, '刚说完话']]);
  check('正在聊 → 不点火', internals.starterDue(state) === false);

  internals.__reset();
  seed([[30, '半小时前的消息']]);
  cfg.enabled = false;
  check('插件关 → 不点火', internals.starterDue(internals.loadState()) === false);
  cfg.enabled = true;
}

console.log('[4] 每日上限');
{
  internals.__reset();
  const st = internals.loadState();
  check('今天 0 次', internals.todayCount(st) === 0);
  st.counts[internals.dayStr()] = 3;
  check('今天 3 次 → 不点火', internals.starterDue(st) === false);
  st.counts[internals.dayStr()] = 0;
}

console.log('[5] 目标选择');
{
  internals.__reset();
  seed([
    [60, '老对话', 'private:111'],
    [20, '最近的', 'private:222'],
    [5, '刚说的', 'private:333']
  ]);
  const st = internals.loadState();
  check('刚说的那条不选（未达 10 分钟）', internals.pickTarget(st) === 'private:222', internals.pickTarget(st));
  cfg.targetIdleMinutes = 1;
  check('放宽后选最近的', internals.pickTarget(st) === 'private:333');
  cfg.targetIdleMinutes = 10;

  st.lastSentAt['private:222'] = Date.now();
  check('冷却中的不选', internals.pickTarget(st) !== 'private:222');
}

console.log('[6] 自我输出解析');
{
  const c = { maxThoughts: 3, maxThoughtChars: 30 };
  const a = internals.parseSelf('{"thoughts":["想吃点甜的","今天有点安静"]}', c);
  check('正常解析', a.length === 2 && a[0] === '想吃点甜的');
  check('坏 JSON → 空', internals.parseSelf('没有 json', c).length === 0);
  check('超长句被丢', internals.parseSelf('{"thoughts":["' + '很'.repeat(80) + '"]}', c).length === 0);
  check('成人内容被丢', internals.parseSelf('{"thoughts":["裸体"]}', c).length === 0);
  check('最多 3 条', internals.parseSelf('{"thoughts":["1条","2条","3条","4条"]}', c).length === 3);
  check('夹在文字里也能取', internals.parseSelf('好的{"thoughts":["嗯嗯"]}完毕', c)[0] === '嗯嗯');
}

console.log('[7] 超我输出解析');
{
  const c = { maxLineChars: 60 };
  const t = internals.parseAction('{"act":"talk","line":"在忙吗","why":"想知道他在干嘛"}', c);
  check('talk 解析', t.act === 'talk' && t.line === '在忙吗');
  const n = internals.parseAction('{"act":"none","why":"没什么想说的"}', c);
  check('none 解析', n.act === 'none' && n.line === '');
  check('乱写 → none', internals.parseAction('乱写', c).act === 'none');
  check('非法动作 → none', internals.parseAction('{"act":"dance"}', c).act === 'none');
  const long = internals.parseAction('{"act":"talk","line":"' + '话'.repeat(120) + '"}', c);
  check('超长句子被截断', long.line.length <= 60, String(long.line.length));
  const p = internals.parseAction('{"act":"plugin","plugin":"web_search","say_after":false}', c);
  check('plugin 解析', p.act === 'plugin' && p.plugin === 'web_search' && p.sayAfter === false);
}

console.log('[8] 行动执行');
{
  internals.__reset();
  const st = internals.loadState();
  const none = await internals.executeAction(st, { act: 'none' }, 'private:1');
  check('none 不执行', none.done === false && none.kind === 'none');

  const plugin = await internals.executeAction(st, { act: 'plugin', plugin: 'x' }, 'private:1');
  check('plugin 暂不支持', plugin.done === false && plugin.kind === 'plugin-unsupported');

  const noTarget = await internals.executeAction(st, { act: 'talk', line: '在吗' }, '');
  check('没目标不发', noTarget.done === false && noTarget.kind === 'no-target');

  const blocked = await internals.executeAction(st, { act: 'talk', line: '裸体' }, 'private:1');
  check('敏感内容被拦', blocked.done === false && blocked.kind === 'talk-blocked');

  const empty = await internals.executeAction(st, { act: 'talk', line: '  ' }, 'private:1');
  check('空句子不发', empty.done === false && empty.kind === 'talk-empty');
}

console.log('[9] 只记私聊');
{
  internals.__reset();
  hooks['before-context']({ chatKey: 'group:9', session: { trigger: [{ id: 1, text: '群里的消息', ts: Date.now() }] } });
  check('群聊不记录', internals.readRecent(0).length === 0);

  hooks['before-context']({ chatKey: 'private:9', session: { trigger: [{ id: 2, text: '私聊的消息', ts: Date.now() }] } });
  const rec = internals.readRecent(0);
  check('私聊被记录', rec.length === 1 && rec[0].text === '私聊的消息');

  hooks['before-context']({ chatKey: 'private:9', session: { trigger: [{ id: 3, text: '我自己说的', ts: Date.now(), self: true }] } });
  check('自己说的不记录', internals.readRecent(0).length === 1);
}

console.log('[10] 提示词构造');
{
  const self = internals.buildSelfMessages([{ ts: Date.now(), text: '今天好累' }], '');
  const all = self.map((m) => m.content).join('\n');
  check('自我提示词含任务', all.includes('想开口说的话'));
  check('自我提示词含素材', all.includes('今天好累'));
  check('自我要求 JSON', all.includes('"thoughts"'));

  const se = internals.buildSuperegoMessages({ lastSelf: { thoughts: ['想问问他'] }, counts: {} }, 'private:1', Date.now());
  const seAll = se.map((m) => m.content).join('\n');
  check('超我提示词含三种行动', seAll.includes('talk') && seAll.includes('none') && seAll.includes('plugin'));
  check('超我提示词含自我输出', seAll.includes('想问问他'));
  check('超我要求 JSON', seAll.includes('"act"'));
}

internals.__reset();

console.log('[按人计次]');
{
  internals.__reset();
  const day = internals.dayStr();
  const st = internals.loadState();
  st.counts[day] = { 'private:a': 2, 'private:b': 3 };
  check('a 已用 2 次', internals.todayCount(st, 'private:a') === 2);
  check('b 已用 3 次', internals.todayCount(st, 'private:b') === 3);
  check('总数 5', internals.todayCount(st) === 5);
  check('未知会话 0 次', internals.todayCount(st, 'private:c') === 0);

  internals.__reset();
  internals.appendRecent({ ts: Date.now() - 30 * 60000, chatKey: 'private:a', text: '甲' });
  internals.appendRecent({ ts: Date.now() - 20 * 60000, chatKey: 'private:b', text: '乙' });
  const st2 = internals.loadState();
  st2.counts[day] = { 'private:b': 3 };
  check('b 满 3 次被跳过', internals.pickTarget(st2) === 'private:a', internals.pickTarget(st2));

  const st3 = internals.loadState();
  st3.counts[day] = { 'private:a': 3, 'private:b': 3 };
  check('两人都满 → 没有目标', internals.pickTarget(st3) === '');

  const st4 = internals.loadState();
  internals.bumpCount(st4, 'private:a');
  check('只给 a 记一次（b 不受影响）', internals.todayCount(st4, 'private:a') === 1 && internals.todayCount(st4, 'private:b') === 0);
  internals.__reset();
}


console.log('[逐人判断]');
{
  internals.__reset();
  internals.appendRecent({ ts: Date.now() - 30 * 60000, chatKey: 'private:a', text: '甲' });
  internals.appendRecent({ ts: Date.now() - 20 * 60000, chatKey: 'private:b', text: '乙' });
  internals.appendRecent({ ts: Date.now() - 5 * 60000, chatKey: 'private:c', text: '丙' });

  const st = internals.loadState();
  const list = internals.pickTargets(st);
  check('返回多个候选', list.length === 2 && list.includes('private:a') && list.includes('private:b'), JSON.stringify(list));
  check('刚说话的 c 不在内', !list.includes('private:c'));

  const day = internals.dayStr();
  st.counts[day] = { 'private:a': 3 };
  const list2 = internals.pickTargets(st);
  check('满额的人被剔除', !list2.includes('private:a') && list2.includes('private:b'), JSON.stringify(list2));

  const st2 = internals.loadState();
  st2.counts = {};
  cfg.maxTargetsPerCycle = 1;
  check('一轮最多 N 人', internals.pickTargets(st2).length === 1);
  cfg.maxTargetsPerCycle = 2;

  check('pickTarget 仍取第一个', internals.pickTarget(st2) === internals.pickTargets(st2)[0]);
  internals.__reset();
}


console.log('[全局安全阀]');
{
  internals.__reset();
  internals.appendRecent({ ts: Date.now() - 30 * 60000, chatKey: 'private:a', text: '甲' });
  const st = internals.loadState();
  cfg.dailyMaxTotal = 0;
  check('默认不限制', internals.starterDue(st) === true);
  st.counts[internals.dayStr()] = { 'private:a': 2, 'private:b': 2 };
  cfg.dailyMaxTotal = 4;
  check('总量到顶就不点火', internals.starterDue(st) === false);
  cfg.dailyMaxTotal = 10;
  check('没到顶照常', internals.starterDue(st) === true);
  cfg.dailyMaxTotal = 0;
  internals.__reset();
}

console.log(`\n结果：${pass} 通过 / ${fail} 失败`);
process.exit(fail ? 1 : 0);
