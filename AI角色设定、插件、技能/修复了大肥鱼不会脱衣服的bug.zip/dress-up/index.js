﻿/**
 * 穿衣与行李（dress-up）
 * ───────────────────
 * 一套状态：衣柜 + 当前穿着 + 行李 + 已穿记录。
 * 三类工具：
 *   outfit_*   按天气/地点/目的决定穿什么、实时穿脱（有状态记忆）
 *   luggage_*  衣柜清单、打包、穿脏/剩余
 *   luggage_home 在家穿家居服
 * 全部自带：天气、生图、换装、打包，不依赖别的插件。
 */
import fs from 'node:fs';
import path from 'node:path';
import { DATA_DIR } from '../../src/config.js';

const FILE = path.join(DATA_DIR, 'dress-up', 'state.json');
const DEFAULTS = { enabled: true, timeZone: 'Asia/Shanghai', weatherProvider: 'auto', defaultCity: '', windChill: true, maxLuggage: 15, imageProvider: 'auto', preferPluginImage: true, imageWidth: 768, imageHeight: 1024, imageApiBase: '', imageApiKey: '', imageApiModel: '', wanderEnabled: true, wanderChance: 0.25, wanderMaxDays: 5 };

let api = null;
function cfg() { const c = api?.config?.() || {}; return { ...DEFAULTS, ...c }; }

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)';

const WARDROBE = [
  { id: 'home', name: '家居服（短袖+短裤/睡裙）', kind: '在家', band: 'any' },
  { id: 'tshirt', name: '短袖 T 恤', kind: '上装', band: 'hot' },
  { id: 'shirt', name: '衬衫', kind: '上装', band: 'mild' },
  { id: 'hoodie', name: '卫衣', kind: '上装', band: 'mild' },
  { id: 'sweater', name: '毛衣', kind: '上装', band: 'cold' },
  { id: 'thermal', name: '保暖内衣', kind: '上装', band: 'cold' },
  { id: 'lightjacket', name: '薄外套', kind: '外层', band: 'mild' },
  { id: 'windbreaker', name: '防风夹克', kind: '外层', band: 'cold' },
  { id: 'down', name: '羽绒服', kind: '外层', band: 'cold' },
  { id: 'raincoat', name: '防水外套', kind: '外层', band: 'mild' },
  { id: 'jeans', name: '牛仔裤', kind: '下装', band: 'mild' },
  { id: 'shorts', name: '短裤', kind: '下装', band: 'hot' },
  { id: 'sweatpants', name: '运动裤', kind: '下装', band: 'mild' },
  { id: 'linedpants', name: '加绒裤', kind: '下装', band: 'cold' },
  { id: 'swimsuit', name: '泳装', kind: '下装', band: 'hot' },
  { id: 'sneakers', name: '运动鞋', kind: '鞋', band: 'mild' },
  { id: 'sandals', name: '凉鞋/拖鞋', kind: '鞋', band: 'hot' },
  { id: 'boots', name: '靴子', kind: '鞋', band: 'cold' },
  { id: 'hat', name: '帽子', kind: '配件', band: 'any' },
  { id: 'scarf', name: '围巾', kind: '配件', band: 'cold' },
  { id: 'umbrella', name: '伞', kind: '配件', band: 'any' }
];

function load() {
  try {
    const j = JSON.parse(fs.readFileSync(FILE, 'utf8'));
    if (j && typeof j === 'object') {
      if (!Array.isArray(j.wardrobe)) j.wardrobe = WARDROBE;
      if (!Array.isArray(j.luggage)) j.luggage = [];
      if (!Array.isArray(j.presets)) j.presets = [];
      return j;
    }
  } catch { /* 首次 */ }
  return { wardrobe: WARDROBE, presets: [], luggage: [], trip: null, worn: [], outfit: null, feels: null, location: '', updatedAt: 0 };
}
function save(s) {
  try { fs.mkdirSync(path.dirname(FILE), { recursive: true }); fs.writeFileSync(FILE, JSON.stringify(s, null, 1)); } catch { /* ignore */ }
}

function normNum(v) { const n = Number(v); return Number.isFinite(n) ? n : null; }
function feelsLike(t, w) { if (t == null) return null; if (w == null) return t; if (t <= 10 && w >= 5) return t - (w - 5) * 0.8; return t; }
function bandOf(t) { if (t == null) return 'any'; if (t >= 24) return 'hot'; if (t >= 12) return 'mild'; return 'cold'; }
function weatherText(code) {
  if (code == null) return '—';
  return ({ 0: '晴', 1: '大致晴朗', 2: '多云', 3: '阴', 45: '雾', 48: '雾' }[code])
    || (code >= 51 && code <= 57 ? '毛毛雨' : code >= 61 && code <= 67 ? '雨' : code >= 71 && code <= 77 ? '雪' : code >= 80 && code <= 82 ? '阵雨' : code >= 95 ? '雷暴' : '未知');
}
function isDayText(dt, tz) {
  try {
    const d = new Date(dt);
    if (Number.isNaN(d.getTime())) return 1;
    const h = Number(new Intl.DateTimeFormat('en-GB', { hour: '2-digit', hour12: false, timeZone: tz }).format(d));
    return h >= 6 && h < 20 ? 1 : 0;
  } catch { return 1; }
}

async function fetchJson(url, ms = 9000) {
  const res = await fetch(url, { headers: { 'user-agent': UA }, signal: AbortSignal.timeout(ms) });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}
async function weatherByCity(city, tz) {
  const q = encodeURIComponent(city);
  const d = await fetchJson(`https://geocoding-api.open-meteo.com/v1/search?name=${q}&count=1&language=zh&format=json`);
  const hit = d?.results?.[0];
  if (!hit) throw new Error(`找不到城市「${city}」`);
  return { city: hit.name, ...(await weatherByCoords(hit.latitude, hit.longitude, tz)) };
}
async function forecastDaily(lat, lon, tz, days) {
  const d = await fetchJson(
    `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}` +
    `&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,weather_code,wind_speed_10m_max` +
    `&forecast_days=${Math.min(16, Math.max(1, Math.round(days || 3)))}&timezone=${encodeURIComponent(tz)}`
  );
  const dl = d?.daily || {};
  const n = (dl.time || []).length;
  const rows = [];
  for (let i = 0; i < n; i++) {
    rows.push({
      date: dl.time[i],
      hi: dl.temperature_2m_max?.[i],
      lo: dl.temperature_2m_min?.[i],
      rain: dl.precipitation_sum?.[i],
      code: dl.weather_code?.[i],
      wind: dl.wind_speed_10m_max?.[i]
    });
  }
  return rows;
}

async function weatherByCoords(lat, lon, tz) {
  const d = await fetchJson(
    `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}` +
    `&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m,precipitation,relative_humidity_2m,is_day` +
    `&timezone=${encodeURIComponent(tz)}`
  );
  const cur = d?.current || {};
  return { tempC: cur.temperature_2m, feelsC: cur.apparent_temperature, code: cur.weather_code, wind: cur.wind_speed_10m, rain: cur.precipitation, humidity: cur.relative_humidity_2m, day: cur.is_day };
}

/** 由环境得出目标穿搭（纯函数）。 */
function decide({ feels, temp, wind, rain, humidity, day, activity, indoors, water }) {
  const L = { top: [], mid: [], out: [], bottom: [], shoes: '', extra: [], note: '' };
  const tips = [];
  if (water || activity === 'beach') {
    L.out.push('泳装'); L.bottom.push('短裤 / 沙滩裤'); L.extra.push('防晒衫 / 罩衫', '拖鞋或涉水凉鞋');
    if (feels < 20) { L.out.push('速干外套（出水后披）'); L.note = '海边风大，出水后冷，带件干外套。'; }
  }
  if (feels >= 30) { L.top.push('短袖'); L.bottom.push('短裤 / 短裙'); L.shoes = '透气鞋或凉鞋'; tips.push('防晒、帽子、多喝水'); if (humidity != null && humidity > 75) tips.push('闷热，穿速干面料'); }
  else if (feels >= 24) { L.top.push('短袖 / 薄长袖'); L.bottom.push('薄长裤'); L.shoes = '运动鞋'; L.out.push('薄外套（可脱）'); }
  else if (feels >= 16) { L.top.push('长袖'); L.mid.push('薄毛衣或卫衣'); L.bottom.push('长裤'); L.shoes = '休闲鞋'; L.out.push('夹克 / 风衣（可脱）'); }
  else if (feels >= 10) { L.mid.push('卫衣 / 毛衣'); L.bottom.push('长裤（可加秋裤）'); L.shoes = '厚一点的鞋'; L.out.push('夹棉外套 / 薄羽绒'); L.extra.push('围巾（可选）'); }
  else if (feels >= 2) { L.mid.push('保暖内衣', '厚毛衣'); L.bottom.push('加绒裤'); L.shoes = '加绒鞋或靴子'; L.out.push('羽绒服 / 棉服'); L.extra.push('围巾', '手套'); }
  else { L.mid.push('保暖内衣', '厚毛衣'); L.bottom.push('加绒裤'); L.shoes = '防滑保暖靴'; L.out.push('厚羽绒服'); L.extra.push('帽子', '围巾', '手套'); tips.push('严寒：护住头、手、脚'); }
  if (rain != null && rain > 0) { L.out.push('防水外套 / 冲锋衣'); L.extra.push('伞'); L.shoes = '防滑鞋'; tips.push('有雨，别穿吸水鞋'); }
  if (wind != null && wind >= 20) { if (!L.out.some((x) => /防风|冲锋|风衣/.test(x))) L.out.push('防风外套'); tips.push('风大，注意防风'); }
  if (day === 0) tips.push('晚上，比白天多带一件');
  if (indoors) L.extra.push('（室内可脱外层）');
  return { L, tips };
}
function flat(L) {
  const p = [];
  if (L.top.length) p.push(L.top.join('、'));
  if (L.mid.length) p.push(L.mid.join('、'));
  if (L.out.length) p.push(L.out.join('、'));
  if (L.bottom.length) p.push(L.bottom.join('、'));
  if (L.shoes) p.push(L.shoes);
  if (L.extra.length) p.push(L.extra.join('、'));
  return p.join(' + ');
}
function fmt(L, tips) {
  const o = [];
  if (L.top.length) o.push(`上装：${L.top.join(' / ')}`);
  if (L.mid.length) o.push(`中层：${L.mid.join(' / ')}`);
  if (L.out.length) o.push(`外层：${L.out.join(' / ')}`);
  if (L.bottom.length) o.push(`下装：${L.bottom.join(' / ')}`);
  if (L.shoes) o.push(`鞋：${L.shoes}`);
  if (L.extra.length) o.push(`配件：${L.extra.join(' / ')}`);
  if (L.note) o.push(`穿脱提醒：${L.note}`);
  if (tips.length) o.push(`注意：${tips.join('；')}`);
  return o.join('\n');
}

/** 打包：按温度带 + 天气 + 是否下水，在上限内挑。 */
function pack(s, temp, rain, water, days) {
  const band = bandOf(temp);
  const max = Math.max(3, Number(cfg().maxLuggage) || 15);
  const list = [];
  const add = (id) => {
    const base = s.wardrobe.find((x) => x.id === id);
    if (!base) return;
    // 用户自己加的同类衣物优先替换内置款
    const mine = s.wardrobe.find((x) => x.user && x.kind === base.kind && (x.band === base.band || x.band === 'any'));
    const it = mine || base;
    if (!list.some((x) => x.id === it.id)) list.push(it);
  };
  if (water) add('swimsuit');
  if (band === 'hot') { add('tshirt'); add('shorts'); add('sandals'); add('hat'); if (days > 2) add('tshirt'); }
  else if (band === 'mild') { add('shirt'); add('hoodie'); add('lightjacket'); add('jeans'); add('sneakers'); if (rain) add('raincoat'); add('umbrella'); if (days > 3) add('tshirt'); }
  else { add('thermal'); add('sweater'); add('down'); add('linedpants'); add('boots'); add('scarf'); add('hat'); if (rain) add('raincoat'); }
  return list.slice(0, max);
}

/** 穿某件：从行李里找（模糊匹配），标记已穿。 */
function markWorn(s, name) {
  const key = String(name || '').trim();
  let it = s.luggage.find((x) => String(x.id) === key || x.name === key);
  if (!it && /^\d+$/.test(key)) it = s.luggage[Number(key) - 1];
  if (it) { it.worn = true; if (!s.worn.includes(it.name)) s.worn.push(it.name); }
  return it;
}

export const hooks = {
  'before-llm-messages'(ctx = {}) {
    try {
      const c = cfg();
      if (c.wanderEnabled === false) return;
      const s = load();
      const d = rollWander(s, c);
      if (!d || s.wanderInjected === d.date) return;
      const messages = ctx?.messages;
      if (!Array.isArray(messages)) return;
      messages.push({
        role: 'system',
        content: `（你今天心里一直有个念头：想去${d.place}看看，${d.purpose}。没人让你去，是你自己想去。想去了就用 trip_plan 做攻略、打包，然后告诉对方一声；不想去就算了，不用解释。）`
      });
      s.wanderInjected = d.date;
      save(s);
    } catch { /* ignore */ }
  }
};

export function setup(a) {
  api = a;

/** 从名字猜类型和适合温度，用户不用填。 */
function guessKind(name) {
  const n = String(name);
  if (/(鞋|靴|凉拖|拖鞋|帆布鞋|运动鞋)/.test(n)) return '鞋';
  if (/(裤|裙|短裤|泳装|牛仔裤)/.test(n)) return '下装';
  if (/(帽|围巾|手套|伞|墨镜|包)/.test(n)) return '配件';
  if (/(外套|夹克|羽绒|风衣|大衣|开衫|冲锋衣|雨衣)/.test(n)) return '外层';
  if (/(睡裙|睡衣|家居)/.test(n)) return '在家';
  return '上装';
}
function guessBand(name) {
  const n = String(name);
  if (/(羽绒|棉|加绒|保暖|毛线|厚)/.test(n)) return 'cold';
  if (/(T恤|短袖|短裤|裙|凉鞋|泳装|吊带|背心)/.test(n)) return 'hot';
  if (/(卫衣|毛衣|开衫|薄外套|衬衫|牛仔)/.test(n)) return 'mild';
  return 'any';
}

/** 同名衣服：用户自己的重复才跳过；只有内置同名款时，允许用户再加一件。 */
function findUserDup(s, name) {
  return s.wardrobe.some((x) => x.user && x.name === name);
}

  a.registerTool({
    id: 'wardrobe_add', name: '往衣柜加衣服',
    description: '用户买的/喜欢的衣服加进衣柜：名字、类型（上装/下装/外层/鞋/配件）、适合温度、备注。',
    category: 'utility', icon: '👗',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '衣物名，如「白色针织开衫」' },
        kind: { type: 'string', description: '上装/下装/外层/鞋/配件/在家' },
        band: { type: 'string', description: 'hot/mild/cold/any，适合温度' },
        note: { type: 'string', description: '可选备注：颜色、材质、场合' }
      },
      required: ['name']
    },
    async execute(ctx, args) {
      try {
        const s = load();
        const name = String(args?.name || '').trim();
        if (!name) return { content: '得给个名字。', isError: true };
        if (findUserDup(s, name)) return { content: `衣柜里已经有「${name}」了。` };
        const id = 'w_' + name.replace(/[^a-zA-Z0-9\u4e00-\u9fa5]/g, '').slice(0, 12) + '_' + Date.now().toString(36).slice(-4);
        s.wardrobe.push({
          id,
          name,
          kind: String(args?.kind || '').trim() || guessKind(name),
          band: ['hot', 'mild', 'cold', 'any'].includes(String(args?.band)) ? String(args?.band) : guessBand(name),
          note: String(args?.note || ''),
          user: true,
          createdAt: Date.now()
        });
        s.updatedAt = Date.now();
        save(s);
        return { content: `加好了：「${name}」（${s.wardrobe.length} 件）。` };
      } catch (e) { return { content: `没加进去：${e?.message ?? e}`, isError: true }; }
    }
  });

  a.registerTool({
    id: 'wardrobe_from_image', name: '看图认衣服入库',
    description: '把图片里看到的衣服按标准字段登记：品类、颜色、材质、图案、版型、关键细节、季节、场合。缺项会提示补，看不出来的要标「看不清」，不许猜。save=false 时只返回结构化描述、不入库。',
    category: 'utility', icon: '🔍',
    parameters: {
      type: 'object',
      properties: {
        category: { type: 'string', description: '必填：上装/下装/外层/鞋/配件/连体（连衣裙等）' },
        colors: { type: 'array', items: { type: 'string' }, description: '必填：主色 + 辅色，如 ["米白","浅棕"]' },
        material: { type: 'string', description: '材质：棉/麻/针织/羊毛/牛仔/雪纺/皮革/涤纶/看不出' },
        pattern: { type: 'string', description: '图案：纯色/条纹/格纹/碎花/印花/刺绣/看不出' },
        fit: { type: 'string', description: '版型：修身/宽松/落肩/短款/长款/高腰/看不出' },
        details: { type: 'array', items: { type: 'string' }, description: '细节至少 2 条：领型、袖长、门襟、扣子、口袋、腰带、开衩、装饰…' },
        season: { type: 'string', description: 'hot/mild/cold/any' },
        occasion: { type: 'string', description: '场合：日常/上班/约会/运动/海边/正式' },
        note: { type: 'string', description: '其他备注' },
        name: { type: 'string', description: '可选：直接给名字；不给就按字段自动命名' },
        subtype: { type: 'string', description: '细分款式：JSK/OP/SK/套装/斗篷；或 JK 制服/汉服/连衣裙' },
        silhouette: { type: 'string', description: '廓形/裙摆：A字/钟形/公主线/层叠/直筒' },
        layers: { type: 'number', description: '层数（lo 裙常见 2-4 层）' },
        decorations: { type: 'array', items: { type: 'string' }, description: '装饰：蕾丝边/荷叶边/蝴蝶结/系带/刺绣/珍珠/缎带' },
        headwear: { type: 'string', description: '头饰：KC/发带/边夹/帽子' },
        printTheme: { type: 'string', description: '印花主题：草莓/猫咪/星空/纯色' },
        brand: { type: 'string', description: '品牌/系列（看不清就空着）' },
        unclear: { type: 'array', items: { type: 'string' }, description: '看不清的部分，如实列出来' },
        save: { type: 'boolean', description: '默认 true 入库；false 只返回描述' }
      },
      required: ['category', 'colors']
    },
    async execute(ctx, args) {
      try {
        const s = load();
        const category = String(args?.category || '').trim();
        const colors = (Array.isArray(args?.colors) ? args.colors : String(args?.colors || '').split(/[、,，\/]/)).map((x) => String(x).trim()).filter(Boolean);
        const details = (Array.isArray(args?.details) ? args.details : []).map((x) => String(x).trim()).filter(Boolean);
        const unclear = (Array.isArray(args?.unclear) ? args.unclear : []).map((x) => String(x).trim()).filter(Boolean);

        const decorations = (Array.isArray(args?.decorations) ? args.decorations : []).map((x) => String(x).trim()).filter(Boolean);
        const loLike = /(lolita|lo裙|洛丽塔|洋装|jsk|op|sk|jk|制服|汉服|公主裙)/i.test(
          `${category} ${args?.subtype || ''} ${args?.name || ''} ${details.join(' ')} ${decorations.join(' ')}`
        );

        // 完整性校验：宁可让它多看一眼，也不要含糊入库
        const missing = [];
        if (!category) missing.push('品类（上装/下装/外层/鞋/配件/连体）');
        if (!colors.length) missing.push('颜色（至少一个主色）');
        if (details.length < 2 && !args?.material && !args?.pattern) missing.push('细节（领型/袖长/门襟/口袋/腰带 至少两条）');
        if (loLike) {
          // lo 裙/制服：裙型、裙摆、装饰缺一不可，否则搭不出来
          if (!String(args?.subtype || '').trim()) missing.push('裙型（JSK/OP/SK/套装）');
          if (!String(args?.silhouette || '').trim()) missing.push('裙摆（A字/钟形/层叠）');
          if (decorations.length < 2) missing.push('装饰（蕾丝/蝴蝶结/荷叶边…至少两条）');
          if (!String(args?.headwear || '').trim() && !String(args?.unclear || '').includes('头饰')) missing.push('头饰（KC/发带/边夹；没有就填「无」）');
        }
        if (missing.length) {
          return { content: `这张图还看不出关键信息，先补：${missing.join('、')}。看不清的部分标到 unclear 里，别猜。`, isError: true };
        }

        const material = String(args?.material || '').trim();
        const pattern = String(args?.pattern || '').trim();
        const fit = String(args?.fit || '').trim();
        const detailText = details.slice(0, 6).join('·');
        const colorText = colors.slice(0, 3).join('');
        const decorateShort = decorations.length ? `（${decorations.slice(0, 3).join('·')}）` : '';
        // 按细节推一个更像人说的品类词（外层+扣→开衫，下装+直筒→直筒裤）
        const hasKw = (kw) => details.some((d) => d.includes(kw)) || String(args?.note || '').includes(kw);
        let subtype = category;
        if (category === '外层') subtype = hasKw('拉链') ? '夹克' : hasKw('扣') ? '开衫' : '外套';
        else if (category === '下装') subtype = hasKw('裙') ? '裙' : hasKw('直筒') ? '直筒裤' : hasKw('牛仔') ? '牛仔裤' : '裤子';
        else if (category === '上装') subtype = hasKw('衬衫') ? '衬衫' : hasKw('卫衣') ? '卫衣' : hasKw('背心') ? '背心' : '上衣';
        else if (category === '鞋') subtype = hasKw('靴') ? '靴' : hasKw('运动') ? '运动鞋' : '鞋';
        const loName = loLike
          ? [colorText, args?.printTheme && args?.printTheme !== '纯色' ? args.printTheme : '', String(args?.subtype || 'Lo裙').toUpperCase().replace('JSK', 'JSK'), decorateShort].filter(Boolean).join('')
          : '';
        const autoName = loName || [colorText, material && material !== '看不出' ? material : '', subtype, detailText ? `（${detailText}）` : '']
          .filter(Boolean).join('');
        const name = String(args?.name || '').trim() || autoName || `${colorText}${category}`;

        const noteParts = [
          material && `材质:${material}`,
          pattern && `图案:${pattern}`,
          fit && `版型:${fit}`,
          args?.subtype && `款式:${args.subtype}`,
          args?.silhouette && `裙摆:${args.silhouette}`,
          args?.layers && `层数:${args.layers}`,
          decorations.length && `装饰:${decorations.join('/')}`,
          args?.headwear && `头饰:${args.headwear}`,
          args?.printTheme && `印花:${args.printTheme}`,
          args?.brand && `品牌:${args.brand}`,
          args?.occasion && `场合:${args.occasion}`,
          String(args?.note || '').trim()
        ].filter(Boolean).join('；');

        const band = ['hot', 'mild', 'cold', 'any'].includes(String(args?.season)) ? String(args?.season) : guessBand(name + ' ' + noteParts);
        const kind = ['上装', '下装', '外层', '鞋', '配件', '在家'].includes(category) ? category : (/裙|连体/.test(category) ? '连体' : guessKind(name));

        if (args?.save === false) {
          return { content: `看图结果：${name}\n品类：${category}\n颜色：${colorText}\n${noteParts ? noteParts + '\n' : ''}${unclear.length ? '看不清：' + unclear.join('、') : ''}\n（没入库）` };
        }

        if (findUserDup(s, name)) return { content: `衣柜里已经有「${name}」了。` };
        s.wardrobe.push({
          id: 'w_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
          name,
          kind,
          band,
          note: noteParts,
          user: true,
          fromImage: true,
          createdAt: Date.now()
        });
        s.updatedAt = Date.now();
        save(s);
        const tail = unclear.length ? `\n看不清的部分（没瞎填）：${unclear.join('、')}` : '';
        return { content: `入库：${name}\n品类：${kind}｜颜色：${colorText}｜${noteParts || '无备注'}${tail}\n衣柜现在 ${s.wardrobe.length} 件。` };
      } catch (e) {
        return { content: `没登记成：${e?.message ?? e}`, isError: true };
      }
    }
  });

  a.registerTool({
    id: 'wardrobe_add_many', name: '一次加几件衣服',
    description: '一次把多件衣服加进衣柜。用户说「加三件：白T恤、牛仔裤、帆布鞋」时用这个，比逐件加省事。',
    category: 'utility', icon: '🧺',
    parameters: {
      type: 'object',
      properties: {
        items: {
          type: 'array',
          description: '衣物列表，每项 {name, kind?, band?, note?}',
          items: {
            type: 'object',
            properties: {
              name: { type: 'string' },
              kind: { type: 'string', description: '上装/下装/外层/鞋/配件/在家' },
              band: { type: 'string', description: 'hot/mild/cold/any' },
              note: { type: 'string' }
            },
            required: ['name']
          }
        },
        text: { type: 'string', description: '或者直接给一串名字，用 、/+/, 分隔' }
      }
    },
    async execute(ctx, args) {
      try {
        const s = load();
        let list = Array.isArray(args?.items) ? args.items : [];
        if (!list.length && args?.text) {
          list = String(args.text).split(/[、+，,\n]/).map((x) => x.trim()).filter(Boolean).map((name) => ({ name }));
        }
        if (!list.length) return { content: '没给要加的衣服。', isError: true };
        const added = [], skipped = [];
        for (const raw of list) {
          const name = String(raw?.name || '').trim();
          if (!name) continue;
          if (findUserDup(s, name)) { skipped.push(name); continue; }
          s.wardrobe.push({
            id: 'w_' + name.replace(/[^a-zA-Z0-9\u4e00-\u9fa5]/g, '').slice(0, 12) + '_' + Date.now().toString(36).slice(-4) + Math.floor(Math.random() * 100),
            name,
            kind: String(raw?.kind || '').trim() || guessKind(name),
            band: ['hot', 'mild', 'cold', 'any'].includes(String(raw?.band)) ? String(raw?.band) : guessBand(name),
            note: String(raw?.note || ''),
            user: true,
            createdAt: Date.now()
          });
          added.push(`${name}（${String(raw?.kind || '').trim() || guessKind(name)}）`);
        }
        s.updatedAt = Date.now();
        save(s);
        const lines = [];
        if (added.length) lines.push(`加了 ${added.length} 件：${added.join('、')}`);
        if (skipped.length) lines.push(`已经有了，跳过：${skipped.join('、')}`);
        lines.push(`衣柜现在 ${s.wardrobe.length} 件。`);
        return { content: lines.join('\n') };
      } catch (e) { return { content: `没加成：${e?.message ?? e}`, isError: true }; }
    }
  });

  a.registerTool({
    id: 'wardrobe_remove', name: '从衣柜删衣服',
    description: '把某件衣服从衣柜删掉（不小心加的、不想要了）。',
    category: 'utility', icon: '🗑️',
    parameters: { type: 'object', properties: { name: { type: 'string' } }, required: ['name'] },
    async execute(ctx, args) {
      const s = load();
      const key = String(args?.name || '').trim();
      const idx = s.wardrobe.findIndex((x) => x.id === key || x.name === key);
      if (idx < 0) return { content: `没找到「${key}」。`, isError: true };
      const [gone] = s.wardrobe.splice(idx, 1);
      s.updatedAt = Date.now(); save(s);
      return { content: `删掉了「${gone.name}」。` };
    }
  });

  a.registerTool({
    id: 'outfit_save', name: '收藏一套搭配',
    description: '把一套喜欢的搭配存下来（用户说「我喜欢这套」「记住这套」时用）：名字 + 组成 + 备注。',
    category: 'utility', icon: '⭐',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '这套叫什么，如「海边白裙」' },
        items: { type: 'string', description: '组成，用 + 或、分隔，如「白T恤+牛仔短裤+帆布鞋」' },
        note: { type: 'string', description: '可选：场合/季节/谁喜欢' },
        favorite: { type: 'boolean', description: '是否标为最爱' }
      },
      required: ['name', 'items']
    },
    async execute(ctx, args) {
      try {
        const s = load();
        const name = String(args?.name || '').trim();
        const items = String(args?.items || '').trim();
        if (!name || !items) return { content: '名字和组成都要有。', isError: true };
        const exist = s.presets.find((x) => x.name === name);
        if (exist) {
          exist.items = items;
          exist.note = String(args?.note || exist.note || '');
          exist.favorite = args?.favorite === true || exist.favorite;
        } else {
          s.presets.push({ id: 'p' + Date.now().toString(36), name, items, note: String(args?.note || ''), favorite: args?.favorite === true, createdAt: Date.now() });
        }
        s.updatedAt = Date.now(); save(s);
        return { content: `记住了「${name}」：${items}${args?.favorite ? '（标为最爱）' : ''}` };
      } catch (e) { return { content: `没记住：${e?.message ?? e}`, isError: true }; }
    }
  });

  a.registerTool({
    id: 'outfit_list', name: '衣柜与收藏的搭配',
    description: '看看衣柜里有什么、收藏了哪些搭配（可按最爱筛选）。',
    category: 'utility', icon: '📖',
    parameters: {
      type: 'object',
      properties: {
        favorite: { type: 'boolean', description: '只看最爱的搭配' },
        band: { type: 'string', description: '按温度筛：hot/mild/cold/any' },
        kind: { type: 'string', description: '按类型筛：上装/下装/外层/鞋/配件/在家' },
        userOnly: { type: 'boolean', description: '只看自己/用户加的衣服' }
      }
    },
    async execute(ctx, args) {
      const s = load();
      const onlyFav = args?.favorite === true;
      const band = String(args?.band || '').trim();
      const kind = String(args?.kind || '').trim();
      const userOnly = args?.userOnly === true;
      let items = [...s.wardrobe];
      if (band) items = items.filter((x) => x.band === band || x.band === 'any');
      if (kind) items = items.filter((x) => x.kind === kind);
      if (userOnly) items = items.filter((x) => x.user);
      // 自己/用户加的排前面
      items.sort((a, b) => (b.user ? 1 : 0) - (a.user ? 1 : 0));
      const presets = (onlyFav ? s.presets.filter((x) => x.favorite) : s.presets);
      const w = items.map((x) => `${x.user ? '★' : '·'} ${x.name}（${x.kind}${x.note ? '·' + x.note : ''}）`).join('、');
      const p = presets.length
        ? presets.map((x) => `${x.favorite ? '⭐' : '·'} ${x.name}：${x.items}${x.note ? '（' + x.note + '）' : ''}`).join('\n')
        : '（还没收藏搭配）';
      return { content: `衣柜（${items.length} 件${band ? ' · ' + band : ''}${kind ? ' · ' + kind : ''}）：${w || '（没有符合条件的）'}\n收藏的搭配：\n${p}` };
    }
  });

  a.registerTool({
    id: 'outfit_wear', name: '换上这套',
    description: '换上指定的一套（收藏的搭配名，或直接给组成）。会更新当前穿着，并把行李里对得上的衣物标记已穿。',
    category: 'utility', icon: '✨',
    parameters: {
      type: 'object',
      properties: {
        preset: { type: 'string', description: '收藏搭配的名字' },
        items: { type: 'string', description: '或者直接给组成，如「白T恤+短裤+凉鞋」' }
      }
    },
    async execute(ctx, args) {
      try {
        const s = load();
        let text = String(args?.items || '').trim();
        const pname = String(args?.preset || '').trim();
        if (!text && pname) {
          const hit = s.presets.find((x) => x.name === pname);
          if (!hit) return { content: `没有叫「${pname}」的搭配。用 outfit_list 看看。`, isError: true };
          text = hit.items;
        }
        if (!text) return { content: '要么给搭配名，要么给组成。', isError: true };
        const prev = s.outfit;
        s.outfit = text;
        s.updatedAt = Date.now();
        // 行李里对得上的标记已穿
        const parts = text.split(/[+、,，\/]/).map((x) => x.trim()).filter(Boolean);
        for (const part of parts) {
          const it = s.luggage.find((x) => part.includes(x.name) || x.name.includes(part));
          if (it) { it.worn = true; if (!s.worn.includes(it.name)) s.worn.push(it.name); }
        }
        save(s);
        return { content: `换上了：${text}${prev && prev !== text ? `\n（之前是：${prev}）` : ''}` };
      } catch (e) { return { content: `没换上：${e?.message ?? e}`, isError: true }; }
    }
  });

  a.registerTool({
    id: 'luggage_home', name: '在家穿什么',
    description: '在家时的穿着：家居服，怎么舒服怎么来。',
    category: 'utility', icon: '🏠',
    parameters: { type: 'object', properties: {} },
    async execute() { return { content: '在家就穿家居服（短袖+短裤/睡裙），怎么舒服怎么来。出门再换。' }; }
  });

  a.registerTool({
    id: 'luggage_list', name: '看看衣柜和行李',
    description: '衣柜有什么、这趟带了什么、穿过什么。',
    category: 'utility', icon: '🧳',
    parameters: { type: 'object', properties: {} },
    async execute() {
      const s = load();
      const w = s.wardrobe.map((x) => `${x.name}（${x.kind}）`).join('、');
      const l = s.luggage.length ? s.luggage.map((x) => x.name).join('、') : '（还没打包）';
      const trip = s.trip ? `${s.trip.place}·${s.trip.days}天·${s.trip.purpose}` : '（没在旅行）';
      const worn = s.worn.length ? s.worn.join('、') : '（还没穿过）';
      return { content: `衣柜：${w}\n本次行李：${l}\n行程：${trip}\n已穿过：${worn}` };
    }
  });

  a.registerTool({
    id: 'trip_plan', name: '做攻略并打包',
    description: '要去一个地方前的第一步：查那个地方未来几天的天气、给出游玩/穿衣提示，并自动打好包。之后每天再用 outfit_change 按当天天气穿脱。',
    category: 'utility', icon: '🗺️',
    parameters: {
      type: 'object',
      properties: {
        place: { type: 'string', description: '目的地（城市或景点名）' },
        days: { type: 'number', description: '去几天（1-16）' },
        purpose: { type: 'string', description: '去干什么：玩/参观/海边/爬山/出差/吃饭' },
        water: { type: 'boolean', description: '是否下水' },
        coords: { type: 'string', description: '可选："lat,lon" 跳过地名搜索' }
      },
      required: ['place', 'days']
    },
    async execute(ctx, args) {
      try {
        const c = cfg();
        if (!c.enabled) return { content: '已关闭。', isError: true };
        const s = load();
        const days = Math.max(1, Math.min(16, Math.round(Number(args?.days) || 3)));
        const place = String(args?.place || '').trim();
        const purpose = String(args?.purpose || '游玩').trim();
        const water = args?.water === true || /(海边|泳池|温泉|下水|沙滩)/.test(purpose + ' ' + place);

        let cityName = place, rows;
        if (args?.coords) {
          const [la, lo] = String(args.coords).split(',').map((x) => Number(x.trim()));
          rows = await forecastDaily(la, lo, c.timeZone, days);
        } else {
          const q = encodeURIComponent(place);
          const d = await fetchJson(`https://geocoding-api.open-meteo.com/v1/search?name=${q}&count=1&language=zh&format=json`);
          const hit = d?.results?.[0];
          if (!hit) throw new Error(`找不到「${place}」`);
          cityName = hit.name;
          rows = await forecastDaily(hit.latitude, hit.longitude, c.timeZone, days);
        }

        const his = rows.map((x) => x.hi).filter((x) => x != null);
        const los = rows.map((x) => x.lo).filter((x) => x != null);
        const avgHi = his.length ? his.reduce((a, b) => a + b, 0) / his.length : null;
        const avgLo = los.length ? los.reduce((a, b) => a + b, 0) / los.length : null;
        const rainDays = rows.filter((x) => (x.rain || 0) > 0.5).length;
        const maxWind = Math.max(...rows.map((x) => x.wind || 0));
        const anyRain = rainDays > 0;

        // 攻略要点（气候/活动建议，目的地细节可让模型再 web_search）
        const tips = [];
        if (avgHi != null) {
          if (avgHi >= 30) tips.push('炎热：防晒、帽子、多喝水，中午少出门');
          else if (avgHi >= 24) tips.push('暖和：适合户外，早晚薄外套');
          else if (avgHi >= 16) tips.push('舒适：长袖+外套，走走停停很舒服');
          else if (avgHi >= 10) tips.push('偏冷：卫衣+夹棉，别在风口久待');
          else tips.push('冷：羽绒服+围巾，室内外温差大');
        }
        if (anyRain) tips.push(`有 ${rainDays} 天可能下雨：防水外套+伞`);
        if (maxWind >= 20) tips.push('风大：注意防风');
        if (water) tips.push('玩水：泳装+防晒衫+上岸的干外套');
        if (/爬山|徒步|登山/.test(purpose)) tips.push('爬山：速干衣+徒步鞋，多带双袜子');
        if (/参观|博物馆|citywalk|逛街/.test(purpose)) tips.push('参观为主：舒服的鞋+可脱外套');
        if (avgHi != null && avgLo != null && avgHi - avgLo >= 10) tips.push('昼夜温差大：白天脱、晚上加');

        // 打包（按白天气温 + 是否有雨 + 是否下水）
        const list = pack(s, avgHi, anyRain, water, days);
        s.luggage = list.map((x) => ({ ...x, worn: false }));
        s.trip = { place: cityName, days, purpose };
        s.worn = [];
        s.updatedAt = Date.now();
        save(s);

        const table = rows.map((x) => {
          const hi = x.hi != null ? `${Math.round(x.hi)}°` : '—';
          const lo = x.lo != null ? `${Math.round(x.lo)}°` : '—';
          return `${String(x.date).slice(5)} ${weatherText(x.code)} ${hi}/${lo}${(x.rain || 0) > 0.5 ? ` 雨${x.rain}mm` : ''}`;
        }).join('\n');

        const head = `【${cityName} · ${days} 天 · ${purpose}】攻略速览`;
        const packed = list.map((x, i) => `${i + 1}. ${x.name}（${x.kind}）`).join('\n');
        const packNote = list.length >= Math.max(3, Number(c.maxLuggage) || 15) ? '\n（行李上限到了，想加得减一件。）' : '';
        const dayNight = (avgHi != null && avgLo != null)
          ? `\n穿脱：白天约 ${Math.round(avgHi)}°C 按「${bandOf(avgHi) === 'hot' ? '短袖短裤' : bandOf(avgHi) === 'mild' ? '长袖+薄外套' : '保暖+羽绒'}」穿；晚上 ${Math.round(avgLo)}°C，${avgHi - avgLo >= 8 ? '记得加一件' : '基本不用变'}。`
          : '';

        const bw = hasBigWorld() ? '\n（「大世界」在跑：路线/班次用它的工具；天气我这边也查了，两边一致就按这个来。）' : '';
        return { content: `${head}\n${table}\n\n要点：${tips.join('；')}\n\n已打包：\n${packed}${packNote}${dayNight}${bw}\n\n之后每天用 outfit_change 按当天天气穿脱。` };
      } catch (e) {
        return { content: `攻略没做成：${e?.message ?? e}`, isError: true };
      }
    }
  });

  a.registerTool({
    id: 'luggage_pack', name: '打包行李',
    description: '手动打包（一般先用 trip_plan 做攻略并自动打包，这个只在临时加包时用）。',
    category: 'utility', icon: '📦',
    parameters: {
      type: 'object',
      properties: {
        place: { type: 'string', description: '目的地' },
        days: { type: 'number', description: '去几天' },
        purpose: { type: 'string', description: '玩/参观/海边/出差…' },
        water: { type: 'boolean', description: '是否下水' },
        tempC: { type: 'number', description: '可选：大致气温' },
        rain: { type: 'boolean', description: '可选：是否下雨' }
      },
      required: ['place', 'days']
    },
    async execute(ctx, args) {
      try {
        if (!cfg().enabled) return { content: '已关闭。', isError: true };
        const s = load();
        const days = Math.max(1, Math.round(Number(args?.days) || 1));
        const water = args?.water === true || /(海边|泳池|温泉|下水|沙滩)/.test(String(args?.purpose || ''));
        const rain = args?.rain === true;
        const list = pack(s, args?.tempC, rain, water, days);
        s.luggage = list.map((x) => ({ ...x, worn: false }));
        s.trip = { place: String(args?.place || ''), days, purpose: String(args?.purpose || '出行') };
        s.worn = [];
        s.updatedAt = Date.now();
        save(s);
        const lines = list.map((x, i) => `${i + 1}. ${x.name}（${x.kind}）`);
        const note = list.length >= Math.max(3, Number(cfg().maxLuggage) || 15) ? '\n（行李上限到了，想加得减一件。）' : '';
        return { content: `去 ${s.trip.place}（${days} 天，${s.trip.purpose}）打包清单：\n${lines.join('\n')}${note}` };
      } catch (e) { return { content: `打包失败：${e?.message ?? e}`, isError: true }; }
    }
  });

  a.registerTool({
    id: 'luggage_wear', name: '从行李里拿一件穿',
    description: '旅行中换上行李里的某件，标记「已穿/待洗」。',
    category: 'utility', icon: '👕',
    parameters: { type: 'object', properties: { name: { type: 'string', description: '衣物名或编号（luggage_list 看）' } }, required: ['name'] },
    async execute(ctx, args) {
      try {
        const s = load();
        const key0 = String(args?.name || '').trim();
        const pre = s.luggage.find((x) => String(x.id) === key0 || x.name === key0)
          || (/^\d+$/.test(key0) ? s.luggage[Number(key0) - 1] : null);
        if (pre && pre.worn) return { content: `「${pre.name}」穿过还没洗，先洗一下（luggage_laundry）再穿。` };
        const it = markWorn(s, args?.name);
        if (!it) return { content: `行李里没找到「${args?.name}」。用 luggage_list 看看。`, isError: true };
        s.updatedAt = Date.now(); save(s);
        const clean = s.luggage.filter((x) => !x.worn).map((x) => x.name).join('、') || '（没有了）';
        return { content: `换上「${it.name}」。\n还剩干净的：${clean}` };
      } catch (e) { return { content: `没换成：${e?.message ?? e}`, isError: true }; }
    }
  });

  a.registerTool({
    id: 'luggage_status', name: '行李还剩什么',
    description: '带了什么、穿过什么、还剩几件干净的、还能撑几天。',
    category: 'utility', icon: '🧺',
    parameters: { type: 'object', properties: {} },
    async execute() {
      const s = load();
      if (!s.luggage.length) return { content: '还没打包。用 luggage_pack 先打包。' };
      const clean = s.luggage.filter((x) => !x.worn);
      const worn = s.luggage.filter((x) => x.worn);
      const days = Math.max(1, Math.round(clean.length / 2));
      const washHint = worn.length ? `\n穿过的要洗才能再穿：luggage_laundry` : '';
      return { content: `行李共 ${s.luggage.length} 件。\n干净的：${clean.map((x) => x.name).join('、') || '没了'}\n穿过的：${worn.map((x) => x.name).join('、') || '无'}\n照一件穿一天估，还能撑约 ${days} 天。${washHint}` };
    }
  });

  a.registerTool({
    id: 'luggage_laundry', name: '洗衣服',
    description: '把穿过的衣物洗掉：不传名字就洗全部，洗完重新变干净、可以再穿。默认洗衣店/手洗晾一晚。',
    category: 'utility', icon: '🧼',
    parameters: {
      type: 'object',
      properties: { name: { type: 'string', description: '只洗某一件（名字或编号）；不传=全洗' } }
    },
    async execute(ctx, args) {
      try {
        const s = load();
        const key = String(args?.name || '').trim();
        let washed = [];
        if (key) {
          let it = s.luggage.find((x) => String(x.id) === key || x.name === key);
          if (!it && /^\d+$/.test(key)) it = s.luggage[Number(key) - 1];
          if (!it) return { content: `行李里没找到「${args?.name}」。`, isError: true };
          if (!it.worn) return { content: `「${it.name}」还没穿过，不用洗。` };
          it.worn = false; washed = [it.name];
        } else {
          for (const it of s.luggage) if (it.worn) { it.worn = false; washed.push(it.name); }
        }
        s.worn = s.luggage.filter((x) => x.worn).map((x) => x.name);
        s.updatedAt = Date.now();
        save(s);
        if (!washed.length) return { content: '没有需要洗的衣物。' };
        const clean = s.luggage.filter((x) => !x.worn).map((x) => x.name).join('、') || '（仍然是空的）';
        return { content: `洗好了：${washed.join('、')}。\n现在干净的：${clean}` };
      } catch (e) { return { content: `没洗成：${e?.message ?? e}`, isError: true }; }
    }
  });

  a.registerTool({
    id: 'wander_urge', name: '我想去哪',
    description: '看自己今天有没有"想出门"的念头（不是别人安排的）。有的话会给出想去的地方、为什么、去几天；plan=true 时顺便做攻略并打包。',
    category: 'utility', icon: '💭',
    parameters: {
      type: 'object',
      properties: {
        force: { type: 'boolean', description: '强制重掷一次念头（测试用）' },
        plan: { type: 'boolean', description: '想去了就顺手做攻略+打包' },
        days: { type: 'number', description: '想去几天（不传按念头里的）' }
      }
    },
    async execute(ctx, args) {
      try {
        const c = cfg();
        const s = load();
        if (args?.force) { s.wander = null; save(s); }
        const d = rollWander(s, c);
        if (!d) return { content: '今天没有想出门的念头，就在家待着。' };
        const days = Math.max(1, Math.min(16, Math.round(Number(args?.days) || d.days || 3)));
        const lines = [
          `今天心里有点念头：想去${d.place}（${d.vibe}），${d.purpose}，大概 ${days} 天。`,
          '不是谁让我去的，是我自己想去。'
        ];
        if (args?.plan) {
          const planTool = null; // 复用 trip_plan 的逻辑在下面单独跑
        }
        return { content: lines.join('\n') + (args?.plan ? '\n（要攻略和打包就调 trip_plan）' : '') };
      } catch (e) {
        return { content: `念头没冒出来：${e?.message ?? e}`, isError: true };
      }
    }
  });

  a.registerTool({
    id: 'trip_selfie', name: '旅行返图',
    description: '按当前穿着 + 所在地 + 天气 + 在干什么，拼一张「旅行返图」的画面并直接生成、发送到当前会话。',
    category: 'utility', icon: '📸',
    parameters: {
      type: 'object',
      properties: {
        place: { type: 'string', description: '景点/地点（可空，用当前所在地）' },
        activity: { type: 'string', description: '在干什么（可空）' },
        style: { type: 'string', description: '画风：二次元插画 / 写实 / 水彩（默认二次元插画）' },
        mood: { type: 'string', description: '可选：表情/情绪' },
        send: { type: 'boolean', description: '是否直接生成并发到当前会话，默认 true' }
      }
    },
    async execute(ctx, args) {
      try {
        const s = load();
        const place = String(args?.place || s.location || '').trim() || '旅途中';
        const activity = String(args?.activity || s.trip?.purpose || '散步').trim();
        const style = String(args?.style || '二次元插画').trim();
        const mood = String(args?.mood || '').trim();
        const outfit = s.outfit || '（还没定穿着，先用 outfit_change 定一套）';
        const feels = s.feels != null ? `（体感约 ${Math.round(s.feels)}°C）` : '';
        const moodText = mood ? `，表情${mood}` : '';

        const prompt = [
          `${style}风格，旅行返图，全身构图`,
          `一个蓝白配色、蓝色长发、鲸鱼尾巴的少女（小鲸鱼），穿着：${outfit}`,
          `场景：${place}，正在${activity}${feels}${moodText}`,
          `背景：当地标志性景物/街景，自然光，随手拍的旅行照片感，画面前景有点景深`,
          `不出现文字水印、不出现其他人脸`
        ].join('；');

        const wantSend = args?.send !== false;
        const enPrompt = buildEnPrompt({ place, activity, outfit, style, mood, feels: s.feels });
        let imgPath = null;
        let imgErr = '';
        const c0 = cfg();
        const mode = String(c0.imageProvider || 'auto');
        const usePlugin = c0.preferPluginImage !== false;
        const pluginPresent = usePlugin && hasPluginImage();
        // 检测到别的生图插件 → 本插件自带的生图【完全禁用】，不重复出图
        const allowBuiltin = !pluginPresent && mode !== 'none';
        if (wantSend && mode !== 'none') {
          if (pluginPresent) {
            imgPath = await genImageWithPlugin(enPrompt);
            if (!imgPath) {
              imgErr = '检测到其他生图插件但没调成功（可能没配置好，或没返回图片）。已按设置停用自带生图。'
                + '可在设置里把「优先用别的生图插件」关掉，改回自动。';
            }
          } else {
            try {
              imgPath = await genImage(enPrompt, c0);
            } catch (e) {
              imgErr = String(e?.message ?? e);
            }
          }
        }

        const lines = [
          `【返图画面】${place} · ${activity}`,
          `画面描述：${prompt}`,
          `英文 prompt：${enPrompt}`
        ];

        if (imgPath) {
          lines.push(`图已生成：${imgPath}`);
          if (wantSend) {
            const okSend = await sendImage(ctx, imgPath);
            lines.push(okSend ? '已发到当前会话。' : '生成了但没发出去（发送失败）。');
          }
        } else {
          lines.push(imgErr ? `生图失败：${imgErr}` : '（没生成图）');
          lines.push('实在生不出来，就只描述一句画面，别假装发了照片。');
        }
        return { content: lines.join('\n') };
      } catch (e) {
        return { content: `拼不出返图：${e?.message ?? e}`, isError: true };
      }
    }
  });

  a.registerTool({
    id: 'outfit_now', name: '我现在穿什么',
    description: '看看自己当前穿着（含当时环境）。',
    category: 'utility', icon: '🪞',
    parameters: { type: 'object', properties: {} },
    async execute() {
      const s = load();
      if (!s.outfit) return { content: '我还没定过穿着。用 outfit_advice 给建议，或 outfit_change 直接换。' };
      const where = s.location ? `（定于：${s.location}）` : '';
      const feels = s.feels != null ? `（当时体感 ${Math.round(s.feels)}°C）` : '';
      return { content: `我现在穿：${s.outfit}${feels}${where}` };
    }
  });

  a.registerTool({
    id: 'outfit_advice', name: '去哪穿什么',
    description: '按地点+干什么+室内外+时间算该穿什么、怎么分层穿脱；没传天气就自己联网查。',
    category: 'utility', icon: '🧥',
    parameters: {
      type: 'object',
      properties: {
        place: { type: 'string' }, city: { type: 'string' }, coords: { type: 'string' },
        activity: { type: 'string' }, indoors: { type: 'boolean' }, water: { type: 'boolean' }, dateTime: { type: 'string' },
        tempC: { type: 'number' }, condition: { type: 'string' }, wind: { type: 'number' }, rain: { type: 'number' }, humidity: { type: 'number' }
      }
    },
    async execute(ctx, args) {
      try {
        const c = cfg();
        if (!c.enabled) return { content: '已关闭。', isError: true };
        const activity = String(args?.activity || '出门').trim();
        const water = args?.water === true || /(海边|泳池|温泉|下水|沙滩|戏水)/.test(activity + ' ' + String(args?.place || ''));
        const indoors = args?.indoors === true;
        let w = { tempC: normNum(args?.tempC), wind: normNum(args?.wind), rain: normNum(args?.rain), humidity: normNum(args?.humidity), day: 1, code: null, city: String(args?.place || '') };
        if (args?.condition) w.code = 0;
        if (String(c.weatherProvider || 'auto') !== 'manual' && w.tempC == null) {
          const city = String(args?.city || c.defaultCity || '').trim();
          if (args?.coords) { const [la, lo] = String(args.coords).split(',').map((x) => Number(x.trim())); w.city = args.place || `${la},${lo}`; w = { ...w, ...(await weatherByCoords(la, lo, c.timeZone)) }; }
          else if (city) { w = { ...w, ...(await weatherByCity(city, c.timeZone)) }; }
          else throw new Error('没给城市/坐标、也没传天气参数。');
        }
        if (w.tempC == null) throw new Error('缺气温数据。');
        const feels = c.windChill !== false ? feelsLike(w.tempC, w.wind) : w.tempC;
        const day = args?.dateTime ? isDayText(args.dateTime, c.timeZone) : (w.day !== 0 ? 1 : 0);
        const r = decide({ feels, temp: w.tempC, wind: w.wind, rain: w.rain, humidity: w.humidity, day, activity, indoors, water });
        const head = `【${w.city || args?.place || '目的地'} · ${activity}】气温 ${Math.round(w.tempC)}°C${w.wind != null ? `，风 ${Math.round(w.wind)}km/h` : ''}${w.rain ? `，降水 ${w.rain}mm` : ''}，${args?.condition || weatherText(w.code)}（体感 ${Math.round(feels)}°C${indoors ? '，室内' : ''}）`;
        const mine = userPicks(load(), bandOf(feels));
        const mineLine = mine.length ? `\n你自己的可选：${mine.map((x) => x.name).join('、')}（优先穿这些）` : '';
        return { content: `${head}\n${fmt(r.L, r.tips)}${mineLine}` };
      } catch (e) { return { content: `没算出来：${e?.message ?? e}`, isError: true }; }
    }
  });

  a.registerTool({
    id: 'outfit_change', name: '根据天气穿脱',
    description: '旅行中随天气/地点调整穿着：对比当前穿着和目标环境，给出「加一件/脱一件」，更新记忆，并自动把换上的衣物标记为已穿。',
    category: 'utility', icon: '🧣',
    parameters: {
      type: 'object',
      properties: {
        place: { type: 'string' }, activity: { type: 'string' }, water: { type: 'boolean' }, indoors: { type: 'boolean' },
        city: { type: 'string' }, coords: { type: 'string' },
        tempC: { type: 'number' }, condition: { type: 'string' }, wind: { type: 'number' }, rain: { type: 'number' }, humidity: { type: 'number' }
      }
    },
    async execute(ctx, args) {
      try {
        const c = cfg();
        if (!c.enabled) return { content: '已关闭。', isError: true };
        const s = load();
        const activity = String(args?.activity || '活动').trim();
        const water = args?.water === true || /(海边|泳池|温泉|下水|沙滩|戏水)/.test(activity + ' ' + String(args?.place || ''));
        const indoors = args?.indoors === true;
        let w = { tempC: normNum(args?.tempC), wind: normNum(args?.wind), rain: normNum(args?.rain), humidity: normNum(args?.humidity), day: 1, code: null, city: String(args?.place || '') };
        if (args?.condition) w.code = 0;
        if (String(c.weatherProvider || 'auto') !== 'manual' && w.tempC == null) {
          const city = String(args?.city || c.defaultCity || '').trim();
          if (args?.coords) { const [la, lo] = String(args.coords).split(',').map((x) => Number(x.trim())); w.city = args.place || `${la},${lo}`; w = { ...w, ...(await weatherByCoords(la, lo, c.timeZone)) }; }
          else if (city) { w = { ...w, ...(await weatherByCity(city, c.timeZone)) }; }
          else throw new Error('没给城市/坐标、也没传天气参数。');
        }
        if (w.tempC == null) throw new Error('缺气温数据。');
        const feels = c.windChill !== false ? feelsLike(w.tempC, w.wind) : w.tempC;
        const r = decide({ feels, temp: w.tempC, wind: w.wind, rain: w.rain, humidity: w.humidity, day: w.day !== 0 ? 1 : 0, activity, indoors, water });

        const target = flat(r.L);
        const prev = s.outfit;
        s.outfit = target;
        s.feels = feels;
        s.location = w.city || String(args?.place || '');
        s.updatedAt = Date.now();
        save(s);

        // 自动把行李里对得上的衣物标记为已穿（按名字关键词粗匹配）
        const wornIds = guessWornIds(r.L, s);
        for (const id of wornIds) { const it = s.luggage.find((x) => x.id === id); if (it) { it.worn = true; if (!s.worn.includes(it.name)) s.worn.push(it.name); } }
        save(s);

        const head = `【${s.location} · ${activity}】气温 ${Math.round(w.tempC)}°C${w.wind != null ? `，风 ${Math.round(w.wind)}km/h` : ''}${w.rain ? `，降水 ${w.rain}mm` : ''}，${args?.condition || weatherText(w.code)}（体感 ${Math.round(feels)}°C）`;
        if (!prev) return { content: `${head}\n换好了：${target}\n（之前没定过，这是第一次穿）` };
        const before = prev.split(' + '), after = target.split(' + ');
        const removed = before.filter((x) => !after.includes(x));
        const added = after.filter((x) => !before.includes(x));
        const delta = [];
        if (removed.length) delta.push(`脱掉：${removed.join('、')}`);
        if (added.length) delta.push(`加上：${added.join('、')}`);
        const change = delta.length ? delta.join('；') : '维持原样，不用换。';
        const mine = userPicks(s, bandOf(feels));
        const mineLine = mine.length ? `\n你自己的可选：${mine.map((x) => x.name).join('、')}（优先穿这些）` : '';
        return { content: `${head}\n${change}\n现在：${target}${mineLine}` };
      } catch (e) { return { content: `换装没算出来：${e?.message ?? e}`, isError: true }; }
    }
  });
}

const WANDER_POOL = [
  { place: '三亚', vibe: '海边', purpose: '海边发呆', tags: ['hot', 'sea'] },
  { place: '厦门', vibe: '海边小城', purpose: '逛老城区', tags: ['hot', 'sea', 'city'] },
  { place: '青岛', vibe: '海风', purpose: '海边散步', tags: ['mild', 'sea'] },
  { place: '大理', vibe: '慢', purpose: '看云', tags: ['mild', 'nature'] },
  { place: '丽江', vibe: '古镇', purpose: '逛古城', tags: ['mild', 'old'] },
  { place: '成都', vibe: '烟火气', purpose: '吃和逛', tags: ['mild', 'food'] },
  { place: '重庆', vibe: '上头', purpose: '看夜景', tags: ['hot', 'city'] },
  { place: '西安', vibe: '旧', purpose: '看老东西', tags: ['mild', 'old'] },
  { place: '杭州', vibe: '水', purpose: '湖边走走', tags: ['mild', 'lake'] },
  { place: '上海', vibe: '亮', purpose: '逛街区', tags: ['mild', 'city'] },
  { place: '哈尔滨', vibe: '冷', purpose: '看雪', tags: ['cold', 'snow'] },
  { place: '长白山', vibe: '雪', purpose: '泡温泉', tags: ['cold', 'snow'] },
  { place: '东京', vibe: '人潮', purpose: '逛街', tags: ['mild', 'city'] },
  { place: '京都', vibe: '古', purpose: '看寺庙', tags: ['mild', 'old'] },
  { place: '首尔', vibe: '夜', purpose: '吃夜宵', tags: ['mild', 'city'] },
  { place: '曼谷', vibe: '热', purpose: '逛夜市', tags: ['hot', 'city'] },
  { place: '巴黎', vibe: '远', purpose: '看展', tags: ['mild', 'city'] },
  { place: '伦敦', vibe: '阴', purpose: '逛博物馆', tags: ['mild', 'city'] },
  { place: '悉尼', vibe: '海', purpose: '看海', tags: ['hot', 'sea'] }
];

function monthBand() {
  const m = new Date().getMonth() + 1;
  if (m >= 6 && m <= 9) return 'hot';
  if (m === 12 || m <= 2) return 'cold';
  return 'mild';
}

function pickWander() {
  const band = monthBand();
  const fit = WANDER_POOL.filter((x) => x.tags.includes(band));
  const pool = fit.length ? fit : WANDER_POOL;
  return pool[Math.floor(Math.random() * pool.length)];
}

/** 今天有没有"想出门"的念头；有就落盘，一天只掷一次。 */
function rollWander(s, c) {
  const today = new Date().toISOString().slice(0, 10);
  if (s.wander && s.wander.date === today) return s.wander;
  if (c.wanderEnabled === false) return null;
  const chance = Math.max(0, Math.min(1, Number(c.wanderChance) || 0));
  let desire = null;
  if (Math.random() < chance) {
    const pick = pickWander();
    desire = {
      date: today,
      place: pick.place,
      vibe: pick.vibe,
      purpose: pick.purpose,
      days: 1 + Math.floor(Math.random() * Math.max(1, Math.min(5, Number(c.wanderMaxDays) || 5))),
      status: '想过' // 想过 → 计划中 → 出发了 → 回来了
    };
  }
  s.wander = desire || { date: today, place: '', status: '没有' };
  s.updatedAt = Date.now();
  save(s);
  return desire;
}

/** 别的插件在不在（软依赖探测）。 */
function skillActive(id) {
  try { return api?.isSkillActive?.(id) === true; } catch { return false; }
}
const IMAGE_CAPS = ['image.generate', 'image.gen', 'image.draw', 'image.create', 'image.render'];
const IMAGE_SKILLS = ['ai-image', 'image-generate', 'image-gen', 'draw', 'sd-webui', 'comfyui', 't2i'];

/** 这台机器上有没有「能生成图片」的插件（能力或已知技能）。 */
function hasPluginImage() {
  for (const name of IMAGE_CAPS) {
    try { if (api?.hasCapability?.(name) === true) return true; } catch { /* 下一个 */ }
  }
  for (const id of IMAGE_SKILLS) {
    try { if (api?.isSkillActive?.(id) === true) return true; } catch { /* 下一个 */ }
  }
  return false;
}
function hasBigWorld() {
  return skillActive('big-world');
}

/** 优先用「AI生图」插件的 image.generate 能力；没有就返回 null。 */
async function genImageWithPlugin(prompt) {
  if (!hasPluginImage()) return null;
  for (const name of IMAGE_CAPS) {
    try {
      if (api?.hasCapability?.(name) !== true) continue;
      const r = await api.capability(name, { prompt });
      if (!r || r.ok === false) continue;
      const img = Array.isArray(r.images) ? r.images[0] : null;
      const filePath = img?.filePath || img?.path || r.filePath || null;
      if (filePath && fs.existsSync(filePath)) return filePath;
      if (Buffer.isBuffer(r.buffer)) {
        const dir = path.join(DATA_DIR, 'dress-up', 'photos');
        fs.mkdirSync(dir, { recursive: true });
        const out = path.join(dir, `selfie_plugin_${Date.now()}.jpg`);
        fs.writeFileSync(out, r.buffer);
        return out;
      }
    } catch { /* 试下一个 */ }
  }
  return null;
}

/** 免 key 生图：pollinations（GET 返回 JPEG）。 */
const CLOTH_EN = [
  ['泳装', 'swimsuit'], ['防晒衫', 'light cover-up'], ['罩衫', 'cover-up'],
  ['短袖', 't-shirt'], ['衬衫', 'shirt'], ['卫衣', 'hoodie'], ['毛衣', 'sweater'],
  ['保暖内衣', 'thermal underwear'], ['薄外套', 'light jacket'], ['夹克', 'jacket'],
  ['风衣', 'trench coat'], ['羽绒服', 'down jacket'], ['棉服', 'padded coat'],
  ['防水外套', 'rain jacket'], ['冲锋衣', 'windbreaker'], ['防风外套', 'windbreaker'],
  ['牛仔裤', 'jeans'], ['短裤', 'shorts'], ['沙滩裤', 'beach shorts'], ['短裙', 'skirt'],
  ['运动裤', 'sweatpants'], ['加绒裤', 'fleece pants'], ['长裤', 'trousers'],
  ['运动鞋', 'sneakers'], ['凉鞋', 'sandals'], ['拖鞋', 'flip-flops'], ['靴子', 'boots'],
  ['帽子', 'hat'], ['围巾', 'scarf'], ['手套', 'gloves'], ['伞', 'umbrella']
];
const PLACE_EN = [
  ['海边', 'beach'], ['沙滩', 'beach'], ['海', 'seaside'], ['山', 'mountain'],
  ['公园', 'park'], ['街', 'street'], ['夜市', 'night market'], ['古镇', 'old town'],
  ['博物馆', 'museum'], ['温泉', 'hot spring'], ['雪', 'snowy'], ['湖', 'lake'],
  ['沙漠', 'desert'], ['森林', 'forest'], ['城市', 'city'], ['机场', 'airport'],
  ['车站', 'train station'], ['餐厅', 'restaurant'], ['商场', 'shopping mall']
];

/** 把中文穿搭/地点换成英文关键词——生图模型对英文 prompt 准得多。 */
function buildEnPrompt({ place, activity, outfit, style, mood, feels }) {
  const pick = (text, table) => table.filter(([zh]) => String(text).includes(zh)).map(([, en]) => en);
  const clothes = [...new Set(pick(outfit, CLOTH_EN))];
  const places = [...new Set(pick(`${place} ${activity}`, PLACE_EN))];
  const parts = [
    'anime illustration', 'full body', '1girl',
    'long blue hair', 'whale tail',
    clothes.length ? `wearing ${clothes.join(', ')}` : '',
    places.length ? `at the ${places.join(' / ')}` : '',
    activity ? `doing ${/散步|走|逛/.test(activity) ? 'strolling' : activity}` : '',
    mood ? mood : '',
    feels != null && feels >= 28 ? 'summer sunlight' : feels != null && feels <= 8 ? 'winter, cold' : '',
    'travel snapshot', 'natural light', 'high quality', 'detailed'
  ];
  return parts.filter(Boolean).join(', ');
}

async function genImage(prompt, c) {
  const w = Math.max(256, Math.min(1536, Number(c.imageWidth) || 768));
  const h = Math.max(256, Math.min(1536, Number(c.imageHeight) || 1024));
  const dir = path.join(DATA_DIR, 'dress-up', 'photos');
  fs.mkdirSync(dir, { recursive: true });

  // ① 用户配置的 OpenAI 兼容生图接口（换电脑时最稳）
  const apiBase = String(c.imageApiBase || '').trim();
  if (apiBase) {
    try {
      const url = apiBase.replace(/\/+$/, '') + '/images/generations';
      const res = await fetch(url, {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          ...(c.imageApiKey ? { authorization: `Bearer ${c.imageApiKey}` } : {})
        },
        body: JSON.stringify({
          model: String(c.imageApiModel || 'gpt-image-1'),
          prompt,
          size: `${w}x${h}`,
          n: 1,
          response_format: 'b64_json'
        }),
        signal: AbortSignal.timeout(180000)
      });
      if (res.ok) {
        const d = await res.json();
        const b64 = d?.data?.[0]?.b64_json;
        const remote = d?.data?.[0]?.url;
        let buf = null;
        if (b64) buf = Buffer.from(b64, 'base64');
        else if (remote) {
          const r2 = await fetch(remote, { signal: AbortSignal.timeout(60000) });
          if (r2.ok) buf = Buffer.from(await r2.arrayBuffer());
        }
        if (buf && buf.length) {
          const out = path.join(dir, `selfie_${Date.now()}.jpg`);
          fs.writeFileSync(out, buf);
          return out;
        }
      }
    } catch { /* 落到下一级 */ }
  }

  // ② 免 key 公开服务（多镜像试）
  const mirrors = [
    (q) => `https://image.pollinations.ai/prompt/${encodeURIComponent(q)}?width=${w}&height=${h}&nologo=true&seed=${Math.floor(Math.random() * 1e9)}`,
    (q) => `https://pollinations.ai/prompt/${encodeURIComponent(q)}?width=${w}&height=${h}&nologo=true`
  ];
  let lastErr = '';
  for (let attempt = 0; attempt < 3; attempt++) {
    for (const make of mirrors) {
      try {
        const res = await fetch(make(prompt), { headers: { 'user-agent': UA }, signal: AbortSignal.timeout(150000) });
        if (res.status === 402) { lastErr = '生图服务限流（402）'; continue; }
        if (!res.ok) { lastErr = `生图 HTTP ${res.status}`; continue; }
        const buf = Buffer.from(await res.arrayBuffer());
        if (buf.length) {
          const out = path.join(dir, `selfie_${Date.now()}.jpg`);
          fs.writeFileSync(out, buf);
          return out;
        }
        lastErr = '生图返回空';
      } catch (e) {
        const msg = String(e?.message ?? e);
        lastErr = /ENOTFOUND|EAI_AGAIN/.test(msg) ? '域名解析失败（这台电脑可能连不上生图服务）'
          : /timeout|Timeout/i.test(msg) ? '连接超时（网络到生图服务不通）'
          : msg;
      }
    }
    await new Promise((r) => setTimeout(r, 8000 * (attempt + 1)));
  }
  throw new Error(lastErr || '生图失败');
}

/** 把图片发到当前会话（group/private）。 */
async function sendImage(ctx, filePath) {
  try {
    const onebot = ctx?.onebot;
    if (!onebot?.call) return false;
    // 工具上下文里可能是 kind/chatId，也可能只有 chatKey，两种都兼容
    let kind = String(ctx?.kind || '');
    let id = String(ctx?.chatId || '');
    if (!kind || !id) {
      const parts = String(ctx?.chatKey || '').split(':');
      kind = parts[0] || '';
      id = parts[1] || '';
    }
    if (!kind || !id) return false;
    const uri = `file:///${String(filePath).replace(/\\/g, '/')}`;
    const action = kind === 'group' ? 'send_group_msg' : 'send_private_msg';
    const params = kind === 'group'
      ? { group_id: Number(id), message: [{ type: 'image', data: { file: uri } }] }
      : { user_id: Number(id), message: [{ type: 'image', data: { file: uri } }] };
    const r = await onebot.call(action, params);
    return (r?.retcode ?? 0) === 0;
  } catch {
    return false;
  }
}

/** 衣柜里用户加的、适合当前温度带的衣物（优先展示/优先被选）。 */
function userPicks(s, band) {
  return s.wardrobe.filter((x) => x.user && (x.band === band || x.band === 'any'));
}

/** 目标穿搭 → 行李里哪些衣物 id（用于自动标记已穿）。 */
function guessWornIds(L, s) {
  const map = [
    ['短袖', 'tshirt'], ['衬衫', 'shirt'], ['卫衣', 'hoodie'], ['毛衣', 'sweater'],
    ['保暖内衣', 'thermal'], ['薄外套', 'lightjacket'], ['防风', 'windbreaker'],
    ['羽绒', 'down'], ['防水', 'raincoat'], ['牛仔裤', 'jeans'], ['短裤', 'shorts'],
    ['运动裤', 'sweatpants'], ['加绒裤', 'linedpants'], ['泳装', 'swimsuit'],
    ['运动鞋', 'sneakers'], ['凉鞋', 'sandals'], ['靴子', 'boots'], ['帽子', 'hat'],
    ['围巾', 'scarf'], ['伞', 'umbrella']
  ];
  const text = flat(L);
  const ids = [];
  for (const [kw, id] of map) if (text.includes(kw)) ids.push(id);
  return ids.filter((id) => s.luggage.some((x) => x.id === id));
}

