// 总装：OneBot 事件接入 → 存储 → 编排器；HTTP API + SSE 给 UI。
// Electron 主进程与 headless 服务器都从这里启动。
import http from 'node:http';
import net from 'node:net';
import fs from 'node:fs';
import path from 'node:path';
import { randomBytes } from 'node:crypto';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { getConfig, updateConfig, ROOT, DATA_DIR, isChatAllowed } from './config.js';
// 版本迁移：处理跨版本升级后残留的旧插件目录/配置引用（详见该文件头部注释）。
// 必须在 reloadSkills 之前跑 —— 插件扫描读的就是 config.trustedPlugins。
import { runUpgrades } from './upgrade.js';
// QQ 版本 vs 协议端声明的只读核对（r132）：面向大众分发后用户 QQ 版本各异，
// 版本错开时登录被拒/接口异常且排查方向极易跑偏 —— 状态接口和启动日志里必须能看见。
import { checkQqVersionMatch } from './qq-version.js';
import { OneBotClient, segmentsToText, extractMediaFromSegments, expandForwardNodes, fetchForwardNodes, forwardIdFromSegments } from './onebot.js';
// isAtMe 是「是否被艾特」的唯一权威实现（含 QQ 号判定，见 prompt.js 注释）。
// 这里曾经就地抄过一份只认名字的判定，结果群昵称改了就漏判 —— 统一走权威实现。
import { isAtMe } from './prompt.js';
import { ChatStore } from './store.js';
import { MemoryStore } from './memory.js';
import { cacheIncomingImages } from './image-cache.js';
import { SendQueue } from './sender.js';
import { SessionRegistry } from './sessions.js';
import { Orchestrator } from './orchestrator.js';
import { ReminderStore } from './reminders.js';
import { VideoReader } from './video-reader.js';
import { cacheHitRate } from './llm.js';
import { isPeakHour, priceAt, resolveModelPrice, modelLabel, splitModelLabel, remoteOverrideCount, UNKNOWN_VENDOR } from './model-prices.js';
import { usageLedgerTotals, listUsageLedgerDays, ledgerDayKey, usageLedgerPrunedRecords } from './usage-ledger.js';
import { initPriceFeed, stopPriceFeed } from './price-feed.js';
import { startTelemetryLoop, stopTelemetryLoop } from './telemetry.js';
import { startCacheWarm, loadPersistedPrefix, seedPrefixFromSessions, warmOnce, markCurrentShapeWarmed } from './cache-warm.js';
import { diskPressure, diskPressureText } from './disk-space.js';
import { loadPlugins, watchPlugins, setOnebotClient, PLUGINS_DIR, SKILLS_DIR } from './plugin-loader.js';
import { skillManager } from './skills/manager.js';
// 插件界面契约：常量 / 路径规则 / URL 拼装 / CSP 全部来自这一份，
// 前端（06-settings-render.js）与插件侧（api.panel）也 import 同一份 ——
// 三处各写一遍的时候，任何一处改动漏掉另一处都表现为"按钮点了白屏"且不报错。
import { PANEL_ROUTE_PREFIX, PANEL_DATA_SEGMENT, PANEL_FILE_TYPES, panelCsp } from './skills/panel.js';
import { extractCandidateUrls, dispatchMediaLinks } from './media-links.js';
import { createRoutes } from './routes.js';
import { handleDesktopPetRequest } from './desktop-pet-api.js';
import * as instanceLockModule from './instance-lock.js';
import { logger } from './logger.js';
import { startCommunitySync, isGloballyBlocked, FIXED_PRICE_FEED_URL } from './community.js';
import { noteMuted, noteUnmuted } from './ban-state-client.js';

// 全局 fetch（undici）默认连接建立超时只有 10 秒，openrouter.ai 这类海外端点
// 握手慢时会直接报 "Connect Timeout Error ... timeout: 10000ms"（注意这不是
// 请求超时——那是 llm.js 里 180 秒的 AbortSignal）。这里放宽到 30 秒。
// 动态导入 + 容错：undici 与 Electron 内置 Node 不兼容时只退回默认超时，绝不崩主进程。
try {
  const { Agent, setGlobalDispatcher } = await import('undici');
  setGlobalDispatcher(new Agent({ connect: { timeout: 30_000 } }));
} catch (error) {
  console.warn('[net] 全局连接超时设置失败（使用 undici 默认值 10s）:', error?.message ?? error);
}

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const UI_DIR = path.resolve(__dirname, '..', 'ui');

// ── 插件界面（`/plugin-panel/<id>/…`）──────────────────────────────────────
// 契约（常量、路径规则、URL 拼装、CSP）全在 src/skills/panel.js —— 这里只负责
// "把磁盘上的文件按那套规则吐出去"。以前这份扩展名表在这里另写了一份，与前端
// 各自演进，所以现在统一 import。

// ── 白名单判断：委托给 config.js 的 isChatAllowed（全库唯一实现） ──────────
// 之前 allowed() 与发送侧闸各写一套，移除白名单后"发言"侧没同步 —— 现在统一走一份。
// 保留本函数名/签名，调用方无需改动。
function allowed(kind, id, cfg) {
  return isChatAllowed(kind, id, cfg);
}

// ── 版本更新检查 ─────────────────────────────────────────────────────
// 线上版本信息只有一份：kondius.cn/qq-agent/version.json（发版时手动改）。
// 由后端代取而不是前端直连：绕过 CORS，且失败信息能统一回给 UI。
const UPDATE_INFO_URL = 'https://kondius.cn/qq-agent/version.json';

function localVersion() {
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
    return String(pkg.version || '0.0.0');
  } catch { return '0.0.0'; }
}

/**
 * 逐段数字比较；返回 1 / 0 / -1。非数字段按 0 处理。
 *
 * ⚠️ 段数必须取两侧的**最大值**（2026-10-16 第二轮审查修）：本项目的版本号是
 *    四段（package.json 现为 0.4.8.7），而线上 version.json 只有三段（0.4.0）。
 *    原实现写死 `i < 3`，只比前三段 —— 一旦线上改用四段、且变化只发生在第四段
 *    （0.4.8.5 → 0.4.8.6），比较结果恒为 0，`hasUpdate` 永远是 false，
 *    用户收不到任何更新提示。按 max(len) 走：两侧都是三段时行为与原来完全一致，
 *    四段版本也不会再漏判。
 */
function compareSemver(a, b) {
  const pa = String(a).split('.').map((x) => parseInt(x, 10) || 0);
  const pb = String(b).split('.').map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    if ((pa[i] || 0) > (pb[i] || 0)) return 1;
    if ((pa[i] || 0) < (pb[i] || 0)) return -1;
  }
  return 0;
}

/* createApp 产生的所有 appLog 函数（模块级 WeakSet）。
   用于识别"调用方传入的 log 是不是上一次 createApp 留下的 appLog"，
   防止监听器链式递归（见 createApp 内的递归护栏注释）。 */
const appLogFns = new WeakSet();

// ── SnowLuma 控制台凭据日志（2026-10-17）────────────────────────────────
// 背景：自动注入失败后想「手动注入」的用户，第一步得先登录 SnowLuma 控制台 ——
//   而密码此前只出现在 SnowLuma 页节点②下方那个小密码框里。用户盯着日志找密码
//   找不到，就卡死在这一步（用户反馈原话：「日志中看不到登录密码」）。
// 处理：把「地址 + 密码 + 三步指引」打进 SnowLuma 页的**运行日志**。
//   刻意只走 pushSnowlumaLog（内存环形缓冲，最近 500 行 + SSE），**不写 data/logs**：
//     · 不落盘 → 用户把磁盘日志整份发给别人时不会连带泄露；
//     · 页面上「运行日志」面板正是排障时盯的那块，放这里才找得到。
//   开关：config.snowluma.logConsoleCredential（默认 true）。设 false 时日志里
//   不出现明文，只指路到页面密码框 —— 给"必须把日志发出去"的人留的口子。
// 为什么把拼装抽成模块级纯函数：这样"显示明文 / 只指路 / 没密码 / 漂移提示"
//   四条分支能被无 Electron、无网络地直接跑测试（见 __testSnowlumaCredLog）。
/**
 * 拼装一行「控制台凭据」日志文本。
 * @param {{password?:string, drifted?:boolean, url?:string}} c 凭据（snowlumaWebuiCredential 的子集）
 * @param {{reason?:string, logEnabled?:boolean}} [opt] reason=前缀说明；logEnabled=false 时不出明文
 * @returns {string}
 */
function formatSnowlumaCredentialLog(c = {}, opt = {}) {
  const head = opt.reason ? `${opt.reason} ` : '';
  const url = String(c.url || '') || 'http://127.0.0.1:5099/';
  const pw = String(c.password || '');
  if (!pw) {
    return `${head}控制台地址：${url} —— 控制台密码尚未生成（启动一次 SnowLuma 后自动创建）。`;
  }
  if (opt.logEnabled === false) {
    return `${head}控制台地址：${url} —— 控制台密码见本页节点②下方的「控制台密码」框（可一键复制）。`;
  }
  const drift = c.drifted
    ? '（注意：实测这份密码已经登不进去了 —— 点「重置并接管控制台密码」可让它重新生效）'
    : '';
  return `${head}控制台地址：${url} ｜ 控制台密码：${pw}${drift}`;
}

/** 手动注入三步指引（与上面的凭据行一起打，免得用户只拿到密码不知道怎么用）。 */
const SNOWLUMA_MANUAL_INJECT_GUIDE =
  '手动注入步骤：① 用上面的地址打开 SnowLuma 控制台；② 用上面的密码登录；'
  + '③ 在「进程」列表里找到机器人那份 QQ，点「注入」。'
  + '若密码已失效，先点本页「重置并接管控制台密码」，重启后再按上面三步做。';

/**
 * 「这份控制台密码是不是失效了」的**唯一**判据（纯函数，2026-10-17 · N1）。
 *
 * 为什么抽出来：旧判据（webui.json 的 mustChangePassword === false）恒为真 ——
 * 我们自己 bootstrap 之后写出来的就是这个状态 —— 于是每个用户都被贴上
 * 「密码可能已失效」，被引导去点「重置并接管」→ 雪茹重启 → 注入全断。
 * 现在只认"上一次真的拿这份密码去登录"的结果：
 *   · 密码换过（probe.password ≠ 当前密码）→ 不认旧结论；
 *   · ok === null（没测过 / 被锁 / 网络不通）→ 不报漂移，只是 verified=false。
 *
 * @param {string} pw 当前 config.snowluma.webuiPassword
 * @param {{password?:string, ok?:boolean|null}} [probe] 最近一次实测结果
 * @returns {{drifted:boolean, verified:boolean}}
 */
function decideCredentialDrift(pw, probe = {}) {
  const pwStr = String(pw ?? '');
  const verified = Boolean(pwStr)
    && String(probe.password ?? '') === pwStr
    && probe.ok !== null && probe.ok !== undefined;
  return { drifted: verified && probe.ok === false, verified };
}

/**
 * 判「这个进程的 OneBot 到底连上没有」（纯函数，2026-10-17 · N2）。
 *
 * 为什么不能只看 /load 的 success：SnowLuma 的 `injected` 只代表组件装进了 QQ 进程，
 * 而 OneBot 还要等 QQ 登录完成 → Hook 检出 → OneBot 实例拉起。实测成功的进程长这样：
 *   `{injected:true, connected:true, loggedIn:true, status:'online', error:''}`
 * 而"刚注入完还没连上"的进程这几个字段都不满足。旧代码一个字段都不看，`success`
 * 就 log「已自动注入机器人 QQ」然后 return —— 于是雪茹控制台说成功、QQ Agent 节点③
 * 说连不上，两边都像在说谎，用户拿着这两条日志去问谁都判断不出来。
 * （`snowlumaSwitchBot` 早就做了 2.5 秒复查，偏偏这条主路径没做。）
 *
 * @param {object|null} p 进程表里的一项
 * @returns {{online:boolean, why:string}}
 */
function onebotOnlineVerdict(p) {
  if (!p) return { online: false, why: '该进程已不在 SnowLuma 的进程表里（QQ 可能退出了）' };
  const err = String(p.error || '');
  const status = String(p.status || '');
  if (err) return { online: false, why: `SnowLuma 报错「${err}」` };
  // status==='online' 与 connected+loggedIn 是同一件事的两种表达，认其一即可 ——
  // 这样将来 SnowLuma 少给一个字段也不会把"已连上"误判成"没连上"（那会重复 load）。
  if (status === 'online' || (p.connected === true && p.loggedIn === true)) {
    return { online: true, why: '' };
  }
  return {
    online: false,
    why: `连接受限（connected=${p.connected === true} loggedIn=${p.loggedIn === true} status=${status || '空'}）`
  };
}

/**
 * 从 SnowLuma 的进程对象提取登录账号（v2.0.2 适配，2026-10-19）。
 *
 * 优先级：p.uin（已注入时雪茹直接回填）→ p.account.uin（**v2 新增**：未注入
 * 的进程也带登录账号，实测 uin='0' 而 account.uin 有值——v1 没有这个字段，
 * 行为与旧逻辑完全一致）→ 空串（调用方再决定要不要 probe-login）。
 *
 * 为什么重要：v1 下"未注入 → probe-login 才知道是谁"是必须的；v2 下 probe-login
 * 对无效 pid 返回的是非 JSON 的 "not found"（实测），对真实进程的响应结构也未
 * 经验证——而 account.uin 就在列表响应里。优先用它：注入轮询每 3 秒一轮，
 * 每个未注入进程省一次 HTTP 往返，「从已登录 QQ 选择」还能白拿昵称。
 */
function snowlumaProcessAccount(p) {
  if (!p) return { uin: '', nick: '' };
  let uin = String(p.uin || '');
  let nick = '';
  if ((!uin || uin === '0') && p.account && p.account.uin && p.account.uin !== '0') {
    uin = String(p.account.uin);
    nick = String(p.account.nickname || '');
  }
  return { uin, nick };
}

export function createApp({ log = console.log, desktopPetHost = null } = {}) {
  const cfg = getConfig();

  // 桌面能力按已激活插件取用；无 Electron 时仍可查看设置和成就。
  function getDesktopPetService() {
    try {
      return skillManager.getCapabilityProviders('desktop.pet.service', {})[0]?.fn?.() || null;
    } catch { return null; }
  }
  // Electron 主进程独占此随机凭据，并通过 webRequest 只注入当前控制台窗口的 API 请求。
  // 不写入 HTML / preload / 配置文件，避免把 server.token 暴露给页面或其他本机进程。
  const rendererAuthToken = randomBytes(32).toString('hex');

  // 详尽日志：把 createApp 的 log 接到分级日志系统（落盘 + 内存缓冲 + SSE）。
  // 关键：logger 的 mirrorConsole 已经会走 console，所以这里**只写 logger、不再调原 log**，
  // 否则 appLog → logger.info → console(log) → 若 log 又被指回 appLog 就会无限递归（selftest 就是这么挂的）。
  // logger.mirrorConsole = true 时 console 输出不丢；调用方传入的自定义 log（如测试的静默 log）
  // 通过 logger 的 onLog 监听器另行转发，不经过 console。
  const appLog = (...args) => {
    logger.info('app', ...args);
  };
  // 把调用方传入的 log（如 Electron 的 console.log 或测试的静默 log）挂到 logger 的监听器上，
  // 与 mirrorConsole 解耦：mirrorConsole 管 console，监听器管调用方的 log。
  //
  // ⚠️ 递归护栏（15GB 日志事故根因）：
  //   若调用方传入的 log 本身就是上一次 createApp 留下的 appLog
  //   （同进程内二次 createApp：Electron 重启核心 / 测试串行多轮），
  //   监听器链会形成 appLog→logger→监听器→appLog 的无限递归，
  //   每轮递归给文本再包一层 [app] 前缀 —— 一条日志膨胀成几千条、
  //   每条带几千个 [app] 前缀，几个小时内日志文件就能写到 15GB。
  //   这里用 WeakSet 识别"这个 log 是不是 appLog"，是则跳过挂载。
  // r92：持有退订函数。原实现把 logger.onLog 的返回值直接丢掉 —— 同进程二次
  // createApp（Electron 重启核心 / 测试串行多轮）时旧监听器仍在：每条日志
  // 广播 N 份、持有上一个 app 的 log 闭包（可能指向已销毁的窗口）。
  let unsubscribeAppLog = null;
  if (!appLogFns.has(log)) {
    unsubscribeAppLog = logger.onLog((entry) => {
      try { log(`[${entry.module}] ${entry.text}`); } catch { /* ignore */ }
    });
  }
  appLogFns.add(appLog);
  // 关掉 logger 的 console 镜像，避免与上面的监听器重复打印（调用方 log 通常就是 console.log）。
  logger.mirrorConsole = false;
  // 后续内部调用统一指向 appLog（关键事件落盘 + 走调用方 log）
  log = appLog;
  // 启动时清理过期日志文件
  logger.prune();

  // ── 进程单实例锁（防止桌面端 + headless 双开导致重复回复群消息）──
  // 与 Electron 的 requestSingleInstanceLock 互补：那只管 Electron 进程之间，
  // 这里管"同一数据目录下任何形态的 QQ Agent 核心"（含 node src/server.js）。
  const { acquireInstanceLock, releaseInstanceLock } = instanceLockModule;
  const lockResult = acquireInstanceLock();
  if (!lockResult.ok) {
    // 不抛异常上抛让进程退出 —— 创建期的失败应当让整个启动失败。
    throw new Error(`[单实例] ${lockResult.reason}。如需多开测试，请用不同的 QQ_AGENT_DATA_DIR。`);
  }
  /* 抢到锁后立刻注册退出清理：正常 exit / SIGINT / SIGTERM 都会释放锁文件。
     曾经只在 stop() 里释放 —— 进程被直接杀掉（任务管理器结束、控制台叉掉）
     时锁文件残留，下次启动要靠"PID 已死"探测才能清掉，多一层失败面。 */
  instanceLockModule.registerLockCleanup();
  const sseClients = new Set();

  // ── SnowLuma 程序目录与进程管理 ──
  function snowlumaDir() {
    const configured = String(getConfig().snowluma?.dir || '').trim();
    if (configured) return configured;
    const bundled = path.join(ROOT, 'snowluma');
    if (fs.existsSync(bundled)) return bundled;
    // 安装版：asar 里的文件不可执行，electron-builder 会把 snowluma/ 解包到
    // resources/app.asar.unpacked/snowluma（见 package.json asarUnpack）
    const unpacked = bundled.replace('app.asar', 'app.asar.unpacked');
    if (unpacked !== bundled && fs.existsSync(unpacked)) return unpacked;
    return '';
  }

  // ── 2026-10-20（S7 修）：runtime.json 读取缓存 ────────────────────────────
  // 这个文件原先每调用一次就读一遍：注入轮询每 3 秒、看门狗每 20 秒、launch、
  // 每条雪茹路由、以及 run() 里 snowlumaWebuiPort() 与 snowlumaWebuiUrl() 紧挨着
  // 调的那一次（同一轮把同一个文件读了两遍）。它是主线程**同步** IO，单次不到 1ms，
  // 但一轮 6 分钟的注入就是 120 次 ×2 —— 属于可以零成本消除的抖动。
  // 用 mtimeMs 做键：文件没变就复用，变了立刻重读（用户改端口能马上生效）。
  let slRuntimeCache = { mtime: -1, data: null };
  function readSnowlumaRuntime() {
    try {
      const dir = snowlumaDir();
      if (!dir) return null;
      const rtPath = path.join(dir, 'config', 'runtime.json');
      const mtime = fs.statSync(rtPath).mtimeMs;
      if (slRuntimeCache.data && slRuntimeCache.mtime === mtime) return slRuntimeCache.data;
      const data = JSON.parse(fs.readFileSync(rtPath, 'utf8'));
      slRuntimeCache = { mtime, data };
      return data;
    } catch {
      return null;
    }
  }

  function snowlumaWsPort() {
    try {
      const wsUrl = String(getConfig().snowluma?.wsUrl || 'ws://127.0.0.1:3001');
      const u = new URL(wsUrl);
      if (u.port) return Number(u.port);
    } catch { /* ignore */ }
    return 3001;
  }

  /**
   * 某个 QQ 号自己的 OneBot WS 端口（从 onebot_<uin>.json 读，2026-10-20 · S8）。
   * 用来诊断"QQ Agent 连的端口"和"雪茹给这个号开的端口"对不上 —— 后者只会在
   * 连接受限时表现为一句 `connected=false loggedIn=false status=空`，把人往
   * "QQ 没登录"的方向带。读不到返回 0（不参与判断）。
   */
  function snowlumaConfiguredWsPortFor(uin) {
    try {
      const u = String(uin || '').trim();
      const dir = snowlumaDir();
      if (!dir || !/^\d{5,12}$/.test(u)) return 0;
      const f = path.join(dir, 'config', `onebot_${u}.json`);
      if (!fs.existsSync(f)) return 0;
      const d = JSON.parse(fs.readFileSync(f, 'utf8'));
      const ws = (d?.networks?.wsServers || [])[0];
      const port = Number(ws?.port);
      return Number.isInteger(port) && port > 0 ? port : 0;
    } catch {
      return 0;
    }
  }

  /** SnowLuma 的 WebUI 端口：进程一启动就监听，与是否登录无关。
   * 用来判定「SnowLuma 进程活着」。 */
  function snowlumaWebuiPort() {
    const rt = readSnowlumaRuntime();
    const p = Number(rt && rt.webuiPort);
    if (Number.isInteger(p) && p > 0) return p;
    return 5099;
  }

  /** 从 SnowLuma 的 runtime.json 读取 WebUI 地址（http(s)://host:port/）。拿不到就返回空串。 */
  function snowlumaWebuiUrl() {
    const rt = readSnowlumaRuntime();
    if (!rt) {
      // 配置读不到时，从最近日志里找 "listening http(s)://…" 兜底
      try {
        for (const line of [...snowlumaLogs].reverse()) {
          const m = /listening\s+(https?:\/\/[\w.:-]+)/i.exec(line.text || '');
          if (m) return m[1];
        }
      } catch { /* 日志缓冲还没就绪 */ }
      return '';
    }
    const host = String(rt.webuiHost || '127.0.0.1');
    const port = Number(rt.webuiPort) || 5099;
    const tls = !!(rt.webuiTls && rt.webuiTls.enabled);
    return `${tls ? 'https' : 'http'}://${host}:${port}/`;
  }

  // 2026-10-15（二次细化）：确保 QQ Agent 能登录 SnowLuma WebUI（注入 API 需要鉴权）。
  // SnowLuma WebUI 有登录密码；QQ Agent 接管它：
  //   · 生成随机 webuiPassword 并存 config（字段含 "password"，会被 sanitizeConfig 自动脱敏）；
  //   · 若 webui.json 不存在，或仍是自动生成的初始状态（mustChangePassword），则删除/让其由
  //     SNOWLUMA_WEBUI_BOOTSTRAP_PASSWORD 重新播种为我们的密码（仅在即将启动 SnowLuma 时动它）；
  //   · 若用户已自定义过密码（mustChangePassword=false 且非我们所设），则不动它、返回 managed:false，
  //     自动注入会优雅跳过并提示手动注入。
  function prepareSnowlumaWebuiAuth(dir) {
    let pw = getConfig().snowluma?.webuiPassword;
    if (!pw) {
      pw = randomBytes(16).toString('hex');
      updateConfig({ snowluma: { webuiPassword: pw } });
    }
    const webuiJson = path.join(dir, 'config', 'webui.json');
    try {
      if (fs.existsSync(webuiJson)) {
        const live = JSON.parse(fs.readFileSync(webuiJson, 'utf8'));
        // 自动生成的初始状态（密码未知）→ 删除，让 bootstrap 用我们的密码重新播种
        if (live && live.mustChangePassword === true) {
          try { fs.unlinkSync(webuiJson); } catch { /* ignore */ }
          return { bootstrap: pw };
        }
        // ⚠️（2026-10-17 修正注释）mustChangePassword=false **不等于**"用户改过密码"：
        //    我们自己 bootstrap 之后雪茹写出来的就是这个状态。这个字段只能决定
        //    "要不要动 webui.json"，绝不能拿来判断"这份密码还能不能用"——
        //    那件事只能靠真去登录一次（见 decideCredentialDrift / slAuthNote）。
        //    这里仍然不动文件（不删用户可能自定义的密码），返回 managed:false
        //    仅表示"本轮不需要播种"，不是"放弃接管"。
        return { managed: false };
      }
      // 不存在 → bootstrap 会播种我们的密码
      return { bootstrap: pw };
    } catch {
      return { bootstrap: pw };
    }
  }

  // ── 「这份控制台密码现在还能不能登」的实测状态（2026-10-17 · N1）─────────────
  //
  // 为什么不再看 webui.json 的 mustChangePassword：
  //   那个字段描述的是「SnowLuma 是否要在控制台里提示用户改密码」，
  //   **和"我们这份密码对不对"毫无关系**。更要命的是：我们自己 bootstrap 之后
  //   它写出来的就是 mustChangePassword=false —— 于是旧判据
  //   （drifted = 文件存在 && mustChangePassword===false）**恒为 true**，
  //   每个用户都会被告诉「你在控制台改过密码，这份可能已失效」。
  //   实测现场：`POST /api/login` 用这份密码返回 success:true 的同一时刻，
  //   接口却在报 drifted:true。用户被这句吓到去点「重置并接管」→ 雪茹重启、
  //   注入全断、机器人掉线 —— 这个误报等于在教用户主动制造故障。
  //
  // 所以判据只留一个：**真的去登录一次，看结果**。
  //   记录规则（slLogin 每次真的问了服务器才写；走 token 缓存的调用不写）：
  //     · 拿到 token                         → ok = true
  //     · 服务器明确拒绝（success:false / 401 / 403）→ ok = false
  //     · 429 被锁 / 网络不可达               → ok = null（这是"测不了"，不是"密码错了"）
  let slAuthProbe = { password: '', ok: null, at: 0, message: '', kind: '' };
  let slAuthProbeInflight = null;
  /**
   * 记录一次登录实测结果。
   * @param {string} password 这次真正用来登录的密码
   * @param {boolean|null} ok true=可登录 / false=被拒 / null=测不了
   * @param {string} [kind] verified | rejected | locked | unreachable
   * @param {string} [message] 服务端原话（给 UI 显示原因）
   */
  function slAuthNote(password, ok, kind = '', message = '') {
    slAuthProbe = { password: String(password ?? ''), ok, at: Date.now(), message: String(message || ''), kind };
  }

  /**
   * 回显 SnowLuma 控制台密码（2026-10-16）。
   *
   * 背景：初次启动 SnowLuma 时，QQ Agent 会接管控制台密码 —— prepareSnowlumaWebuiAuth
   * 删掉 mustChangePassword=true 的 webui.json，让 SNOWLUMA_WEBUI_BOOTSTRAP_PASSWORD
   * 重新播种成我们生成的密码。但 SnowLuma 自己的首启流程也会播种一份「随机初始密码」，
   * 这两份一旦对不上（探测不到 QQ、注入没跑成、用户手动改过），用户手里的初始密码就作废了，
   * 而 QQ Agent 从不把它显示出来 → 用户进不去控制台、也无从判断该不该点「重置并接管」。
   *
   * 所以这里把「机器初始密码」显式暴露给 UI：它就是 config 里的 webuiPassword，
   * 也是自动注入实际用来登录 WebUI 的那份凭据。
   *
   * 安全边界（与项目其它敏感端点同一口径，勿放宽）：
   *   · 路由只挂在回环服务上，且过 authorize + originAllowed（app.js:2224）——
   *     无 Origin/Referer 的写操作一律拒绝，GET 需同源 Host。
   *   · **刻意不进 /api/status**：那条路走 sanitizeConfig，webuiPassword 命中
   *     SECRET_KEY_PATTERN 会被 delete，这里是唯一出口（见 routes.js 该路由注释）。
   *   · 日志通道：**2026-10-17 起允许进 snowlumaLogs，但仍不进 data/logs**。
   *     起因：自动注入失败的用户要「手动注入」，必须先登录控制台，而密码此前只在
   *     节点②的小密码框里 —— 他们对着日志找密码找不到，就卡死在这一步（实测反馈）。
   *     为什么放宽：该密码本就以明文躺在 data/config.json 里，页面上也能一键显示 /
   *     复制 —— 进内存环形缓冲并没有新增本机读取面。
   *     为什么仍不进 data/logs：那才是我真正在意的泄漏路径 —— 用户排障时会把磁盘
   *     日志整份发出来，磁盘日志里出现凭据就等于外泄。
   *     要彻底关掉明文：config.snowluma.logConsoleCredential = false（见该字段注释）。
   */
  function snowlumaWebuiCredential() {
    const pw = String(getConfig().snowluma?.webuiPassword || '');
    const dir = snowlumaDir();
    // 磁盘实况：webui.json 存的是 passwordHash（雪茹的 PBKDF2 派生，不可逆），
    // 所以只能判断「是否已被用户改过」而无法反推用户改成了什么。
    let onDisk = null;
    try {
      const p = dir ? path.join(dir, 'config', 'webui.json') : '';
      if (p && fs.existsSync(p)) {
        const live = JSON.parse(fs.readFileSync(p, 'utf8'));
        onDisk = {
          exists: true,
          mustChangePassword: live?.mustChangePassword === true,
          generatedAt: live?.generatedAt || ''
        };
      } else {
        onDisk = { exists: false };
      }
    } catch { onDisk = null; }

    // 只认实测（2026-10-17 N1，判据见文件顶部的 decideCredentialDrift）：
    // 上一次真的拿这份密码去登录、而且被拒了，才算"已失效"。
    // 没测过（雪茹没跑 / 从没登录过）时一律**不报漂移** —— 宁可不说，
    // 也不要吓着用户去点「重置并接管」把正在跑的注入整断（那才是真正的故障来源）。
    const { drifted, verified } = decideCredentialDrift(pw, slAuthProbe);

    return {
      ok: true,
      // 空串 = 还没生成过（SnowLuma 从未由 QQ Agent 拉起）。此时不编造，UI 应提示"尚未生成"。
      password: pw,
      managed: Boolean(pw),
      // 我们已接管（config 里有密码）但**实测登录被拒** → 这个密码已经登不进去，
      // UI 应给出「重置并接管控制台密码」入口，别让用户对着一个失效密码发呆。
      drifted,
      // 密码对不对有没有被实测过。false = 雪茹没跑或还没登录过 → UI 只单纯展示密码，
      // 不给任何"可能失效"的暗示（本次误报就是用这个字段区分开的）。
      verified,
      verifiedAt: verified ? new Date(slAuthProbe.at).toISOString() : '',
      verifyMessage: drifted ? slAuthProbe.message : '',
      // disk 保留给排障用（不再参与 drifted 判定）。字段含义见上面 prepareSnowlumaWebuiAuth 注释。
      disk: onDisk,
      webuiUrl: snowlumaWebuiUrl()
    };
  }

  /**
   * 生成一条「控制台凭据」日志文本（2026-10-17）。
   *
   * 给谁用：自动注入失败后想**手动注入**的用户 —— 手动注入的第一步就是登录
   * SnowLuma 控制台，而登进去需要密码。此前密码只在节点②下方那个小密码框里，
   * 用户盯着日志翻不到就卡住了（实测反馈原话：「日志中看不到登录密码」）。
   *
   * 落点刻意选 pushSnowlumaLog（内存环形缓冲 + SSE），**不写 data/logs**：
   *   · 不落盘 → 用户把磁盘日志整份贴出来时不会连带泄露；
   *   · 页面上的「运行日志」面板正是用户排障时盯的那块，密码出现在这里才找得到。
   * 是否出现明文由 config.snowluma.logConsoleCredential 控制（默认 true）。
   *
   * 文本拼装本身抽到模块级的 formatSnowlumaCredentialLog（纯函数）——
   * 这样"显不显示明文 / 漂移怎么提示 / 没密码怎么说"能被无 Electron 地直接测。
   *
   * @param {string} [reason] 前缀说明（如「自动注入准备登录控制台。」）
   * @returns {string} 可直接 pushSnowlumaLog 的文本
   */
  function snowlumaConsoleCredentialLog(reason = '') {
    const c = snowlumaWebuiCredential();
    return formatSnowlumaCredentialLog(
      // 地址优先用 SnowLuma 自己写的 runtime.json；拿不到就让纯函数用默认端口兜底 ——
      // 目标地址不是秘密，能给具体值就别给"启动后自动识别"这种要用户再找一遍的话。
      { password: c.password, drifted: c.drifted, url: c.webuiUrl || `http://127.0.0.1:${snowlumaWebuiPort()}/` },
      // ⚠️ 只有**显式 false** 才关（老配置缺字段 / null 都按"开"处理）——
      //   这个开关的默认行为必须是"用户看得到密码"，否则这次改动就白做了。
      { reason, logEnabled: getConfig().snowluma?.logConsoleCredential !== false }
    );
  }

  /**
   * 端口探测（**永不 reject**，失败一律 resolve(false)）。
   *
   * 为什么强调这一点（2026-10-17 加固）：这是看门狗、`launchSnowluma`、多条雪茹路由的
   * 公共前置探测。端口值来自 `snowluma/config/runtime.json`（雪茹自己写的，也可能被
   * 用户/别的版本写坏）。实测 `net.Socket.connect(99999 / -1 / NaN)` 会**同步抛**
   * RangeError → Promise executor 抛 = 这个 Promise **reject** → 顺着 await 往外冒：
   *   · 看门狗有 try/catch，表现为每 20 秒一行异常日志（自愈等于没了）；
   *   · `launchSnowluma` / 取消注入 / 切换账号没有逐层兜，路由直接 500。
   * "端口写坏了"只应该等于"没开"，绝不该等于"功能全废"。
   */
  function isPortOpen(host, port, timeoutMs = 800) {
    return new Promise((resolve) => {
      const p = Number(port);
      const h = String(host ?? '').trim();
      if (!Number.isInteger(p) || p < 1 || p > 65535 || !h) { resolve(false); return; }
      const socket = new net.Socket();
      let settled = false;
      let guard = null;
      const done = (result) => {
        if (settled) return;
        settled = true;
        if (guard) clearTimeout(guard);
        try { socket.destroy(); } catch { /* ignore */ }
        resolve(result);
      };
      try {
        socket.setTimeout(timeoutMs);
        socket.once('connect', () => done(true));
        socket.once('timeout', () => done(false));
        socket.once('error', () => done(false));
        socket.once('close', () => { if (guard) clearTimeout(guard); });
        // 双保险：个别异常 socket 状态可能既不 error 也不 timeout（半开连接）。
        // 到点直接判"没开" —— 探测本身绝不能成为卡住调用方的那一环。
        guard = setTimeout(() => done(false), timeoutMs + 500);
        guard.unref?.();
        socket.connect(p, h);
      } catch {
        done(false);
      }
    });
  }

  // SnowLuma 内置控制台日志（环形缓冲，最近 500 行）
  // 内置 SnowLuma 状态与日志。未采用多进程方案：由 Electron 主进程提供 IPC 控制与日志转发，
  // 确保 SnowLuma 随 QQ Agent 退出、无需单独管理窗口。
  const snowlumaLogs = [];
  let snowlumaProc = null;
  let snowlumaLaunching = false;   // SnowLuma 启动互斥标记（防连点「运行」按钮并发拉起多个）
  let snowlumaStopping = false;
  // 用户**显式**点过「停止 SnowLuma」→ 看门狗不许自动把它拉回来（2026-10-17）。
  // 没有这一位的话，autoLaunch 默认打开后，用户一点停止、20 秒后它自己又起来了，
  // 会显得软件失控。clear 的时机只有"用户又让它启动"（launchSnowluma 入口）。
  let snowlumaUserStopped = false;
  let pluginWatcher = null;        // 开发模式热重载 watcher（stop() 时要 close，否则句柄泄漏）
  let obPortPollTimer = null;      // OneBot WS 端口就绪轮询（stop() 时要 clear，start() 里赋值）
  let slInjectWatchTimer = null;   // 自动注入看门狗（stop() 时要 clear，start() 里赋值）
  let diskPatrolTimer = null;      // 数据盘空间巡检（stop() 时要 clear，start() 里赋值）

  function pushSnowlumaLog(text, stream = 'stdout') {
    const line = { at: Date.now(), stream, text: String(text ?? '').replace(/\r?\n$/, '') };
    if (!line.text) return;
    snowlumaLogs.push(line);
    if (snowlumaLogs.length > 500) snowlumaLogs.splice(0, snowlumaLogs.length - 500);
    emit('snowluma-log', line);
  }

  function snowlumaStatus() {
    return { embedded: !!snowlumaProc, pid: snowlumaProc?.pid ?? null };
  }

  /** 关闭 SnowLuma。内置进程等待 exit；外部进程按精确 index.mjs 路径查找并等待终止确认。 */
  async function stopSnowluma() {
    if (snowlumaStopping) return false;
    // 用户显式停止 → 记下来，别让看门狗又给拉起来（resetSnowlumaWebui 里会紧接着
    // 调 launchSnowluma，那边会把这位清掉，所以"重置并接管"不受影响）。
    snowlumaUserStopped = true;
    snowlumaStopping = true;
    try { return await stopSnowlumaImpl(); }
    finally { snowlumaStopping = false; }
  }

  async function stopSnowlumaImpl() {
    const proc = snowlumaProc;
    if (proc) {
      try {
        const stopped = await new Promise((resolve) => {
          let timer = null;
          const finish = (ok) => {
            if (timer) clearTimeout(timer);
            proc.removeListener('exit', onExit);
            proc.removeListener('error', onError);
            resolve(ok);
          };
          const onExit = () => finish(true);
          const onError = () => finish(false);
          if (proc.exitCode !== null || proc.signalCode !== null) return finish(true);
          proc.once('exit', onExit);
          proc.once('error', onError);
          timer = setTimeout(() => finish(proc.exitCode !== null || proc.signalCode !== null), 3000);
          try {
            proc.kill();
          } catch (error) {
            finish(false);
            throw error;
          }
        });
        if (stopped) {
          pushSnowlumaLog('SnowLuma 已停止。', 'stdout');
          snowlumaProc = null;
          return true;
        }
        pushSnowlumaLog('SnowLuma 仍未退出，请查看进程状态后重试。', 'stderr');
        return false;
      } catch (error) {
        pushSnowlumaLog(`关闭 SnowLuma 失败：${error?.message ?? error}`, 'stderr');
        throw error;
      }
    }
    // 外部启动的实例：PowerShell/CIM 输出 UTF-8 JSON，避免 WMIC 缺失及中文路径乱码。
    try {
      const dir = snowlumaDir();
      if (!dir) return false;
      const scriptPath = path.resolve(dir, 'index.mjs');
      const dirNorm = path.resolve(dir).replace(/[\\/]+$/, '').toLowerCase().replace(/\\/g, '/');
      const scriptNorm = scriptPath.toLowerCase().replace(/\\/g, '/');
      const { execFile } = await import('node:child_process');
      const { promisify } = await import('node:util');
      const execFileAsync = promisify(execFile);
      let processes = [];
      if (process.platform === 'win32') {
        const { stdout } = await execFileAsync('powershell', [
          '-NoProfile', '-NonInteractive', '-Command',
          '[Console]::OutputEncoding=[Text.Encoding]::UTF8; '
            + 'Get-CimInstance Win32_Process -Filter "name=\'node.exe\'" | '
            + 'Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress'
        ], { timeout: 15000, windowsHide: true, maxBuffer: 4 * 1024 * 1024 });
        const text = String(stdout).trim();
        if (text) {
          const parsed = JSON.parse(text);
          processes = Array.isArray(parsed) ? parsed : [parsed];
        }
      } else {
        const { stdout } = await execFileAsync('ps', ['-eo', 'pid=,args='], {
          timeout: 8000, maxBuffer: 4 * 1024 * 1024
        });
        processes = String(stdout).split(/\r?\n/).map((line) => {
          const match = /^\s*(\d+)\s+(.+)$/.exec(line);
          return match ? { ProcessId: match[1], CommandLine: match[2] } : null;
        }).filter(Boolean);
      }
      const target = processes.filter((item) => {
        const pid = Number(item.ProcessId);
        const cmdline = String(item.CommandLine ?? '').replace(/\\/g, '/').toLowerCase();
        const at = cmdline.indexOf(scriptNorm);
        if (!(pid > 0) || at < 0 || !cmdline.includes(dirNorm)) return false;
        const after = cmdline[at + scriptNorm.length] ?? '';
        return !/[a-z0-9._-]/i.test(after);
      }).map((item) => Number(item.ProcessId));
      if (!target.length) return false;

      const requested = [];
      for (const pid of target) {
        try {
          process.kill(pid, 'SIGTERM');
          requested.push(pid);
        } catch (error) {
          if (error?.code !== 'ESRCH') pushSnowlumaLog(`关闭 PID ${pid} 失败：${error?.message ?? error}`, 'stderr');
        }
      }
      if (!requested.length) return false;

      let alive = requested;
      for (let i = 0; i < 12 && alive.length; i++) {
        await new Promise((resolve) => setTimeout(resolve, 250));
        alive = alive.filter((pid) => {
          try { process.kill(pid, 0); return true; } catch { return false; }
        });
      }
      if (alive.length) {
        pushSnowlumaLog(`SnowLuma 仍未退出（pid=${alive.join(',')}），请稍后重试。`, 'stderr');
        return false;
      }
      pushSnowlumaLog(`外部启动的 SnowLuma 已停止（pid=${requested.join(',')}）。`, 'stdout');
      snowlumaProc = null;
      emit('snowluma-status', { running: false, embedded: false, pid: null });
      return true;
    } catch (error) {
      pushSnowlumaLog(`关闭 SnowLuma 失败：${error?.message ?? error}`, 'stderr');
      return false;
    }
  }

  // ── 便携 QQ 进程管理 ──
  // 便携 QQ 与用户日常 QQ 完全隔离：独立安装目录 + 独立 user-data-dir。
  // 绝不 taskkill QQ.exe 全名——只杀路径匹配 runtime/qq-portable 的进程。
  const qqPortableLogs = [];
  let qqPortableProc = null;
  let qqPortableLaunching = false;   // 便携 QQ 启动互斥标记（防连点「启动 QQ」并发拉起）

  function qqPortableDir() {
    return path.join(ROOT, 'runtime', 'qq-portable');
  }

  function qqPortableDataDir() {
    return path.join(ROOT, 'runtime', 'qq-portable-data');
  }

  function qqPortableExe() {
    return path.join(qqPortableDir(), 'QQ.exe');
  }

  function pushQqLog(text, stream = 'stdout') {
    const line = { at: Date.now(), stream, text: String(text ?? '').replace(/\r?\n$/, '') };
    if (!line.text) return;
    qqPortableLogs.push(line);
    if (qqPortableLogs.length > 500) qqPortableLogs.splice(0, qqPortableLogs.length - 500);
    emit('qq-portable-log', line);
  }

  /** 检查便携 QQ 是否已安装 */
  function qqPortableReady() {
    return fs.existsSync(qqPortableExe());
  }

  /** 列出所有 QQ.exe 进程，返回 [{ pid, path }]（Windows only） */
  /**
   * 列出所有 QQ.exe 进程，返回 [{ pid, path }]（Windows only）。
   *
   * ── 这里踩过一个很隐蔽的坑，务必别再改回去 ──────────────────────────
   * 原来首选 `wmic process ... /format:csv`。它有两个问题：
   *
   * 1. **编码**：wmic 按**系统 ANSI 代码页（中文系统是 GBK）**输出，
   *    而 Node 按 UTF-8 读 —— 路径里的中文会变成乱码。
   *    实测：`qq-agent - 副本` → `qq-agent - ????`。
   *    于是拿乱码路径去和真实路径比，**永远比不上**，
   *    表现就是"QQ 明明在跑，界面却说未启动"。
   *    ⚠️ 纯英文路径下这个 bug 完全不暴露，所以特别难查。
   * 2. **CSV**：路径里有逗号就会错位。
   * 3. 而且 wmic 在 Win11 24H2+ 已被移除，本来也不能当主路径。
   *
   * 现在改用 PowerShell + **显式强制 UTF-8 输出** + JSON。
   * ⚠️ 只写 PowerShell 是不够的：PS 5.1 默认同样按 ANSI 输出，
   *    必须带上 `[Console]::OutputEncoding=[Text.Encoding]::UTF8`
   *    （这行是实测对比出来的，去掉就又是乱码）。
   * 用 JSON 而不是 CSV，顺带解决逗号错位。
   */
  // R113：listQqProcesses 的短 TTL 缓存 + 在途共享。
  //
  // 背景（用户 2026-10-14 实测复现）：用量页报「用量加载失败：请求超时（15 秒无响应）」。
  // 逐接口计时发现根因不在统计接口（/api/usage/stats 实测 2ms，force 重算也只要 0.26s），
  // 而在 /api/status —— 它每轮要 spawn 一次 PowerShell 查 QQ 进程列表（本机单次
  // CIM 查询 ~1.5s：PS 5.1 启动 + CIM 冷缓存）。而 /api/status 是秒级轮询（渲染端
  // 15s 轮询 + 每次 SSE 事件都 refreshStatus + 用量页的 Promise.all 也带它），
  // 机器再忙一点（图片缓存/模型调用/全量重扫同时跑）就顶穿前端 15s 超时，
  // 整个 Promise.all 连带统计接口一起挂 → 用户看到"用量页一直加载失败"。
  //
  // 3 秒 TTL：UI 状态显示允许 3 秒陈旧；在途共享避免并发调用叠出多个 PowerShell
  // （force=true 只给"刚装完 QQ 要立刻看到结果"这类显式场景用）。
  let qqProcListCache = { at: 0, rows: null };
  let qqProcListInFlight = null;
  const QQ_PROC_LIST_TTL = 3000;

  async function listQqProcesses({ force = false } = {}) {
    if (process.platform !== 'win32') return [];
    const now = Date.now();
    if (!force) {
      if (qqProcListCache.rows && now - qqProcListCache.at < QQ_PROC_LIST_TTL) {
        return qqProcListCache.rows;
      }
      if (qqProcListInFlight) return qqProcListInFlight;   // 已在查 → 共用这一次，别叠 spawn
    }
    const p = __listQqProcessesOnce()
      .then((rows) => { qqProcListCache = { at: Date.now(), rows }; return rows; });
    qqProcListInFlight = p;
    try { return await p; } finally { qqProcListInFlight = null; }
  }

  /** 真正干活的单次查询（无缓存）。空结果也缓存 3s —— 失败的 spawn 同样是慢操作。 */
  async function __listQqProcessesOnce() {
    if (process.platform !== 'win32') return [];
    const { execFile } = await import('node:child_process');
    const { promisify } = await import('node:util');
    const execFileAsync = promisify(execFile);
    try {
      const { stdout } = await execFileAsync('powershell', [
        '-NoProfile', '-NonInteractive', '-Command',
        '[Console]::OutputEncoding=[Text.Encoding]::UTF8; '
          + 'Get-CimInstance Win32_Process -Filter "name=\'QQ.exe\'" | '
          // r105 搬运（自 v0.4.5）：连 CommandLine 一起取 —— 本机 QQ 模式下机器人的
          //   QQ 和用户自己的 QQ 是同一个 exe 路径，靠命令行里的 --user-data-dir 区分。
          + 'Select-Object ProcessId,ExecutablePath,CommandLine | ConvertTo-Json -Compress'
      ], { timeout: 20000, windowsHide: true, maxBuffer: 4 * 1024 * 1024 });
      const txt = String(stdout).trim();
      if (!txt) return [];
      const data = JSON.parse(txt);
      const arr = Array.isArray(data) ? data : [data];
      return arr
        .map((p) => ({
          pid: Number(p.ProcessId),
          path: String(p.ExecutablePath ?? ''),
          cmd: String(p.CommandLine ?? '')   // r105 搬运：命令行，用于识别「机器人那份 QQ」
        }))
        .filter((p) => p.pid > 0);
    } catch {
      // 查不到就当没有。**不要**在这里退回 wmic —— 它给的乱码路径会导致
      // "误判为别的 QQ"或"漏判本机的便携 QQ"，比返回空更糟。
      return [];
    }
  }

  /** 检查便携 QQ 是否在运行（按路径匹配，不碰用户 QQ） */
  async function qqPortableRunningPid() {
    // 1) 本进程拉起过的那个：spawn 时就拿到 pid 了，不用查系统 ——
    //    最快，也不受任何编码/权限问题影响。
    if (qqPortableProc && !qqPortableProc.killed) {
      try {
        process.kill(qqPortableProc.pid, 0);   // signal 0 = 只探测存活
        return qqPortableProc.pid;
      } catch { /* 已退出，往下走 */ }
    }
    // 2) 查系统：覆盖"上次启动的 QQ 还在跑，但应用重启过"的情况
    //    r105 搬运（自 v0.4.5 r90 判据）：我们启动 QQ 时一定带
    //    --user-data-dir=<runtime/qq-portable-data>，命令行里含这个数据目录的
    //    就是机器人那份 —— 与 exe 在哪儿无关（本机 QQ 模式下机器人和用户的
    //    QQ 是同一个 exe 路径，只按路径匹配会永远显示"未运行"）。
    //    便携模式旧行为（按安装目录前缀匹配）保留为兜底。
    const procs = await listQqProcesses();
    const dataDir = qqPortableDataDir().toLowerCase();
    const byData = procs.find((p) => p.cmd && p.cmd.toLowerCase().includes(dataDir));
    if (byData) return byData.pid;
    const portableDir = qqPortableDir().toLowerCase();
    const byPath = procs.find((p) => p.path.toLowerCase().startsWith(portableDir));
    return byPath?.pid ?? null;
  }

  /**
   * 启动机器人的 QQ（r105 搬运，自 v0.4.5 r90/r100 版本）。
   *
   * ── r90 语义 ────────────────────────────────────────────────────────
   * 便携副本优先；没有便携副本时**直接用本机已装的 QQ**（不再强制复制
   * 1~2GB）。隔离靠 --user-data-dir：不管 exe 在哪儿，登录数据都写进
   * runtime/qq-portable-data，与用户日常 QQ 互不干扰。
   */
  async function launchPortableQQ() {
    // 便携 QQ 的做法是「复制本机 QQNT 目录 + 带 --user-data-dir 启动」，而 QQNT 本身
    // 只有 Windows 版。Linux/macOS 上直接说清楚，别让用户对着 spawn 失败发呆。
    if (process.platform !== 'win32') {
      return { ok: false, error: '「一键便携 QQ」仅支持 Windows —— QQNT 没有 Linux/macOS 版。Linux 上请改用外部 OneBot 协议端（如 NapCat / LLOneBot）。' };
    }
    const target = await resolveQqTarget();
    if (!target.exe) {
      return {
        ok: false,
        error: '没找到可用的 QQ：既没有便携副本，也没在本机检测到已安装的 QQ —— 请先安装新版 QQ（QQNT）'
      };
    }
    if (!fs.existsSync(target.exe)) {
      return { ok: false, error: `QQ 主程序不见了：${target.exe} —— QQ 可能已被卸载或挪走，重装后重试` };
    }
    // r132：启动前把版本核对结果落进 QQ 日志 —— 版本错开时"登录被拒/接口异常"
    // 的第一现场在这里，用户不用等出事再翻文档。'unknown' 不打扰。
    try {
      const vc = checkQqVersionMatch({ qqDir: target.dir });
      if (vc?.status === 'mismatch') {
        pushQqLog(`⚠️ ${vc.detail}`, 'stderr');
      } else if (vc?.status === 'ok') {
        pushQqLog(`版本核对通过：QQ ${vc.qqVersion} = 协议端声明 ${vc.declaredVersion}`);
      }
    } catch { /* 核对是提示性质，任何异常都不拦启动 */ }
    // 启动互斥：连点「启动 QQ」时，第一次还在 spawn，第二次直接拒绝
    if (qqPortableLaunching) {
      pushQqLog('QQ 正在启动中，忽略重复的启动请求');
      return { ok: true, alreadyRunning: true, launching: true };
    }
    const existingPid = await qqPortableRunningPid();
    if (existingPid) {
      pushQqLog(`机器人的 QQ 已在运行（pid=${existingPid}），无需重复启动`);
      return { ok: true, alreadyRunning: true, pid: existingPid };
    }

    // 本机模式：用户自己的 QQ 可能正在跑。我们不拦（QQ 带不同 --user-data-dir
    // 一般能再开一个实例），但先把话说在前面，免得"没反应"时无从下手。
    if (target.source === 'local') {
      const others = (await listQqProcesses())
        .filter((p) => p.path && p.path.toLowerCase() === target.exe.toLowerCase());
      if (others.length) {
        pushQqLog(
          `注意：你电脑上的 QQ 正在运行（pid=${others.map((o) => o.pid).join(',')}）。`
          + '机器人的 QQ 会**另开一个窗口**登录，和你的 QQ 是两套数据，不会顶掉你。',
          'stdout'
        );
      }
    }

    qqPortableLaunching = true;
    try {
      const exe = target.exe;
      const dataDir = qqPortableDataDir();
      fs.mkdirSync(dataDir, { recursive: true });

      try {
        const child = spawn(exe, [`--user-data-dir=${dataDir}`], {
          cwd: target.dir,
          stdio: ['ignore', 'pipe', 'pipe'],
          windowsHide: false, // QQ 需要显示窗口让用户扫码
          detached: true
        });
        qqPortableProc = child;
        child.unref();
        pushQqLog(
          target.source === 'local'
            ? `用你电脑里的 QQ 启动机器人（pid=${child.pid}），登录数据单独放：${dataDir}`
            : `便携 QQ 启动中（pid=${child.pid}），数据目录：${dataDir}`
        );
        child.stdout?.on('data', (d) => {
          for (const line of String(d).split(/\r?\n/)) {
            if (line.trim()) pushQqLog(line, 'stdout');
          }
        });
        child.stderr?.on('data', (d) => {
          for (const line of String(d).split(/\r?\n/)) {
            if (line.trim()) pushQqLog(line, 'stderr');
          }
        });
        child.on('exit', (code, signal) => {
          qqPortableProc = null;
          pushQqLog(`便携 QQ 进程已退出（code=${code ?? ''} signal=${signal ?? ''}）`, 'stderr');
          emit('qq-portable-status', { running: false, pid: null });
        });
        child.on('error', (error) => {
          pushQqLog(`便携 QQ 启动失败：${error?.message ?? error}`, 'stderr');
        });
        emit('qq-portable-status', { running: true, pid: child.pid });
        return { ok: true, launched: true, pid: child.pid };
      } catch (error) {
        pushQqLog(`便携 QQ 启动失败：${error?.message ?? error}`, 'stderr');
        return { ok: false, error: String(error?.message ?? error) };
      }
    } finally {
      qqPortableLaunching = false;
    }
  }

  /** 关闭便携 QQ（只杀路径匹配的 PID，绝不碰用户 QQ） */
  async function stopPortableQQ() {
    const pid = await qqPortableRunningPid();
    if (!pid) {
      pushQqLog('便携 QQ 未在运行');
      return { ok: true, stopped: false, reason: 'not_running' };
    }
    try {
      process.kill(pid, 'SIGTERM');
      pushQqLog(`已请求关闭便携 QQ（pid=${pid}）`);
      // 等待进程退出
      for (let i = 0; i < 10; i++) {
        await new Promise((r) => setTimeout(r, 500));
        const still = await qqPortableRunningPid();
        if (!still) {
          pushQqLog('便携 QQ 已退出');
          emit('qq-portable-status', { running: false, pid: null });
          return { ok: true, stopped: true, pid };
        }
      }
      // 还没退，强制 kill
      process.kill(pid, 'SIGKILL');
      pushQqLog(`便携 QQ 已强制结束（pid=${pid}）`);
      emit('qq-portable-status', { running: false, pid: null });
      return { ok: true, stopped: true, pid, forced: true };
    } catch (error) {
      pushQqLog(`关闭便携 QQ 失败：${error?.message ?? error}`, 'stderr');
      return { ok: false, error: String(error?.message ?? error) };
    }
  }

  /**
   * QQ 内核状态摘要（r105 搬运，自 v0.4.5 r90 版本）。
   * `ready` = **有能启动的 QQ**：便携副本装了 ✔ 或本机检测到 QQ ✔。
   * `source` 告诉前端当前走的是哪一种（'portable' | 'local' | 'none'）。
   * @param {{force?: boolean}} opts ?force=1 跳过本机 QQ 探测的 30s 缓存
   */
  async function qqPortableStatus(opts = {}) {
    const pid = await qqPortableRunningPid();
    const target = await resolveQqTarget(opts);
    // r132：QQ 版本 vs 协议端声明的核对结果（内部全带缓存 + 失败兜底，
    // 不会抛错；'unknown' 形态表示任一边读不到，前端不告警）。
    let versionCheck = null;
    try { versionCheck = checkQqVersionMatch({ qqDir: target.dir }); } catch { versionCheck = null; }
    return {
      ready: target.exe !== null,
      running: pid !== null,
      pid,
      dir: target.dir || qqPortableDir(),
      dataDir: qqPortableDataDir(),
      // r52：一键安装的实时进度（前端轮询 /api/status 读这里显示「复制中 n/m」）
      setup: { ...qqSetupState },
      // r89/r90：探测到本机 QQ（= 用户日常用的那个 QQ）时的路径
      localQqDir: target.source === 'local' ? target.dir : null,
      // r90：'portable' 用独立副本 / 'local' 用本机 QQ / 'none' 都没有
      source: target.source,
      // 独立副本装没装 —— 决定 UI 要不要显示「装一份独立副本（可选）」
      portableInstalled: qqPortableReady(),
      // r132：版本核对（status: 'ok' | 'mismatch' | 'unknown'，detail 带下一步话术）
      versionCheck
    };
  }

  /* ── r105 搬运（自 v0.4.5）：本机 QQ 探测 + 一键安装便携 QQ ─────────── */

  /**
   * 解析「机器人实际要启动的那份 QQ」（r90 核心）。
   * 便携副本优先，本机已装的 QQ 直接算通过。
   * @returns {{dir:string|null, exe:string|null, source:'portable'|'local'|'none'}}
   */
  async function resolveQqTarget(opts = {}) {
    if (qqPortableReady()) {
      return { dir: qqPortableDir(), exe: qqPortableExe(), source: 'portable' };
    }
    const local = await detectLocalQqDir(opts);
    if (local) {
      return { dir: local, exe: path.join(local, 'QQ.exe'), source: 'local' };
    }
    return { dir: null, exe: null, source: 'none' };
  }

  const qqSetupState = { running: false, step: '', done: 0, total: 0, error: null, ok: false };

  // /api/status 是秒级轮询，而探测要 spawn 两次 reg query + 若干 existsSync。
  // 30s 内复用上次结果（force 可跳过缓存，给"刚装完 QQ"的场景用）。
  let localQqCache = { at: 0, dir: null };
  const LOCAL_QQ_TTL = 30000;

  /** 定位本机已安装的 QQNT（带 30s 缓存）：注册表 Uninstall\QQ 优先，常见路径兜底 */
  async function detectLocalQqDir(opts = {}) {
    const now = Date.now();
    if (!opts?.force && localQqCache.at && now - localQqCache.at < LOCAL_QQ_TTL) {
      return localQqCache.dir;
    }
    const found = await detectLocalQqDirOnce();
    localQqCache = { at: now, dir: found };
    return found;
  }

  /** 注册表里可能记录 QQNT 安装位置的键（覆盖 64 位 / WOW6432Node / 当前用户三种视图） */
  const QQ_REG_KEYS = [
    'HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\QQ',
    'HKLM\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\QQ',
    'HKCU\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\QQ',
    'HKLM\\SOFTWARE\\Tencent\\QQNT',
    'HKLM\\SOFTWARE\\WOW6432Node\\Tencent\\QQNT',
    'HKCU\\SOFTWARE\\Tencent\\QQNT'
  ];
  const QQ_REG_VALUES = ['InstallLocation', 'DisplayIcon', 'InstallDir', 'InstallPath', 'Path'];

  /** 由环境变量推出的 QQNT 常见目录。
   *  ⚠️ 一律不写死盘符：ProgramFiles / LOCALAPPDATA / SystemDrive 都是运行时取的，
   *     所以系统装在哪个盘、QQ 装的是"全机器"还是"仅当前用户"都能覆盖到。 */
  function envBasedQqDirs() {
    const out = [];
    for (const root of [process.env.ProgramFiles, process.env['ProgramFiles(x86)'], process.env.ProgramW6432]) {
      if (root) out.push(path.join(root, 'Tencent', 'QQNT'));
    }
    if (process.env.LOCALAPPDATA) out.push(path.join(process.env.LOCALAPPDATA, 'Programs', 'Tencent', 'QQNT'));
    const sysDrive = process.env.SystemDrive || 'C:';
    out.push(path.join(sysDrive, 'Tencent', 'QQNT'));
    return out;
  }

  /** 枚举本机硬盘盘符（如 ['C:\\','D:\\']）。失败返回空数组 —— 探测整体不该因此失败。 */
  async function listFixedDrives() {
    try {
      const { execFile } = await import('node:child_process');
      const { promisify } = await import('node:util');
      const { stdout } = await promisify(execFile)('powershell', [
        '-NoProfile', '-NonInteractive', '-Command',
        '[Console]::OutputEncoding=[Text.Encoding]::UTF8; '
          + 'Get-PSDrive -PSProvider FileSystem | Select-Object -ExpandProperty Root'
      ], { timeout: 6000, windowsHide: true });
      // 只保留盘符形式（如 C:\ 或 D:\）。映射的网络驱动器路径会被这里滤掉 ——
      // 对断开的网络盘做 existsSync 可能长时间阻塞，不值得为它冒险。
      return String(stdout).split(/\r?\n/)
        .map((x) => x.trim())
        .filter((x) => /^[A-Za-z]:[\\/]?$/.test(x));
    } catch { return []; }
  }

  /** 兜底候选目录：环境变量优先，再枚举盘符拼（都不写死盘符）。 */
  async function qqDirFallbacks() {
    const out = envBasedQqDirs();
    for (const drive of await listFixedDrives()) {
      out.push(path.join(drive, 'Program Files', 'Tencent', 'QQNT'));
      out.push(path.join(drive, 'Program Files (x86)', 'Tencent', 'QQNT'));
      out.push(path.join(drive, 'Tencent', 'QQNT'));
    }
    return out;
  }

  /** 探测一次本机 QQNT 安装目录（无缓存）。
   *
   *  ⚠️ 这里**不允许**再出现写死盘符的路径（原实现硬编码了 C:\\ / D:\\ 五条，
   *     换台机器、或把 QQ 装到别的盘/用户目录就整个失效）。
   *     现在按「注册表 → 环境变量 → 枚举盘符」三级兜底，只拼相对片段 Tencent\\QQNT。 */
  async function detectLocalQqDirOnce() {
    // QQNT 只有 Windows 版：注册表（HKLM/HKCU）、Get-PSDrive、%ProgramFiles% 全是
    // Windows 语义，非 Windows 上直接短路，别白跑三次 reg query 再返回 null。
    if (process.platform !== 'win32') return null;
    const candidates = [];
    // ── ① 注册表：三种视图都查（原实现只查 WOW6432Node，64 位安装与"仅当前用户"
    //       两种安装方式都查不到）──
    try {
      const { execFile } = await import('node:child_process');
      const { promisify } = await import('node:util');
      const execFileAsync = promisify(execFile);
      for (const key of QQ_REG_KEYS) {
        for (const val of QQ_REG_VALUES) {
          try {
            const { stdout } = await execFileAsync('reg', ['query', key, '/v', val],
              { timeout: 8000, windowsHide: true });
            const m = /REG_SZ\s+(.+)/.exec(String(stdout));
            if (m) candidates.push(m[1].trim());
          } catch { /* 单个键值查不到就继续 */ }
        }
      }
    } catch { /* reg 不可用就走路径探测 */ }
    // ── ② + ③ 环境变量 / 盘符枚举 ──
    for (const base of await qqDirFallbacks()) candidates.push(base);
    for (const raw of candidates) {
      if (!raw) continue;
      // DisplayIcon 形如 "X:\dir\QQ.exe,0" → 取目录；InstallLocation 本就是目录
      let dir = String(raw).replace(/,0$/, '').trim().replace(/^"|"$/g, '');
      if (/QQ\.exe$/i.test(dir)) dir = path.dirname(dir);
      if (dir && fs.existsSync(path.join(dir, 'QQ.exe'))) return dir;
    }
    return null;
  }

  /** 源目录的 QQ.exe 是否在运行（按完整路径匹配，不碰其它 QQ） */
  async function qqRunningFromDir(dir) {
    try {
      const procs = await listQqProcesses();
      const exe = path.join(dir, 'QQ.exe').toLowerCase();
      return procs.find((p) => p.path && p.path.toLowerCase() === exe) || null;
    } catch { return null; }
  }

  /** 顶层逐条复制（fs.promises.cp 无进度回调，按顶层条目打点） */
  async function copyDirWithProgress(src, dst) {
    fs.mkdirSync(dst, { recursive: true });
    const entries = fs.readdirSync(src, { withFileTypes: true });
    qqSetupState.total = entries.length;
    let done = 0;
    for (const ent of entries) {
      await fs.promises.cp(path.join(src, ent.name), path.join(dst, ent.name), { recursive: true, force: true });
      done++;
      qqSetupState.done = done;
      qqSetupState.step = ent.name;
      pushQqLog(`[一键安装] ${done}/${entries.length} ${ent.name}`);
    }
  }

  /** 唤起便携 QQ 主窗口（NTQQ 启动后不自动弹窗，新手找不到登录入口）。
   *  按 pid 枚举它名下**有标题的顶层窗口**（隐藏的也要枚举 —— NTQQ「关闭窗口」
   *  是 SW_HIDE），最小化的 SW_RESTORE、隐藏的 SW_SHOW，再 SetForegroundWindow 置前。 */
  async function showPortableQQ() {
    if (process.platform !== 'win32') {
      return { ok: false, error: '仅支持 Windows' };
    }
    const pid = await qqPortableRunningPid();
    if (!pid) {
      pushQqLog('便携 QQ 未在运行，无法唤起窗口');
      return { ok: false, error: '便携 QQ 未在运行 —— 请先启动 QQ' };
    }
    const { execFile } = await import('node:child_process');
    const { promisify } = await import('node:util');
    const execFileAsync = promisify(execFile);
    const ps = [
      '$target = ' + pid,
      'Add-Type -TypeDefinition @"',
      'using System;',
      'using System.Runtime.InteropServices;',
      'public class QQWin {',
      '  public delegate bool EnumProc(IntPtr h, IntPtr l);',
      '  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr lp);',
      '  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);',
      '  [DllImport("user32.dll")] public static extern int GetWindowTextLength(IntPtr h);',
      '  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);',
      '  [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);',
      '  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);',
      '  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);',
      '}',
      '"@',
      '$script:found = 0',
      '$cb = [QQWin+EnumProc]{ param($h, $l)',
      '  $wpid = [uint32]0',
      '  [QQWin]::GetWindowThreadProcessId($h, [ref]$wpid) | Out-Null',
      '  if ($wpid -eq $target -and [QQWin]::GetWindowTextLength($h) -gt 0) {',
      '    if ([QQWin]::IsIconic($h)) { [QQWin]::ShowWindow($h, 9) | Out-Null }',
      '    elseif (-not [QQWin]::IsWindowVisible($h)) { [QQWin]::ShowWindow($h, 8) | Out-Null }',
      '    [QQWin]::SetForegroundWindow($h) | Out-Null',
      '    $script:found++',
      '  }',
      '  $true',
      '}',
      '[QQWin]::EnumWindows($cb, [IntPtr]::Zero) | Out-Null',
      'Write-Output "FOUND $($script:found)"'
    ].join('\n');
    try {
      const { stdout } = await execFileAsync('powershell', [
        '-NoProfile', '-NonInteractive', '-Command', ps
      ], { timeout: 15000, windowsHide: true, maxBuffer: 1024 * 1024 });
      const m = /FOUND\s+(\d+)/.exec(String(stdout));
      const found = m ? Number(m[1]) : 0;
      if (found > 0) {
        pushQqLog(`已唤起便携 QQ 窗口（pid=${pid}，命中 ${found} 个窗口）`);
        return { ok: true, shown: found, pid };
      }
      pushQqLog(`未找到便携 QQ 的窗口（pid=${pid}）—— 可能还在启动`, 'stderr');
      return { ok: false, error: '没找到 QQ 的窗口 —— 刚启动的话 QQ 可能还在初始化，稍等几秒再试' };
    } catch (error) {
      pushQqLog(`唤起便携 QQ 窗口失败：${error?.message ?? error}`, 'stderr');
      return { ok: false, error: String(error?.message ?? error) };
    }
  }

  /**
   * 一键安装便携 QQ（r52/r105）：从本机已安装的 QQNT 复制一份。
   * 复制本机安装目录即完成安装。**源目录只读**，绝不写用户 QQ 一个字节。
   * @param {{sourceDir?: string}} opts
   */
  async function setupPortableQQFromLocal(opts = {}) {
    if (qqSetupState.running) {
      return { ok: false, error: '正在安装中，请等当前安装完成（看下方日志的复制进度）' };
    }
    if (qqPortableReady()) {
      return { ok: true, alreadyInstalled: true };
    }
    // force：用户刚装完 QQ 就来点安装，别拿 30s 前的"没找到"糊弄他
    const sourceDir = String(opts?.sourceDir || '').trim() || await detectLocalQqDir({ force: true });
    if (!sourceDir) {
      return {
        ok: false,
        error: '没找到本机安装的 QQ（需要装过新版 QQ/QQNT）。也可以看下方日志里的说明手动指定目录'
      };
    }
    if (!fs.existsSync(path.join(sourceDir, 'QQ.exe'))) {
      return { ok: false, error: `这个目录里没有 QQ.exe：${sourceDir}` };
    }
    const busy = await qqRunningFromDir(sourceDir);
    if (busy) {
      return {
        ok: false,
        needExit: true,
        error: `本机 QQ 正在运行（pid=${busy.pid}）：请先完全退出 QQ（包括托盘图标）再点安装`
      };
    }
    qqSetupState.running = true;
    qqSetupState.done = 0; qqSetupState.total = 0;
    qqSetupState.error = null; qqSetupState.ok = false;
    qqSetupState.step = '准备复制';
    pushQqLog(`一键安装：从 ${sourceDir} 复制便携 QQ 到 ${qqPortableDir()}（源目录只读）`);
    try {
      await copyDirWithProgress(sourceDir, qqPortableDir());
      qqSetupState.running = false;
      qqSetupState.ok = true;
      qqSetupState.step = '完成';
      pushQqLog('[一键安装] 便携 QQ 安装完成 ✓ 可点「单独启动 QQ」了');
      return { ok: true, installed: true, dir: qqPortableDir() };
    } catch (error) {
      qqSetupState.running = false;
      qqSetupState.error = String(error?.message ?? error);
      pushQqLog(`一键安装失败：${qqSetupState.error}`, 'stderr');
      const busyHint = /EBUSY|EPERM|EACCES/i.test(qqSetupState.error)
        ? ' —— 多半是 QQ 还在运行或有文件被占用：完全退出 QQ 后重试'
        : '';
      return { ok: false, error: '安装失败：' + qqSetupState.error + busyHint };
    }
  }

  /** 拉起 SnowLuma。优先用项目内置 node.exe 直接运行（日志进内置控制台）；失败再回退到独立窗口 launcher.bat。 */
  async function launchSnowluma() {
    if (snowlumaStopping) return { ok: false, error: 'SnowLuma 正在关闭，请稍后重试' };
    // 只要有人（用户或看门狗）真的调了启动，就清掉"用户要求停着"的标记。
    snowlumaUserStopped = false;
    // ⚠️ 平台守卫（2026-10-13 加）：内置的 SnowLuma 只提供 Windows 原生模块
    //    （snowluma-win32-x64.node / .dll）与 node.exe，Linux/macOS 上根本无法启动。
    //    不拦的话会一路走到 spawn(nodeExe) 再失败，报的是「目录里没有 node.exe」——
    //    用户完全看不出真正原因。这里直接说明白，并给出外部 OneBot 的替代路径。
    if (process.platform !== 'win32') {
      return { ok: false, error: 'Linux 版不内置 SnowLuma 协议端（其原生模块只发布了 Windows 构建）。请改用外部 OneBot 协议端（如 NapCat / LLOneBot，均有 Linux 版），把设置里的 SnowLuma wsUrl / httpUrl 指向它（默认 ws://127.0.0.1:3001、http://127.0.0.1:3000），并保持「启动时自动拉起 SnowLuma」关闭。' };
    }
    const dir = snowlumaDir();
    if (!dir) return { ok: false, error: '找不到 SnowLuma 目录：请确认项目内 snowluma/ 文件夹存在，或在设置里填写 SnowLuma 目录' };
    // ⚠️ 端口探测必须用 WebUI 端口（2026-09-19）：WS 3001 是 OneBot 实例开的，
    // OneBot 实例只有**账号登录后**才创建 —— "SnowLuma 起了但还没登录"是常态
    // （用户先启动 QQ Agent，再扫码）。用 3001 判"运行中"会把正常状态误判成
    // "未运行"，于是又拉起第二个 SnowLuma 实例 → 两个进程抢 mojo 管道与端口，
    // 用户看到的是"管道异常/连接不上/时好时坏"这类无法自圆其说的现象。
    // WebUI 端口进程一启动就监听，与登录无关，才是"进程活着"的准确信号。
    const probePort = snowlumaWebuiPort();

    // ── 启动互斥（防多次点击「运行 SnowLuma」端口冲突 / 多实例）──
    // 三道防线，按成本从低到高：
    //   1. 本进程正在启动中（用户连点按钮）→ 直接拒绝
    //   2. 本进程已拉起过 SnowLuma（snowlumaProc 活着）→ 已在运行
    //   3. 端口已被任何进程占用（包括上次残留 / 别的实例）→ 已在运行
    if (snowlumaLaunching) {
      pushSnowlumaLog('SnowLuma 正在启动中，忽略重复的启动请求', 'stdout');
      return { ok: true, alreadyRunning: true, launching: true };
    }
    if (snowlumaProc && !snowlumaProc.killed) {
      pushSnowlumaLog(`SnowLuma 已由本实例拉起（pid=${snowlumaProc.pid}），无需重复启动`, 'stdout');
      // N5：本实例拉起的也验一次 —— 用户可能在两次启动之间去控制台改过密码。
      await diagnoseWebuiAuth('SnowLuma 已由本实例拉起：');
      scheduleAutoInjectBotQq({ force: true });
      return { ok: true, alreadyRunning: true, pid: snowlumaProc.pid };
    }
    if (await isPortOpen('127.0.0.1', probePort)) {
      pushSnowlumaLog(`SnowLuma 已在运行（WebUI 端口 ${probePort} 已就绪），无需重复启动`, 'stdout');
      // ⚠️（2026-10-17 · N5）这里从前是**直接 return**：既不做鉴权体检、也不排期注入。
      //   于是"用户自己双击启动的雪茹 / 上次崩了但雪茹还活着"这条最常见的现场，
      //   用的是雪茹自己的初始密码 → 我们登录恒失败 → 自动注入全灭，而日志里
      //   一句解释都没有。现在补两件事：① 只读体检（能登 / 不能登说清楚怎么修）；
      //   ② 补排期（这条路径此前谁都没想到要排期，只有 start() 里另调了一次）。
      await diagnoseWebuiAuth('SnowLuma 已在运行：');
      scheduleAutoInjectBotQq({ force: true });
      return { ok: true, alreadyRunning: true };
    }

    snowlumaLaunching = true;
    try {
      // 2026-10-15（二次细化）：准备 SnowLuma WebUI 鉴权 —— QQ Agent 接管 WebUI 密码，
      // 才能调用注入 API 精准注入「机器人那份 QQ」（不再用一刀切的 SNOWLUMA_HOOK_AUTOLOAD，
      // 那个会注入所有发现的 QQ，包括个人 QQ）。只在我们即将启动时才动 webui.json。
      const slAuth = prepareSnowlumaWebuiAuth(dir);
      // ⚠️ 密码在返回值的 bootstrap 字段里（{bootstrap: pw}）—— 曾经错写成 slAuth.password
      //（不存在 → undefined）→ 服务端收到的环境变量是空的 → 永远走「生成初始凭据」分支，
      // 接管从未生效过（用户被迫在控制台设自己的密码 → QQ Agent 登录不上 → 自动注入全灭）。
      const slAuthEnv = slAuth.bootstrap ? { SNOWLUMA_WEBUI_BOOTSTRAP_PASSWORD: String(slAuth.bootstrap) } : {};
      const indexMjs = path.join(dir, 'index.mjs');
      const nodeExe = path.join(dir, 'node.exe');
      if (fs.existsSync(indexMjs) && fs.existsSync(nodeExe)) {
        try {
          // 用 Windows 的 CREATE_NEW_PROCESS_GROUP + 独立进程方式启动，
          // 让 SnowLuma 真正独立于 Electron 主进程（Electron 退出时不会拖垮它）。
          // 2026-10-15：SnowLuma ≥1.14.20 要求显式同意 EULA/隐私策略，缺任一项会
          // 在首启卡住「同意页」导致机器人连不上。这里把两项注入环境，无人值守/自动
          // 拉起时直接跳过同意页（老版本忽略未知环境变量，向下兼容）。
          const snowlumaEnv = {
            ...process.env,
            SNOWLUMA_ACCEPT_EULA: '1',
            SNOWLUMA_ACCEPT_PRIVACY: '1',
            ...slAuthEnv
          };
          const child = spawn(nodeExe, [indexMjs], {
            cwd: dir,
            stdio: ['ignore', 'pipe', 'pipe'],
            windowsHide: true,
            detached: false,
            env: snowlumaEnv
          });
          snowlumaProc = child;
          child.unref();
          pushSnowlumaLog(`SnowLuma 启动中（内置模式，pid=${child.pid}）…`, 'stdout');
          // 2026-10-17：把控制台凭据写进日志 —— 自动注入失败的用户要手动注入时，
          //   第一件事就是登录控制台，而他们只会盯着这块日志找密码（见该函数注释）。
          pushSnowlumaLog(snowlumaConsoleCredentialLog('SnowLuma 已启动。'), 'stdout');
          child.stdout.on('data', (d) => {
            for (const line of String(d).split(/\r?\n/)) {
              if (line.trim()) pushSnowlumaLog(line, 'stdout');
            }
          });
          child.stderr.on('data', (d) => {
            for (const line of String(d).split(/\r?\n/)) {
              if (line.trim()) pushSnowlumaLog(line, 'stderr');
            }
          });
          child.on('exit', (code, signal) => {
            snowlumaProc = null;
            pushSnowlumaLog(`SnowLuma 进程已退出（code=${code ?? ''} signal=${signal ?? ''}）`, 'stderr');
            emit('snowluma-status', { running: false, embedded: false, pid: null });
          });
          child.on('error', (error) => {
            pushSnowlumaLog(`SnowLuma 启动失败：${error?.message ?? error}`, 'stderr');
          });
          emit('snowluma-status', { running: true, embedded: true, pid: child.pid });
          // 2026-10-15：启动成功后自动打开控制台（WebUI）一次，萌新无需手动找入口；
          // 同时排期「精准注入机器人 QQ」（只注入用户指定的那份，不碰个人 QQ）。
          scheduleAutoOpenSnowlumaConsole();
          scheduleAutoInjectBotQq({ force: true });
          return { ok: true, launched: true, embedded: true, pid: child.pid };
        } catch (error) {
          pushSnowlumaLog(`内置模式启动失败，尝试回退独立窗口：${error?.message ?? error}`, 'stderr');
          snowlumaProc = null;
        }
      }
      // 回退：launcher.bat 独立控制台窗口（老行为，日志无法内置）
      const launcher = path.join(dir, 'launcher.bat');
      if (!fs.existsSync(launcher)) return { ok: false, error: `目录里没有 index.mjs / node.exe，也没有 launcher.bat：${dir}` };
      const child = spawn('cmd.exe', ['/c', launcher], {
        cwd: dir,
        detached: true,
        stdio: 'ignore',
        windowsHide: false, // 保留 SnowLuma 自己的控制台窗口
        env: {
          ...process.env,
          SNOWLUMA_ACCEPT_EULA: '1',
          SNOWLUMA_ACCEPT_PRIVACY: '1',
          ...slAuthEnv
        }
      });
      child.unref();
      pushSnowlumaLog('SnowLuma 已用独立控制台窗口启动（此模式下日志不进内置控制台）', 'stdout');
      // 独立窗口模式下 SnowLuma 自己的输出进不去内置日志，但**我们**这条要留 ——
      // 手动注入需要的凭据全在这一行里。
      pushSnowlumaLog(snowlumaConsoleCredentialLog('SnowLuma 已启动。'), 'stdout');
      scheduleAutoOpenSnowlumaConsole();
      scheduleAutoInjectBotQq({ force: true });
      return { ok: true, launched: true, embedded: false };
    } finally {
      // 启动动作结束后释放互斥标记（端口就绪与否由上面的端口探测兜底）
      snowlumaLaunching = false;
    }
  }

  // 2026-10-15：启动 SnowLuma 后自动打开控制台（WebUI）。
  // 萌新登录 QQ 后常不知道要去控制台手动「进程注入」；现在 QQ Agent 在 WebUI 端口就绪后
  // 自动唤起默认浏览器打开 SnowLuma 控制台一次，免去手动找入口。
  // 每个进程生命周期只开一次（snowlumaConsoleAutoOpened 兜底），且可被 snowluma.autoOpenConsole=false 关闭。
  let snowlumaConsoleAutoOpened = false;
  function scheduleAutoOpenSnowlumaConsole() {
    if (snowlumaConsoleAutoOpened) return;
    if (getConfig().snowluma?.autoOpenConsole === false) return;
    snowlumaConsoleAutoOpened = true;
    const webuiPort = snowlumaWebuiPort();
    const tryOpen = async () => {
      // 等 WebUI 端口就绪（最多 ~25s），就绪后立即打开控制台。
      // ⚠️（2026-10-17 N6 / SnowLuma 报告 L3）**必须区分"就绪"与"超时"**。
      //    旧写法无论端口是否就绪都往下走，两种情形在用户侧都表现为
      //    "什么都没发生"（自动打开功能像坏了），而 catch 里只写主进程 console ——
      //    普通用户看不到。现在两类可观测失败都往内置控制台推一条可读日志。
      let ready = false;
      for (let i = 0; i < 25; i++) {
        if (await isPortOpen('127.0.0.1', webuiPort)) { ready = true; break; }
        await new Promise((resolve) => setTimeout(resolve, 1000));
      }
      if (!ready) {
        pushSnowlumaLog(`等待 WebUI 端口 ${webuiPort} 就绪超时（约 25s），已跳过自动打开控制台；SnowLuma 可能仍在启动，稍后可手动打开。`, 'warn');
        return;
      }
      const webuiUrl = snowlumaWebuiUrl();
      if (!webuiUrl || !/^https?:\/\/[^\s&|^<>]+$/.test(String(webuiUrl))) {
        pushSnowlumaLog('SnowLuma 控制台地址无效，未自动打开浏览器。', 'warn');
        return;
      }
      // 与 /api/snowluma/open-webui 同源的净化：URL 必须 http(s) 且无 shell 元字符。
      const child = spawn('cmd.exe', ['/c', 'start', '', webuiUrl], { detached: true, stdio: 'ignore' });
      // 启动即忘的 `start` 不会把"没有可用浏览器"之类的错误回传父进程，
      // 但 spawn 本身失败（如 cmd.exe 不可用）会走 'error' —— 一样要可见。
      child.on('error', (err) => {
        pushSnowlumaLog(`自动打开 SnowLuma 控制台失败：${err?.message ?? err}`, 'warn');
      });
      child.unref();
    };
    tryOpen().catch((err) => {
      pushSnowlumaLog(`自动打开 SnowLuma 控制台失败：${err?.message ?? err}`, 'warn');
      log('[snowluma] 自动打开控制台失败:', err?.message ?? err);
    });
  }

  // ── SnowLuma WebUI HTTP 客户端（用于精准注入，避免一刀切注入所有 QQ）──
  // 这些只在 QQ Agent 主进程内调用；SnowLuma 的 WebUI 与 API 同端口。
  // token 缓存：同 base 10 分钟内复用 —— SnowLuma 登录错误 5 次会锁 ~15 分钟，
  // 每次点选按钮/每轮注入轮询都重新登录是纯风险（用户实测被锁到怀疑密码不对）。
  let slTokenCache = { base: '', token: '', at: 0 };
  /**
   * 最近一次 slLogin 失败的原因（只给调用方区分"密码被拒"和"根本连不上"用）。
   * kind: '' | 'rejected' | 'locked' | 'unreachable'
   */
  let slLoginFail = { kind: '', message: '' };
  /** 同 base + 同密码的登录单飞（{key, promise}）—— 防并发登录踩「错 5 次锁 15 分钟」 */
  let slLoginInflight = null;
  /**
   * SnowLuma WebUI 请求的硬超时（2026-10-17 加固）。
   *
   * 为什么必须有：`fetch` 本身**没有**业务级超时，undici 默认要等到
   * headersTimeout（300 秒）才失败。而"端口开着但服务卡死"是雪茹的常见故障
   * （进程还在、WebUI 不响应）。没有超时的话，下面三条 await 链会一起悬住：
   *   ① 页面读「控制台密码」的 GET（前端一直转圈，看起来像卡死）；
   *   ② 点「运行 SnowLuma」的 POST（同前，而且已经在跑了，本不该等）；
   *   ③ 注入看门狗（snowlumaInjectRunning 长期为 true，自愈停摆）。
   * 本机 HTTP 往返都是毫秒级，这些上限给得非常宽松，只用来兜"服务无响应"。
   */
  const SL_TIMEOUT_LOGIN_MS = 10 * 1000;
  const SL_TIMEOUT_GET_MS = 8 * 1000;
  // load / unload 要动 QQ 进程（装组件），比查询慢得多，但也不能无限等
  const SL_TIMEOUT_POST_MS = 30 * 1000;
  const slFetch = (url, init = {}, ms = SL_TIMEOUT_GET_MS) => fetch(url, { ...init, signal: AbortSignal.timeout(ms) });
  /**
   * 登录 SnowLuma WebUI（**单飞包装**：同一 base + 同一密码，同一时刻只发一次请求）。
   *
   * 为什么要单飞（2026-10-17 加固）：雪茹对「连续登录失败 5 次」会锁 ~15 分钟。
   * 而同时可能有 3 条链各自去登录：注入轮次、页面读密码的体检、用户点「取消注入」
   * /「切换账号」。密码一旦不对，这 3 次并发登录就是 3 次失败计数 —— 再加上页面
   * 重绘再验一次，用户的密码锁就被自己踩满了，表现是「明明密码是对的，却说登不上」。
   * 单飞之后：并发只算一次，失败计数按"用户真的又试了一次"增长。
   *
   * ⚠️ 只对**完全相同**（base + 密码）的请求合并；force 与不带 force 的请求也合并 ——
   *    两种情况都是"去问服务器要一个 token"，共享结果没有语义差别。
   *
   * @param {string} base
   * @param {string} pw
   * @param {{force?: boolean, timeoutMs?: number}} [opt] force=true 时**绕过 token 缓存**真的去问一次服务器 ——
   *   只有"要验密码对不对"的地方用（见 probeSnowlumaWebuiAuth），日常调用别传。
   *   timeoutMs 给"只是顺手验一下"的调用方一个更短的上限（页面读密码不能等 10 秒）。
   * @returns {Promise<string|null>} token / null
   */
  async function slLogin(base, pw, opt = {}) {
    // 缓存命中直接返回（单飞之前在缓存之后判定：缓存不该被"正在登录"挡住）
    if (!opt.force && slTokenCache.token && slTokenCache.base === base && Date.now() - slTokenCache.at < 10 * 60 * 1000) {
      return slTokenCache.token;
    }
    const key = `${base}|${String(pw ?? '')}`;
    if (slLoginInflight && slLoginInflight.key === key) return slLoginInflight.promise;
    // ⚠️ 必须把契约咬死成 `Promise<string|null>`（2026-10-17 加固）：
    //    slLoginImpl 内部虽已 try/catch，但只要它抛出**任何**东西（哪怕是把来的重构引入的），
    //    单飞那个 Promise 就会变成 rejected，而 `let token = await slLogin(...)` 这种写法
    //    在注入轮次里**没有局部 try/catch**（只靠外层 run().catch 兜底）—— 多一层不确定的
    //    reject 面就多一次"这一轮白跑/看门狗打一行异常"的机会。这里统一降级成 null，
    //    并记成 unreachable（= 短退避 30 秒），而不是密码类长退避。
    const promise = slLoginImpl(base, pw, opt).catch((error) => {
      // ⚠️ catch 里也要能容错：log() 自己抛（日志盘满 / 流已销毁）就会让这个
      //    "降级处理器"再抛一次，等于白兜。这一层是最后一道，必须哑火。
      try { log('[snowluma] 登录流程内部异常（按"连不上"处理）:', error?.message ?? error); } catch { /* ignore */ }
      slLoginFail = { kind: 'unreachable', message: `内部异常：${error?.message ?? error}` };
      return null;
    }).finally(() => {
      if (slLoginInflight && slLoginInflight.promise === promise) slLoginInflight = null;
    });
    slLoginInflight = { key, promise };
    return promise;
  }
  async function slLoginImpl(base, pw, opt = {}) {
    slLoginFail = { kind: '', message: '' };
    try {
      const r = await slFetch(`${base}/api/login`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ password: pw || '' })
      }, opt.timeoutMs || SL_TIMEOUT_LOGIN_MS);
      const j = await r.json().catch(() => null);
      if (j && j.success && j.token) {
        slTokenCache = { base, token: j.token, at: Date.now() };
        // 实测证据：这份密码现在**确实能登**（N1 唯一的"没漂移"来源）
        slAuthNote(pw, true, 'verified');
        return j.token;
      }
      // 把服务端的人话透传出来（"密码错误" / "登录尝试过多，请 N 秒后重试"），别吞成 null
      const msg = (j && (j.message || j.error))
        || (r.status === 429 ? '登录尝试过多，被临时锁定，请等几分钟再试' : `HTTP ${r.status}`);
      // ⚠️ 429 = 输错太多次被锁，**说明不了密码对不对** → 记成"测不了"，
      //    绝不能据此给用户贴「密码可能已失效」（那会导致误点重置 → 注入全断）。
      //    版本差异：有的雪茹版本把锁定时长写在 body 里而 HTTP 仍是 200，所以
      //    除状态码外还要看文案，否则一次误锁就会长期挂上"已失效"标签。
      const locked = r.status === 429 || /过多|锁定|locked|too many/i.test(msg);
      if (locked) slAuthNote(pw, null, 'locked', msg);
      else slAuthNote(pw, false, 'rejected', msg);
      // 调用方（自动注入）要靠这个区分"该不该退避 15 分钟"
      slLoginFail = { kind: locked ? 'locked' : 'rejected', message: msg };
      // 2026-10-20（S5 修）：这里只落盘、不进页面「运行日志」面板。
      // 调用方（自动注入 / 取消注入 / 切换 / 列表）自己会打一条带上下文的话；
      // 两边都打，用户看到的是两行"登录失败"，读起来像两次独立事故。
      log(`[snowluma] WebUI 登录失败：${msg}`);
      slTokenCache = { base: '', token: '', at: 0 };
      return null;
    } catch (e) {
      // 网络不可达 = 雪茹没起 / 端口还没就绪，同样不是"密码错了"。
      // 已有同密码的结论就保留（否则一次网络抖动会把"已验证"抹成"未验证"）。
      const msg = e?.name === 'TimeoutError' ? '请求超时（控制台无响应）' : (e?.message ?? String(e));
      // ⚠️ 超时 / 连接被重置都归到这里：**绝对不能**当成"密码被拒"。
      //    当成密码被拒的代价是 15 分钟长退避 + 一句误导人的「密码不被认可」，
      //    用户会去点「重置并接管」（雪茹重启，注入全断），而真正的问题只是服务卡了一下。
      slLoginFail = { kind: 'unreachable', message: msg };
      if (slAuthProbe.password !== String(pw ?? '')) slAuthNote(pw, null, 'unreachable', msg);
      // 2026-10-20（S5 修）：这里只落盘、不进页面「运行日志」面板。
      // 调用方（自动注入 / 取消注入 / 切换 / 列表）自己会打一条带上下文的话；
      // 两边都打，用户看到的是两行"登录失败"，读起来像两次独立事故。
      log(`[snowluma] WebUI 登录失败：${msg}`);
      return null;
    }
  }
  async function slGet(base, token, p) {
    try {
      const r = await slFetch(`${base}${p}`, { headers: { authorization: `Bearer ${token}` } }, SL_TIMEOUT_GET_MS);
      if (r.status === 401) {
        // ── 2026-10-20（S3 修）：清缓存后**返回 null**，不要把 401 的 body 当数据返回 ──
        // 旧写法 `return await r.json()`：401 的 body 是合法 JSON（{success:false,...}），
        // 于是调用方的 `if (!list)`「请求失败」分支永远不会触发，而 `list.list || []`
        // 得到空数组 —— 令牌失效被误报成「进程表是空的（QQ 还没登录）」，方向全错。
        slTokenCache = { base: '', token: '', at: 0 };  // token 失效，下轮重新登录
        return null;
      }
      // 其他非 2xx（405/500）的 body 同样不是进程表，一律按"这次没读到"处理
      if (!r.ok) return null;
      return await r.json().catch(() => null);
    } catch {
      return null;
    }
  }
  async function slPost(base, token, p, body) {
    try {
      const r = await slFetch(`${base}${p}`, {
        method: 'POST',
        headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json' },
        body: JSON.stringify(body || {})
      }, SL_TIMEOUT_POST_MS);
      return await r.json().catch(() => null);
    } catch {
      return null;
    }
  }

  /**
   * 主动验一次「config 里的控制台密码现在还能不能登录」（N1 的配套，2026-10-17）。
   *
   * 谁调用：① 读「控制台密码」框之前（路由里 await，让 drifted 有真凭据）；
   *         ② 「雪茹已经在跑，但不是我们这轮拉起的」时的体检（N5）。
   *
   * 为什么不每次读都登录：SnowLuma 连续登录失败 5 次会锁 ~15 分钟，
   * 密码框随页面反复重绘就会把用户锁在门外。所以结论带 TTL ——
   * 成功的结论缓存 5 分钟、失败的缓存 10 分钟（失败更贵，宁可用旧结论）。
   *
   * @param {{force?: boolean}} [opt] force 跳过 TTL（只在用户明确点「重试」时用）
   * @returns {Promise<{ok: boolean|null, kind: string}>} ok=null 表示"测不了"（没跑 / 没密码）
   */
  async function probeSnowlumaWebuiAuth(opt = {}) {
    const pw = String(getConfig().snowluma?.webuiPassword || '');
    if (!pw) return { ok: null, kind: 'no-password' };
    const webuiPort = snowlumaWebuiPort();
    // 端口探测给短超时（400ms）：这是"顺手确认一下"，不能拖慢页面
    if (!(await isPortOpen('127.0.0.1', webuiPort, 400))) return { ok: null, kind: 'not-running' };
    // 「连不上」也要短缓存（30 秒）：服务卡死时每次页面重绘都真去等一次超时，
    // 在用户那里就是"设置页打开要卡十几秒"。30 秒足够覆盖一次页面渲染 / 连点刷新，
    // 又不会把恢复拖太久（真恢复了，30 秒后自动重验）。
    if (!opt.force && slAuthProbe.kind === 'unreachable'
      && slAuthProbe.password === pw && Date.now() - slAuthProbe.at < 30_000) {
      return { ok: null, kind: 'unreachable' };
    }
    const ttl = slAuthProbe.ok === false ? 10 * 60 * 1000 : 5 * 60 * 1000;
    const fresh = slAuthProbe.password === pw && slAuthProbe.ok !== null && Date.now() - slAuthProbe.at < ttl;
    if (fresh && !opt.force) return { ok: slAuthProbe.ok, kind: slAuthProbe.kind };
    if (slAuthProbeInflight) return slAuthProbeInflight;
    slAuthProbeInflight = (async () => {
      const base = (snowlumaWebuiUrl() || `http://127.0.0.1:${webuiPort}/`).replace(/\/$/, '');
      // force：不读 token 缓存 —— 要的是"现在这一刻密码对不对"，不是"十分钟前对过"。
      // 超时 6 秒（比注入用的 10 秒短）：这条链是页面同步等的，宁可早放弃也别让界面卡住。
      const token = await slLogin(base, pw, { force: true, timeoutMs: 6000 });
      // 超时 / 连不上 ≠ 密码错：返回"测不了"，让 drifted 保持不下结论（N1 的判据靠这个）。
      if (!token && slLoginFail.kind === 'unreachable') return { ok: null, kind: 'unreachable' };
      return { ok: Boolean(token), kind: token ? 'verified' : (slAuthProbe.kind || 'rejected') };
    })().finally(() => { slAuthProbeInflight = null; });
    return slAuthProbeInflight;
  }

  /**
   * 「雪茹已经在跑，但不是我们这轮拉起的」→ 只做**只读体检**（N5，2026-10-17）。
   *
   * 现场：用户习惯自己双击雪茹（或上次 QQ Agent 崩了但雪茹还活着）→ 走
   * launchSnowluma / snowlumaReady 的"已在运行"早退分支 → 从前**一次鉴权都不验**
   * → 雪茹用着它自己的初始密码 → QQ Agent 登录恒失败 → 自动注入一句「密码不被认可」
   * 就结束，用户根本不知道该点「重置并接管」。
   *
   * ⚠️ 这里**只诊断，不动 webui.json、不重启雪茹**：用户可能正连着机器人，
   *    自动重置会把他直接踢下线 —— 那正是 N1 误报把人害惨的路径。
   */
  async function diagnoseWebuiAuth(reason = '') {
    const pw = String(getConfig().snowluma?.webuiPassword || '');
    if (!pw) {
      pushSnowlumaLog(`${reason}控制台密码尚未生成 —— 自动注入需要它才能登录控制台，请点「重置并接管控制台密码」。`, 'warn');
      return { ok: false, kind: 'no-password' };
    }
    const r = await probeSnowlumaWebuiAuth().catch((error) => {
      // 体检本身出错不该把"运行 SnowLuma"这条链变成 500 —— 当成"测不了"继续往下走
      try { log('[snowluma] 控制台密码体检异常（不影响启动）:', error?.message ?? error); } catch { /* ignore */ }
      return { ok: null, kind: 'probe-error' };
    });
    if (r.ok === true) {
      pushSnowlumaLog(`${reason}已确认控制台密码可用（自动注入能登录控制台）。`, 'stdout');
      return r;
    }
    if (r.ok === null) {
      // 没在跑 / 刚被锁定 / 网络不通 —— 不下结论，别吓用户
      pushSnowlumaLog(`${reason}暂时无法验证控制台密码（${r.kind}），等 SnowLuma 就绪后自动注入会再试一次。`, 'stdout');
      return r;
    }
    // 2026-10-20（S2）：被锁定时不能报"密码不被认可" —— 那会把用户推向"重置并接管"
    if (r.kind === 'locked') {
      pushSnowlumaLog(`${reason}控制台暂时无法登录：连续失败被临时锁定 —— 这不代表密码错了，等几分钟会自动恢复，请不要为此重置密码。`, 'warn');
      return r;
    }
    pushSnowlumaLog(`${reason}控制台密码不被认可 —— 这份 SnowLuma 用的是它自己的初始密码，或者你在控制台里改过密码。`, 'warn');
    pushSnowlumaLog(snowlumaConsoleCredentialLog('手动注入所需凭据 →'), 'warn');
    pushSnowlumaLog(SNOWLUMA_MANUAL_INJECT_GUIDE, 'warn');
    pushSnowlumaLog('若要让 QQ Agent 重新接管：点本页「重置并接管控制台密码」（会重启 SnowLuma 并断开当前注入），机器人正连着时请等它闲时再做。', 'warn');
    return r;
  }
  // botQQ 留空时的兜底已升级（2026-10-15）：不再按 exe 路径匹配（本机 QQ 模式下
  // 机器人与用户共用同一个 exe，路径永远匹配不上 → 自动注入从未生效过）。
  // 改用 qqPortableRunningPid()：按「我们启动 QQ 时必带的 --user-data-dir」命令行
  // 精准识别机器人那份（r105 判据，本机/便携模式都准），拿 pid 去 SnowLuma 进程表比对。

  // 2026-10-15（二次细化）：精准注入「用户指定的机器人 QQ」，绝不碰个人 QQ。
  // 之前用 SNOWLUMA_HOOK_AUTOLOAD 会一刀切注入所有发现的 QQ（含个人 QQ）—— 不对。
  // 现在改为：SnowLuma WebUI 就绪后轮询进程，对每个未注入的 QQ 用 probe-login 读出 uin；
  // 只有 uin 命中 botQQ 的那份才调 load 注入。botQQ 留空时回退到路径识别（仍只认机器人那份）。
  // ── 注入调度状态（2026-10-17「成功后永不自愈」修：把"跑没跑"和"成功过没"拆开）──
  // 旧实现只有一个布尔 `snowlumaInjectGuard`，语义是「每进程生命周期只跑一次」：
  // 失败路径会把它还回来，**成功路径不还**（当时的用意是防止端口抖动反复排期）。
  // 但没人给"成功之后"配一条重新开始的入口，于是形成一条真实的死锁：
  //   注入成功 → 雪茹重启（Hook 丢失）→ OneBot 的 WS 3001 **永远不会再监听**
  //   → 「端口关→开」这个唯一的重排期触发点根本不会发生
  //   → 守卫又永远是 true → **机器人永久掉线**。
  // 更糟的是此时 `injectCancelled=false`，界面按钮文案是「取消注入」——
  // 用户/小白**看不到「重新注入」**，只能重启整个应用。
  // （实测脚本 `_luofix/t-probe-guard-reinject.mjs` 7/7 复现并钉死了这条链。）
  //
  // 现在拆成三个量，各自只负责一件事：
  //   · snowlumaInjectRunning —— 此刻是否有**一轮在跑**（纯粹的并发去重，跑完必复位）
  //   · snowlumaInjectNextAt  —— 常规重试的最早时刻（秒级退避，防刷日志）
  //   · snowlumaInjectAuthAt  —— 密码被拒后的长退避（防撞上雪茹「错 5 次锁 15 分钟」）
  // 「成功过」不再是状态 —— 它由 **OneBot 是否真连着** 实时判断：连着就没事，
  // 断了就自愈（见 start() 里的自动注入看门狗）。
  let snowlumaInjectRunning = false;
  let snowlumaInjectNextAt = 0;
  let snowlumaInjectAuthAt = 0;
  // 「已取消注入」这句话由看门狗每 20 秒问一次，只提示一次就够。
  let snowlumaInjectCancelLogged = false;
  // 用户上一次**显式动这个页面**的时刻（切换账号 / 取消注入 / 重新注入 / 重置并接管）。
  // 这些操作自己会排期注入；夹一个 20 秒静默窗，免得看门狗在"卸载旧号 → 注入新号"
  // 的中途插进来对同一个进程再 load 一次（那是新增的并发面，必须堵住）。
  let snowlumaUserActionAt = 0;
  // 密码被拒后的长退避：雪茹对连续登录失败会锁 15 分钟，退避必须 ≥ 它，
  // 否则「5 次失败 → 锁 15 分 → 解锁后再失败 5 次」会无限循环，永远好不了。
  const SL_AUTH_FAIL_BACKOFF_MS = 15 * 60 * 1000;
  // 2026-10-17（报告5 M2 修）：注入轮询的「代号」。
  // 原实现只有一个布尔守卫，而且**只在入口看一次** —— 置位之后循环体内部再也不看它。
  // 于是用户点「取消注入」后立刻点「重新注入」（resumeInject 会复位守卫并再次排期），
  // 若旧循环还卡在某次 await 上，就会出现**两个 run() 并行**：双倍 WebUI 请求、
  // 更快撞上登录锁（5 次错误锁 15 分钟）、两处都可能执行 load 注入。
  // 改成递增代号：每真正启动一轮就 ++，循环内每轮（以及 load 之前）比对，
  // 不是自己的代号就立刻退出。取消注入 / 重新注入都会让旧循环当场作废。
  let snowlumaInjectGen = 0;
  /** 这一轮注入是否已被更新的调度取代（取消注入 / 重新注入 / 重新排期）。 */
  const injectStale = (myGen) => snowlumaInjectGen !== myGen;

  // 判「OneBot 连上没有」= 模块级纯函数 onebotOnlineVerdict（文件顶部，可单测）。

  /**
   * 排期一轮自动注入。
   * @param {{force?: boolean, reason?: string}} [opt]
   *   force=true 绕过常规退避（用户显式动作，例如「重新注入」/ 重置并接管）。
   *   ⚠️ force **不能**绕过密码长退避 —— 密码被拒时反复真登录会把雪茹的
   *      「错 5 次锁 15 分钟」踩满，反而更难恢复；要解除只能重置密码或重启应用。
   * @returns {boolean} 是否真的开了一轮
   */
  function scheduleAutoInjectBotQq(opt = {}) {
    if (snowlumaInjectRunning) return false;
    if (getConfig().snowluma?.autoInject === false) return false;
    // 用户点过「取消注入」→ 持久暂停：本轮不跑，重启应用也不跑（2026-10-15 用户要求：
    // 取消之后就不该再自动重新注入），直到点「重新注入」或重置接管流程显式恢复。
    if (getConfig().snowluma?.injectCancelled) {
      if (!snowlumaInjectCancelLogged) {
        snowlumaInjectCancelLogged = true;
        pushSnowlumaLog('自动注入：处于「已取消注入」暂停状态，跳过（点「重新注入」可恢复）', 'warn');
      }
      return false;
    }
    snowlumaInjectCancelLogged = false;
    if (Date.now() < snowlumaInjectAuthAt) return false;
    if (!opt.force && Date.now() < snowlumaInjectNextAt) return false;
    snowlumaInjectRunning = true;
    const myGen = ++snowlumaInjectGen;   // 启动新一轮 = 让所有旧循环作废（M2）
    /** 被更新的调度取代了？是则记一句并返回 true（调用方直接 return）。 */
    const staleStop = () => {
      if (!injectStale(myGen)) return false;
      pushSnowlumaLog('自动注入：本轮已被更新的调度取代（取消注入 / 重新注入 / 重新排期），停止', 'warn');
      return true;
    };
    /**
     * 收尾：结束本轮并设定下一次最早可重试的时刻。
     *
     * 与旧 releaseGuard 的关系：旧版只有"放行 / 不放行"两种，且**成功时不放行**，
     * 导致成功后永不自愈（详见 snowlumaInjectRunning 上方注释）。这里统一改成
     * "本轮结束 + 一个退避时长"，成功也结束 —— 是否要再来一轮由看门狗按
     * 「OneBot 到底连着没有」决定，而不是按"做过没有"。
     *
     * @param {number} nextDelayMs 下一次最早可重试的延迟（0 = 立刻可再排期）
     * ⚠️ 被取代的轮次**必须什么都不做**：状态已归新循环所有，改它就是踩新循环。
     */
    const finishRound = (nextDelayMs = 0) => {
      if (injectStale(myGen)) return;
      snowlumaInjectRunning = false;
      snowlumaInjectNextAt = Date.now() + nextDelayMs;
    };
    const run = async () => {
      const webuiPort = snowlumaWebuiPort();
      // 等 WebUI 端口就绪（最多 ~2 分钟，给冷启动留足；注入本身很快）
      for (let i = 0; i < 120; i++) {
        if (await isPortOpen('127.0.0.1', webuiPort)) break;
        await new Promise((r) => setTimeout(r, 1000));
      }
      if (staleStop()) return;
      if (!(await isPortOpen('127.0.0.1', webuiPort))) {
        // 等了 2 分钟端口还没起 —— 对小白来说这就是"协议端没开"，必须说清怎么开，
        // 光说"端口未就绪"他会以为是自己网络问题。
        pushSnowlumaLog(`自动注入：等了 2 分钟 SnowLuma 的控制台端口（${webuiPort}）还没起来 —— 协议端没在运行。`
          + '请点页面上的「运行 SnowLuma」；设置里开了「启动时自动拉起 SnowLuma」的话，重启 QQ Agent 即可。', 'warn');
        finishRound(30_000);
        return;
      }
      const base = (snowlumaWebuiUrl() || `http://127.0.0.1:${webuiPort}/`).replace(/\/$/, '');
      const pw = getConfig().snowluma?.webuiPassword;
      if (staleStop()) return;
      let token = await slLogin(base, pw);
      if (!token) {
        // 2026-10-17（加固）：先分清"密码被拒"和"根本连不上"。
        //   连不上（超时 / 连接被重置 / 服务卡死）跟密码毫无关系，却和密码错走同一条
        //   15 分钟长退避 —— 于是雪茹只是卡了一下，自动注入就哑了 15 分钟，日志还写着
        //   「密码不被认可」，把用户引去点「重置并接管」（雪茹重启、注入全断）。
        //   这里按原因分岔：连不上只等 30 秒，不打密码的标签。
        if (slLoginFail.kind === 'unreachable') {
          pushSnowlumaLog(`自动注入：连不上 SnowLuma 控制台（${slLoginFail.message || '无响应'}）—— 端口开着但没响应，30 秒后再试；这不影响控制台密码。`, 'warn');
          finishRound(30_000);
          return;
        }
        // 2026-10-20（S2 修）：被锁 ≠ 密码错。
        // 429 /「登录尝试过多」说明不了密码对不对，却和"密码被拒"共用一句
        // 「密码不被认可 → 请点重置并接管」的话术 —— 而重置会重启雪茹、断开当前注入。
        // 这正是 2026-10-17 N1 只修了一半的地方（做到了"别给密码贴失效标签"，
        // 没做到"别把锁误报成密码错"）。这里单独分支，并明确劝止重置。
        if (slLoginFail.kind === 'locked') {
          pushSnowlumaLog(`自动注入：SnowLuma 控制台因连续登录失败被临时锁定（${slLoginFail.message || '请稍后重试'}）`
            + '—— 这不代表密码错了，锁定过去后会自动恢复。此时**不要**点「重置并接管控制台密码」，'
            + '那会重启 SnowLuma 并断开当前注入。', 'warn');
          // 与 rejected 同样落长退避：锁定期间再登录只会把锁续上，而 force 不该绕过它
          // （authAt 的检查在 force 之前）。⚠️ 必须单独赋值 —— finishRound 写的是
          // snowlumaInjectNextAt，那条闸 force 能绕，挡不住"锁定期内反复登录"。
          if (!injectStale(myGen)) snowlumaInjectAuthAt = Date.now() + SL_AUTH_FAIL_BACKOFF_MS;
          finishRound(SL_AUTH_FAIL_BACKOFF_MS);
          return;
        }
        pushSnowlumaLog('自动注入：无法登录 SnowLuma WebUI（密码不被认可，可能你给控制台设过密码）。', 'warn');
        // 2026-10-17：这条失败路径正是「要手动注入」的现场 —— 把凭据 + 三步指引一并
        //   打出来，用户照抄就能登进控制台。此前这里只有一句"或在控制台手动注入"，
        //   却没给密码，对用户等于没说（反馈原话：日志中看不到登录密码）。
        pushSnowlumaLog(snowlumaConsoleCredentialLog('手动注入所需凭据 →'), 'warn');
        pushSnowlumaLog(SNOWLUMA_MANUAL_INJECT_GUIDE, 'warn');
        // 密码被拒 = 真登录失败。这里必须退避 15 分钟：雪茹对连续登录失败会锁
        // 15 分钟，短退避会让看门狗把锁踩满，反而永远恢复不了。
        // 解除方式只有用户显式动作（重置并接管 / 重新注入）或重启应用。
        // ⚠️ 只有"仍是当前这一轮"才许写：被取代的老一轮（用户点了取消/切换/重新注入）
        //    如果在这里落一个 15 分钟长退避，会把新调度一起压住 —— 表现就是
        //    "刚重置了密码，注入却 15 分钟没动静"。finishRound 本身有这层保护，
        //    但这个变量是**直接赋值**的，得单独挡。
        if (!injectStale(myGen)) snowlumaInjectAuthAt = Date.now() + SL_AUTH_FAIL_BACKOFF_MS;
        finishRound(SL_AUTH_FAIL_BACKOFF_MS);
        return;
      }
      // 等机器人 QQ 登录（用户扫码/输密码），最多 6 分钟。
      // botQQ 每轮都重读（用户可能在轮询期间才填）；留空时按命令行识别的 pid 兜底。
      const deadline = Date.now() + 6 * 60 * 1000;
      let reloginFailAt = 0;      // N3：重新登录失败别每轮刷一行
      let missLogged = false;     // N4：首次"没匹配到目标"只打一次明细
      let awaitingOnline = false; // N2：本轮是否见过「已注入但 OneBot 还没连上」
      const warnedPending = new Set();  // N2：同一个 pid 的"还没连上"只提示一次
      // 本轮由**我们自己** load 成功的 pid。用来区分"刚注入完在等连接"与
      // "上次就已经注入了"——两者都走"已注入只复查"的分支，但日志该说不同的话
      // （否则用户会看到"无需重复注入"，而明明就是刚才注入的，读起来像自相矛盾）。
      const injectedByUs = new Set();
      while (Date.now() < deadline) {
        // 轮询中用户点了「取消注入」→ 立即收手，别把刚卸载的又注回去
        if (getConfig().snowluma?.injectCancelled) {
          pushSnowlumaLog('自动注入：用户已取消注入，本轮停止', 'warn');
          finishRound(0);
          return;
        }
        // 被更新的调度取代（M2）→ 立刻退出，别和新的那轮并行跑
        if (staleStop()) return;

        // ── N3：token 可能已经被 401 清掉了（雪茹重启 / 令牌轮换）───────────
        // 旧写法是"取一次用到底"：slGet 收到 401 只清缓存，循环里仍拿那个死 token
        // 请求 → /api/processes 恒 null → processes=[] → 静默空转到 6 分钟，
        // 最后报「限时内未找到」（方向全错：其实一次请求都没成）。
        if (!slTokenCache.token || slTokenCache.base !== base) {
          const fresh = await slLogin(base, String(getConfig().snowluma?.webuiPassword || ''));
          if (!fresh) {
            if (Date.now() - reloginFailAt > 30000) {
              reloginFailAt = Date.now();
              pushSnowlumaLog('自动注入：控制台登录已失效，重新登录也没成功（雪茹可能重启过，或密码被改），30 秒后再试', 'warn');
            }
            await new Promise((r) => setTimeout(r, 5000));
            continue;
          }
          token = fresh;
          pushSnowlumaLog('自动注入：控制台登录已刷新（雪茹重启或令牌轮换），继续', 'stdout');
        }

        const botQQ = String(getConfig().snowluma?.botQQ || '').trim();
        const botPid = botQQ ? null : await qqPortableRunningPid();
        const list = await slGet(base, token, '/api/processes');
        if (!list) {
          // 请求本身失败（401 已在 slGet 里清缓存，下一轮会重新登录）
          await new Promise((r) => setTimeout(r, 3000));
          continue;
        }
        const processes = list.list || [];
        let retryThisRound = false;   // 本轮 load 失败过 → 多等一会儿
        let matchedBot = 0;
        const seen = [];              // N4：给"没匹配到"的日志用
        for (const p of processes) {
          const pid = Number(p.pid);
          let uin = snowlumaProcessAccount(p).uin;
          // 已注入的 p.uin 直接可信；未注入的常是 '0'，要 probe-login 才读得出
          // （v2.0.2 起 account.uin 在上一步就已拿到，这里只有 v1 会真正发请求）
          if ((!uin || uin === '0') && !p.injected) {
            const info = await slGet(base, token, `/api/processes/${p.pid}/probe-login`);
            uin = (info && info.info && info.info.uin) || '';
          }
          const isBot = botQQ
            ? (String(uin) === String(botQQ))
            : (botPid != null && Number(pid) === Number(botPid));
          if (!isBot) {
            seen.push(`pid ${p.pid}${uin ? ` uin=${uin}` : ''}${p.injected ? '（已注入）' : ''}`);
            continue;
          }
          matchedBot++;

          // ── 2026-10-20（P4 修）：本轮已经 load 过这个 pid → 只复查，绝不再 load ──
          // 旧代码里 injectedByUs 只用来决定日志措辞（见下面两个分支）。而 load 成功后
          // 若复查发现 OneBot 还没连上，走的是 continue → 3 秒后重拉进程表；此刻真实
          // SnowLuma 的 injected 标志由它自己的 watcher 刷新，不会在 /load 返回时立刻
          // 置 true，于是 p.injected 仍为 false → **又调一次 /load**。
          // 重复 load 轻则白跑一次，重则把已建好的 OneBot 会话重建（WS 断开、重连窗口
          // 内的群消息丢失）。假雪茹（返回即置位）测不出这条，所以原来的断言漏了它。
          if (injectedByUs.has(pid)) {
            const v = onebotOnlineVerdict(p);
            if (v.online) {
              pushSnowlumaLog(`已自动注入机器人 QQ（pid=${p.pid}${uin ? ` uin=${uin}` : ''}），OneBot 已连接`, 'stdout');
              finishRound(60_000);
              return;
            }
            awaitingOnline = true;
            continue;
          }

          // ── N2 + 「已经注入过」的复查（2026-10-17）────────────────────────
          // 旧代码在这里是 `if (p.injected) continue;` —— 于是"上次已经注入好、
          // 这次重启 QQ Agent"这个**最常见**的场景永远匹配不到任何东西，空转
          // 6 分钟后报「限时内未找到/未成功注入」，纯属误报。现在：已注入 →
          // 只复查 OneBot 是否真连上，连上了就直接宣布成功。
          if (p.injected) {
            const v = onebotOnlineVerdict(p);
            if (v.online) {
              const tail = `（pid=${p.pid}${uin ? ` uin=${uin}` : ''}）`;
              if (injectedByUs.has(pid)) {
                pushSnowlumaLog(`已自动注入机器人 QQ${tail}，OneBot 已连接`, 'stdout');
              } else {
                pushSnowlumaLog(`机器人 QQ 已在注入状态且 OneBot 已连接${tail}，无需重复注入`, 'stdout');
              }
              // 结论是"一切正常" → 60 秒内不再重排期。看门狗本来就以
              // onebot.connected 为先决条件，这一条只是抹平"雪茹说在线、我们
              // 的 WS 还差一两秒才连上"这个窗口，避免多打一行重复日志。
              finishRound(60_000);
              return;
            }
            awaitingOnline = true;
            // 同一个 pid 只提示一次，避免每 3 秒刷一行同样的警告
            if (!warnedPending.has(pid)) {
              warnedPending.add(pid);
              pushSnowlumaLog(`自动注入：Hook 已装上但 OneBot 还没连上（pid=${p.pid}，${v.why}），继续等`, 'warn');
            }
            continue;
          }

          // 2026-10-17（报告5 M1 兜底）：真正 load 之前再查一次取消标记 + 代号。
          // 「取消注入」的卸载流程要等 2.5 秒复查，如果本循环恰好在这段窗口里
          // await 到这里，注入就会在卸载**之后**又被装回去 —— 而 cancel 只让
          // "下一轮"退出，本轮已经把 DLL 注回去了。用户看到的就是"取消失败"。
          if (staleStop()) return;
          if (getConfig().snowluma?.injectCancelled) {
            pushSnowlumaLog('自动注入：用户已取消注入，放弃本次注入', 'warn');
            finishRound(0);
            return;
          }
          const r = await slPost(base, token, `/api/processes/${p.pid}/load`, {});
          if (r && r.success) {
            injectedByUs.add(pid);
            // pid 兜底命中时顺手把探测到的 uin 记成 botQQ —— 下次启动直接按 QQ 号精准匹配
            // ⚠️ 被取代的老一轮不许写：用户可能刚「切换到 B」，而这一轮是照着
            //    切换前的空 botQQ 用 pid 匹配到 A 的（把 A 写回去 = 切换被撤销）。
            if (!botQQ && uin && uin !== '0' && !injectStale(myGen)) {
              updateConfig({ snowluma: { botQQ: String(uin) } });
              pushSnowlumaLog(`已自动记住机器人 QQ：${uin}（下次启动按 QQ 号精准注入）`, 'stdout');
            }
            // ── N2：success 只代表「组件装进去了」，必须立刻复查运行态 ──────
            // 不复查就会 log「已自动注入」然后 return，而用户那边 OneBot 明明没连上。
            const after = await slGet(base, token, '/api/processes');
            const self = after ? (after.list || []).find((q) => Number(q.pid) === pid) : undefined;
            // 复查请求本身失败时别下"进程消失了"的结论 —— 那是两件不同的事，
            // 说错了会把用户往"QQ 掉线"的方向带偏。
            const v = after ? onebotOnlineVerdict(self) : { online: false, why: '复查请求没成功（稍后自动再看）' };
            if (v.online) {
              pushSnowlumaLog(`已自动注入机器人 QQ（pid=${p.pid}${uin ? ` uin=${uin}` : ''}），OneBot 已连接`, 'stdout');
              finishRound(60_000);
              return;
            }
            awaitingOnline = true;
            pushSnowlumaLog(`自动注入：组件已装入 pid=${p.pid}，${v.why}，继续观察（不会重复注入）`, 'stdout');
            continue;
          }
          pushSnowlumaLog(`注入失败（pid=${p.pid}）：${r && r.message ? r.message : '未知错误'}，稍后重试`, 'warn');
          retryThisRound = true;
        }

        // ── N4：一个目标都没匹配到 → 把"我到底看到了什么"说清楚 ──────────────
        // 旧代码在这种情况下零日志，用户只等到 6 分钟后一句「未找到」，
        // 分不清是"号没登录"、"登录的不是这个号"，还是"压根没进程"。
        if (!matchedBot && !missLogged) {
          missLogged = true;
          if (!processes.length) {
            pushSnowlumaLog('自动注入：SnowLuma 的进程表还是空的（QQ 还没登录 / 还没被检出），继续等', 'warn');
          } else if (!botQQ && botPid == null) {
            pushSnowlumaLog(`自动注入：没有注入目标（「注入目标」为空，也没识别到 QQ Agent 启动的那份 QQ）—— 当前看到 ${processes.length} 个 QQ 进程。请填「注入目标」或点「从已登录 QQ 选择」`, 'warn');
          } else {
            pushSnowlumaLog(`自动注入：注入目标（${botQQ ? `QQ ${botQQ}` : `pid ${botPid}`}）不在 SnowLuma 的进程表里 —— 当前看到 ${processes.length} 个：${seen.join('、')}。请确认那个号已经登录`, 'warn');
          }
        }
        await new Promise((r) => setTimeout(r, retryThisRound ? 5000 : 3000));
      }
      // 本轮结束（超时退出，非用户取消、非被取代）。
      // 这里不再"永久烧掉调度机会"：由看门狗按 OneBot 实际连接状态决定要不要再来一轮。
      // 退避取值的意思：
      //   awaitingOnline → 60 秒。Hook 在、只差 QQ 登录完成，短退避能尽早接上；
      //   no match       → 120 秒。本轮已经空转满 6 分钟，"没人登录"是稳定状态，
      //                    退避长一点只是少打日志，用户一登录下一轮照样能抓到。
      finishRound(awaitingOnline ? 60_000 : 120_000);
      if (awaitingOnline) {
        // N2：注入其实成功了，卡在 OneBot 连接 —— 提示必须指向"接下来查什么"，
        // 而不是像旧文案那样说"未成功注入"（那会把排查方向带到注入上，全错）。
        pushSnowlumaLog(`自动注入：机器人 QQ 的 Hook 已装上，但 6 分钟内 OneBot 仍未连上 —— 请确认那个 QQ 是否还正常登录，以及 SnowLuma 是否已启用 OneBot 实例（ws://127.0.0.1:${snowlumaWsPort()}）。后台会继续自动重试。`, 'warn');
        // 2026-10-20（S8）：端口对不上是"连接受限"的真实成因之一，但旧日志一点线索
        // 都没有 —— 目标号的 onebot_<uin>.json 里端口若与 wsUrl 不同，那个号再怎么登录
        // 也连不上，而报错只有一句 `connected=false loggedIn=false status=空`。
        const cfgBotQQ = String(getConfig().snowluma?.botQQ || '').trim();
        const cfgWsPort = snowlumaConfiguredWsPortFor(cfgBotQQ);
        if (cfgWsPort && cfgWsPort !== snowlumaWsPort()) {
          pushSnowlumaLog(`⚠ 端口对不上：目标号 ${cfgBotQQ} 的 OneBot WS 端口是 ${cfgWsPort}，`
            + `但 QQ Agent 连的是 ${snowlumaWsPort()} —— 请把「设置 → 连接与启动」里的 wsUrl `
            + `改成 ws://127.0.0.1:${cfgWsPort}，否则它永远不会连上。`, 'warn');
        }
      } else {
        pushSnowlumaLog('自动注入：这一轮没找到可注入的机器人 QQ（多半是那个号还没登录）。后台会每 2 分钟自动再看一次，不用手动点；'
          + '若一直不注入，翻上面的日志看它到底看到了哪些进程。', 'warn');
      }
    };
    run().catch((err) => {
      finishRound(30_000);
      log('[snowluma] 自动注入异常:', err?.message ?? err);
    });
  }

  // 雪茹整个挂掉时的自动拉起退避（看门狗用；失败一次就退避，别刷屏）
  let slRelaunchRetryAt = 0;
  // 连续拉起失败次数 → 指数退避（5 分钟起，封顶 1 小时）。
  // 为什么不用定长 5 分钟：雪茹起不来通常是硬故障（缺原生模块 / 目录被删 / 端口被别的程序占），
  // 定长退避会让它每小时崩 12 次、日志刷 12 行，用户以为"软件在自己乱动"。
  let slRelaunchFails = 0;
  // 2026-10-20（P1 修）：「OneBot 连着、但连的不是注入目标」的告警/纠正限频。
  // 没有这两个量的话，看门狗每 20 秒都会告警一次、并反复触发 switchBot。
  let slWrongAccountAt = 0;
  let slWrongAccountBusy = false;
  // 注入目标的"变动感知"（2026-10-20，P1 与「仅保存」的语义冲突修）：
  //   「仅保存」按钮的承诺是"下次启动生效，不做任何注入改动"（见 UI title）。
  //   如果看门狗一发现 selfId ≠ botQQ 就立刻 switchBot，那用户点「仅保存」后
  //   一分钟内就会被自动切走 —— 按钮语义被悄悄改写。所以：
  //     · 目标刚变过 10 分钟内 → 只告警、不自动纠正（尊重"仅保存"）；
  //     · 超过 10 分钟仍不一致（用户没管）→ 才自动纠正（机器人必须用对号）。
  let slBotQQSeen = null;
  let slBotQQChangedAt = 0;

  /**
   * 自动注入看门狗的单次判定（2026-10-17 · A 修）。
   *
   * 它存在的**唯一**理由：注入成功之后 Hook 若丢失（雪茹重启 / 机器人 QQ 重登），
   * OneBot 的 WS 3001 会永远不再监听 —— 没有端口边沿，`obPortPollTimer` 里的那次
   * 补排期一次都不会触发；而旧守卫"成功后不还"，于是永久不恢复。
   * 所以判据必须是**结果**（OneBot 到底连着没有），而不是过程（这一轮做没做过）。
   *
   * 由 `start()` 里的 `setInterval(slInjectWatchdogTick, 20_000)` 驱动；
   * 也通过 `__testInjectWatchdogTick` 暴露给离线验证脚本直接调用（生产无副作用）。
   */
  // ── 单账号约束（2026-10-24 参照上游 0.4.8.8）─────────────────────────────
  // 产品定位：**同时只注入一个账号，不支持多开**。这不是"建议"，是要强制的。
  let slSingleAccountAt = 0;
  let slSingleAccountBusy = false;
  let slSingleAccountWarnedSig = '';   // 告警去重：状态没变就不重复刷
  let slSingleAccountAuthUntil = 0;    // 登录失败后的退避（控制台密码问题交给注入流程去报）

  /**
   * 强制「同一时刻只有一个账号处于注入状态」。
   *
   * 为什么不能只靠下面的 selfId 对账：那段纠正逻辑有个前提 —— `onebot.connected`
   * 得先为真。可目标号如果注入后**抢不到 OneBot 端口**（两个号的 onebot_<uin>.json
   * 端口都是 3000/3001），它压根连不上，于是永远走不到那段，而占着端口的那个号
   * 会一直留在注入状态里 —— 这正是"多开"，且雪茹侧会显示成"未启用"（排查黑洞）。
   *
   * 所以这里不看连接状态，直接查雪茹进程表：injected 的号多于一个，就把非目标号
   * 卸掉。宁可多卸一次（卸错了下一轮自动注入会注回来），也不让两个号长期并存。
   *
   * 边界（都不能碰）：
   *   · 没定注入目标 → 返回，交给注入流程去定，这里不猜；
   *   · 用户「取消注入」或关了自动注入 → 返回（那个语义就是"别动我的进程"）；
   *   · 用户刚在页面上动过手（20 秒窗）→ 让开，别和切换/取消抢同一个进程；
   *   · **目标号自己不在注入列表里 → 这一轮完全不碰** —— 否则把"所有号"都当成
   *     多余的卸光，机器人瞬间没有任何注入、而目标号又没登录，比多开更糟。
   *
   * @returns {Promise<number>} 请求卸载被接受的进程数（unload 返回值不可信，见下）
   */
  async function enforceSingleInjection() {
    const sl = getConfig().snowluma || {};
    const wantQQ = String(sl.botQQ || '').trim();
    if (!wantQQ || sl.injectCancelled || sl.autoInject === false) return 0;
    const now = Date.now();
    if (slSingleAccountBusy || slWrongAccountBusy) return 0;      // 与 selfId 纠正互斥
    if (now - slSingleAccountAt < 60_000) return 0;               // 限频：每分钟最多查一次
    if (now - snowlumaUserActionAt < 20_000) return 0;            // 用户正在操作，让开
    // ⚠️ 控制台密码不对时**不能**每 60 秒硬试一次：雪茹对登录失败有速率限制
    //    （连续失败会临时锁定），而这条检查不是关键路径 —— 没必要为了它去撞锁。
    if (now < slSingleAccountAuthUntil) return 0;
    slSingleAccountAt = now;
    slSingleAccountBusy = true;
    try {
      const webuiPort = snowlumaWebuiPort();
      if (!(await isPortOpen('127.0.0.1', webuiPort, 600))) return 0;
      const base = (snowlumaWebuiUrl() || `http://127.0.0.1:${webuiPort}/`).replace(/\/$/, '');
      const token = await slLogin(base, getConfig().snowluma?.webuiPassword);
      if (!token) {
        // 登不进控制台 → 这轮不插手，并且 10 分钟内不再试（避免撞雪茹的登录限频）。
        slSingleAccountAuthUntil = Date.now() + 10 * 60_000;
        return 0;
      }
      slSingleAccountAuthUntil = 0;
      const list = await slGet(base, token, '/api/processes');
      if (!list) return 0;                                        // 读不到 ≠ 没有，不下结论
      const injected = (list.list || []).filter((p) => p && p.injected);
      if (injected.length <= 1) {
        slSingleAccountWarnedSig = '';                            // 恢复正常 → 清签名，下次能重新告警
        return 0;                                                 // 正常：只有一个号在注
      }

      const hasTarget = injected.some((p) => String(snowlumaProcessAccount(p).uin || '') === wantQQ);
      if (!hasTarget) return 0;                                   // 交给注入流程去注目标号

      const extras = [];
      for (const p of injected) {
        const uin = String(snowlumaProcessAccount(p).uin || '');
        if (uin === wantQQ) continue;                             // 目标号留着
        // uin 拿不到时别直接塞 pid —— 日志里一串数字会被当成 QQ 号，反而误导
        extras.push({ pid: p.pid, uin: uin || `pid:${p.pid}` });
      }
      if (!extras.length) return 0;

      // ⚠️ 动手前**再确认一次**用户有没有动过手：开头那次检查在 await 之前，
      //    登录 + 拉进程表可能花掉几秒，期间用户可能正在切换目标。
      if (Date.now() - snowlumaUserActionAt < 20_000) return 0;

      // ⚠️ unload 的返回值**不可信**：服务端对已注入进程是空操作，HTTP 照样返回
      //    success（上游实测：返回成功、2.5 秒后复查仍是 injected=true）。
      //    这里数的是"请求被接受几次"，真正的验证在下一轮（60 秒后再看列表）。
      let okCount = 0;
      for (const o of extras) {
        try {
          const r = await slPost(base, token, `/api/processes/${o.pid}/unload`, {});
          if (r && (r.success ?? r.ok)) okCount++;
        } catch { /* 单个失败不影响其他 */ }
      }
      const names = extras.map((x) => x.uin).join('、');
      // 告警去重：Hook 卸不掉时会每 60 秒重来一次，不去重就变成刷屏。
      const sig = `${injected.length}|${names}|${okCount}`;
      if (sig !== slSingleAccountWarnedSig) {
        slSingleAccountWarnedSig = sig;
        pushSnowlumaLog(
          `⚠ 检测到 ${injected.length} 个账号同时处于注入状态（${names}）—— `
          + `本应用只支持注入一个账号，已请求卸载 ${extras.length} 个多余账号`
          + `（${okCount} 个被接受）。`
          + `如果过一会儿还是同样的告警，说明没真卸掉：运行中的 Hook 无法热卸载，`
          + `请退出并重启那个 QQ。`,
          'warn'
        );
      }
      return okCount;
    } catch (error) {
      try { log('[snowluma] 单账号约束检查失败（不影响主流程）:', error?.message ?? error); } catch { /* ignore */ }
      return 0;
    } finally {
      slSingleAccountBusy = false;
    }
  }

  async function slInjectWatchdogTick() {
    try {
      // ── 单账号约束（2026-10-24 参照上游）──────────────────────────────────
      // 放在「连上了吗」判断**之前**：目标号如果抢不到端口就压根连不上，而恰恰是
      // 这种时候最需要先把多余的号清掉 —— 放到 connected 分支里就永远轮不到它。
      await enforceSingleInjection();
      const sl = getConfig().snowluma || {};
      if (onebot.connected) {
        // ── 2026-10-20（P1 修）：连着 ≠ 连对了 ──────────────────────────────
        // 旧判据只有 `onebot.connected` 一个布尔。可 OneBot 的 WS 端口属于**被注入的
        // 那个 QQ 进程**：多号同时注入时谁先抢到 3001 就是谁（两个号的 OneBot 配置
        // 端口都是 3000/3001，实测）。于是"配置写着 A、实际连着个人号 B"这种状态，
        // 旧看门狗第一行就 return，永远不会发现、更不会纠正 —— 机器人用错号说话，
        // 界面还显示"已连接、正常工作中"。selfId 是 get_login_info 拿到的真实登录号，
        // 用它对账（注意 3721 那条注释早就承认过"selfId 只是当前占用端口的账号"）。
        //
        // 用户已取消 / 关了自动注入时**不纠正**：纠正走 switchBot，而它会清掉
        // injectCancelled —— 那等于替用户撤销"取消"，绝不允许。
        if (sl.injectCancelled || sl.autoInject === false) return;
        const wantQQ = String(sl.botQQ || '').trim();
        // 感知注入目标是否刚被改过（见 slBotQQSeen 注释里的「仅保存」语义）
        if (slBotQQSeen === null) slBotQQSeen = wantQQ;
        else if (slBotQQSeen !== wantQQ) { slBotQQSeen = wantQQ; slBotQQChangedAt = Date.now(); }
        const selfId = String(onebot.selfId || '');
        if (!wantQQ || !selfId || selfId === wantQQ) return;   // selfId 空 = 还没取到，等下一轮
        const justSaved = Date.now() - slBotQQChangedAt < 10 * 60 * 1000;
        if (Date.now() - slWrongAccountAt > 60_000) {
          slWrongAccountAt = Date.now();
          pushSnowlumaLog(`⚠ OneBot 连的是 ${selfId}${onebot.selfNickname ? `（${onebot.selfNickname}）` : ''}，`
            + `但注入目标是 ${wantQQ} —— 另一个号仍处于注入状态并抢到了 OneBot 端口。`
            + (justSaved
              ? '你刚改过注入目标：如果只是点了「仅保存」，这是预期的（下次启动才生效）；'
                + '要现在就切过去，点「切换到此账号」。'
              : '正在尝试撤掉它（若提示卸不掉，请退出并重启那个 QQ）。'), 'warn');
        }
        // 用户刚在页面上动过手（20 秒窗）不插手；刚改过配置（10 分钟窗）也只告警；
        // 上一次纠正还在跑不并发。
        if (!justSaved && !slWrongAccountBusy && Date.now() - snowlumaUserActionAt > 60_000) {
          slWrongAccountBusy = true;
          const target = wantQQ;
          snowlumaSwitchBot(target)
            .then((r) => {
              if (r && r.ok) pushSnowlumaLog(`已纠正注入目标：现在只注入 ${target}（OneBot 将重新连接）`, 'stdout');
              else pushSnowlumaLog(`自动纠正注入目标失败：${(r && r.error) || '未知原因'}`, 'warn');
            })
            .catch((e) => pushSnowlumaLog(`自动纠正注入目标异常：${e?.message ?? e}`, 'warn'))
            .finally(() => { slWrongAccountBusy = false; });
        }
        return;
      }
      if (sl.autoInject === false || sl.injectCancelled) return;
      // 用户正在页面上动手（切换账号 / 取消注入 / 重置并接管）→ 让开 20 秒。
      // 这些操作自己会排期，看门狗插进来只会对同一进程重复 load。
      if (Date.now() - snowlumaUserActionAt < 20_000) return;
      // ── ① 先判"协议端还活着吗"，再判"该不该注入"（2026-10-17 顺序修正）────
      // 旧顺序把 `snowlumaInjectNextAt / AuthAt`（注入退避）与 `snowlumaInjectRunning`
      // 放在**端口探测之前**。后果实测出来了：雪茹在"上一轮注入刚成功"之后崩溃时，
      // 那 60 秒常规退避会把**拉起动作**一起挡住 —— 用户看到的就是"崩了以后一分多钟
      // 没有任何反应"。可雪茹死了的时候，"注入该不该重试"这个问题根本不存在，
      // 该做的是立刻把它拉起来。所以顺序必须是：活着吗 → 死了就拉 → 活着才轮到注入退避。
      if (!(await isPortOpen('127.0.0.1', snowlumaWebuiPort(), 600))) {
        if (sl.autoLaunch === false || snowlumaUserStopped) return;
        if (!snowlumaDir()) return;                       // 没配目录 → 交给页面提示，别刷日志
        if (Date.now() < slRelaunchRetryAt) return;
        const waitMs = Math.min(5 * 60 * 1000 * 2 ** Math.max(0, slRelaunchFails), 60 * 60 * 1000);
        slRelaunchRetryAt = Date.now() + waitMs;          // 失败后至少 5 分钟内不再试
        // 只要这次是"端口没开 → 又拉了一次"，就先记一笔；下一秒端口真起来了，
        // 上面的 `slRelaunchFails = 0` 会清零。崩了又崩（起来了立刻退）才会翻倍到封顶。
        slRelaunchFails++;
        pushSnowlumaLog('自动注入：发现 SnowLuma 没在运行，正在自动拉起…', 'warn');
        const r = await launchSnowluma();
        if (!r.ok) {
          const mins = Math.round(waitMs / 60000);
          pushSnowlumaLog(`自动注入：自动拉起 SnowLuma 失败（${r.error || '未知原因'}），${mins} 分钟内不再尝试`, 'warn');
        }
        return;
      }
      slRelaunchFails = 0;   // 端口开着 = 雪茹活着，失败计数清零
      // ── ② 雪茹活着，才轮到"要不要再注一次" ────────────────────────────
      if (snowlumaInjectRunning) return;                  // 已有一轮在跑
      if (Date.now() < snowlumaInjectNextAt || Date.now() < snowlumaInjectAuthAt) return;
      scheduleAutoInjectBotQq();
    } catch (error) {
      try { log('[snowluma] 注入看门狗异常（不影响主流程）:', error?.message ?? error); } catch { /* ignore */ }
    }
  }

  // 供前端「从已登录 QQ 选择」按钮：列出已登录的 QQ 进程（uin + 昵称），让用户点选机器人那份。
  async function snowlumaListAccounts() {
    const webuiPort = snowlumaWebuiPort();
    if (!(await isPortOpen('127.0.0.1', webuiPort))) return { ok: false, message: 'SnowLuma 未运行' };
    const base = (snowlumaWebuiUrl() || `http://127.0.0.1:${webuiPort}/`).replace(/\/$/, '');
    const pw = getConfig().snowluma?.webuiPassword;
    const token = await slLogin(base, pw);
    if (!token) {
      // 2026-10-17：用户点「从已登录 QQ 选择」撞上登录失败 = 又一个"想手动干活"的现场，
      //   同样把凭据 + 指引落进日志（前端那条 message 在 hint 里，页面一重渲染就没了）。
      pushSnowlumaLog('「从已登录 QQ 选择」：无法登录 SnowLuma WebUI（密码不被认可）。', 'warn');
      pushSnowlumaLog(snowlumaConsoleCredentialLog('手动注入所需凭据 →'), 'warn');
      pushSnowlumaLog(SNOWLUMA_MANUAL_INJECT_GUIDE, 'warn');
      return {
        ok: false,
        message: '无法登录 SnowLuma WebUI（密码不被认可）。若你给控制台设过密码或见过这条提示，点旁边「重置并接管控制台密码」一键修复；重置后 QQ Agent 会展示新密码。'
      };
    }
    const list = await slGet(base, token, '/api/processes');
    // S3 修：401 → null。不能当成"没有已登录的 QQ"，否则用户点「从已登录 QQ 选择」
    // 会看到"当前没有已登录的 QQ（先登录机器人的 QQ 再点）"—— 而号明明登着。
    if (!list) return { ok: false, message: '读取 SnowLuma 进程表失败（控制台令牌失效或服务无响应），请稍后重试' };
    const processes = list.list || [];
    const out = [];
    for (const p of processes) {
      // v2.0.2：account.uin / account.nickname 未注入就有，免 probe 白拿昵称
      const acc = snowlumaProcessAccount(p);
      let uin = acc.uin;
      let nick = acc.nick;
      if (!uin || uin === '0') {
        const info = await slGet(base, token, `/api/processes/${p.pid}/probe-login`);
        uin = (info && info.info && info.info.uin) || '';
        nick = (info && info.info && info.info.nickName) || '';
      }
      // 已注入进程 p.uin 可信（上面分支没走），昵称从 account 顺手补——
      // 否则 v2 下「从已登录 QQ 选择」列表里已注入那行的昵称恒为空
      if (!nick && p.account && p.account.nickname) nick = String(p.account.nickname);
      out.push({
        pid: p.pid,
        uin: String(uin || ''),
        nickName: nick,
        injected: !!p.injected,
        loggedIn: !!p.loggedIn,
        name: p.name || ''
      });
    }
    return { ok: true, accounts: out };
  }

  // 2026-10-15：一键重置并接管 SnowLuma 控制台密码。
  // 场景：webui.json 已存在且 mustChangePassword=false（用户走过初始流程/自己设过密码），
  // bootstrap 环境变量密码只在文件缺失时播种 → 永远不生效 → QQ Agent 无法登录 WebUI
  // 调注入 API（表现为「无法登录 SnowLuma WebUI（QQ Agent 未接管 WebUI 密码）」）。
  // 做法：关 SnowLuma → 删 webui.json → 重启。launchSnowluma 内 prepareSnowlumaWebuiAuth
  // 会带 SNOWLUMA_WEBUI_BOOTSTRAP_PASSWORD 播种 QQ Agent 的密码（mustChangePassword=false）。
  // 返回 password 供前端向用户展示一次（登录控制台也要用它）。
  async function resetSnowlumaWebui() {
    snowlumaUserActionAt = Date.now();   // 让开看门狗 20 秒（这是会重启雪茹的重操作）
    const dir = snowlumaDir();
    if (!dir) return { ok: false, error: '找不到 SnowLuma 目录' };
    let stopOk = false;
    try {
      stopOk = await stopSnowluma();
    } catch (error) {
      pushSnowlumaLog(`重置控制台密码：停止 SnowLuma 失败（${error?.message ?? error}）`, 'warn');
      stopOk = false;
    }
    // 等端口真正释放（stopSnowluma 只等进程退出，端口释放可能再晚一拍）
    const webuiPort = snowlumaWebuiPort();
    for (let i = 0; i < 10 && (await isPortOpen('127.0.0.1', webuiPort)); i++) {
      await new Promise((r) => setTimeout(r, 500));
    }
    // ── 2026-10-20（P5 修）：停不掉就**中止**，绝不删配置文件 ──────────────
    // 旧实现 catch 完照样往下走：雪茹还活着时 unlink webui.json。结果是内存里的
    // 旧密码仍生效、磁盘认证材料被移除（重启后行为不确定），而 launchSnowluma
    // 又会因端口开着走 alreadyRunning 早退 —— 新密码根本没播种，可界面照样显示
    // "✓ 已重置并重启，密码：xxx"，用户拿着它登不进控制台。
    if (!stopOk || (await isPortOpen('127.0.0.1', webuiPort))) {
      pushSnowlumaLog('重置控制台密码：没能停掉 SnowLuma（WebUI 端口仍被占用），已中止 —— 没有改动任何配置文件。请先点「关闭 SnowLuma」再重试。', 'warn');
      return { ok: false, error: '停止 SnowLuma 失败，已中止（配置文件未改动）。请先点「关闭 SnowLuma」再重试。' };
    }
    const webuiJson = path.join(dir, 'config', 'webui.json');
    try { fs.unlinkSync(webuiJson); } catch { /* 文件不存在也没关系 */ }
    slTokenCache = { base: '', token: '', at: 0 };   // 服务器要重启，旧 token 全部失效
    // N1：旧密码的实测结论也作废 —— 重启后这份新播种的密码要重新验一次，
    //     否则会把"上一份密码不行"的结论继续挂在新的密码上（虽然密码字符串不同
    //     不会误配，但显式清掉更不容易被后人改坏）。
    slAuthProbe = { password: '', ok: null, at: 0, message: '', kind: '' };
    // 确保有可播种的密码（正常情况早已在 prepareSnowlumaWebuiAuth 里生成过）
    if (!getConfig().snowluma?.webuiPassword) {
      updateConfig({ snowluma: { webuiPassword: randomBytes(16).toString('hex') } });
    }
    const r = await launchSnowluma();
    // 重启 SnowLuma 后立刻重排期注入：这是用户显式动作，而且雪茹刚重启、
    // webui.json 也被删掉重播了种 —— 两种退避都必须清掉，否则"重置成功了却
    // 还要手动注入"（用户实测踩过）。
    snowlumaInjectRunning = false;
    snowlumaInjectNextAt = 0;
    snowlumaInjectAuthAt = 0;
    scheduleAutoInjectBotQq({ force: true });
    snowlumaConsoleAutoOpened = false;   // 旧浏览器页签已随重启失效，重开一个能用的
    scheduleAutoOpenSnowlumaConsole();
    // 2026-10-17：重置后的新密码也写进日志。前端那条 #sl-hint 提示会随页面重渲染消失，
    //   而"重置完又忘了密码"是常事 —— 日志里的这条留着，回头还能翻出来。
    // 2026-10-20（P5 修）：但**必须先实测登录一次**才敢说"已接管"。
    //   上面已经保证端口释放后才删文件，可 launch 仍可能异常（原生模块缺失、
    //   端口被别的程序抢走）。无条件报成功 + 把 password 交给前端显示，等于让
    //   用户拿着一个没验证过的密码去登录 —— 登不进就又是"连接不上"的现场。
    const finalPw = String(getConfig().snowluma?.webuiPassword || '');
    const credBase = (snowlumaWebuiUrl() || `http://127.0.0.1:${webuiPort}/`).replace(/\/$/, '');
    let verified = false;
    for (let i = 0; i < 20; i++) {
      if (await isPortOpen('127.0.0.1', webuiPort)) break;
      await new Promise((wait) => setTimeout(wait, 1000));
    }
    if (await isPortOpen('127.0.0.1', webuiPort)) {
      // force：绕过 token 缓存，要的是"现在这一刻这份密码对不对"
      verified = Boolean(await slLogin(credBase, finalPw, { force: true, timeoutMs: 8000 }));
    }
    if (verified) {
      pushSnowlumaLog(snowlumaConsoleCredentialLog('已重置并接管控制台密码（实测登录成功）。'), 'stdout');
    } else {
      pushSnowlumaLog('重置控制台密码：配置文件已重建，但**实测登录仍未成功** —— 先别拿下面这份密码去试，'
        + '建议点「关闭 SnowLuma」后再点一次「重置并接管」。', 'warn');
      pushSnowlumaLog(snowlumaConsoleCredentialLog('当前保存的凭据（未验证）→'), 'warn');
    }
    return { ...r, password: finalPw, verified };
  }

  // 2026-10-15：取消注入 —— 卸载 SnowLuma 对 QQ 的注入（POST /api/processes/:pid/unload）。
  // 二次调整：卸载**所有**已注入的进程 —— 用户实测：只卸 botQQ 命中的那份时，另一个
  // 已注入账号仍在收发消息，「取消注入」看起来像没生效。语义应为「把注入全撤掉」。
  // 卸载后 OneBot 断开、机器人停止收发消息；重新注入 = 重启 SnowLuma（自动注入会重新跑）。
  async function snowlumaUnloadBot() {
    snowlumaUserActionAt = Date.now();   // 让开看门狗 20 秒：别在"正在卸载"的中途又 load 回来
    // ── 2026-10-20（P3 修）：**先落暂停意图，再去卸载** ────────────────────
    // 旧实现的置位在下面卸载循环之前（见下面保留的 M1 注释），但仍然晚于三条早退：
    //   · 「SnowLuma 未运行」直接 return → 不置位；
    //   · 登录失败直接 return → 不置位；
    //   · 「当前没有任何已注入的 QQ」直接 return → 不置位。
    // 这三条路径下用户**明确点了取消**，可 injectCancelled 仍是 false：
    // 雪茹一起来 / QQ 一重新登录，看门狗立刻把它注回去 —— 按钮承诺的
    // 「重启应用也不会再自动注入」被反向兑现。现在把置位提到函数最前面，
    // 早退分支只需如实说明"已经暂停，只是没东西可卸"。
    updateConfig({ snowluma: { injectCancelled: true } });
    snowlumaInjectGen += 1;   // 让正在跑的那一轮当场作废（M2），不必等它走到下一个检查点
    const paused = true;
    const webuiPort = snowlumaWebuiPort();
    if (!(await isPortOpen('127.0.0.1', webuiPort))) {
      // 没有雪茹就没有注入可撤，但"暂停"这件事必须生效（否则它一起来就又被注回去）
      pushSnowlumaLog('已取消注入：SnowLuma 未运行，没有需要卸载的进程；自动注入已暂停（点「重新注入」恢复）', 'stdout');
      return { ok: true, unloaded: 0, total: 0, stuck: [], paused, message: 'SnowLuma 未运行，没有需要卸载的进程；自动注入已暂停' };
    }
    const base = (snowlumaWebuiUrl() || `http://127.0.0.1:${webuiPort}/`).replace(/\/$/, '');
    const pw = getConfig().snowluma?.webuiPassword;
    const token = await slLogin(base, pw);
    if (!token) {
      pushSnowlumaLog('「取消注入」：无法登录 SnowLuma WebUI（密码不被认可）—— 自动注入已暂停，但当前注入**没能卸载**。', 'warn');
      pushSnowlumaLog(snowlumaConsoleCredentialLog('手动注入所需凭据 →'), 'warn');
      return {
        ok: false,
        paused,
        error: '已暂停自动注入，但无法登录 SnowLuma 控制台、当前注入仍未卸载。可点「重置并接管控制台密码」修复后再点一次「取消注入」。'
      };
    }
    const list = await slGet(base, token, '/api/processes');
    // S3 修：slGet 在 401 时返回 null（不再返回 401 的 body）——「读不到」和「真的没有」必须分开
    if (!list) {
      pushSnowlumaLog('「取消注入」：读取 SnowLuma 进程表失败（控制台令牌失效或服务无响应）—— 自动注入已暂停，但当前注入**没能卸载**。', 'warn');
      return { ok: false, paused, error: '已暂停自动注入，但读取进程表失败，当前注入仍未卸载。请稍后重试。' };
    }
    const processes = list.list || [];
    const targets = processes.filter((p) => p.injected);
    if (!targets.length) {
      pushSnowlumaLog('已取消注入：当前没有已注入的 QQ；自动注入已暂停（点「重新注入」恢复）', 'stdout');
      return { ok: true, unloaded: 0, total: 0, stuck: [], paused, message: '当前没有已注入的进程；自动注入已暂停' };
    }
    // 2026-10-17（报告5 M1 修）：**先置位、再卸载**。
    // 原顺序是「逐个 unload → 等 2.5 秒复查 → 最后才 updateConfig(injectCancelled)」，
    // 那 2.5 秒 + 2 次 HTTP 往返就是竞态窗口：注入轮询若在这段窗口内跑到
    // slPost(.../load)，DLL 会在卸载**之后**又被注回去，而 injectCancelled 只是让
    // "下一轮"退出 —— 本轮已经把注入装回去了。用户看到的现象是「取消注入不可靠」，
    // 这是语义级错误，不是概率问题。
    // 顺带 snowlumaInjectGen += 1：让正在跑的那一轮当场作废（M2），
    // 不必等它自己走到下一个检查点。
    // 代价（明说）：若后续卸载失败，暂停标记已经落下 —— 但用户点的就是"取消"，
    // 暂停本来就符合他的意图，一键「重新注入」即可恢复。
    // 2026-10-20（P3）：置位与代数自增已**进一步提前到函数最前面**（见开头注释），
    // 这里不再重复写 —— 早退路径也要享受同一个"意图先落地"的保证。
    const results = [];
    for (const t of targets) {
      const r = await slPost(base, token, `/api/processes/${t.pid}/unload`, {});
      results.push({ pid: t.pid, uin: String(t.uin || ''), ok: !!(r && (r.success ?? r.ok)) });
    }
    // 卸载校验（等 SnowLuma 的 watcher 走一轮再复查）：
    // 服务端 unload 对「接管型注入」（DLL 是更早的 SnowLuma 会话留下的，没有卸载句柄）
    // 是**空操作** —— 管道仍活着，watcher 会把 injected 重新置回 true，而 HTTP 返回照样
    // success:true（用户实测：接口说成功、QQ 依然注入着）。所以必须实测，不能信返回值。
    await new Promise((r) => setTimeout(r, 2500));
    const after = await slGet(base, token, '/api/processes');
    const afterList = (after && after.list) || [];
    const stuck = [];
    for (const item of results) {
      const p = afterList.find((q) => Number(q.pid) === Number(item.pid));
      if (p && p.injected) { item.ok = false; stuck.push(item.uin || String(item.pid)); }
    }
    const okCount = results.filter((x) => x.ok).length;
    // 注：暂停标记与代号自增已**提前到卸载循环之前**（见上面的 M1 说明），
    // 这里不再重复 updateConfig —— 否则又会在 2.5 秒复查之后产生一次无意义的写盘。
    pushSnowlumaLog(`已取消注入：${okCount}/${results.length} 个进程真正卸载；自动注入已暂停${stuck.length ? `（${stuck.join('、')} 的 DLL 无法运行中卸载，需重启该 QQ）` : ''}`, stuck.length ? 'warn' : 'stdout');
    return {
      ok: okCount > 0,
      unloaded: okCount,
      total: results.length,
      stuck,
      paused: true,
      error: stuck.length
        ? `有 ${stuck.length} 个 QQ 的注入无法在运行中解除（DLL 是早期会话留下的）：${stuck.join('、')} —— 重启这些 QQ 后即彻底解除，且不会被再次自动注入`
        : ''
    };
  }

  /**
   * 切换注入目标（2026-10-16）。
   *
   * 背景：多 QQ 场景下用户实测「注入目标从 A 换成 B 后，取消不掉 A 的注入」。
   * 根因是**缺少这个语义**——原有两条路都不管用：
   *   · scheduleAutoInjectBotQq 只**新增**注入 botQQ，从不卸载别的账号；
   *   · snowlumaUnloadBot 卸载**全部**已注入并持久暂停自动注入（"把注入全撤掉"），
   *     与"我只想要 B"完全相反，而且它顺带把自动注入也停了。
   * 于是 A 的注入一直挂着、OneBot 抢到 A、重启后自动注入又只补 B，用户看到的
   * 就是"切换不生效 / 重启就切回去了"。
   *
   * 这里的语义 = 精确切换：
   *   1. 卸载**除目标以外**所有已注入的进程（保留目标已有的注入，不折腾它）；
   *   2. 目标若尚未注入 → 调 load 注入它；
   *   3. 清掉 injectCancelled 暂停标记（用户既然点了"切到这里"，就是要恢复自动注入）。
   *
   * ⚠️ 卸载同样有"接管型注入卸载不掉"的老问题（见上面 snowlumaUnloadBot 的注释：
   *    服务端对早期会话留下的 DLL 是空操作，HTTP 照样返回 success）。所以这里
   * **同样不信任返回值**，等 watcher 走一轮后重拉进程表实测复查，卸不掉的如实上报。
   */
  function switchErrorText(success, stillInjected, uin, unloaded) {
    if (success) return '';
    const parts = [];
    const extra = stillInjected.filter((x) => x && x !== uin);
    if (extra.length) {
      parts.push(`${extra.join('、')} 仍处于注入状态 —— 注入是把组件装进 QQ 进程、运行中无法卸载，`
        + '需要退出并重启那个 QQ 才能彻底解除（重启后不会再被自动注回来）。');
    }
    const failed = unloaded.filter((x) => !x.ok).map((x) => x.uin || String(x.pid));
    if (failed.length) parts.push(`${failed.join('、')} 的卸载接口返回了失败。`);
    if (extra.length === 0 && failed.length === 0) {
      // 2026-10-17：这条就是"用户马上要去手动注入"的分支 —— 顺带把凭据在哪说清楚，
      //   否则用户点开控制台又卡在登录页（同一批反馈）。
      parts.push(`目标 ${uin} 未处于注入状态，可稍后在 SnowLuma 控制台手动注入`
        + '（地址与密码：上方节点②的「控制台密码」框，或下方「运行日志」里那一行）。');
    }
    return parts.join(' ');
  }

  async function snowlumaSwitchBot(targetQQ) {
    snowlumaUserActionAt = Date.now();   // 让开看门狗 20 秒：别在"卸旧号→注新号"中途插一脚
    const uin = String(targetQQ ?? '').trim();
    if (!uin) return { ok: false, error: '请先填注入目标 QQ 号，或点「从已登录 QQ 选择」' };
    if (!/^\d{5,12}$/.test(uin)) return { ok: false, error: '注入目标应该是纯数字 QQ 号' };

    const webuiPort = snowlumaWebuiPort();
    if (!(await isPortOpen('127.0.0.1', webuiPort))) return { ok: false, error: 'SnowLuma 未运行' };
    const base = (snowlumaWebuiUrl() || `http://127.0.0.1:${webuiPort}/`).replace(/\/$/, '');
    const pw = getConfig().snowluma?.webuiPassword;
    const token = await slLogin(base, pw);
    if (!token) {
      pushSnowlumaLog('「切换到此账号」：无法登录 SnowLuma WebUI（密码不被认可）。', 'warn');
      pushSnowlumaLog(snowlumaConsoleCredentialLog('手动注入所需凭据 →'), 'warn');
      return { ok: false, error: '无法登录 SnowLuma WebUI（密码不被认可）。可点「重置并接管控制台密码」修复。' };
    }

    // ── 2026-10-20（P2 修）：**先校验目标存在，再落配置** ────────────────────
    // 旧顺序是「updateConfig(botQQ) → 拉进程表 → 找不到目标就 return」。
    // 用户在「注入目标」里填了一个还没登录 / 填错的号，点「切换到此账号」时：
    // 接口会报"没找到该进程"，可 botQQ 已经被写脏 —— 之后每一轮自动注入都
    // 匹配不到任何进程，每 2 分钟空转 6 分钟，直到用户自己把号改回来。
    // 配置必须等到"目标确实存在"的那一刻才落；原注释里"先落配置以免重启后注回旧号"
    // 的理由，只对"目标存在、但 load 失败"成立，对"目标根本不存在"恰好相反。
    const list = await slGet(base, token, '/api/processes');
    // S3 修：slGet 在 401 时返回 null（不再返回 401 的 body）——读不到就说读不到，
    // 不能当成"进程表是空的"，否则会把令牌问题误导成"QQ 没登录"。
    if (!list) return { ok: false, error: '读取 SnowLuma 进程表失败（控制台令牌失效或服务无响应），请稍后重试' };
    const processes = list.list || [];

    // probe 未注入进程读 uin：已注入的 p.uin 直接可信；未注入的可能还是 '0'
    // （v2.0.2 的 account.uin 在 snowlumaProcessAccount 里已兜住，v1 才走 probe）。
    const resolved = [];
    for (const p of processes) {
      let cur = snowlumaProcessAccount(p).uin;
      if ((!cur || cur === '0') && !p.injected) {
        const info = await slGet(base, token, `/api/processes/${p.pid}/probe-login`);
        cur = String((info && info.info && info.info.uin) || '');
      }
      resolved.push({ pid: p.pid, uin: cur, injected: !!p.injected });
    }

    const target = resolved.find((p) => p.uin === uin);
    if (!target) {
      const seen = resolved.filter((p) => p.uin).map((p) => p.uin);
      return {
        ok: false,
        error: `没找到 QQ 号 ${uin} 的进程${seen.length ? `（当前已登录：${seen.join('、')}）` : ''} —— 请先启动并登录那个 QQ`
      };
    }

    // 目标确认存在 → 这时才落配置（botQQ 与 injectCancelled 一次写完；
    // 分两次 updateConfig 是两次读改写，中间可能被自动注入的 updateConfig({botQQ}) 插队）。
    updateConfig({ snowluma: { botQQ: uin, injectCancelled: false } });
    // 「切到这里」= 显式恢复自动注入 → 调度状态必须一并清干净（2026-10-17 加固）。
    // 不清的后果是**卡死不自愈**：上一次「取消注入」只是让在跑的那轮作废
    // （snowlumaInjectGen += 1），`snowlumaInjectRunning` 要等那一轮自己走到检查点才归位，
    // 而它是被 staleStop 直接 return 的 —— 位子留着没人清。于是切换完：
    // 看门狗每 20 秒都在第一道闸 `if (snowlumaInjectRunning) return` 被挡回，
    // 目标号注不进去，界面上没有任何"正在重试"的迹象。只有点「重新注入」或重启才好。
    // 顺带 gen += 1：让还在 await 里的老一轮当场作废，别和新调度抢同一个进程。
    snowlumaInjectGen += 1;
    snowlumaInjectRunning = false;
    snowlumaInjectNextAt = 0;
    snowlumaInjectAuthAt = 0;

    // ① 卸载除目标外的所有已注入进程
    const others = resolved.filter((p) => p.injected && p.uin !== uin);
    const unloaded = [];
    for (const o of others) {
      const r = await slPost(base, token, `/api/processes/${o.pid}/unload`, {});
      unloaded.push({ pid: o.pid, uin: o.uin, ok: !!(r && (r.success ?? r.ok)) });
    }

    // ② 目标没注入才注入（已有就别碰，避免把正在跑的会话重启一遍）
    let injectedTarget = target.injected;
    if (!injectedTarget) {
      const r = await slPost(base, token, `/api/processes/${target.pid}/load`, {});
      injectedTarget = !!(r && r.success);
    }

    // ③ 实测复查（不信任上面的返回值）
    await new Promise((r) => setTimeout(r, 2500));
    const after = await slGet(base, token, '/api/processes');
    // ── 2026-10-20（P6/S3 修）：复查请求失败 ≠ 切换失败 ──────────────────────
    // 旧写法把 `after` 为 null 折算成 `afterList = []`，于是 stillInjected 恒为空，
    // success 恒为 false，日志还会打出「⚠ 仍有其他账号在注入：」后面跟一片空白 ——
    // 凭空造一个不存在的问题，用户照着去查"哪个号还在注入"，什么也查不到。
    // slGet 现在对 401 返回 null，这里必须把"没复查成功"单列出来，不做结论。
    if (!after) {
      pushSnowlumaLog(`切换注入目标 → ${uin}：注入动作已执行，但复查请求没成功（不做结论，稍后自动再看）`, 'warn');
      return {
        ok: Boolean(injectedTarget),
        target: uin,
        unloaded: unloaded.filter((x) => x.ok).length,
        unloadTotal: unloaded.length,
        stuck: [],
        stillInjected: [],
        needRestart: [],
        unverified: true,   // 前端据此不要说"已确认只剩目标"
        error: ''
      };
    }
    const afterList = after.list || [];
    const stillInjected = afterList
      .filter((q) => q.injected)
      .map((q) => {
        const hit = resolved.find((p) => Number(p.pid) === Number(q.pid));
        return hit ? hit.uin || String(q.pid) : String(q.uin || q.pid);
      })
      .filter(Boolean);

    const okUnloaded = unloaded.filter((x) => x.ok).length;
    const stuck = unloaded.filter((x) => !x.ok).map((x) => x.uin || String(x.pid));
    const success = injectedTarget && stillInjected.length === 1 && stillInjected[0] === uin;

    // ── 2026-10-20（S1 修）：切换完成后按目标号对齐 OneBot 令牌 ─────────────
    // SnowLuma 的 OneBot 配置是**按 QQ 号分文件**的（onebot_<uin>.json），令牌也按号
    // 独立 —— 实测两个号的 WS/HTTP 令牌完全不同。而 config.snowluma.accessToken 存的是
    // "上次连上的那个号"的令牌，候选集又按它排第一；切号后不主动对齐，就只能靠
    // 401 试错轮换：每次 401 限频 5 秒、换一个候选，切到排序靠后的号要连撞两次
    // （≈10 秒）。这十秒里节点③ 显示"未连接"、日志刷"令牌无效"，而注入其实早已成功。
    // 对齐之后直接重连，切号从"抖十秒"变成"断一下就回"。
    if (injectedTarget) {
      const aligned = applyTokensForUin(uin);
      if (aligned.changed) {
        pushSnowlumaLog(`已按目标 QQ ${uin} 对齐 OneBot 令牌，正在重连…`, 'stdout');
        onebot.reconnect();
      }
    }

    const detail = [
      `已卸载其他账号 ${okUnloaded}/${unloaded.length}`,
      injectedTarget ? `目标 ${uin} 已注入` : `目标 ${uin} 注入失败`,
      stillInjected.length === 1 && stillInjected[0] === uin
        ? '当前仅目标处于注入状态'
        : `⚠ 仍有其他账号在注入：${stillInjected.join('、')}`
    ].join('；');
    pushSnowlumaLog(`切换注入目标 → ${uin}：${detail}`, success ? 'stdout' : 'warn');

    return {
      ok: success,
      target: uin,
      unloaded: okUnloaded,
      unloadTotal: unloaded.length,
      stuck,
      stillInjected,
      // ⚠️ 关于「卸不掉」：SnowLuma 的注入是把组件装进 QQ 进程，运行中无法卸载 ——
      //   服务端 unload 对已注入进程是空操作、HTTP 照样返回 success（下面的复查会戳穿它）。
      //   实测确认：unload 返回成功，2.5 秒后复查该进程仍是 injected=true。
      //   所以提示必须落到「用户能做什么」，而不是丢一句『卸载失败』让人干瞪眼。
      needRestart: stillInjected.filter((x) => x !== uin),
      error: switchErrorText(success, stillInjected, uin, unloaded)
    };
  }

  // 恢复自动注入：「取消注入」的反操作。清掉暂停标记并重新排期 ——
  // 这是用户显式动作，所以两种退避（常规 / 密码被拒）一并清掉，
  // 否则"点了重新注入却没反应"（密码退避有 15 分钟）。
  function snowlumaResumeInject() {
    snowlumaUserActionAt = Date.now();   // 同上（本函数自己会立刻排期，不需要看门狗帮忙）
    updateConfig({ snowluma: { injectCancelled: false } });
    snowlumaInjectRunning = false;
    snowlumaInjectNextAt = 0;
    snowlumaInjectAuthAt = 0;
    snowlumaInjectCancelLogged = false;
    scheduleAutoInjectBotQq({ force: true });
    pushSnowlumaLog('已恢复自动注入：登录机器人 QQ 后会自动注入并连接', 'stdout');
    return { ok: true };
  }

  const emit = (type, payload) => {
    if (type === 'onebot-status' || type === 'status' || type.startsWith('session-')) {
      try { getDesktopPetService()?.onCoreEvent?.(type, payload); } catch { /* 桌宠异常不影响群聊 */ }
    }
    // 说明：这里曾经先走一个进程内事件总线（createEventBus），但全项目**没有任何订阅者**，
    // 属于纯空转；更糟的是它给人"存在进程内订阅者"的错觉。真正的消费者只有 SSE。
    let line = null;
    if (type === 'session-update' && payload?.sessionId) {
      try {
        // peek：只序列化、不修改，不需要 get() 那份全量 structuredClone
        // （运行中的会话每次更新都广播，克隆大会话会拖慢事件投递）
        const s = sessions?.peek(payload.sessionId);
        if (s) {
          line = `event: ${type}\ndata: ${JSON.stringify({
            sessionId: s.id,
            chatKey: s.chatKey,
            startedAt: s.startedAt,
            status: s.status,
            waitUntil: s.waitUntil ?? null,
            activity: s.activity ?? '',
            webSearchCount: s.webSearchCount ?? 0,
            rounds: s.rounds ?? 0,
            usage: s.usage ?? null,
            trigger: s.triggerSummary ?? '',
            triggerSummary: s.triggerSummary ?? '',
            messages: s.messages ?? [],
            // sent/finishReason/error/endedAt 必须随 SSE 推下去：
            // 曾经载荷里没有它们，"已发送到 QQ"徽标只能等 HTTP 轮询带回来；
            // 而会话一结束轮询就不再拉详情（只刷 running/waiting），
            // 用户只能手动刷新才看得到最终发言 —— 这就是"详情更新不及时"。
            sent: s.sent ?? [],
            finishReason: s.finishReason ?? null,
            error: s.error ?? null,
            endedAt: s.endedAt ?? null
          })}\n\n`;
        }
      } catch { /* 失败就退回原 payload */ }
    }
    if (!line) line = `event: ${type}\ndata: ${JSON.stringify(payload ?? {})}\n\n`;
    for (const res of sseClients) {
      // 同步异常 + 已经不可写的连接都要清理，否则集合只增不减、每次都白写
      if (res.writableEnded || res.destroyed) { sseClients.delete(res); continue; }
      try {
        res.write(line);
      } catch {
        sseClients.delete(res);
      }
    }
  };

  // ── 组件 ──
  const visionScan = { running: false };   // 模型图片输入能力扫描的运行状态
  const store = new ChatStore(cfg.store?.maxMessagesPerChat ?? 0);   // 0 = 不限
  const memory = new MemoryStore();
  const sessions = new SessionRegistry(cfg.store?.keepSessionFiles ?? 0);   // 0 = 不限
  const onebot = new OneBotClient({
    wsUrl: cfg.snowluma?.wsUrl,
    httpUrl: cfg.snowluma?.httpUrl,
    accessToken: cfg.snowluma?.accessToken,
    httpToken: cfg.snowluma?.httpAccessToken || cfg.snowluma?.accessToken,
    onEvent: (event) => handleOneBotEvent(event).catch((error) => log('[ingest] 处理事件出错:', error?.message ?? error))
  });
  setOnebotClient(onebot);
  const sender =   new SendQueue({
    onebot, store,
    onSent: ({ chatKey, text }) => log(`[发送 -> ${chatKey}] ${String(text).slice(0, 60)}`),
    log
  });
  const reminders = new ReminderStore();
  const videoReader = new VideoReader(onebot);
  const orchestrator = new Orchestrator({ store, memory, sender, sessions, onebot, emit, reminders, videoReader });

  // [[travel-whale:services]] 把核心服务交给技能：后台任务型技能（旅行鲸鱼等）的 ticker
  // 不经过工具调用，拿不到 ctx ⇒ 只能靠这个口子发消息。
  // 纯新增；不读它的既有技能行为完全不变。
  // ★ 2026-10-17：0.4.8.5 起宿主不再有 stickers 这个变量（表情管理搬去 sticker 插件），
  //   直接写它会 ReferenceError ⇒ 宿主起不来。所以用 typeof 守卫，0.4.5 / 0.4.8.5 两版都安全。
  skillManager.setServices({
    store, memory, sender, sessions, onebot, reminders, videoReader,
    orchestrator, emit, log,
    ...(typeof stickers === 'undefined' ? {} : { stickers })
  });

  // 远程价格表固定为官网公开地址；不从用户配置读取，避免被页面/配置篡改。
  initPriceFeed(FIXED_PRICE_FEED_URL);

  // 云端统一屏蔽名单：启动先用 data 缓存，后台同步；网络失败不影响本地拦截。
  const communitySyncTimer = startCommunitySync(log);
  communitySyncTimer.unref?.();

  // 前缀缓存保活：默认开启（2026-10-15 用户要求；会主动联网，开关改动无需重启）。
  // 放在这里是为了让它在 orchestrator / 插件加载之前就位 —— 保活构造前缀要用到
  // skillManager 的当前状态，而它晚于本行加载；所以首次 tick 延迟 20 秒兜住。
  const cacheWarm = startCacheWarm(log);

  // 启动即预热（2026-09-20）：保活原先只能等"本次运行"构造出前缀才知道要预热什么，
  // 于是**每个会话的第一次调用永远赶不上预热**（实测 11:12:17 首次调用命中 32%，
  // 而预热 11:12:34 才发出）。这里在启动时载入上次运行落盘的前缀，直接暖一次 ——
  // 第一条群消息的调用就能命中。插件还没加载完，所以延迟 15 秒等 skillManager 就位。
  //
  // ⚠️ R1（2026-10-12）：重启后第一条**仍然会掉**（实测 cached=3200 = 20%）。
  //    原因不是"没预热"，而是**预热的前缀形状与真实调用不同**：
  //    loadPersistedPrefix 载入的是「上次运行」的 system+tools，而本次运行的
  //    代码/工具集可能已经变了（如刚改过 prompt.js / 装了新扩展）→ 预热写的是
  //    旧形状的缓存，真实调用用的是新形状 → 必然错位一次。
  //    修法：预热完成后把**预热用的形状**登记为「已预热形状」，并让真实运行的
  //    noteRealPrompt 在形状变化时自动补一次预热（见 cache-warm.js 的
  //    noteShapeChange）。这样重启后的第一枪落在「上一次真实形状」上，
  //    第二枪时形状已对齐。
  {
    const bootWarm = setTimeout(async () => {
      try {
        // 优先用落盘的前缀；没有（首次安装/刚清过数据）就从会话存档里借一份。
        // 少了这条兜底，"启动预热"在第一次重启后永远没有样本 —— 而第一次调用
        // 恰恰是最需要它的那一次。
        const ok = loadPersistedPrefix() || seedPrefixFromSessions();
        if (!ok) return;
        const r = await warmOnce({ log });
        if (r.ok) {
          markCurrentShapeWarmed();   // R1：登记"这份形状已预热"，避免重复预热
          log(`[cache-warm] 启动预热完成（${r.prompt} tok，命中 ${r.cached}）`);
        }
      } catch { /* 启动预热失败不影响任何功能 */ }
    }, 15000);
    bootWarm.unref?.();
  }

  // OneBot 连接状态推送
  onebot.onStatus((status) => emit('onebot-status', status));

  // ── 从 SnowLuma 配置自动同步 OneBot 令牌 ──
  // SnowLuma 给每个登录过的账号生成独立随机 token（config/onebot_<uin>.json），
  // 且**永久保留**——不表示"当前在线"。多账号场景下"取第一个文件"会拿错 token
  // （WS 401 无限重试）。策略改为：收集所有 per-uin 文件的 token 作为候选，
  // 401 时轮换下一个重连，连上后记住生效的那个（天然支持 SnowLuma 里切账号）。
  let lastSyncTokenSig = '';

  /** 从单个配置对象里提取 ws/http token（找不到网络段时返回 null）。 */
  function extractTokens(data) {
    const http = (data?.networks?.httpServers || []).find((s) => (s.port === 3000) || (s.name === 'http-default')) || (data?.networks?.httpServers || [])[0];
    const ws = (data?.networks?.wsServers || []).find((s) => (s.port === 3001) || (s.name === 'ws-default')) || (data?.networks?.wsServers || [])[0];
    return { wsToken: String(ws?.accessToken ?? ''), httpToken: String(http?.accessToken ?? '') };
  }

  /** 收集所有候选 token（含 onebot_0.json 的空令牌兜底），按"最可能正确"排序。
   *
   * ⚠️ 排序规则（2026-09-19 修订）：以前按文件名排序，多账号时 candidates[0]
   * 几乎总是错的（字典序小的那个 < 字典序大的那个，但在线的可能是后者），每次启动都要
   * 先吃一轮 401 再轮换到正确令牌。现在排序：
   *   1. 当前配置里已保存的 token（上次连成功过的，最可信）
   *   2. 文件序的其余候选
   *   3. 空令牌兜底（SnowLuma 允许无 token 连接，永远排最后）
   * 去重保持首次出现的顺序。
   */
  function readSnowlumaTokenCandidates() {
    const out = [];
    const seen = new Set();
    const push = (c) => {
      const key = `${c.wsToken}|${c.httpToken}`;
      if (seen.has(key)) return;
      seen.add(key);
      out.push(c);
    };
    try {
      const dir = snowlumaDir();
      if (!dir) return out;
      const cfgDir = path.join(dir, 'config');
      // 当前配置的令牌优先：上次连接成功时 applyTokens 已把它写进 data/config.json。
      const cur = getConfig().snowluma || {};
      const curWs = String(cur.accessToken || '');
      const curHttp = String(cur.httpAccessToken || cur.accessToken || '');
      if (curWs || curHttp) push({ wsToken: curWs, httpToken: curHttp });
      let files = [];
      try {
        files = fs.readdirSync(cfgDir).filter((f) => /^onebot_\d+\.json$/.test(f) && !/^onebot_0\.json$/.test(f)).sort();
      } catch { /* ignore */ }
      for (const f of files) {
        try {
          const data = JSON.parse(fs.readFileSync(path.join(cfgDir, f), 'utf8'));
          push(extractTokens(data));
        } catch { /* 单个文件坏了跳过，不影响其他候选 */ }
      }
      // 空令牌兜底：SnowLuma 允许无 token 连接（onebot_0.json 模板就是空）
      push({ wsToken: '', httpToken: '' });
    } catch (error) {
      log('[onebot] 读取 SnowLuma OneBot 配置失败:', error?.message ?? error);
    }
    return out;
  }

  /** 候选游标：401 时递增轮换。连上后会钉住当前生效下标。 */
  let tokenCandidateIndex = 0;

  function applyTokens({ wsToken, httpToken }) {
    onebot.accessToken = wsToken;
    onebot.httpToken = httpToken || wsToken;
    const cur = getConfig();
    if (cur.snowluma?.accessToken !== wsToken || cur.snowluma?.httpAccessToken !== (httpToken || wsToken)) {
      // 2026-10-17（报告3 M4）：patch 里展开了整段 snowluma，读的却是上面那份快照 ——
      // 改成函数式入口，展开的基准由 updateConfig 在写入前一刻给出，不会拿旧快照
      // 把并发写进来的其它 snowluma 字段（botQQ / injectCancelled）抹掉。
      updateConfig((cfg) => ({
        snowluma: { ...cfg.snowluma, accessToken: wsToken, httpAccessToken: httpToken || wsToken }
      }));
      log(`[onebot] 应用 OneBot 访问令牌（WS ${wsToken ? '有' : '无'} / HTTP ${httpToken ? '有' : '无'}）`);
    }
  }

  /**
   * 按 QQ 号把 OneBot 令牌对齐到 config + onebot 实例（2026-10-20 · S1）。
   *
   * 为什么需要它：SnowLuma 的 OneBot 配置按号分文件（onebot_<uin>.json），令牌
   * 按号独立 —— 实测两个号的 WS/HTTP 令牌完全不同。切换注入目标后，占着 3001 的
   * 是**新号**的 OneBot 实例，而 QQ Agent 手里仍拿着旧号的令牌，只能靠 401 试错
   * 轮换（限频 5 秒 / 每次换一个候选）。本函数直接把目标号的令牌装上，
   * 调用方再 reconnect，切号抖动从"最多十几秒"降到"一次重连"。
   *
   * ⚠️ 只读 onebot_<uin>.json，不猜、不学：读不到就返回 changed=false 交给原有
   *    401 轮换兜底（那条路能自愈，只是慢）。绝不因为读不到就把令牌清空。
   *
   * @param {string} uin
   * @returns {{changed: boolean, ok: boolean}}
   */
  function applyTokensForUin(uin) {
    try {
      const u = String(uin || '').trim();
      const dir = snowlumaDir();
      if (!dir || !/^\d{5,12}$/.test(u)) return { changed: false, ok: false };
      const f = path.join(dir, 'config', `onebot_${u}.json`);
      if (!fs.existsSync(f)) return { changed: false, ok: false };
      const t = extractTokens(JSON.parse(fs.readFileSync(f, 'utf8')));
      if (!t.wsToken && !t.httpToken) return { changed: false, ok: false };
      const changed = onebot.accessToken !== t.wsToken
        || onebot.httpToken !== (t.httpToken || t.wsToken);
      // 候选游标同步：下次断线重连第一个试的就是这个令牌，不再先撞错误的那个
      const cands = onebot.tokenCandidates || [];
      const idx = cands.findIndex((c) => c.wsToken === t.wsToken && c.httpToken === t.httpToken);
      applyTokens(t);
      if (idx >= 0) tokenCandidateIndex = idx;
      return { changed, ok: true };
    } catch (error) {
      try { log('[onebot] 按 QQ 号对齐令牌失败（退回 401 轮换）:', error?.message ?? error); } catch { /* ignore */ }
      return { changed: false, ok: false };
    }
  }

  /** 把候选列表同步进配置 + 挂到 onebot 实例（不立即连接）。返回是否有变化。 */
  function syncSnowlumaTokens() {
    try {
      const candidates = readSnowlumaTokenCandidates();
      if (!candidates.length) return false;
      const sig = candidates.map((c) => `${c.wsToken}|${c.httpToken}`).join(';');
      if (sig === lastSyncTokenSig) return false;
      // 游标重置：候选集变化了，从头开始试
      tokenCandidateIndex = 0;
      applyTokens(candidates[0]);
      onebot.tokenCandidates = candidates;   // 401 轮换用
      lastSyncTokenSig = sig;
      log(`[onebot] 已收集 ${candidates.length} 个 OneBot 令牌候选（当前配置令牌优先，401 时自动轮换）`);
      return true;
    } catch (error) {
      log('[onebot] 同步 SnowLuma 令牌失败:', error?.message ?? error);
      return false;
    }
  }

  // 401 / 未连接时：轮换下一个候选 token 重连（3 秒重连循环已有，轮换成本为零）
  let tokenSyncRetryAt = 0;
  function maybeRecoverOnebot() {
    const now = Date.now();
    if (now - tokenSyncRetryAt < 5000) return;   // 限频
    tokenSyncRetryAt = now;
    // ⚠️ 先重读磁盘：全新安装是"先启动后登录"，候选集是启动时的 [空令牌]；
    // 登录后 per-uin 文件才带着真令牌落盘。不回读就会拿空令牌 401 到天荒地老。
    const refreshed = syncSnowlumaTokens();
    const candidates = onebot.tokenCandidates || [];
    if (!candidates.length) return;
    if (refreshed) {
      // 候选集变了（sig 变化时内部已重置游标并应用候选[0]）→ 直接拿新集合的第一个试
      onebot.reconnect();
      return;
    }
    // 磁盘没变化：指向下一个候选（首次触发也从 0→1 开始换：刚被 401 拒的就是当前这个）
    tokenCandidateIndex = (tokenCandidateIndex + 1) % candidates.length;
    const c = candidates[tokenCandidateIndex];
    applyTokens(c);
    onebot.reconnect();
  }
  onebot.onStatus((status) => {
    if (status.connected) {
      // 连上了：把当前生效的候选「钉住」—— 写进游标。
      // （2026-10-20 注释修正：这里并不会把令牌挪到候选列表首位，只记下标；
      //   功能上等价 —— 轮换从该下标开始，下次断线重连第一个试的就是它。）
      const cands = onebot.tokenCandidates || [];
      const cur = { wsToken: String(onebot.accessToken || ''), httpToken: String(onebot.httpToken || '') };
      const hit = cands.findIndex((c) => c.wsToken === cur.wsToken && c.httpToken === cur.httpToken);
      tokenCandidateIndex = hit >= 0 ? hit : 0;
      if (cands.length > 1) log('[onebot] 连接成功，当前令牌候选已生效');
      return;
    }
    if (String(status.error || '').includes('401')) maybeRecoverOnebot();
  });

  // HTTP 通道的 401：与上面 WS 的 401 共用同一套令牌轮换。
  //
  // 为什么必须单独挂（2026-10-13 修复的真实故障）：
  //   上面的 onStatus 只看 WebSocket 的连接状态，而取群名 / 表情库 / 发消息
  //   全走 HTTP。SnowLuma 允许 WS 与 HTTP 配**不同**令牌（配置里就是
  //   snowluma.accessToken 与 snowluma.httpAccessToken 两个字段），
  //   于是会出现「WS 连得好好的、HTTP 却一直 401」——
  //   轮换钩子永远等不到触发，所有 HTTP 能力全线失效，
  //   表现为「群友说机器人不说话了」，而会话全部卡在 0 轮、日志一条错误都没有。
  onebot.onAuthError(({ action, status: code } = {}) => {
    log(`[onebot] HTTP ${code}（${action || '未知 action'}）→ 触发令牌轮换`);
    maybeRecoverOnebot();
  });

  // ── 入站事件处理 ──
  let atNameCache = new Map(); // groupId:userId -> name
  async function resolveAtName(groupId, userId) {
    const key = `${groupId}:${userId}`;
    if (atNameCache.has(key)) return atNameCache.get(key);
    try {
      const info = await onebot.getGroupMemberInfo(groupId, userId);
      const name = info?.card || info?.nickname || null;
      if (name) {
        atNameCache.set(key, String(name));
        if (atNameCache.size > 500) atNameCache.clear(); // 简单防膨胀
        return String(name);
      }
    } catch { /* ignore */ }
    return null;
  }

  async function resolveReply(messageId) {
    try {
      const msg = await onebot.getMsg(messageId);
      const senderName = msg?.sender?.card || msg?.sender?.nickname || '';
      let text = '';
      if (Array.isArray(msg?.message)) {
        text = msg.message.map((s) => (s.type === 'text' ? s.data?.text ?? '' : `[${s.type}]`)).join('').trim();
      } else if (typeof msg?.message === 'string') {
        text = msg.message;
      }
      // senderId 一并带回：引用块显示为 名字(QQ:xxx)，与发言人标签同口径 ——
      // 没有它，模型分不清引用的是"哪个张三"
      return { sender: String(senderName), senderId: String(msg?.sender?.user_id ?? ''), text: String(text).slice(0, 120) };
    } catch {
      return null;
    }
  }

  async function ingestMessage(kind, id, event) {
    const cfgNow = getConfig();
    if (!allowed(kind, id, cfgNow)) return; // 白名单外的聊天完全不记录

    const segments = Array.isArray(event.message) ? event.message : null;
    const senderId = String(event.sender?.user_id ?? event.user_id ?? '');
    const senderName = String(event.sender?.card || event.sender?.nickname || senderId || '');

    // 屏蔽名单：被屏蔽群员的消息直接丢弃 —— 不存档、不触发会话、不进提示词背景。
    // 放在最前面：连合并转发展开这种网络请求都不值得为它做。
    // 两道屏蔽：全局（所有群+私聊）优先，其次按群。
    if (senderId) {
      const globalBlocked = isGloballyBlocked(senderId);
      if (globalBlocked) return;
      if (kind === 'group' && (cfgNow.blocklist?.[id] || []).map(String).includes(senderId)) return;
    }
    const media = segments ? extractMediaFromSegments(segments) : [];

    let text;
    if (segments) {
      text = await segmentsToText(segments, {
        resolveReply: (mid) => resolveReply(mid),
        resolveAtName: (qq) => kind === 'group' ? resolveAtName(id, qq) : null,
        // 语音转写（`media.transcribe`）要用它去 get_record 取音频
        onebot
      });
    } else {
      text = String(event.raw_message ?? event.message ?? '').trim();
    }

    // 合并转发：占位符 → 展开真实内容（2026-10-10 forward-id 补丁）
    let fwdId = null;
    if (segments && (text.includes('[合并转发') || text.includes('[转发消息'))) {
      fwdId = forwardIdFromSegments(segments);
      if (event.message_id != null || fwdId) {
        try {
          const { nodes } = await fetchForwardNodes(onebot, { fwdId, messageId: event.message_id });
          const ex = await expandForwardNodes(nodes, { onebot });
          if (ex && ex.text) {
            text = ex.text;
            if (ex.media?.length) media.push(...ex.media);
          }
        } catch (e) {
          log(`[ingest] 展开合并转发失败（保留占位符）: ${e?.message ?? e}`);
        }
      }
    }

    if (!text && !media.length) return;

    // ── 图片入库缓存 ──
    // QQ(NTQQ) 的图片下载链接带 rkey 签名，**几分钟内就失效**（实测入库 48 秒后
    // get_message_images 去下载就 400，官方错误体 "download url has expired"）——
    // 模型只能回"这张读不出来"。入库这一刻 url 是新鲜的，所以在这里就地排队下载
    // （image-cache.js 后台串行，不阻塞 ingest），看图工具优先读本地缓存。
    if (media.length) {
      try { cacheIncomingImages(`${kind}:${id}`, event.message_id, media); } catch { /* 缓存失败不影响入库 */ }
    }

    // ── 指令禁言：群内任何人 @机器人 + 发送指定指令 → 该群暂时固定 1 档（仅艾特）──
    // 在存档前处理：指令本身也要留档（让机器人知道被禁言了），但先设置禁言状态。
    if (kind === 'group') {
      maybeTriggerCommandMute(id, text, event);
    }


    // ── [[command-gateway:dispatch]] 「指令前置」插件自动维护，不要手改这一段 ──
    // ── 指令前置：在存档与会话创建之前，给「指令前置」插件一次认领机会 ──
    // 约定（见 plugins/command-gateway/README.md）：
    //   · dispatch 必须**同步**返回 { handled }；认领后要做的异步工作放进 run()，
    //     这样消息热路径不等待网络/模型调用；
    //   · handled = true → 不存档、不触发会话，彻底不诞生这条会话；
    //   · run() 还可以再返回 { passthrough } 表达「指令执行完后放行」：
    //       true         → 按消息原文放行（存档 + 触发会话，和没认领过一样）；
    //       非空字符串   → 用这段文本替代原文放行（修改后再进会话）；
    //       false / 缺省 → 不放行，消息到此为止。
    //     放行走的是下面的 releaseClaimed()：**不重新过拦截链**（防止链上插件
    //     二次认领造成循环），原消息的媒体段原样保留。
    //   · 未认领、插件没装、插件抛错 → 一律原样放行，行为与没装插件完全一致。
    //
    // ⚠️ 块与核心之间是**软引用**（术语见项目 CONTEXT.md 的「会话前缝」）：
    //    核心句柄一律从 pluginHost 里取，取不到就是 undefined，调用处一律 ?.（有就调用、
    //    没有就跳过）。这样"上游删掉了某个函数"的表现是"少一项功能"，而不是"整块每次
    //    执行都抛 ReferenceError、被自己的 catch 吞掉，用户只看到指令毫无反应"。
    //    真正缺了干不了活的符号（store / orchestrator / emit / log / skillManager）写在
    //    补丁表的 needs 里，打补丁之前就会被拦下来并说清缺了谁。
    let pluginHost = null;
    /**
     * 拼核心句柄。`typeof` 对**不存在的名字**也是安全的（不会抛 ReferenceError），
     * 所以同一份块既能在京玉版上跑（没有 reminders / 指令禁言 / 链接转发），
     * 也能在老核心（0.4）上跑（有这些）。
     * 只在真的要分发时拼一次 —— 插件没装/没启用时，热路径上只多一次能力查询。
     */
    const makePluginHost = () => ({
      // 必需项：直接引用。缺了宁可炸得看得见（而且 needs 会在安装前就拦住）
      store,
      orchestrator,
      emit,
      log,
      // 可选项：有就给，没有就是 undefined
      sessions: typeof sessions === 'undefined' ? undefined : sessions,
      stickers: typeof stickers === 'undefined' ? undefined : stickers,
      sender: typeof sender === 'undefined' ? undefined : sender,
      onebot: typeof onebot === 'undefined' ? undefined : onebot,
      memory: typeof memory === 'undefined' ? undefined : memory,
      dataDir: typeof DATA_DIR === 'undefined' ? undefined : DATA_DIR,
      getConfig: typeof getConfig === 'undefined' ? undefined : getConfig,
      updateConfig: typeof updateConfig === 'undefined' ? undefined : updateConfig,
      // 老核心（0.4）有这两个函数；京玉版已经把「指令禁言」和「链接媒体转发」删掉了，
      // 这里自然为 undefined —— 调用处是 ?.，所以是"跳过"，不是"报错"。
      maybeTriggerCommandMute: typeof maybeTriggerCommandMute === 'undefined' ? undefined : maybeTriggerCommandMute,
      forwardLinkedMedia: typeof forwardLinkedMedia === 'undefined' ? undefined : forwardLinkedMedia
    });
    try {
      const dispatch = skillManager.getCapabilityProviders('command.dispatch')[0]?.fn;
      if (dispatch) {
        pluginHost = makePluginHost();
        const chatKey = `${kind}:${id}`;
        // 指令目录：只取「声明了 command 的插件」的清单元信息，不做可用性计算
        //（用 registry.list() 而不是 skillManager.list()，避免每条消息都跑一遍
        //  isActive 依赖链）。插件自己会用 api.hasCapability 判断能力是否可用。
        const catalog = skillManager.registry.list()
          .map((s) => ({
            id: s?.manifest?.id,
            name: s?.manifest?.name,
            commands: Array.isArray(s?.manifest?.commands) ? s.manifest.commands : [],
            // 消息入口拦截声明：{ capability, order }（见 manifest.js 的 normalizeIntercept）
            intercept: s?.manifest?.intercept || null
          }))
          .filter((s) => s.id && (s.commands.length || s.intercept));
        const decision = dispatch({
          text,
          segments,
          rawMessage: String(event.raw_message ?? (typeof event.message === 'string' ? event.message : '') ?? ''),
          messageId: event.message_id != null ? String(event.message_id) : '',
          kind,
          chatId: String(id),
          chatKey,
          senderId,
          senderName,
          catalog,
          ctx: {
            kind, chatId: String(id), chatKey,
            // 核心句柄：给「指令前置」把它包装成对外服务能力（ai.ask / search.web / history.read…）。
            // 插件不该自己 import src/，所以由核心在这一处把实例交出去。
            // chat 单独再给一份：链上的拦截者（比如隐私模式）要"用核心的模型链路问一次 AI"。
            onebot: pluginHost.onebot,
            sender: pluginHost.sender,
            store: pluginHost.store,
            memory: pluginHost.memory,
            log: pluginHost.log,
            emit: pluginHost.emit,
            host: pluginHost,
            chat: (messages, options = {}) => import('./llm.js').then((m) => m.chatCompletionWithRetry({
              messages,
              temperature: options.temperature ?? null,
              maxTokens: Number(options.maxTokens) || 0
            }))
          }
        });
        if (decision && decision.handled === true) {
          if (typeof decision.run === 'function') {
            Promise.resolve()
              .then(() => decision.run())
              .then((r) => releaseClaimed(kind, id, text, media, event, senderId, senderName, r))
              .catch((error) => pluginHost.log(`[指令前置] 执行失败：${error?.message ?? error}`));
          }
          return;
        }
      }
    } catch (error) {
      // 这条路径上"上游把符号删了"会让**每条消息**都进来一次 —— 只报第一次，
      // 之后静默按普通消息放行，别用同一行把日志淹掉（事故里的表现就是这样）。
      const once = (globalThis.__cgDispatchErrorLogged ||= { at: 0 });
      if (!once.at) {
        once.at = Date.now();
        log(`[指令前置] 分发失败，已按普通消息放行：${error?.message ?? error}`);
      }
    }

    /**
     * 「执行完后放行」：把已认领的消息按插件的要求放回正常聊天流程。
     * 独立成函数声明，是为了让上面那条 Promise 链在 try 块结束之后仍能调到它。
     * 顺序说明：指令的回复此刻多半已经发出并入档（appendSelf），这里补存的是
     * 用户那条原始消息 —— 存档时间用消息本来的时间，不用现在，避免历史错序。
     */
    function releaseClaimed(kind, id, text, media, event, senderId, senderName, result) {
      const pass = result ? result.passthrough : undefined;
      if (pass === undefined || pass === null || pass === false) return;
      let body;
      if (pass === true) {
        body = String(text ?? '');
      } else {
        body = String(pass).trim();
        if (!body) {
          log('[指令前置] 放行文本为空，已忽略本次放行');
          return;
        }
      }
      if (!pluginHost) pluginHost = makePluginHost();
      const chatKey = `${kind}:${id}`;
      // 指令禁言（0.4 的核心有；京玉版没有 → 跳过）
      if (kind === 'group') pluginHost.maybeTriggerCommandMute?.(id, body, event);
      pluginHost.store.appendIncoming(chatKey, {
        mid: event?.message_id,
        ts: event?.time ? Math.round(Number(event.time) * 1000) : Date.now(),
        senderId,
        senderName,
        text: body || '[图片]',
        media
      });
      pluginHost.emit('chat-update', chatKey);
      pluginHost.orchestrator.onIncoming(chatKey);
      // 链接媒体转发（0.4 的核心有；京玉版没有 → 跳过）
      pluginHost.forwardLinkedMedia?.(kind, id, body)?.catch?.(
        (e) => pluginHost.log(`[media] 链接转发失败：${e?.message ?? e}`)
      );
    }
    // ── [[/command-gateway:dispatch]] ──

    store.appendIncoming(`${kind}:${id}`, {
      mid: event.message_id,
      ts: event.time ? Math.round(Number(event.time) * 1000) : Date.now(),
      senderId,
      senderName,
      text: text || '[图片]' ,
      media,
      fwdId
    });
    // 「收到消息」事件点（onMessage 钩子）：**每条**消息都经过这里 ——
    // 确定性扩展（反撤回缓存、开发工单的「开发 xxx」识别）不能依赖"参与度判定放行"
    // 这个不确定条件（2026-10-08：这条调用原先缺失 —— 反撤回的 onMessage 一直在空转，
    // 开发工单的指令也只有在"恰好被唤醒"时才可能被看见）。
    // send：把"话筒"递给插件（开发模式的回信直接走统一发送队列：限频/去重/切分/留档）。
    try {
      await skillManager.runHook('onMessage', {
        event,
        chatKey: `${kind}:${id}`,
        senderId,
        senderName,
        text: text || '',
        // 契约字段（CORE-PATCH.md）：onebot/sender/store/log/sendSegments —— 与 onRecall 同款。
        onebot,
        sender,
        store,
        log,
        sendSegments: (k, id2, segs) => onebot.sendSegments(k, id2, segs),
        // opts 可选透传（如 { dedupe: false }）—— 给"进度提示"这类本就该重复的内容用。
        // 不传时行为与以前完全一致（走默认去重）。
        send: (messages, opts) => sender.sendTextBatch(`${kind}:${id}`, Array.isArray(messages) ? messages : [String(messages)], opts || {})
      });
    } catch { /* 单个钩子出错由管理器隔离并记日志，这里不阻断 ingest */ }
    // ── 开发模式让路：由 dev-orders 提供 dev.route 能力表态 ──
    // 这条消息若已被开发会话接走（白名单 + 开发模式中），普通人格不再插嘴：
    // 标记已读（与"不响应"路径同款）、只广播 chat-update（消息照常留档、UI 可见）。
    let handledByDev = false;
    try {
      const ck = `${kind}:${id}`;
      const provs = skillManager.getCapabilityProviders('dev.route', { chatKey: ck, senderId });
      for (const p of provs) {
        try {
          if (p?.fn?.({ chatKey: ck, senderId, senderName, text: text || '', mid: event.message_id })?.handled === true) {
            handledByDev = true;
            break;
          }
        } catch { /* 单个 provider 出错不影响其它 */ }
      }
    } catch { /* 没装插件就无感 */ }
    if (handledByDev) {
      store.markAllRead(`${kind}:${id}`);
      emit('chat-update', `${kind}:${id}`);
      return;
    }
    emit('chat-update', `${kind}:${id}`);

    // ── [[sleep-gate:inbound]] 入站闸门（能力名 message.inbound-gate，单提供者）──
    // 恢复 0.4.5 的行为：睡眠类插件（plugins/sleep-mood）在**消息入口**决定"这条
    // 要不要送模型"。拦下时**仍然存档**（她醒来能补看），但不建会话、不调模型
    // （零 token）。为什么必须在入口做：hook（before-context / before-tool）拿不到
    // 返回值，拦不住"建会话 + 调模型"，只能事后拦发送。
    // 单提供者：只看第一个（0.4.5 的约定，多声明的不会被调用）。
    // 闸门缺失 / 抛错一律放行 —— 睡眠功能坏掉绝不能把消息入口拖死。
    let gateBlocked = false;
    let gatePlugin = '';
    if (text) {
      try {
        const gateProv = skillManager.getCapabilityProviders(
          'message.inbound-gate', { chatKey: `${kind}:${id}`, kind }
        )[0];
        if (gateProv && typeof gateProv.fn === 'function') {
          const g = await gateProv.fn({
            kind,
            chatKey: `${kind}:${id}`,
            text: String(text || ''),
            senderId: String(senderId || ''),
            store,
            orchestrator,
            sender,
            onebot,
            botName: getConfig().persona?.botName || ''
          });
          gateBlocked = g?.blocked === true;
          gatePlugin = gateProv.skillId || '';
        }
      } catch (e) {
        log(`[gate] 入站闸门异常（已放行给模型）：${e?.message ?? e}`);
      }
    }
    if (gateBlocked) {
      log(`[gate] 已拦下（${gatePlugin || '未知'}）：本条已存档，不进模型：${String(text).replace(/\s+/g, ' ').slice(0, 60)}`);
      return;
    }

    // ── [[sleep-gate:heal]] 残留暂停位自愈 ─────────────────────────────────
    // 场景：命令睡眠期间插件被热载 / 全量重扫（宿主检测到别的插件文件变动时会重扫
    // 所有插件），sleep-mood 的 commandSleep 是**内存变量**（有意不落盘），一重扫就
    // 变回 false；而 orchestrator.paused 是另一处内存，仍是 true。
    // 结果：闸门不再拦，但调度一直被暂停 ⇒ 她**永远沉默、而且 /起床 也叫不醒**
    //（唤醒分支只在 commandSleep=true 时才会执行），只能重启宿主。
    // 对策：闸门这次没拦（= 她并不在命令睡眠）却还挂着 command-sleep 的暂停位，
    // 说明两者脱节了，就地恢复。只认 'command-sleep'，不动用户手动点的「暂停」。
    if (orchestrator?.paused && orchestrator.pauseReason === 'command-sleep') {
      try {
        const n = orchestrator.resumeAll?.() ?? 0;
        log(`[gate] 检测到残留的 command-sleep 暂停位（插件状态已重置），已自愈恢复并补处理 ${n} 个会话`);
      } catch (e) {
        log(`[gate] 自愈恢复失败：${e?.message ?? e}`);
      }
    }

    orchestrator.onIncoming(`${kind}:${id}`);

    // 链接媒体转发（确定性）：刻意不 await —— 百兆级下载/上传不能卡住 ingest 热路径。
    // 内部已把错误全部收口（含 provider 抛错），这里再挂一次 catch 只为防漏网。
    forwardLinkedMedia(kind, id, text).catch((e) => log(`[media] 链接转发失败：${e?.message ?? e}`));
  }

  /**
   * 指令禁言：检测"@机器人 + 指定指令"，命中则把该群响应档位暂时固定为 1 档。
   * 禁言状态写入 config.commandMute.active[群号] = 到期时间戳（0 = 直到手动解除）。
   */
  function maybeTriggerCommandMute(groupId, text, event) {
    const cm = getConfig().commandMute;
    if (!cm || cm.enabled !== true) return;
    const command = String(cm.command || '').trim();
    if (!command) return;
    // 必须同条消息里既 @机器人 又含指令
    // ⚠️ 走统一的 isAtMe（QQ 号优先）：此前这里只比对名字，而群昵称（群名片）
    //    与配置里的 botName/selfNickname 不一致时会漏判，导致禁言指令失效。
    const atMe = isAtMe(text, {
      selfId: onebot.selfId,
      botName: getConfig().persona?.botName || '',
      selfNickname: getConfig().persona?.selfNickname || onebot.selfNickname || ''
    });
    if (!atMe) return;
    if (!text.includes(command)) return;
    // 设置禁言：durationMin>0 则到期时间戳，否则 0（直到手动解除）
    const durationMs = Math.max(0, Number(cm.durationMin) || 0) * 60000;
    const until = durationMs > 0 ? Date.now() + durationMs : 0;
    // 2026-10-17（报告3 M4）：改走 updateConfig 的**函数式入口** —— 读当前 active
    // 与写回同一个同步块，结构上不可能被并发的另一次禁言/解禁覆盖。
    // （原写法读 getConfig() 与 updateConfig() 之间也没有 await，本就不竞态；
    //   换成函数式入口是为了让"原子"由接口保证，而不是靠调用点的写法。）
    updateConfig((cfg) => ({
      commandMute: { active: { __replace__: { ...(cfg.commandMute?.active || {}), [String(groupId)]: until } } }
    }));
    const untilStr = until ? new Date(until).toLocaleTimeString('zh-CN', { hour12: false }) : '直到手动解除';
    log(`[指令禁言] 群 ${groupId} 已被「${command}」禁言，响应档位临时固定为 1 档（仅艾特），${untilStr} 解除`);
    emit('chat-update', `group:${groupId}`);
  }

  // ── 链接媒体转发（确定性触发） ──────────────────────────────────────────

  /**
   * 确定性触发：消息里出现 B站/抖音链接 → 下载并转发。
   *
   * 与 LLM 型（注册工具）的区别正在这里：插件开着，条件满足就一定会跑，
   * 模型想忽略也忽略不掉 —— 整条链路上没有任何"让模型决定"的环节。
   *
   * 一个提供者都不在（插件未装/未启用）时立刻返回 —— 零网络请求、零副作用。
   * 调度细节（候选链接提取、多提供者协商、失败文案）在 src/media-links.js，
   * 那部分是纯逻辑、可被测试直接驱动；这里只负责从 skillManager 取提供者。
   */
  async function forwardLinkedMedia(kind, id, text) {
    const providers = skillManager.getCapabilityProviders('media.download');
    if (!providers.length) return;
    await dispatchMediaLinks({
      urls: extractCandidateUrls(text),
      providers,
      ctx: { onebot, sender, kind, chatId: id, text },
      log
    });
  }

  async function ingestPoke(event) {    // OneBot v11: notice_type=notify, sub_type=poke；群拍 target_id，私聊拍自己
    const isGroup = event.group_id != null;
    const id = isGroup ? String(event.group_id) : String(event.user_id);
    const cfgNow = getConfig();
    if (!allowed(isGroup ? 'group' : 'private', id, cfgNow)) return;

    const operatorId = String(event.user_id ?? '');
    // 自己拍的拍（send_poke 的 OneBot 回显）不触发处理——与 message_sent 同理，发送时已留档
    // ⚠️ 2026-10-16：判定用**事件自带的 self_id**（优先），回落到 onebot.selfId。
    // 存档实证（2026-10-15）：onebot.selfId 曾不等于机器人真实 QQ（get_login_info
    // 在 SnowLuma 慢启动/切号期间拿到的是别的账号或空值）—— 后果是双向的：
    //   ① 真被拍时文案写成"X 拍了拍 机器人名"而不是"我"，拍一拍召唤识别不到；
    //   ② 若 selfId 恰好是群里某个普通成员的 QQ，**群友拍那个人时文案变成
    //      "X 拍了拍 我"**，机器人误以为在拍自己、按 1 档响应 —— 用户反馈的
    //     "拍别人时机器人总会认为在拍自己"。self_id 是每条事件自带的真值，
    //     不依赖连接期的全局查询，才是"这次是谁的视角"的权威来源。
    const evSelfId = String(event.self_id ?? '') || onebot.selfId;
    if (operatorId && operatorId === evSelfId) return;
    // 屏蔽名单对拍一拍同样生效（操作者是被屏蔽群员则丢弃）：全局优先，其次按群
    if (operatorId) {
      if (isGloballyBlocked(operatorId)) return;
      if (isGroup && (cfgNow.blocklist?.[id] || []).map(String).includes(operatorId)) return;
    }
    const targetId = String(event.target_id ?? event.user_id ?? '');
    const selfId = evSelfId;
    // 拍一拍也要记下真实群名片：原先这里硬编码"（拍一拍事件）"，
    // 会覆盖同一 QQ 在普通消息里的真实昵称 —— 记忆整理时取名字会拿到这个占位符，
    // 导致"某群友的名字叫（拍一拍事件）"这种脏数据。
    const chatKeyNow = `${isGroup ? 'group' : 'private'}:${id}`;
    let operatorName = isGroup ? ((await resolveAtName(id, operatorId)) || '') : '';
    if (!operatorName) {
      const prior = (store.recent(chatKeyNow, { limit: 500 }) || [])
        .find((m) => !m.self && String(m.senderId) === operatorId
          && String(m.senderName || '') && String(m.senderName) !== '（拍一拍事件）');
      operatorName = prior ? String(prior.senderName) : operatorId;
    }
    // 目标名字同样补齐（被拍者的群名片；解析不到就留 QQ 号，formatEntry 会拼 (QQ:xxx)）
    const targetName = (isGroup && String(targetId) !== String(selfId))
      ? ((await resolveAtName(id, targetId)) || targetId)
      : targetId;
    // 展示名：管理员备注 > 群名片（与消息历史同口径）
    const notes = cfgNow.memberNotes || {};
    const opLabel = notes[operatorId] || operatorName || operatorId;
    // 私聊里"用户拍机器人"没有 target_id 时回落 user_id（= 操作者），文案会变成
    // "拍了拍自己" —— 1v1 场景下能收到的拍一拍只可能是拍机器人，直接按"拍我"处理。
    const pokeSelf = isGroup ? String(targetId) === String(selfId) : true;
    const tgtLabel = pokeSelf
      ? '我'
      : (notes[targetId] || targetName || targetId);
    // 文案统一为「X 拍了拍 Y」视角（机器人被拍时 Y=我）。
    // 旧文案"你拍了拍（来自 张三）"视角混乱（读起来像"我拍了别人"），
    // 是机器人被拍时识别错乱的主因。名字带 QQ 号，与发言人标签同口径。
    const opWithId = String(operatorId) ? `${opLabel}(QQ:${operatorId})` : opLabel;
    const tgtWithId = (pokeSelf || !String(targetId)) ? tgtLabel : `${tgtLabel}(QQ:${targetId})`;
    // 群内"自己拍自己"（target_id 缺失回落成操作者，或真的自拍）→ "拍了拍自己"；
    // 私聊没有群自拍语义 —— 缺 target_id 时回落值就是操作者，但 1v1 里能收到的
    // 拍一拍只可能是拍机器人，走"拍了拍 我"分支（pokeSelf 已置 true）。
    const text = (operatorId === targetId && isGroup)
      ? `[拍一拍] ${opWithId} 拍了拍自己`
      : `[拍一拍] ${opWithId} 拍了拍 ${tgtWithId}`;
    // 拍一拍是"轻量召唤"信号：作为触发批发给模型（isPoke 标记让档位判定
    // 按 1 档响应），但**不进【过去状态】历史**——buildPastState 会跳过 isPoke，
    // 存档里只留一条轻量记录（聊天记录页仍可见，模型历史里不出现）。
    // ⚠️ 2026-10-16：同时落 pokeSelf 真值标记 —— 档位判定（"是不是拍我"）从此
    // 不靠正则猜文本（被拍者名字以"我"开头时会误判），以入库时的身份判定为准。
    store.appendIncoming(chatKeyNow, {
      mid: null,
      ts: event.time ? Math.round(Number(event.time) * 1000) : Date.now(),
      senderId: operatorId,
      senderName: operatorName,
      text,
      media: [],
      isPoke: true,
      pokeSelf
    });
    emit('chat-update', `${isGroup ? 'group' : 'private'}:${id}`);
    orchestrator.onIncoming(`${isGroup ? 'group' : 'private'}:${id}`);
  }

  async function handleOneBotEvent(event) {
    if (!event || typeof event !== 'object') return;
    if (event.post_type === 'message' || event.post_type === 'message_sent') {
      // 自己发的消息（message_sent / self_id 相同）不触发处理（发送时已自行记录）
      // ⚠️ 2026-10-16：判定优先用事件自带的 self_id（每条事件的权威"这是谁的
      // 视角"），回落到 onebot.selfId —— 后者来自连接时的 get_login_info，
      // 在 SnowLuma 慢启动/切号期间可能为空或指向别的账号，用错时机器人的
      // 发言会被当群友消息入库、真群友的消息反被丢弃（与拍一拍同一根因）。
      const evSelfId = String(event.self_id ?? '') || onebot.selfId;
      if (String(event.user_id ?? event.sender?.user_id ?? '') === evSelfId) return;
      if (event.message_type === 'group' && event.group_id != null) return ingestMessage('group', String(event.group_id), event);
      if (event.message_type === 'private' && event.user_id != null) return ingestMessage('private', String(event.user_id), event);
      return;
    }
    if (event.post_type === 'notice' && event.notice_type === 'notify' && event.sub_type === 'poke') {
      return ingestPoke(event);
    }
    // 撤回事件：群撤回 group_recall / 好友撤回 friend_recall
    // 用户撤回的消息，后续会话不再发给大模型（从存档里标记/删除）。
    if (event.post_type === 'notice' && (event.notice_type === 'group_recall' || event.notice_type === 'friend_recall')) {
      return handleRecall(event);
    }
    // 群禁言通知（2026-10-24 参照上游 F2）：OneBot group_ban —— 机器人自己被禁言/解禁的
    // **权威事件源**。此前这条通知到达后被当"不关心的事件"直接丢弃，ban-state 插件的
    // 两条写入来源（协议层通知 / 发送被拒兜底）双双落空，唯一的查询兜底又被缓存架空 ——
    // 上游实测禁言 10 分钟烧 19.5 万 prompt token。
    if (event.post_type === 'notice' && event.notice_type === 'group_ban' && event.group_id != null) {
      return handleGroupBan(event);
    }
    // 未识别的 notice / request：记一条 debug 落盘（默认级别 info 过滤掉，零噪音；
    // 排障时把日志级别调到 debug 就能看见）。**静默丢弃是上游排查同类 bug 最大的障碍** ——
    // group_ban 被丢了一年都没人发现。meta_event（心跳）除外，那条没有排查价值。
    if ((event.post_type === 'notice' || event.post_type === 'request') && event.post_type !== 'meta_event') {
      logger.debug('app',
        `未处理的事件：post_type=${event.post_type}`
        + ` notice_type=${event.notice_type ?? '-'} sub_type=${event.sub_type ?? '-'}`
        + ` group_id=${event.group_id ?? '-'} user_id=${event.user_id ?? '-'}`);
    }
    // meta/心跳等事件忽略
  }

  /**
   * 处理群禁言通知（OneBot v11: notice_type=group_ban；2026-10-24 参照上游 F2）。
   *
   * snowluma 的转换口径（to-notice.ts convertGroupMute）：
   *   sub_type = duration > 0 ? 'ban' : 'lift_ban'，duration 为禁言秒数。
   *   注意 OneBot v11 原语义里「ban 且 duration=0」也是解禁，一并按解禁处理。
   *
   * 只认 **user_id === self_id** 的通知 —— 群友被禁言与机器人无关，
   * 误把自己标成禁言会让整个群停止回复（上游报告 P0 级风险）。
   * self_id 用事件自带值优先，回落 onebot.selfId（与 message / poke 同口径，
   * 慢启动/切号期间 get_login_info 可能为空或指向别的账号）。
   */
  function handleGroupBan(event) {
    const evSelfId = String(event.self_id ?? '') || onebot.selfId;
    const userId = String(event.user_id ?? '');
    if (userId && userId !== evSelfId) {
      logger.debug('app', `群 ${event.group_id} 的禁言通知与机器人无关（user_id=${userId}），忽略`);
      return;
    }
    const chatKey = `group:${String(event.group_id)}`;
    const duration = Number(event.duration) || 0;
    const isBan = event.sub_type === 'ban' && duration > 0;
    try {
      if (isBan) {
        noteMuted(chatKey, duration);
        logger.info('app', `群 ${event.group_id} 机器人被禁言 ${duration} 秒，已记录禁言状态（期间跳过处理）`);
      } else {
        noteUnmuted(chatKey);
        logger.info('app', `群 ${event.group_id} 机器人禁言解除，已恢复正常处理`);
      }
    } catch (error) {
      // ban-state 插件缺失/坏了不该影响事件处理本身（查询兜底仍在）
      logger.warn('app', `禁言状态写入失败（${chatKey}）：${error?.message ?? error}`);
    }
  }

  /** 处理消息撤回：把对应 mid 的存档消息标记为已撤回（后续提示词过滤掉）。 */
  function handleRecall(event) {
    const isGroup = event.notice_type === 'group_recall';
    const chatKey = isGroup ? `group:${String(event.group_id)}` : `private:${String(event.user_id)}`;
    const mid = event.message_id;
    if (mid == null) return;
    const marked = store.markRecalled(chatKey, mid);
    if (marked) {
      log(`[撤回] ${chatKey} 消息 #${mid} 已被撤回，后续不再发给模型`);
      emit('chat-update', chatKey);
    }
    // onRecall 钩子：反撤回插件在这里把撤回的消息原文重发回群（2026-10-08 补的触发点）。
    // 无论 store 里有没有标记成功都要发 —— 插件的缓存与 store 是两套记录。
    // ⚠️ ctx 必须带齐 onebot/sender/store/log/sendSegments（2026-10-08 修）：
    //   之前只传了 { chatKey, mid, event }，而 runHook 原样透传 ctx，于是
    //   anti-recall 的 sendSegmentsSafe 三级回退全落空（ctx.onebot.call 抛
    //   TypeError 被 catch 吞掉）→ 撤回时机器人毫无反应。见 CORE-PATCH.md 的契约。
    //   段发送用 onebot.sendSegments —— SendQueue **没有**同名方法（只有
    //   sendMedia/sendTextBatch），按 CORE-PATCH 原文写 sender.sendSegments 会 undefined。
    try {
      skillManager.runHook('onRecall', {
        event, chatKey, mid, onebot, sender, store, log,
        sendSegments: (kind, id2, segs) => onebot.sendSegments(kind, id2, segs)
      }).catch(() => {});
    } catch { /* ignore */ }
  }

  // ── HTTP API ──
  const server = http.createServer((req, res) => {
    handleHttp(req, res).catch((error) => {
      log('[http] 处理出错:', error?.message ?? error);
      try {
        res.writeHead(500, { 'content-type': 'application/json' });
        res.end(JSON.stringify({ error: String(error?.message ?? error) }));
      } catch { /* ignore */ }
    });
  });

  function json(res, code, data) {
    res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
    res.end(JSON.stringify(data));
  }

  // ── 请求体读取 ──────────────────────────────────────────────────────────
  // 抛出的错误必须是**可暴露的 HTTP 错误**（带 .expose 标记），由 /api 分发层
  // 统一转成 4xx。否则：JSON.parse 异常会冒成 500；"超限直接 throw" 会让没读完的
  // socket 变脏 —— 客户端连接池下次复用这条连接就是 ECONNRESET。
  const MAX_BODY_BYTES = 2 * 1024 * 1024;
  const HARD_BODY_LIMIT = 16 * 1024 * 1024;   // 超此值不再排空，直接断链
  function httpError(status, message) {
    const e = new Error(message);
    e.expose = true;
    e.status = status;
    return e;
  }

  async function readBody(req, { maxBytes = MAX_BODY_BYTES } = {}) {
    const chunks = [];
    let size = 0;
    let tooLarge = false;
    for await (const chunk of req) {
      size += chunk.length;
      if (size > HARD_BODY_LIMIT) {
        req.destroy();
        throw httpError(413, '请求体过大');
      }
      if (size > maxBytes) {
        tooLarge = true;          // 继续读干净（内容丢弃），保证连接可复用
        chunks.length = 0;
        continue;
      }
      chunks.push(chunk);
    }
    if (tooLarge) throw httpError(413, `请求体过大（上限 ${Math.round(maxBytes / 1024)}KB）`);
    const text = Buffer.concat(chunks).toString('utf8');
    if (!text) return {};
    try {
      return JSON.parse(text);
    } catch {
      throw httpError(400, '请求体不是合法 JSON');
    }
  }

  // ── 来源校验（CSRF / DNS rebinding 防护）────────────────────────────────
  // 服务只监听回环，但**浏览器里的任意网页都能向 127.0.0.1 发简单请求**，
  // 而 CORS 只挡"读响应"、挡不住"副作用"（改配置、暂停、重置数据…）。
  // 所以所有 /api/* 都必须来自回环 Host；带 Origin/Referer 时必须同源。
  function isLoopbackHostHeader(host) {
    return /^127\.0\.0\.1(:\d+)?$/.test(host)
      || /^localhost(:\d+)?$/.test(host)
      || /^\[::1\](:\d+)?$/.test(host);
  }

  /** 请求是否带了「可归属来源」信息（Origin 或 Referer 或 Sec-Fetch-Site）。 */
  function hasProvenance(req) {
    if (String(req.headers.origin ?? '')) return true;
    if (String(req.headers.referer ?? '')) return true;
    // ⚠️ 2026-10-17 补：**本应用自己把 Referer 掐掉了**。
    //   静态服务器给控制台页面发的是 `referrer-policy: no-referrer`
    //   （见本文件 2818/2863 两处），所以页面里发的同源 fetch **永远不带 Referer**；
    //   而同源 GET 也不带 Origin。于是"页面 fetch 有来源信息"这个前提在这里并不成立
    //   （原注释写的就是这个假设，它已经被同一份代码里的 referrer-policy 推翻了）。
    //   Sec-Fetch-Site 是浏览器强制标注的请求来源类别：页面脚本改不了、不受
    //   referrer-policy 影响、curl 默认也不会发 —— 正好补上"请求确实出自我们自己的页面"。
    //   安全性没有放宽：本机进程本来就能伪造 Referer（伪造 Sec-Fetch-Site 同理），
    //   这里仍要再过 originAllowed() 的回环 Host 校验；密钥端点的强凭据是
    //   keyEndpointAllowed() 里那个进程私有的渲染进程凭据。
    if (String(req.headers['sec-fetch-site'] ?? '').toLowerCase() === 'same-origin') return true;
    return false;
  }

  /**
   * @param {boolean} [opts.readOnly] 传入true 时表示这是一个**只读**请求
   *   （GET/HEAD）。无来源信息时，只读请求放行、有副作用的请求拒绝。
   *
   * ⚠️ 2026-10-07 审查修正：原实现对"无来源信息"一律放行，
   *   理由写的是「留空 = 只监听 127.0.0.1」——**这个推理是错的**：
   *   回环绑定只挡远程，**不挡本机上的任何进程**（非管理员即可）。
   *   于是 `curl http://127.0.0.1:3210/api/api-key` 能读走明文主 API Key
   *   （curl 不发 Origin/Referer → 命中最后一行放行），
   *   /api/reset-data（删库）、/api/config（改配置）同理。
   *
   *   现在的规则：无来源信息（curl / 本机脚本 / 地址栏直达）时，
   *   **只有只读请求放行**，任何有副作用的请求（POST/PUT/DELETE/PATCH）
   *   一律拒绝。这样既关掉了本机进程的越权面，
   *   又不影响控制台正常使用 —— 页面里的 fetch 虽然是同源，
   *   但浏览器会带 Referer（有来源信息），走的是上面两条正常校验。
   */
  function originAllowed(req, opts = {}) {
    const host = String(req.headers.host ?? '');
    if (!isLoopbackHostHeader(host)) return false;
    const origin = String(req.headers.origin ?? '');
    if (origin) {
      try {
        const u = new URL(origin);
        return isLoopbackHostHeader(u.host) && u.host === host;
      } catch { return false; }
    }
    const referer = String(req.headers.referer ?? '');
    if (referer) {
      try { return new URL(referer).host === host; } catch { return false; }
    }
    // 无来源信息（curl / 本机脚本 / 地址栏直达）
    const method = String(req.method ?? 'GET').toUpperCase();
    if (method === 'GET' || method === 'HEAD') return true;
    if (opts.readOnly) return true;
    return false;
  }
  // ── 外部脚本调用口径（收包人报告 P3 问"为什么 POST 全 403"）──────────────
  // 这是上面的**有意设计**（2026-10-07 安全审查：回环绑定挡不住本机其它进程，
  // 无来源的写请求一律拒绝）。脚本要调写接口，两条正路：
  //   1. 带 `Origin: http://127.0.0.1:<实际端口>` 头（回环同源即过；实际端口
  //      看 <DATA_DIR>/console-port，多安装并存时不一定等于 config.server.port）；
  //   2. 配置 server.token 后，外部脚本带 `x-console-token: <token>` 头或 ?token= 参数
  //      （过 authorize；但 originAllowed 仍要求 Origin 同源 —— 两条都要满足）。
  // Electron 控制台的随机凭据由主进程通过 webRequest 注入，不暴露到渲染页面。
  // 纯读取（GET）无来源也放行，脚本探测无需任何头。

  function authorize(req) {
    const token = String(getConfig().server?.token ?? '');
    if (!token) return true;
    const url = new URL(req.url, 'http://127.0.0.1');
    return req.headers['x-console-token'] === token
      || url.searchParams.get('token') === token
      || req.headers['x-console-token'] === rendererAuthToken;
  }

  // ── 配置脱敏 ────────────────────────────────────────────────────────────
  // 凡是字段名命中这些模式的，值一律替换为空串（保留"有/无"的 hasXxx 标记）。
  // 覆盖：apiKey / api_key / accessToken / httpAccessToken / token / secret / password / cookie …
  // ⚠️ cookie 必须在内：media-download 插件的 bilibiliCookie / douyinCookie
  //    是登录凭据，曾经 pattern 不认导致 /api/config 明文返回。
  const SECRET_KEY_PATTERN = /(apikey|api_key|accesstoken|access_token|communitykey|cookie|secret|password|privatekey|private_key)/i;
  // 形如 apiKeyFrom 的字段存的是"密钥来源标识"（如 manual），不是密钥本身，不要脱敏
  const SECRET_KEY_EXCLUDE = /from$/i;

  function sanitizeConfig(cfg) {
    const out = JSON.parse(JSON.stringify(cfg ?? {}));
    const seen = new WeakSet();

    const walk = (node) => {
      if (!node || typeof node !== 'object' || seen.has(node)) return;
      seen.add(node);
      for (const key of Object.keys(node)) {
        const value = node[key];
        if (value && typeof value === 'object') { walk(value); continue; }
        if (SECRET_KEY_EXCLUDE.test(key)) continue;
        // 已生成的 hasXxx 布尔标记本身也会被 apikey 模式匹配到，
        // 不排除就会连锁生成 hasHasXxx
        if (/^has/i.test(key) && typeof value === 'boolean') continue;
        if (SECRET_KEY_PATTERN.test(key)) {
          // ⚠️ 必须"删除字段"而不是"置为空串"。
          // 前端保存设置时会把整个 config 展开成 patch 回传（...c.webSearch?.deepseek），
          // 若这里留一个空串，deepMerge 会拿空串覆盖掉服务端保存的真 Key ——
          // 表现为：用户点一次"保存设置"，所有搜索 Key 就被静默清空。
          // 删掉字段则展开时不会带上该键，服务端原值得以保留。
          delete node[key];
          const flagName = `has${key.charAt(0).toUpperCase()}${key.slice(1)}`;
          node[flagName] = Boolean(String(value ?? '').trim());
        }
      }
    };
    walk(out);

    // 密钥集合整体清空（不逐 key 暴露存在性）
    if (out.dshProviderKeys && typeof out.dshProviderKeys === 'object') {
      const has = {};
      for (const [k, v] of Object.entries(out.dshProviderKeys)) has[k] = Boolean(String(v ?? '').trim());
      out.dshProviderKeys = {};
      out.dshProviderKeyPresence = has;
    }

    // 提供商列表：删掉 key 字段（同样不能置空串，否则回传时覆盖真实 Key），补 hasKey
    if (Array.isArray(out.providers)) {
      for (const p of out.providers) {
        const real = (cfg?.dshProviderKeys || {})[p.id] || p.apiKey;
        delete p.apiKey;
        p.hasKey = Boolean(String(real ?? '').trim());
      }
    }
    // 顶层 api：walk 已生成 hasApiKey，这里补一个简写的 hasKey 供旧代码读取
    if (out.api) out.api.hasKey = out.api.hasApiKey ?? Boolean(String(cfg?.api?.apiKey ?? '').trim());

    return out;
  }

  // ── 明文密钥端点守卫 ────────────────────────────────────────────────────
  /**
   * 这是本地单机程序，控制台就在本机浏览器打开，「显示密钥」是用户自己的操作，
   * 不该被禁用。真正的风险来自**外部网页**冒用浏览器读 127.0.0.1（CSRF /
   * DNS rebinding）—— 所以防线是「校验请求来源」。
   *
   * ⚠️ 历史实现里有一句 `if (req.headers['x-console-token']) return true`：
   *    只看"有没有这个头"、不看值，等于任何人加个头就能读明文密钥。
   *    已删除 —— 来源校验交由 originAllowed() 统一负责。
   */
  function keyEndpointAllowed(req) {
    // ① 渲染进程凭据：主进程用 webRequest 注入，进程私有（每次启动随机 32 字节）、
    //    不落盘、不进 DOM、不进 preload。这是控制台自己的最强凭据，**必须独立判定**。
    //    ⚠️ 2026-10-17 修（本次 bug 的根因）：这条判断原先被写在下面对 `if (token)` 的
    //    分支里 —— `config.server.token` 为空（默认值，也是 Electron 控制台的常态）时
    //    整段被跳过，于是**最强的凭据从头到尾没被看过一眼**，只能落到 hasProvenance()。
    //    而静态服务器给控制台页面发 referrer-policy: no-referrer，同源 GET 又不带
    //    Origin ⇒ 控制台里所有密钥端点恒 403：SnowLuma「控制台密码」永远是
    //    「读取失败（后端没有应答）」，设置页的「显示 API Key」同理。
    //    修前沙箱实测：带渲染进程凭据的请求 403（见 _luofix/t-verify-keyendpoint.mjs）。
    if (rendererAuthToken && req.headers['x-console-token'] === rendererAuthToken) return true;

    // ② 用户自配的 server.token（给外部脚本用；也可放在 ?token= 上）。
    const token = String(getConfig().server?.token ?? '');
    if (token) {
      const url = new URL(req.url, 'http://127.0.0.1');
      if (req.headers['x-console-token'] === token
        || url.searchParams.get('token') === token) return true;
    }
    // ⚠️ 这里**不能**退化成 originAllowed 的"无来源即放行"（见上面 originAllowed 注释）：
    //   明文密钥端点全是只读 GET，若跟着放行，本机任意进程 curl 一下就能读走主 API Key。
    //   也没必要退化 —— ①② 已经覆盖了控制台（渲染进程凭据）和脚本（server.token）两条正路；
    //   剩下的 ③ 只是"没有配置 token、又从浏览器里打开控制台"的兜底。
    if (!hasProvenance(req)) {
      return false;
    }
    return originAllowed(req);
  }

  /**
   * 提供商对象脱敏：去掉明文 apiKey，只留 hasKey。
   * upsertProvider / addModelsToProvider / removeModelFromProvider 的返回值都带
   * 明文 key（来自 withResolvedKey），不能直接 json 给前端。
   */
  function sanitizeProvider(p) {
    if (!p || typeof p !== 'object') return p;
    const { apiKey, ...rest } = p;
    return { ...rest, apiKey: '', hasKey: Boolean(String(apiKey ?? '').trim()) };
  }

  // 声明式路由表（src/routes.js）：把所有依赖一次性注入。
  // 路由 handler 通过闭包取用这些依赖，handleHttp 只负责匹配分发。
  const apiRoutes = createRoutes({
    store, memory, sessions, onebot, orchestrator,
    emit, log,
    localVersion, compareSemver, UPDATE_INFO_URL,
    sanitizeConfig, keyEndpointAllowed, sanitizeProvider,
    readBody, authorize,
    snowlumaDir, snowlumaWsPort, snowlumaWebuiUrl, snowlumaWebuiPort, snowlumaStatus, snowlumaLogs,
    snowlumaWebuiCredential,
    // 2026-10-17（N1）：读密码框之前先实测一次"这份密码还能不能登"，
    // 让 drifted 有真凭据（旧判据看 webui.json 的 mustChangePassword，恒为真）。
    probeSnowlumaWebuiAuth,
    launchSnowluma, stopSnowluma,
    snowlumaListAccounts, scheduleAutoInjectBotQq, resetSnowlumaWebui, snowlumaUnloadBot, snowlumaResumeInject,
    snowlumaSwitchBot,
    qqPortableStatus, qqPortableLogs, launchPortableQQ, stopPortableQQ,
    showPortableQQ, setupPortableQQFromLocal,
    visionScan, isPortOpen,
    buildUsageStats, buildUsageBreakdown,
    reloadSkills
  });

  async function handleHttp(req, res) {
    const url = new URL(req.url, 'http://127.0.0.1');
    const pathname = url.pathname;

    // SSE
    if (pathname === '/api/events' && req.method === 'GET') {
      if (!authorize(req)) return json(res, 401, { error: '未授权' });
      if (!originAllowed(req)) return json(res, 403, { error: '请求来源不被信任' });
      res.writeHead(200, {
        'content-type': 'text/event-stream',
        'cache-control': 'no-cache',
        connection: 'keep-alive'
      });
      res.write(`event: hello\ndata: {}\n\n`);
      sseClients.add(res);
      // 心跳：半开 TCP（拔网线 / NAT 超时，没有 FIN）不会触发 req 'close'，
      // 少了心跳这些客户端会永久留在 sseClients 里，之后每次 emit 都白写一遍。
      const heartbeat = setInterval(() => {
        try { res.write(': ping\n\n'); } catch { /* 下面 error/close 会清理 */ }
      }, 15000);
      heartbeat.unref?.();
      const cleanup = () => {
        clearInterval(heartbeat);
        sseClients.delete(res);
      };
      // 异步写错误不会走 try/catch，必须显式兜住，否则会变成 uncaughtException
      res.on('error', cleanup);
      res.on('close', cleanup);
      req.on('close', cleanup);
      return;
    }

    if (pathname.startsWith('/api/')) {
      if (!authorize(req)) return json(res, 401, { error: '未授权' });
      // 来源校验：挡住"恶意网页借浏览器打 127.0.0.1"（CSRF / DNS rebinding）。
      // 必须在 authorize 之后、路由分发之前。
      if (!originAllowed(req)) {
        return json(res, 403, { error: '请求来源不被信任（仅接受本机控制台的同源请求）' });
      }
      const method = req.method;

      // 继承控制台鉴权与同源检查。屏幕内容仅进入桌面上下文。
      if (pathname.startsWith('/api/desktop-pet/')) {
        try {
          await handleDesktopPetRequest({ req, res, url, readBody, json, desktopHost: desktopPetHost, emit });
        } catch (error) {
          log('[desktop-pet] API 处理失败：', error?.message ?? error);
          if (!res.headersSent) json(res, error?.status || error?.statusCode || 500, { ok: false, error: String(error?.message || '桌宠操作失败') });
          else if (!res.writableEnded) res.end();
        }
        return;
      }

      // 声明式路由分发（路由表在 src/routes.js）
      try {
        for (const route of apiRoutes) {
          if (route.method !== '*' && route.method !== method) continue;
          let match = null;
          if (typeof route.pattern === 'string') {
            if (route.pattern !== pathname) continue;
          } else {
            match = route.pattern.exec(pathname);
            if (!match) continue;
          }
          return await route.handler({ req, res, url, pathname, method, match, json });
        }
      } catch (error) {
        // readBody 等抛出的"可暴露错误"统一转 4xx；其余记日志、返回 500 而不是让连接挂掉
        if (error?.expose && Number.isInteger(error.status)) {
          return json(res, error.status, { error: String(error.message || '请求无效') });
        }
        log(`[api] ${method} ${pathname} 处理失败：${error?.stack ?? error?.message ?? error}`);
        return json(res, 500, { error: '服务器内部错误' });
      }
      return json(res, 404, { error: `未知 API：${method} ${pathname}` });
    }


    // 静态 UI


    // ── [[command-gateway:plugin-assets]] 「指令前置」插件自动维护，不要手改这一段 ──
    // 插件自带的静态资源：/plugin-assets/<插件id>/<文件>
    //
    // 用途：插件把自己的设置页模块（settings-ui.js）放在插件目录里，由控制台动态加载。
    // 安全约束与下面 UI 目录同一套，只是根目录换成「那个插件自己的目录」：
    //   1. 插件 id 必须对应一个**已注册**的插件（不存在的 id 直接 404，不猜路径）；
    //   2. 文件路径逐段校验，拒绝 ..、控制字符，拼好后再用 path.relative 二次确认没跳出目录；
    //   3. no-cache：插件文件是开发期会频繁改的东西，不能吃浏览器缓存。
    if (req.method === 'GET' && pathname.startsWith('/plugin-assets/')) {
      const rest = pathname.slice('/plugin-assets/'.length);
      const cut = rest.indexOf('/');
      let id = '';
      let file = '';
      try {
        id = decodeURIComponent(cut >= 0 ? rest.slice(0, cut) : '');
        file = decodeURIComponent(cut >= 0 ? rest.slice(cut + 1) : '');
      } catch {
        res.writeHead(400, { 'content-type': 'text/plain; charset=utf-8' });
        res.end('Bad Request');
        return;
      }
      const entry = id ? skillManager.registry.get(id) : null;
      const dir = entry?.dir ? path.resolve(ROOT, entry.dir) : '';
      const segs = file.split(/[/\\]+/).filter((s) => s !== '' && s !== '.');
      const bad = !entry || !dir || !segs.length
        || segs.some((s) => s === '..' || /[\x00-\x1f]/.test(s));
      const fullPath = bad ? '' : path.join(dir, ...segs);
      const relCheck = fullPath ? path.relative(dir, fullPath) : '..';
      if (bad || relCheck === '' || relCheck.startsWith('..') || path.isAbsolute(relCheck)) {
        res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
        res.end('Not Found');
        return;
      }
      try {
        const data = fs.readFileSync(fullPath);
        const ext = path.extname(fullPath);
        const assetTypes = {
          '.js': 'text/javascript; charset=utf-8',
          '.mjs': 'text/javascript; charset=utf-8',
          '.css': 'text/css; charset=utf-8',
          '.json': 'application/json; charset=utf-8',
          '.svg': 'image/svg+xml',
          '.png': 'image/png'
        };
        res.writeHead(200, {
          'content-type': assetTypes[ext] ?? 'application/octet-stream',
          'cache-control': 'no-cache'
        });
        res.end(data);
        return;
      } catch {
        res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
        res.end('Not Found');
        return;
      }
    }

    // ── [[/command-gateway:plugin-assets]] ──

    if (req.method === 'GET') {
      // 路径穿越防护：
      // 旧实现 file.replace(/\.\./g,'') 只删字面 ".." —— "/....//" 删完仍还原出 ".."，
      // 且 startsWith 校验在 path.join 之后做（顺序颠倒），形同虚设。
      // 正确做法：先 URL 解码 → 规范化 → 拼接 → 用 path.relative 判断跳出界。
      let decoded;
      try {
        decoded = decodeURIComponent(pathname === '/' ? '/index.html' : pathname);
      } catch {
        res.writeHead(400, { 'content-type': 'text/plain; charset=utf-8' });
        res.end('Bad Request');
        return;
      }
      // 去掉前导斜杠后按 / 与 \ 切段，逐段校验
      const segs = decoded.replace(/^([/\\])+/, '').split(/[/\\]+/);
      // 逐段过滤：拒绝空段、"."、".."、以及任何含控制字符的段
      let blocked = false;
      const clean = [];
      for (const seg of segs) {
        if (seg === '' || seg === '.') continue;      // 空段/当前目录，忽略
        if (seg === '..') { blocked = true; break; }  // 任何 .. 直接拒绝，不做消解
        if (/[\x00-\x1f]/.test(seg)) { blocked = true; break; }
        clean.push(seg);
      }
      if (blocked || clean.length === 0) {
        res.writeHead(403, { 'content-type': 'text/plain; charset=utf-8' });
        res.end('Forbidden');
        return;
      }
      // ── 插件自带页面：/plugin-panel/<id>/…（只读）───────────────────────
      // 这是"插件能在控制台里放自己界面"的唯一出口。完整契约见 src/skills/panel.js；
      // 插件在 plugin.json 的 configSchema 里声明 { type: 'action', panel: 'panel/x.html' }，
      // 加载时被规范成 manifest.panels（含校验好的 URL），设置弹窗据此渲染按钮。
      //
      // 两个根，都**只读**：
      //   /plugin-panel/<id>/…        → <APP_ROOT>/plugins/<id>/… 或 <APP_ROOT>/skills/<id>/…
      //   /plugin-panel/<id>/@data/…  → <DATA_DIR>/plugin-data/<id>/…
      // 后者是插件运行时数据的出口：api.storage 写进去的东西，页面 fetch 出来用。
      // 没有它，插件想给页面喂数据就只能塞一份静态副本，每次变化都要重新生成。
      //
      // 安全（五道）：
      //   ① 来源校验：只有本机控制台同源 / 无来源的 GET 能过（同 /api 的口径）。
      //      ⚠️ 与 /ui 的静态分支不同 —— 那边是应用自身资源，这里可能带插件运行时数据，
      //         不能让"恶意网页借浏览器读 127.0.0.1"顺手读走。
      //   ② id 只允许 [A-Za-z0-9._-] 且必须真实存在于 plugins/ 或 skills/ 下。
      //      上面已按 / \ 切过段，所以 id 里不可能带路径分隔符。
      //   ③ 其余段沿用同一套校验（拒 .. / 控制字符）。
      //   ④ 扩展名白名单（PANEL_FILE_TYPES）：不做通用文件下载器。
      //   ⑤ realpath 二次确认 —— 挡符号链接/目录联接指向目录外，这是 path.relative 挡不住的。
      if (clean[0] === PANEL_ROUTE_PREFIX.slice(1) && clean.length >= 3) {
        if (!originAllowed(req)) {
          res.writeHead(403, { 'content-type': 'text/plain; charset=utf-8' });
          res.end('Forbidden');
          return;
        }
        const panelId = clean[1];
        const rest = clean.slice(2);
        const fromData = rest[0] === PANEL_DATA_SEGMENT;
        if (fromData) rest.shift();
        const idOk = /^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(panelId);
        let root = null;
        if (idOk && rest.length) {
          if (fromData) {
            root = path.join(DATA_DIR, 'plugin-data', panelId);
          } else {
            for (const base of [PLUGINS_DIR, SKILLS_DIR]) {
              const cand = path.join(base, panelId);
              try { if (fs.statSync(cand).isDirectory()) { root = cand; break; } } catch { /* 试下一个 */ }
            }
          }
        }
        // realpath 一把过：既确认存在，又消掉符号链接
        let realRoot = null;
        let realFile = null;
        if (root) {
          try {
            realRoot = fs.realpathSync(root);
            realFile = fs.realpathSync(path.join(root, ...rest));
          } catch { /* 不存在 → 走下面 404 */ }
        }
        const inside = Boolean(realRoot && realFile)
          && (realFile === realRoot || realFile.startsWith(realRoot + path.sep));
        const panelType = inside ? PANEL_FILE_TYPES[path.extname(realFile).toLowerCase()] : null;
        if (!panelType) {
          res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
          res.end('Not Found');
          return;
        }
        try {
          const data = fs.readFileSync(realFile);
          const headers = { 'content-type': panelType, 'cache-control': 'no-cache' };
          if (panelType.startsWith('text/html')) {
            // CSP 由 panelCsp() 统一给出（见 src/skills/panel.js 的注释：
            // script-src 'self' 禁内联脚本、frame-ancestors 'self' 允许被设置弹窗嵌）。
            headers['content-security-policy'] = panelCsp();
            headers['x-content-type-options'] = 'nosniff';
            headers['referrer-policy'] = 'no-referrer';
          }
          res.writeHead(200, headers);
          res.end(data);
          return;
        } catch {
          res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
          res.end('Not Found');
          return;
        }
      }

      const fullPath = path.join(UI_DIR, ...clean);
      // 二次校验：解析后的路径必须仍在 UI_DIR 内
      const relCheck = path.relative(UI_DIR, fullPath);
      if (relCheck === '' || relCheck.startsWith('..') || path.isAbsolute(relCheck)) {
        res.writeHead(403, { 'content-type': 'text/plain; charset=utf-8' });
        res.end('Forbidden');
        return;
      }
      try {
        const data = fs.readFileSync(fullPath);
        const ext = path.extname(fullPath);
        const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png' };
        const headers = { 'content-type': types[ext] ?? 'application/octet-stream', 'cache-control': 'no-cache' };
        if (ext === '.html') {
          // CSP 用 HTTP 头再声明一次：header 里的 frame-ancestors 才生效
          // （meta 版本会被浏览器忽略该指令），同时给不解析 meta 的场景兜底。
          // ⚠️ 口径必须与 index.html 的 meta 版本**逐条一致** —— 双份 CSP 是
          //    取交集执行的：2026-10-17 人机验证接入时只改了 meta、漏了这份头，
          //    script-src 少了 kondius.cn，结果 SDK 脚本被头拦死，滑块永远
          //    "加载失败"（界面出现脚本错误 toast 就是它）。改 meta 时务必同步这里。
          headers['content-security-policy'] = [
            "default-src 'self'",
            // ★ 桌宠：只有 pet.html 需要 wasm-unsafe-eval（Live2D Cubism Core）。
            //   JS 的 unsafe-eval 仍然禁止 —— 这是 api-pet-wasm-csp 的原意。
            (clean.join('/') === 'desktop-pet/pet.html'
              ? "script-src 'self' 'wasm-unsafe-eval'"
              : "script-src 'self' https://kondius.cn https://o.alicdn.com"),
            "style-src 'self' 'unsafe-inline'",
            "img-src 'self' data: blob: http: https:",
            "media-src 'self' data: blob:",
            "connect-src 'self' https://kondius.cn",
            "font-src 'self' data:",
            // ⚠️ 'self' 不能省（2026-10-18）：插件自带页面（表情库 viewer.html 等）
            //    是同源 http://127.0.0.1:port/plugin-panel/... 的 iframe，只写 https:
            //    会让「查看收藏的表情」等入口直接 ERR_BLOCKED_BY_CSP。
            //    与 ui/index.html 的 meta 版本必须逐条一致（双份 CSP 取交集）。
            "frame-src 'self' https:",
            "object-src 'none'",
            "base-uri 'none'",
            "form-action 'none'",
            "frame-ancestors 'none'"
          ].join('; ');
          headers['x-content-type-options'] = 'nosniff';
          headers['referrer-policy'] = 'no-referrer';
        }
        res.writeHead(200, headers);
        res.end(data);
        return;
      } catch {
        res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
        res.end('Not Found');
        return;
      }
    }

    res.writeHead(404);
    res.end();
  }

  // ── 启停 ──
  // DSH 自动导入已移除：模型目录改为在设置页手动维护（见 /api/providers 相关接口）。

  // ── 启停 ──
  async function listenOn(port) {
    return new Promise((resolve, reject) => {
      server.once('error', reject);
      // R112：localhost 长连接下 Node 默认 keepAliveTimeout(5s) 比 Chromium 空闲
      // socket 复用窗口短 —— 服务端先关了 socket，渲染进程还拿它复用，触发
      // ERR_CONNECTION_RESET，前端表现为"Failed to fetch"（curl 是新连接不受影响）。
      // 这正是"长期运行后用量页/会话列表反复卡加载"的根因。把服务端保活时间抬到
      // Chromium 空闲超时之上，避免"服务端已关、客户端还在用"的半死 socket。
      server.keepAliveTimeout = 61000;
      server.headersTimeout = 65000;
      server.listen(port, '127.0.0.1', () => {
        server.off('error', reject);
        resolve(port); // 必须把实际端口传回去，Electron 壳要用它加载页面
      });
    });
  }

  async function start() {
    // ── 版本迁移（必须排在插件扫描之前）──────────────────────────────────
    // 为什么排第一：老用户升级后，旧版被删掉的插件目录可能还在（免安装覆盖路径
    // 只写新文件、不删旧文件），而 config.trustedPlugins 里指向它的引用也还在
    // —— 信任闸按目录名直接放行，残留插件就会照常加载、与新插件抢同名能力。
    // reloadSkills 读的正是这份 trustedPlugins，晚一步处理等于白做。
    // 同步、开销极小（几次 stat，最多写一次 config）；内部已逐项隔离失败。
    try {
      runUpgrades({ log });
    } catch (error) {
      log(`[upgrade] ⚠️ 迁移流程异常（不影响启动）：${error?.message ?? error}`);
    }

    // ── 启动顺序（2026-09-18 按耗时画像重排）────────────────────────────
    // 旧顺序的瓶颈：HTTP → 遥测 → Skill加载(串行import) → SnowLuma启动(最长20s等端口)
    //              → OneBot连接 → 就绪日志。Skill 与 SnowLuma 互不依赖却串行，
    //              白白把两段等待加在一起。
    // 新顺序：HTTP（页面先活）→ 遥测(纯后台) → **Skill 与 SnowLuma 并行** →
    //         OneBot 连接 → 就绪。会话索引的磁盘对账（reconcileInBackground）
    //         在 HTTP 起来后就排上，不占启动关键路径。
    const basePort = Number(getConfig().server?.port) || 3210;
    let port = null;
    let lastError = null;
    for (let p = basePort; p < basePort + 10; p++) {
      try {
        port = await listenOn(p);
        break;
      } catch (error) {
        lastError = error;
        if (error?.code !== 'EADDRINUSE') throw error;
      }
    }
    if (port == null) throw lastError ?? new Error('无法监听端口');

    // 实际端口落盘（收包人报告 P4）：多安装并存时 basePort 起步逐个 +10 试听，
    // 实际端口往往 ≠ config.server.port（配置里写 3210、实际在 3211）——
    // 外部脚本/运维无从得知。写到 <DATA_DIR>/console-port（一行数字），
    // 每次启动覆盖；故意**不**在退出时删除 —— 应用没起时脚本还能读到
    // "上次端口"作为猜测起点，比没有强。
    try {
      fs.writeFileSync(path.join(DATA_DIR, 'console-port'), String(port), 'utf8');
      log(`[api] 控制台实际端口 ${port} 已写入 ${path.join(DATA_DIR, 'console-port')}`);
    } catch (e) { log(`[api] ⚠️ 端口落盘失败（不影响使用）：${e?.message ?? e}`); }

    // 匿名用量遥测：启动 90 秒后发第一次，之后每 6 小时一次；失败静默不影响使用
    startTelemetryLoop(log);

    // 会话索引后台对账：启动读的是毫秒级缓存，这里异步补扫磁盘修正差异
    // （缓存缺失的新文件/外部删除的文件）。不 await —— 不挡任何启动步骤。
    sessions.reconcileInBackground();

    // 用量档案预热：首次打开用量页的卡顿来自"冷 parse 全部会话文件"
    //（2290 个 / 178MB 实测 1.3~1.9 秒）。启动后台先预热一次（collectUsageRows
    // 内部分片让步，不阻塞事件循环），用户点开用量页时档案已就绪，
    // 只剩窗口过滤（毫秒级）。不 await；失败静默（用量页会自己再算）。
    collectUsageRows({ range: '7' }).catch(() => {});

    // ── Skill 加载 与 SnowLuma 拉起并行（互不依赖）──
    const skillsReady = (async () => {
      try {
        const pluginResult = await reloadSkills({ reason: 'boot' });
        const okCount = pluginResult.loaded.length;
        const failCount = pluginResult.failed.length;
        if (okCount > 0) log(`[skill] 已加载 ${okCount} 个 Skill`);
        for (const f of pluginResult.failed) {
          log(`[skill] ❌ ${f.id || '(未知)'}：${f.error}`);
        }
        if (failCount > 0) log(`[skill] ${failCount} 个 Skill 加载失败`);

        const toolCount = orchestrator.refreshToolDefs();
        log(`[skill] 工具集已刷新：${toolCount} 个工具`);

        // 热重载日志：reloadSkills({reason:'boot'}) 里已经把 watcher 建好了
        // （默认开 config.extensions.hotReload，QQ_AGENT_DEV=1 可强制打开）
        if (pluginWatcher) {
          // 明确告知"落地的代码会被执行"，让用户知道这个行为的边界
          log('[skill] 热重载已启用：放入 plugins/ 或 skills/ 的目录会自动加载并执行'
            + '（要关闭请设 config.extensions.hotReload=false）');
        } else {
          log('[skill] 热重载未启用（config.extensions.hotReload=false）：改动后需重启');
        }
      } catch (error) {
        log('[skill] 加载失败:', error?.message ?? error);
      }
    })();

    const snowlumaReady = (async () => {
      if (!getConfig().snowluma?.autoLaunch) return;
      try {
        // 等待就绪用 WebUI 端口（进程即起即听）；OneBot WS 端口要等账号登录，
        // 在这里等 3001 是"永远等不到"的（没人扫码就一直挂着 20 秒）。
        const webuiPort = snowlumaWebuiPort();
        if (!(await isPortOpen('127.0.0.1', webuiPort))) {
          const r = await launchSnowluma();
          if (r.ok && r.launched) {
            for (let i = 0; i < 20 && !(await isPortOpen('127.0.0.1', webuiPort)); i++) {
              await new Promise((resolve) => setTimeout(resolve, 1000));
            }
          }
        } else {
          // ⚠️（2026-10-17 · N5）雪茹已在跑 —— 很可能是用户自己双击启动的。
          // 从前这里什么都不做，直接往下排期注入；而用户启的雪茹用的是它自己的
          // 初始密码 → 登录恒失败 → 自动注入只报一句「密码不被认可」，
          // 用户不知道该点「重置并接管」。补一次只读体检，把原因和动作说清楚。
          await diagnoseWebuiAuth('启动检查：SnowLuma 已在运行，');
        }
        // 2026-10-15：无论本次是「刚拉起」还是「本来就在跑」，都自动打开一次控制台
        // （launchSnowluma 内已对"刚拉起"调用过，这里用 snowlumaConsoleAutoOpened 去重）；
        // 同时排期精准注入机器人 QQ（snowlumaInjectRunning / 退避去重）。
        scheduleAutoOpenSnowlumaConsole();
        scheduleAutoInjectBotQq();
      } catch (error) {
        log('[snowluma] 自动启动/打开控制台失败:', error?.message ?? error);
      }
    })();

    // R81（BUG-10 轻量版）：出窗不再死等 SnowLuma。
    // 原实现在这里 await Promise.all([skillsReady, snowlumaReady]) 才返回，
    // 而 main.js 是 core.start() 完成后才 createWindow —— SnowLuma 冷启动
    // 最坏约 20 秒（snowlumaReady 里 20×1s 的端口轮询），这段时间用户连
    // 窗口都没有（群友反馈"双击没反应 / 打不开"）。SnowLuma 就绪只影响
    // OneBot 首连，而首连失败有现成的双兜底：connectLoop 退避重试 +
    // 下面 2 秒一次的端口就绪轮询（端口一通立即 reconnect）。所以这里只
    // 给它 5 秒宽限：到点继续启动，连接恢复交给轮询。snowlumaReady 的
    // launch 不取消（继续在后台跑完），只是不再挡启动关键路径。
    const SNOWLUMA_GRACE_MS = 5000;
    const SKILL_GRACE_MS = 5000;
    let graceTimer = null;
    let skillGraceTimer = null;
    const boundedSkillsReady = Promise.race([
      skillsReady,
      new Promise((resolve) => {
        skillGraceTimer = setTimeout(() => {
          log(`[skill] 初始化超过 ${SKILL_GRACE_MS / 1000} 秒，先继续打开控制台；插件加载仍在后台等待。`);
          resolve('skills-grace-timeout');
        }, SKILL_GRACE_MS);
      }),
    ]);
    await Promise.all([
      boundedSkillsReady,
      Promise.race([
        snowlumaReady,
        new Promise((resolve) => {
          graceTimer = setTimeout(() => resolve('snowluma-grace-timeout'), SNOWLUMA_GRACE_MS);
        }),
      ]),
    ]);
    if (graceTimer) clearTimeout(graceTimer);
    if (skillGraceTimer) clearTimeout(skillGraceTimer);

    // OneBot 连接前先尝试从 SnowLuma 配置同步令牌（脱敏副本/首次登录场景尤其重要）
    if (syncSnowlumaTokens()) {
      const c = getConfig();
      onebot.wsUrl = String(c.snowluma?.wsUrl || onebot.wsUrl);
      onebot.httpUrl = String(c.snowluma?.httpUrl || onebot.httpUrl).replace(/\/+$/, '');
      // accessToken/httpToken 已由 applyTokens 直接挂到实例（候选[0]）
    }
    await onebot.connect();

    // ── OneBot 端口就绪轮询（2026-09-19）────────────────────────────────────
    // WS 3001 只有「QQ 登录 → Hook 检出 → OneBot 实例拉起」后才监听。常见时序：
    // QQ Agent 先启动（此时 3001 未开）→ connectLoop 吃 ECONNREFUSED → 退避
    // 涨到 30 秒 → 用户在这中间扫码登录 → 3001 开了，但下一次重试可能还要等
    // 二十多秒，用户看到的就是"登录了半天连不上 / 重启就好了"。
    // 这里加一个主动轮询：每 2 秒探一次 WS 端口，端口一开立即触发重连（走
    // connectLoop 的代际互斥，不会产生并发连接）。已连接后轮询自动停止；
    // 断线（SnowLuma 重启等）时轮询自动恢复 —— 恢复延迟从"最多 30 秒"降到
    // "最多 2 秒 + 一次连接建立"。
    const obWsPort = snowlumaWsPort();
    // r92（R78-3）：边沿触发。原实现端口开着就每 2 秒无条件 reconnect()，而
    // reconnect 会清零 onebot 的指数退避 —— 端口已开但连接失败（如 token 未
    // 就绪）时，3s→6s→12s→24s→30s 的退避完全失效，被钉死在 2 秒一轮，
    // SnowLuma 侧日志里全是永不收敛的 unauthorized 尝试。只在"关→开"的
    // 边沿触发一次重连，之后交给 onebot 自己的退避循环。
    let obPortWasOpen = false;
    // 2026-10-20（S4 补）：首轮探测只建立基线，不能当成"关→开"边沿。
    // 冷启动时进程已经是连接状态、obPortWasOpen 初值为 false，若不区分，
    // 第一次探测就会误判为"端口刚开"而白重连一次（还会清掉一次退避）。
    let obPortEdgePrimed = false;
    obPortPollTimer = setInterval(async () => {
      // 整段兜住异常（2026-10-17 加固）：这是个 async 定时器回调，里面抛出的异常
      // 没人 await → 变成 unhandledRejection。主进程那条兜底只记日志、**不退出**
      // （electron/main.js:243），所以一旦这里每 2 秒抛一次，用户看到的就是
      // "窗口还在、但什么都不工作"的半死状态，日志里刷满同一条。宁可单轮失败。
      try {
      // ── 2026-10-20（S4 修）：已连接时也要更新端口边沿状态 ─────────────────
      // 旧写法是 `if (onebot.connected) return;` —— obPortWasOpen 只在"未连接"
      // 分支里更新。若雪茹在一个轮询周期内快速重启（端口关→开），而 QQ Agent 的
      // socket 还没收到 close（TCP 半开，connected 仍为 true），这次边沿就被永久
      // 吞掉，只能等 onebot 自己的退避（最长 30 秒）或 TCP 超时 —— 与下面注释承诺的
      // "恢复延迟最多 2 秒"不符。connected 时顺手探一次端口，成本是一次本机 connect。
      if (onebot.connected) {
        const stillOpen = await isPortOpen('127.0.0.1', obWsPort);
        // 2026-10-20（S4 补）：只是"把状态记下来"还不够 —— 记下来不等于处理了。
        // 端口关过一次又开（雪茹重启 / 换端口前的短暂关闭），说明手里这条 socket
        // 连的已经是上一代进程，边沿必须在**这里**消费掉，否则要等 TCP 自己超时
        // 才发现断线。reconnect 内部有连接代际互斥（onebot.js:143），不会双连。
        if (obPortEdgePrimed && stillOpen && !obPortWasOpen) {
          syncSnowlumaTokens();
          onebot.reconnect();
          // 雪茹是新的了，之前注入的 Hook 也随之失效 → 补一次注入排期
          // （与下面"端口关→开"分支保持同一套处置）。
          scheduleAutoInjectBotQq({ force: true });
        }
        obPortWasOpen = stillOpen;
        obPortEdgePrimed = true;
        return;
      }
      // 注：曾经在这里做「selfId 自动学习 botQQ」，已移除（2026-10-15 三次调整）——
      // selfId 只是「当前占用 OneBot 端口的账号」，双号在线时会抓到个人号（实测
      // 个人号被学成了机器人）。botQQ 现在只有两个可靠来源：
      //   ① 用户在页面「注入目标」显式输入/点选；
      //   ② QQ Agent 自己启动的 QQ 注入成功后，把 probe-login 读到的 uin 记下来
      //     （见 scheduleAutoInjectBotQq 里的自动记住逻辑）。
      const open = await isPortOpen('127.0.0.1', obWsPort);
      obPortEdgePrimed = true;   // 未连接分支自己就在处理边沿，从此开始按边沿判定
      if (open && !obPortWasOpen && !onebot.connected) {
        // 端口从关到开：登录完成 / SnowLuma 就绪。先回读磁盘拉取最新 per-uin 令牌
        // （冷启动时令牌可能还没落盘，否则首连会拿空令牌撞一轮 401 再轮换）；
        // 再立即重连（reconnect 会重置退避，秒级恢复）。syncSnowlumaTokens 幂等，
        // 候选集没变时不改令牌，只走重连。
        syncSnowlumaTokens();
        onebot.reconnect();
        // 2026-10-17（报告5 M3）：端口"关→开"这条边沿顺带补一次自动注入排期。
        // 2026-10-17（A 修）补 force：用户刚扫码登录完，端口一开就该立刻注入，
        //   不该被上一轮的 60/120 秒常规退避白等两分钟。注意 force **绕不过**
        //   密码长退避（snowlumaInjectAuthAt 的检查在 force 之前），所以不会踩登录锁。
        //   真正的自愈主力是下面 start() 里的看门狗 —— 这条边沿只是让"刚登录"
        //   这个瞬间更快（秒级），不承担兜底职责（Hook 丢了连边沿都没有）。
        scheduleAutoInjectBotQq({ force: true });
      }
      obPortWasOpen = open;
      } catch (error) {
        try { log('[onebot] 端口轮询异常（已忽略，2 秒后继续）:', error?.message ?? error); } catch { /* ignore */ }
      }
    }, 2000);
    obPortPollTimer.unref?.();

    // ── 自动注入看门狗（2026-10-17 · A 修：成功后永不自愈）──────────────────
    // 为什么必须有一个**周期性**的东西，而不是再加一个"触发点"：
    //   雪茹重启后注入的 Hook 随之消失 → SnowLuma 根本不会去创建 OneBot 实例
    //   → WS 3001 **永远不再监听**。也就是说"端口关→开"这个边沿永远不会发生，
    //   任何基于边沿的补排期在这里都等于零。
    // 所以判据必须换成**结果**：OneBot 到底连着没有。断了就重来一轮，
    // 不管之前"成功过几次"（旧守卫正是因为这个才把机器人永久卡死）。
    // 20 秒一次极廉价：一次布尔判断，必要时一次 600ms 的端口探测。
    // 所有闸门（autoInject / injectCancelled / 运行中 / 常规退避 / 密码退避）
    // 都在 scheduleAutoInjectBotQq 里，看门狗只负责"该不该问一声"。
    slInjectWatchTimer = setInterval(slInjectWatchdogTick, 20_000);
    slInjectWatchTimer.unref?.();

    // ── WS 就绪后的账号信息兜底（2026-09-19）────────────────────────────────
    // SnowLuma 重启/换号后，QQ Agent 侧的 WS 可能先于 OneBot 实例完全就绪连上，
    // open 时的 get_login_info 失败 → selfInfo 恒空 → UI"检测不到账号"。
    // onebot.js 里已有 15 秒延迟补拉；这里再挂一道 45 秒后的终检：
    // 连着但仍没有 selfInfo 就强制补一次并广播状态（长期运行的兜底，幂等）。
    setTimeout(() => {
      if (!onebot.connected || onebot.selfInfo) return;
      onebot.call('get_login_info').then((info) => {
        if (info) {
          onebot.selfInfo = info;
          emit('onebot-status', { connected: true, everConnected: true, error: '' });
          log('[onebot] 账号信息延迟恢复成功');
        }
      }).catch(() => { /* 仍失败：连接层已尽力，UI 状态如实反映 */ });
    }, 45_000).unref?.();
    if (getConfig().proactive?.enabled) orchestrator.startProactiveLoop();
    orchestrator.startReminderLoop();   // 提醒（闹钟）调度：到点往群里发提醒
    log(`控制台已就绪：http://127.0.0.1:${port}`);

    // ── 用量档案后台预热（2026-09-22）────────────────────────────────────
    // 首次打开用量页要先把全部会话文件解析一遍（实测 170MB ≈ 3.1 秒）——
    // 启动后闲置时先付掉，用户点「今日」就不用等。延迟 8 秒避开启动高峰
    // （插件加载 / 价格表 / 遥测都挤在头几秒），解析本身分片让步不阻塞事件循环。
    const usageWarmTimer = setTimeout(() => {
      warmUsageArchive()
        .then((r) => { if (r) log(`[usage] 用量档案已后台预热（${r.files} 个会话，${r.ms}ms）`); })
        .catch((error) => log(`[usage] 后台预热失败（首次打开用量页时会现场重算）：${error?.message ?? error}`));
    }, 8000);
    usageWarmTimer.unref?.();

    // ── 数据盘空间巡检（2026-10-16 外部审查 #9）──────────────────────────
    // 应用本体原来没有任何磁盘满处理：写不进去时只会看到一串次级错误，真正的
    // "盘满了"反而不见。这里启动时查一次 + 每小时一次，水位过低就记警告/错误；
    // critical 档另由 image-cache.js 的 enabled() 停止写入（见 disk-space.js）。
    const diskCheck = () => {
      // 同步定时器回调**必须**自己兜异常（2026-10-17 加固）：这里抛出去没有任何
      // try/catch 能接住，直接变成 uncaughtException → 主进程弹窗后 app.exit(1)。
      // diskPressure() 内部要 statfs / 查盘，权限、卷被卸载、网络盘掉线都可能抛 ——
      // 「磁盘巡检失败」绝不该等于「整个程序退出」。
      try {
        const level = diskPressure();
        if (level === 'ok') return;
        const text = diskPressureText();
        if (level === 'critical') log(`[disk] 🔴 ${text} —— 已暂停图片缓存写入，请清理空间`);
        else log(`[disk] 🟡 ${text} —— 建议清理（图片缓存 TTL 3 天 + 总量闸 2GB）`);
      } catch (error) {
        // 同上：catch 里也不许再抛（log 失败 → 这里的抛出就是 uncaughtException）
        try { log(`[disk] 磁盘巡检异常（已忽略，不影响运行）: ${error?.message ?? error}`); } catch { /* ignore */ }
      }
    };
    diskCheck();
    // 注意：赋值给外层 let，不能用 const（会遮蔽，stop() 里的 clearInterval 永远清不到）
    diskPatrolTimer = setInterval(diskCheck, 60 * 60 * 1000);
    diskPatrolTimer.unref?.();
    log(`OneBot（SnowLuma）: ws=${getConfig().snowluma?.wsUrl} http=${getConfig().snowluma?.httpUrl}`);
    log(`模型: ${getConfig().api.model || '（未设置，请在设置里选择）'} @ ${getConfig().api.baseUrl}`);
    return port;
  }

  // ── Skill 重扫：UI「刷新」按钮的唯一后端入口 ──────────────────────────
  // 之前「刷新」只重读内存注册表（GET /api/skills），不碰磁盘 —— watcher 丢事件
  // （目录删除重建后 fs.watch 句柄失效、网络盘、杀毒软件）时，点多少次刷新都
  // 看不到新插件。这里把"重扫磁盘 + 激活 + 刷工具 + 重建 watcher"做成一个
  // 幂等函数，启动流程和手动重扫共用，行为完全一致。
  async function reloadSkills({ reason = 'manual', result: preloaded = null } = {}) {
    // r92：watcher 的 runReload 已经 loadPlugins 过一遍（它的 result 通过
    // onReload 传进来）—— 原实现这里无视入参再 loadPlugins 一遍，每个插件的
    // setup() 实跑两遍（import(url?t=) 两次）：日志洪水、插件副作用双跑
    // （计时器/计数/通知）、工具集反复重建导致系统提示重建 → 前缀缓存断裂 ×N。
    // 手动/接口入口没有预载结果，照常全量扫。
    const result = preloaded || await loadPlugins({ log });
    for (const st of skillManager.list()) {
      if (st.enabled && st.loaded) {
        try { skillManager.activate(st.id); } catch (error) { log(`[skill] 激活 ${st.id} 失败：${error?.message ?? error}`); }
      }
    }
    try { orchestrator.refreshToolDefs(); } catch { /* 刷新失败不影响主流程 */ }

    // watcher 自愈：fs.watch 监听的目录被删除再重建后收不到任何事件，
    // 这里关掉旧的重新建。热重载关闭时保持关闭（尊重用户配置）。
    const hotReloadOn = process.env.QQ_AGENT_DEV === '1'
      || getConfig().extensions?.hotReload !== false;
    try { pluginWatcher?.close?.(); } catch { /* ignore */ }
    pluginWatcher = null;
    if (hotReloadOn) {
      // r92：新 watcher 继承一段静默期 —— 原实现重建后 quietUntil=0，而重扫
      // 自己会 import/触碰 skill 目录里的文件，晚到的事件会立刻再触发一轮
      // 全量重扫（旧 watcher 花 2.5s 建的静默期随 close 一起作废）。
      pluginWatcher = watchPlugins({ log, quietMs: 2500, onReload: (r) => reloadSkills({ reason: 'watch', result: r }) });
    }

    if (reason !== 'boot') {
      log(`[skill] 重扫完成（${reason}）：${result.loaded.length} 成功，${result.failed.length} 失败`
        + (result.pruned?.length ? `，卸载 ${result.pruned.length} 个已删除的 Skill` : ''));
      emit('status', { configUpdated: true });
    }
    return result;
  }

  async function stop() {
    // 先停掉热重载 watcher：否则 stop() 之后文件变动仍会触发重载 + 广播
    try { pluginWatcher?.close?.(); } catch { /* ignore */ }
    pluginWatcher = null;
    // r92：退订本次 createApp 挂的日志监听器（见上方 onLog 注释）
    try { unsubscribeAppLog?.(); } catch { /* ignore */ }
    unsubscribeAppLog = null;
    await orchestrator.abortAll();
    orchestrator.stopReminderLoop();
    // 主动发言循环也要停（2026-09-26 补）：此前只停了 reminderLoop，
    // proactiveTimer 在 stop() 后仍会继续 tick，headless 下进程不死就一直调度。
    try { orchestrator.stopProactiveLoop(); } catch { /* ignore */ }
    // 回收全部 Skill 实例：插件自己的 setInterval/落盘定时器（health-system
    // 的状态衰减等）此前从不 dispose —— 句柄泄漏 + 退出窗口可能写坏数据文件。
    try { skillManager.disposeAll({ reason: 'shutdown' }); } catch { /* ignore */ }
    if (communitySyncTimer) clearInterval(communitySyncTimer);
    try { cacheWarm?.stop?.(); } catch { /* ignore */ }
    if (obPortPollTimer) clearInterval(obPortPollTimer);
    // 注入看门狗必须一起停：headless 场景下 stop() 之后进程可能还活着，
    // 它会继续每 20 秒去拉 SnowLuma / 触发注入（对已关闭的实例做无意义的事）。
    if (slInjectWatchTimer) { clearInterval(slInjectWatchTimer); slInjectWatchTimer = null; }
    if (diskPatrolTimer) clearInterval(diskPatrolTimer);
    // 退出前停掉遥测与价格表轮询（2026-09-25 补）：headless 模式 stop() 后进程若
    // 继续存活，这两个定时器会照常发起网络请求。
    try { stopTelemetryLoop(); } catch { /* ignore */ }
    try { stopPriceFeed(); } catch { /* ignore */ }
    // 索引缓存立刻落盘：正常运行中靠防抖（5s），退出前必须写一次，
    // 否则最后的会话变动丢失、下次启动要靠后台对账补（慢路径）
    sessions.flushIndexCache();
    // 消息存档的延迟落盘也要立刻兑现（报告3 M5）：saveChat 现在按会话节流 300ms，
    // 退出前不 flush 就会丢掉"刚看到消息就关程序"那最后几百毫秒的聊天记录。
    try { store.flushPendingSaves(); } catch { /* 退出路径上不再抛 */ }
    // 关闭所有 SSE 长连接，避免 server.close() 一直等它们
    for (const c of [...sseClients]) {
      try { c.end(); } catch { /* ignore */ }
    }
    sseClients.clear();
    onebot.close();
    server.close();
    // 内置启动的 SnowLuma：QQ Agent 退出时一并关掉，避免留一个无窗口的后台进程。
    // 注意：SnowLuma 退出时不一定能立刻把 config 落盘，但我们的 stop 不会再去读它，
    // 下次启动会读到完整文件。
    try { snowlumaProc?.kill(); } catch { /* ignore */ }
    // 便携 QQ：默认保留运行（避免误杀用户登录态），如需清理可在 UI 手动关闭
    // try { await stopPortableQQ(); } catch { /* ignore */ }
    // 释放单实例锁（下次启动才能再抢到）
    releaseInstanceLock();
  }

  return {
    server, onebot, store, memory, sender, sessions, orchestrator, start, stop, emit, getConfig, updateConfig, getRendererAuthToken: () => rendererAuthToken, launchSnowluma, stopSnowluma, snowlumaStatus, launchPortableQQ, stopPortableQQ, qqPortableStatus, reloadSkills,
    scheduleAutoInjectBotQq,
    // ── 离线验证钩子（2026-10-17 · A 修）──────────────────────────────────
    // 让 `_luofix/t-verify-inject-selfheal.mjs` 能在几秒内驱动"成功之后
    // Hook 丢失 → 是否自愈"这条链，而不用真等 20 秒的定时器 + 60 秒退避。
    // 生产路径不读这三个成员，纯观察/驱动，不改任何持久状态。
    __testInjectWatchdogTick: slInjectWatchdogTick,
    // 2026-10-20：这两个是纯转发，只为让"目标不存在时配置不许被写脏"（P2）、
    // "取消注入的早退分支也要落暂停标记"（P3）、"复查失败不等于切换失败"（P6）
    // 能离线验证。生产路径不读它们，也不改变任何行为。
    __testSnowlumaSwitchBot: snowlumaSwitchBot,
    __testSnowlumaUnloadBot: snowlumaUnloadBot,
    __testSnowlumaResume: snowlumaResumeInject,
    __testInjectState: () => ({
      running: snowlumaInjectRunning,
      nextInMs: Math.max(0, snowlumaInjectNextAt - Date.now()),
      authHoldInMs: Math.max(0, snowlumaInjectAuthAt - Date.now())
    }),
    __testClearInjectBackoff: () => {
      snowlumaInjectRunning = false;
      snowlumaInjectNextAt = 0;
      snowlumaInjectAuthAt = 0;
    },
    // 单独"把用户动作冷却拨快"：让测试能分别验证"冷却窗"和"密码退避"两道闸，
    // 而不是一清全清（那样就分不清是哪一道在起作用了）。
    __testAgeUserAction: () => { snowlumaUserActionAt = 0; }
  };
}

/**
 * 成本看板数据：按天 / 按会话 / 按群聚合最近 N 天的用量。
 *
 * 数据源是 data/sessions/*.json（会话留档），每个会话对象里已有
 * usage.{promptTokens, completionTokens, cachedTokens} 与 chatKey / model / rounds。
 * 没有历史汇总文件也能算 —— 直接扫留档即可。
 */
/**
 * 解析时间范围参数。
 *   'today' → 今天 00:00 起
 *   '24h'   → 最近 24 小时（滚动窗口，可能跨天）
 *   '3'|'7'|'14'|'30' → 最近 N 个自然日
 */
function resolveRange(raw) {
  const s = String(raw || '7').trim().toLowerCase();
  const now = Date.now();
  if (s === 'today') {
    const d = new Date(now);
    d.setHours(0, 0, 0, 0);
    return { mode: 'today', start: d.getTime(), end: now, label: '今天' };
  }
  if (s === '24h') {
    return { mode: '24h', start: now - 24 * 60 * 60 * 1000, end: now, label: '最近 24 小时' };
  }
  // 前端"全部"按钮：不设起始时间。曾经静默回落"近 7 天"（Number('all')||7），
  // 用户以为在看全量历史实际被截断 —— 与"求和一致"的产品口径冲突。
  if (s === 'all') {
    return { mode: 'all', start: 0, end: now, label: '全部' };
  }
  const n = Math.min(30, Math.max(1, Number(s) || 7));
  // 按自然日：从 N-1 天前的 0 点算起，保证"7 天"是 7 个完整日历日
  const d = new Date(now);
  d.setHours(0, 0, 0, 0);
  return { mode: 'days', start: d.getTime() - (n - 1) * 24 * 60 * 60 * 1000, end: now, label: `最近 ${n} 天` };
}

/** 本地时区的 YYYY-MM-DD（用于按天分桶）。 */
function dayKeyOf(ts) {
  const d = new Date(Number(ts) || 0);
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

/**
 * 收集时间窗内的所有"调用行"。
 * 每行是一次真实 API 调用（有 raw 时）或一次会话聚合（无 raw 时），
 * 都带自己的 token、发生时刻、模型、所属会话。
 */
// ── 用量行缓存 ──
// collectUsageRows 要遍历并 JSON.parse 全部会话文件。实测 300 个文件 / 25MB 时
// 单次约 200ms，而前端每 15 秒轮询一次、stats 与 breakdown 还各扫一遍。
// 会话文件是"结束写一次、之后不再改"，所以缓存很安全。
//
// 失效策略（双保险，任一条命中就重算）：
//   1. 目录快照变化：文件数或目录 mtime 变了（新增/删除会话）
//   2. TTL 到期：20 秒。兜住"内容被改写但目录快照不变"这类边缘情况。
//      原来是 5 秒，但轮询间隔 4 秒、用户切页签的时机又很随机，
//      导致切过去时缓存经常刚好过期 → 每次都走 200ms 的冷启动（"黑一下"）。
//      用量统计不是实时数据，20 秒的新鲜度完全够用。
//      另外前端还有一层：切过去先用上次数据立即渲染，不等网络。
//
// ⚠️ 数据量增长后的实测（2026-09-17，真实部署 2144 个会话 / 172MB）：
//    全量 parse 需要 ~1.9s —— 20 秒 TTL 到期后的每次重算都会把主进程
//    event loop 阻塞近 2 秒，期间 HTTP/SSE/消息处理全部排队 —— 前端表现
//    就是"用量页卡住、整个控制台无响应"。两条治理（同步进 collectUsageRows）：
//    A. **增量解析**：目录快照没变时复用上一轮解析结果（不只 TTL 内 ——
//       sig 相同就复用，只是重做时间窗过滤与派生字段），冷启动只在
//       真有新会话落盘时才发生。TTL 仍然保留，兜"内容被改写"的边缘情况。
//    B. **流式分片解析**：真要冷启动时，把 172MB 的同步 parse 拆成
//       每 50 个文件一让步（setImmediate）的异步流水线 —— 单次让步前的
//       阻塞 <100ms，消息处理/界面请求不再被长阻塞。
//      会话文件"结束写一次、之后不改"的语义不变，A 的复用与原缓存同样安全。
const usageRowsCache = { key: '', at: 0, rows: null, win: null };
const USAGE_CACHE_TTL_MS = 20000;
// 已解析会话的档案（增量解析的持久层）：sig（目录快照）→ 每会话的展开行/计数。
// 与 usageRowsCache 的区别：后者是"某个时间窗的最终 rows"，前者是
// "全部会话的原始素材" —— 换 range 时不必重新读盘。
const usageArchive = { sig: '', at: 0, sessions: null };   // sessions: Map(file -> {rows[], searchCount, toolCounts})
// 让步前最多同步解析的文件数（B 方案的切片粒度）
const USAGE_PARSE_CHUNK = 50;
// 让步前最多同步 stat 的文件数（档案命中时只剩 stat，粒度可以粗一些）
const USAGE_STAT_CHUNK = 400;

/** 目录快照：文件数 + 目录 mtime。成本低（一次 stat），足以捕捉增删。 */
function sessionsDirSignature() {
  const dir = path.join(DATA_DIR, 'sessions');
  try {
    const files = fs.readdirSync(dir).filter((f) => f.endsWith('.json'));
    const st = fs.statSync(dir);
    return files.length + ':' + st.mtimeMs + ':' + files.reduce((a, f) => a + f.length, 0);
  } catch {
    return '';
  }
}

/**
 * 读盘解析单个会话文件 → { rows, searchCount, toolCounts, started }。
 * 纯函数（不含时间窗过滤）：窗口过滤在 collectUsageRows 里做 —— 这样
 * 换 range（今天/7天/全部）时可以完全复用这份解析结果。
 */
function parseUsageSessionFile(dir, f) {
  const out = { rows: [], searchCount: 0, toolCounts: Object.create(null), started: 0, mtime: 0, size: -1 };
  try {
    const fp = path.join(dir, f);
    const st = fs.statSync(fp);
    out.mtime = st.mtimeMs;
    // size 与 mtime 一起当"这个文件没变过"的判据：NTFS 的 mtime 粒度是 100ns，
    // 单独用 mtime 已经够稳；多存一个 size 是白送的保险（同一个 mtime 刻度内
    // 被改写且长度恰好相同 —— 概率极低但不是零）。
    out.size = st.size;
    const s = JSON.parse(fs.readFileSync(fp, 'utf8'));
    const started = Number(s.startedAt) || 0;
    out.started = started;
    if (!started) return out;
    out.searchCount = Number(s.webSearchCount) || 0;
    // 逐次调用展开：每条 message.raw 有独立的 usage / created / model
    const exactRows = [];
    for (const m of (s.messages || [])) {
      const name = m && m.toolCall && m.toolCall.name;
      if (name) out.toolCounts[String(name)] = (out.toolCounts[String(name)] || 0) + 1;
      const raw = m?.raw;
      if (!raw || typeof raw !== 'object') continue;
      const ru = raw.usage || {};
      const rp = Number(ru.prompt_tokens) || 0;
      const rc = Number(ru.completion_tokens) || 0;
      if (!rp && !rc) continue;
      const at = Number(raw.created) ? Number(raw.created) * 1000 : started;
      exactRows.push({
        promptTokens: rp,
        completionTokens: rc,
        cachedTokens: Number(ru.prompt_tokens_details?.cached_tokens) || 0,
        at,
        model: String(raw.model || s.model || '') || '(未知)'
      });
    }
    if (exactRows.length) {
      for (const c of exactRows) {
        out.rows.push({ ...c, vendor: String(s.vendor || ''), chatKey: String(s.chatKey || '(未知)'), sessionId: s.id, exact: true });
      }
    } else {
      const u = s.usage || {};
      const p = Number(u.promptTokens) || 0;
      const c = Number(u.completionTokens) || 0;
      if (p || c) {
        out.rows.push({
          promptTokens: p,
          completionTokens: c,
          cachedTokens: Number(u.cachedTokens) || 0,
          at: started,
          model: String(s.model || '') || '(未知)',
          chatKey: String(s.chatKey || '(未知)'),
          vendor: String(s.vendor || ''),
          sessionId: s.id,
          exact: false
        });
      }
    }
  } catch { /* 坏文件跳过（与旧行为一致） */ }
  return out;
}

/**
 * （异步）刷新"已解析档案"到当前目录快照。
 * 只重读**变化过的文件**（新文件 + mtime/size 变了的文件），其余复用 ——
 * 2144 个文件只有几个新增时，重读量从 172MB 降到几 MB。
 * 解析按 USAGE_PARSE_CHUNK 分片、片间 setImmediate 让步，不长阻塞事件循环。
 *
 * ⚠️ 2026-09-22 修：这里曾经有一行"前置复用条件"，只有目录签名前两段
 *    （文件数 : 目录 mtime）完全一致才肯以旧档案为底，否则 `prev = new Map()`
 *    —— 于是**每落一个新会话文件就把已解析的整份档案全部丢弃、全量重解析**。
 *    机器人正常运行时新会话每几分钟落一个，等于这个增量缓存从未生效过。
 *    实测（800 文件 / 121MB 合成数据）：增量解析 5ms，被整体丢弃后 2157ms，
 *    而用量页"点今日"走的正是这条路径 —— 这就是"加载非常久"的直接原因。
 *
 *    那行条件本来是想兜"目录被换掉/清空"的场景，但下面**逐文件**比对
 *    (mtime, size) 已经覆盖了它：文件被删就不在 files 列表里、被改写则
 *    mtime/size 必变。所以现在无条件以现有档案为底，稳定性由逐文件判据保证。
 */
async function refreshUsageArchive(dir, files, sig) {
  // ⚠️ 这里**故意不做** "sig 相同就直接返回" 的短路（2026-09-22 实测踩到）：
  //    sessionsDirSignature 只是「文件数 : 目录 mtime : 文件名总长」，
  //    而会话文件是**原地改写**的（会话跑完 #persist 落盘、运行中节流保存），
  //    NTFS 下改写文件内容不会动父目录的 mtime —— 于是"内容变了但签名没变"
  //    会让档案一直沿用旧的解析结果。实测：把一个会话从 4 次调用改写成 40 次，
  //    档案里仍然是 4 —— 而且只要目录没有增删文件，这个错值就**永远**不修正。
  //    多付的代价只是一次"每文件一次 stat"的扫描（1200 文件 ≈ 5ms）；
  //    真正省钱的判据是下面逐文件的 (mtime, size) 比对，那是零读盘的。
  const prev = usageArchive.sessions || new Map();
  const next = new Map();
  for (let i = 0; i < files.length; i++) {
    const f = files[i];
    const old = prev.get(f);
    let st;
    try { st = fs.statSync(path.join(dir, f)); } catch { continue; }
    if (old && old.mtime === st.mtimeMs && old.size === st.size) {
      next.set(f, old);   // 文件没变：复用上次的解析结果（零读盘）
      // 纯 stat 的批次也可能很长（上万文件），同样分片让步
      if ((i + 1) % USAGE_STAT_CHUNK === 0) await new Promise((r) => setImmediate(r));
      continue;
    }
    next.set(f, parseUsageSessionFile(dir, f));
    // 分片让步：单文件最大 ~1MB，50 个一批的同步解析 < 100ms
    if ((i + 1) % USAGE_PARSE_CHUNK === 0) await new Promise((r) => setImmediate(r));
  }
  usageArchive.sessions = next;
  usageArchive.sig = sig;
  usageArchive.at = Date.now();
  return next;
}

/**
 * 后台预热用量档案（2026-09-22）。
 *
 * 用量统计的第一道工序是把全部会话文件 JSON.parse 一遍（实测 1200 文件 /
 * 170MB ≈ 3.1 秒）。不预热的话，**每次启动后第一次打开用量页都要等这 3 秒**，
 * 用户看到的就是"点今日加载非常久"—— 而这 3 秒完全可以在启动后闲置时先付掉。
 *
 * 由 start() 在启动 8 秒后调用：那时插件加载、价格表、遥测都已就位，档案解析
 * 又是分片让步的，不会长阻塞事件循环。没有任何会话文件（全新安装）直接跳过。
 *
 * @returns {Promise<{files:number, ms:number}|null>}
 */
async function warmUsageArchive() {
  const dir = path.join(DATA_DIR, 'sessions');
  let files = [];
  try { files = fs.readdirSync(dir).filter((f) => f.endsWith('.json')); } catch { return null; }
  if (!files.length) return null;
  const t0 = Date.now();
  const archive = await refreshUsageArchive(dir, files, sessionsDirSignature());
  return { files: archive.size, ms: Date.now() - t0 };
}

/**
 * 历史文件指纹：只统计"已完结"的会话文件（最后写盘时刻早于今天 0 点）。
 *
 * 为什么日快照判据不用目录签名（sessionsDirSignature）：目录签名含目录 mtime，
 * 机器人每结束一个新会话就落一个新文件 → 签名必变。旧判据下签名一变，
 * **全部历史日快照同时失效** → 每次统计把窗口内每一天从档案全量重算
 * （每天遍历全部会话行 + 逐行计价，同步无让步），数据量大时事件循环被
 * 阻塞数秒、所有接口排队 —— 长期使用后"用量页卡死在加载界面"的根因。
 *
 * 而已完结文件（会话写完一次后不再改写）的集合对历史日是稳定的：
 * 新增会话只影响"今天"（今天永远实时聚合、不进快照）。指纹不变 →
 * 历史快照持续有效；清理/删除旧会话文件会改变指纹 → 相关快照正确失效。
 * 每天 0 点跨越会让指纹变一次（昨天写完的文件被纳入）→ 一天仅重算一次。
 *
 * 指纹从已解析档案派生（每文件 mtime 在 refreshUsageArchive 时已 stat），
 * 零额外 IO。格式带 h: 前缀，与旧目录签名天然不同 —— 旧快照首次统计时
 * 自动失效重算一遍，随即迁移成新格式，无需专门迁移代码。
 */
function historySignatureOf(archive, todayStartMs) {
  let count = 0, mtimeSum = 0;
  for (const parsed of archive.values()) {
    if (!parsed || !parsed.mtime || parsed.mtime >= todayStartMs) continue;
    count++;
    mtimeSum += parsed.mtime;
  }
  // ⚠️（2026-10-17）h: → h2: 是一次性快照作废：账本补差修好之后
  // （"已知覆盖"不再拿账本总量顶数、补差改按会话粒度生成），旧快照的
  // 口径与新算法不同。改前缀让全部历史日按新算法重算一遍，随后迁移成
  // 新格式；算不出数据的日子会走"保留旧值 + 对齐新签名"的自愈路径，
  // 不会把仅存的快照抹成 0。
  return `h2:${count}:${mtimeSum}`;
}

async function collectUsageRows({ range }) {
  const win = resolveRange(range);
  // 命中缓存就直接返回（注意 rows 会被调用方改写字段，所以必须给副本）
  const sig = sessionsDirSignature() + '@' + String(range);
  if (usageRowsCache.rows && usageRowsCache.key === sig
      && (Date.now() - usageRowsCache.at) < USAGE_CACHE_TTL_MS) {
    return {
      // 深拷贝：曾经 slice() 只是浅拷贝，调用方往行对象上写字段（如 dayKey）
      // 会写穿到缓存对象；当前写入恰好幂等无害，但承诺的"防污染"并不成立
      rows: usageRowsCache.rows.map((r) => ({ ...r })),
      win: win || usageRowsCache.win,
      searchCount: usageRowsCache.searchCount || 0,
      toolCounts: { ...(usageRowsCache.toolCounts || {}) }
    };
  }

  const dir = path.join(DATA_DIR, 'sessions');
  let files = [];
  try { files = fs.readdirSync(dir).filter((f) => f.endsWith('.json')); } catch { return { rows: [], win, searchCount: 0, toolCounts: {} }; }

  // ── 数据量治理（2026-09-17，见"用量行缓存"注释的 A/B 方案）──
  // 档案层增量解析 + 分片让步；时间窗过滤只对窗口内的素材做。
  const archive = await refreshUsageArchive(dir, files, sig.split('@')[0]);

  const rows = [];
  // 会话级计数：搜索次数、各工具的调用次数。
  // 注意这些是"次数"不是"成本"：搜索通常是资源包或免费的，
  // 所以只列数量、绝不参与成本计算（用户明确要求）。
  let searchCount = 0;
  const toolCounts = Object.create(null);

  for (const f of files) {
    const parsed = archive.get(f);
    if (!parsed || !parsed.started) continue;
    // 这个会话是否落在时间窗口内（工具/搜索计数按会话归属，没有独立时间戳）
    if (parsed.started >= win.start && parsed.started <= win.end) {
      searchCount += parsed.searchCount || 0;
      for (const [name, n] of Object.entries(parsed.toolCounts)) {
        toolCounts[name] = (toolCounts[name] || 0) + n;
      }
    }
    // 逐次调用行：窗口内才收进 rows（行自带 at，可精确到调用时刻）
    for (const r of parsed.rows) {
      if (r.at < win.start || r.at > win.end) continue;
      rows.push(r);
    }
  }

  // ── 账本兜底：补回被 keepFiles 裁掉的会话的用量 ──────────────────
  //
  // 会话文件是可裁剪的（config.json 的 store.keepSessionFiles，默认 120），
  // 文件一删，它携带的用量就再也读不到了 —— 统计会被冻结在"最近 N 个会话"上，
  // 用户看到的现象是"今日 200 次运行，页面只算 120 次"。
  //
  // 补差分两层，全部以**按会话 id 去重**为前提：
  //   ① 逐会话补行：账本里"文件已不在"的会话，每条转一行统计行
  //      （带 chatKey/model/vendor/calls，见 ledgerSessionRow）——
  //      按会话、按模型、调用次数、成本全部恢复；
  //   ② 按天聚合补差：① 之后与权威真值（账本 / 跨天归档 / usage-today.json
  //      逐字段取最大，见 authoritativeGapForDay）仍有差距的
  //      （账本漏记、账本建立之前的日子），再补一条聚合行。
  {
    const onDiskIds = new Set(files.map((f) => f.replace(/\.json$/, '')));
    const ledgerDayInWin = (dayKey) => {
      const d0 = new Date(`${dayKey}T00:00:00`);
      if (isNaN(d0.getTime())) return false;
      const d1 = new Date(d0.getTime());
      d1.setDate(d1.getDate() + 1);
      return d1.getTime() - 1 >= win.start && d0.getTime() <= win.end;
    };
    // ① 逐会话补行（被裁掉的会话）
    for (const dayKey of listUsageLedgerDays()) {
      if (!ledgerDayInWin(dayKey)) continue;
      for (const rec of usageLedgerPrunedRecords(dayKey, onDiskIds)) {
        rows.push(ledgerSessionRow(rec));
      }
    }
    // 已进 rows 的覆盖量（按天；runs 按去重后的会话数计 —— 真值侧的
    // runs 是会话数，两边必须同口径，否则次数补差永远算不平）
    const coveredByDay = new Map();
    const seenSessions = new Set();
    for (const r of rows) {
      const day = ledgerDayKey(r.at);
      const cur = coveredByDay.get(day) || { promptTokens: 0, completionTokens: 0, cachedTokens: 0, webSearchCount: 0, runs: 0 };
      cur.promptTokens += Number(r.promptTokens) || 0;
      cur.completionTokens += Number(r.completionTokens) || 0;
      cur.cachedTokens += Number(r.cachedTokens) || 0;
      const sk = `${day}|${String(r.sessionId || '')}`;
      if (r.sessionId && !seenSessions.has(sk)) { seenSessions.add(sk); cur.runs += 1; }
      coveredByDay.set(day, cur);
    }
    // 搜索次数是会话级计数（没有独立时间戳，按会话归属），单独按天记一份
    for (const f of files) {
      const parsed = archive.get(f);
      if (!parsed || !parsed.started) continue;
      if (parsed.started < win.start || parsed.started > win.end) continue;
      const day = ledgerDayKey(parsed.started);
      const cur = coveredByDay.get(day) || { promptTokens: 0, completionTokens: 0, cachedTokens: 0, webSearchCount: 0, runs: 0 };
      cur.webSearchCount += parsed.searchCount || 0;
      coveredByDay.set(day, cur);
    }
    // ② 按天聚合补差（① 之后仍对不上账的部分）
    const { days: ledgerByDay } = usageLedgerTotals(ledgerDayInWin);
    const doneDays = new Set();
    // 归档日也要进循环：账本是从"启用那一天"起记的，更早的跨天归档只存在于
    // usage-archived-days.json 里 —— 只遍历账本的日就等于永远看不到它们。
    for (const dayKey of new Set([...ledgerByDay.keys(), ...Object.keys(loadArchivedUsageDays())])) {
      if (!ledgerDayInWin(dayKey)) continue;
      const gap = authoritativeGapForDay(coveredByDay, ledgerByDay, dayKey);
      if (!gap) continue;
      rows.push(ledgerGapRow(dayKey, gap));
      searchCount += gap.webSearchCount;
      doneDays.add(dayKey);
    }
    // 账本日里**没有今天**时（账本刚建立、或跨天后第一段时间），当天权威值
    // 仍在 usage-today.json 里 —— 单独为它补一次，否则「今日」卡片会一直
    // 显示残缺值，而这正是用户报的"估算根本不更新"。
    {
      const todayFile = loadUsageTodayFile();
      if (todayFile && !doneDays.has(todayFile.dayKey) && ledgerDayInWin(todayFile.dayKey)) {
        const gap = authoritativeGapForDay(coveredByDay, new Map(), todayFile.dayKey);
        if (gap) {
          rows.push(ledgerGapRow(todayFile.dayKey, gap));
          searchCount += gap.webSearchCount;
        }
      }
    }
    // ②-b 工具调用计数补回（2026-10-19）
    //
    // 上面第一圈的 toolCounts 只来自**磁盘上还存在的**会话文件。keepSessionFiles
    // （默认 120）一裁，调用明细就只剩"最近 120 个会话"—— 实测 120 个文件只覆盖
    // 5 小时，弹窗却写"近 7 天共 157 次"，而单日账本里就有上千次调用。
    //
    // 账本自 2026-10-19 起记录 toolCounts，这里把"文件已不在磁盘上"的会话补回来，
    // 与上面 token 的补差（authoritativeGapForDay）同一口径：
    // 文件在的用文件（带逐次明细），文件不在的用账本（只有计数），两边不重叠。
    {
      const onDiskIds = new Set(files.map((f) => f.replace(/\.json$/, '')));
      for (const [dayKey, dayAgg] of ledgerByDay) {
        if (!ledgerDayInWin(dayKey)) continue;
        // 快路径：该日账本里一条工具计数都没有（全是改造前的老行）→ 直接跳过，
        // 免得为了"补 0 条"去读一遍整天的账本文件。
        if (!dayAgg?.toolCounts || !Object.keys(dayAgg.toolCounts).length) continue;
        for (const rec of usageLedgerPrunedRecords(dayKey, onDiskIds)) {
          // 以日粒度判断窗口不够精确：同一天里跨窗口边界的会话要按 startedAt 再滤一次
          const st = Number(rec.startedAt) || Number(rec.endedAt) || 0;
          if (st && (st < win.start || st > win.end)) continue;
          const tc = rec.toolCounts;
          if (!tc || typeof tc !== 'object') continue;   // 老账本行没有这个字段
          for (const [name, n] of Object.entries(tc)) {
            const c = Number(n) || 0;
            if (c > 0) toolCounts[String(name)] = (toolCounts[String(name)] || 0) + c;
          }
        }
      }
    }
  }
  // 模型身份 = 渠道 + 模型 id。
  // 渠道取**会话自己记录的** vendor（创建会话时由当时的配置派生）。
  // 老会话没这个字段 → 标为「未知渠道」，绝不拿当前配置去倒推历史 ——
  // 用户很可能早就换过渠道了，猜出来的结果是错的。
  for (const r of rows) {
    r.vendor = String(r.vendor || '').trim() || UNKNOWN_VENDOR;
    r.modelKey = modelLabel(r.vendor, r.model);
  }
  // 写缓存：存的是"清洗完的 rows"，取用时给副本避免调用方污染
  // ⚠️ rows 里的对象来自档案层（可能被多个 range 的缓存共享引用）——
  //    上面 vendor/modelKey 的改写是幂等的，但调用方还会写 dayKey，
  //    所以缓存里也存一份浅拷贝行（同 range 复用时的防污染，与旧行为一致）。
  usageRowsCache.key = sig;
  usageRowsCache.at = Date.now();
  usageRowsCache.rows = rows.map((r) => ({ ...r }));
  usageRowsCache.win = win;
  usageRowsCache.searchCount = searchCount;
  usageRowsCache.toolCounts = { ...toolCounts };
  return { rows, win, searchCount, toolCounts };
}

// ── 按日快照（2026-09-19）──────────────────────────────────────────
//
// 问题：collectUsageRows 即使有档案层缓存，冷启动（2144 文件 / 172MB）仍要
// 全量流式解析；"今天之前的每一天"的数据是**不可变的**（会话结束写一次、
// 之后不改），每次打开用量页都从头统计它们是纯浪费。
//
// 方案：把"已完结自然日"（今天之前）的聚合结果固化到
// data/usage-daily.json。读取路径优先快照；只有快照缺失/失效的日才回退
// 到"从档案聚合"。写快照时机：每次统计完顺手补齐（异步、不阻塞响应）。
//
// 有效性判据：每条日快照带生成时的目录快照 sig。sig 没变 → 该日必然没
// 新增会话（会话文件不改写），直接用。sig 变了 → 重算该日（分片解析会
// 复用 mtime 相同的旧解析结果，增量代价很小）。"今天"永远不进快照。
//
// ⚠️ 成本口径：快照存 costOfRows 聚合结果。价格表（自定义价/远程价）变化
//    会让历史成本跟着变 —— 快照固定的是"生成当时的计价"。这是刻意取舍：
//    量级收益（秒→毫秒）远大于"改价后历史成本不联动"的小误差；想重算
//    任何一天，删掉快照文件对应条目即可。
const USAGE_DAILY_FILE = path.join(DATA_DIR, 'usage-daily.json');
// 跨天归档（sessions.js 的 #archiveDayUsage 写的**独立文件**）。
// ⚠️ 它与 usage-daily.json 是两回事，别混：usage-daily 存的是"按日聚合快照"，
//    这个存的是 usage-today.json 那个单槽文件在跨零点时被顶下来的**上一日权威总量**。
const USAGE_ARCHIVED_FILE = path.join(DATA_DIR, 'usage-archived-days.json');
const USAGE_DAILY_VERSION = 1;

function loadUsageDaily() {
  try {
    const parsed = JSON.parse(fs.readFileSync(USAGE_DAILY_FILE, 'utf8'));
    if (parsed?.version === USAGE_DAILY_VERSION && parsed.days && typeof parsed.days === 'object') {
      return parsed.days;
    }
  } catch { /* 无文件/坏文件 = 全部重算 */ }
  return {};
}

function saveUsageDaily(days) {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    const tmp = `${USAGE_DAILY_FILE}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify({ version: USAGE_DAILY_VERSION, savedAt: Date.now(), days }, null, 1), 'utf8');
    fs.renameSync(tmp, USAGE_DAILY_FILE);
  } catch { /* 快照写失败只是慢一点，绝不能影响统计主流程 */ }
}

/**
 * 已完结自然日列表：从窗口起点（或快照里最早的日）到昨天。
 * 今天永远实时算（数据还在长）。
 */
function completedDayKeys(fromTs) {
  const out = [];
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  // 昨天的 0 点（今天之前最后一个已完结日）
  d.setDate(d.getDate() - 1);
  const start = new Date(Number(fromTs) || 0);
  start.setHours(0, 0, 0, 0);
  while (d.getTime() >= start.getTime()) {
    out.push(dayKeyOf(d.getTime()));
    d.setDate(d.getDate() - 1);
  }
  return out;
}

/**
 * 「数据元年」——最早**可能**有数据的自然日 0 点。
 *
 * 为什么需要它（2026-09-22）：'all' 范围给 completedDayKeys 传的起点是 0，
 * 于是从 1970-01-01 一路枚举到昨天 —— 实测 20718 个空日。代价有三层：
 *   1. 枚举本身要遍历两万多次（13ms，还算便宜）；
 *   2. 每个空日都会生成一条快照写进 usage-daily.json → 文件被灌到 9.95MB，
 *      而这份文件**每次统计**都要 JSON.parse 一遍（≈65ms）；
 *   3. 更糟的是 days 维度会吐 20718 个数据点，前端折线图直接画两万个点。
 *
 * 取两侧较小值，宁可保守（算早不算晚，绝不把真有数据的日子切掉）：
 *   ① 档案里最早一个会话的开始时刻；
 *   ② 日快照里最早一个"确有数据"（runs 或 token 非零）的日。
 * 两边都拿不到 → 返回 0，等于不做任何下限（老行为），安全兜底。
 */
function usageDataFloorMs(archive, snapshotDays) {
  let floorMs = Infinity;
  for (const parsed of archive.values()) {
    const t = Number(parsed?.started) || 0;
    if (t > 0 && t < floorMs) floorMs = t;
  }
  // ⚠️ 账本也要计入数据元年！否则会出现：会话文件被裁光后档案层的最早
  //    会话已经是很近的日子，但账本里还有更早的日子 —— 按档案算出的
  //    下限会把那些日子判成"元年之前"并裁掉，历史数据凭空消失。
  for (const dayKey of listUsageLedgerDays()) {
    const t = new Date(`${dayKey}T00:00:00`).getTime();
    if (Number.isFinite(t) && t < floorMs) floorMs = t;
  }
  // 日键是 YYYY-MM-DD，字典序即时间序，不必逐条 new Date（两万条 Date 解析不便宜）
  let floorKey = '';
  for (const [dayKey, snap] of Object.entries(snapshotDays || {})) {
    const t = snap?.aggregates?.totals;
    if (!t) continue;
    if (!((Number(t.runs) || 0) > 0 || (Number(t.totalTokens) || 0) > 0)) continue;
    if (!floorKey || dayKey < floorKey) floorKey = dayKey;
  }
  if (floorKey) {
    const k = new Date(floorKey + 'T00:00:00').getTime();
    if (!isNaN(k) && k < floorMs) floorMs = k;
  }
  if (!isFinite(floorMs)) return 0;
  const d = new Date(floorMs);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}

/**
 * 裁掉日快照里"数据元年"之前的日（只会是空日）与未来日。
 *
 * 保守三条，确保它永远不会删掉真实数据：
 *   ① 元年拿不到（0 / 非有限数）→ 一条都不裁；
 *   ② 只裁 **严格早于** 元年的日 —— 元年当天及以后原样保留；
 *   ③ 只裁字典序比较这一天（不做任何数值猜测）。
 * 被裁掉的日子如果将来真有数据，会作为"快照缺失"被正常重算，不会丢。
 *
 * @returns {number} 实际裁掉的条数（>0 时需要回写快照）
 */
function pruneUsageDaily(snapshotDays, floorMs) {
  if (!floorMs || !isFinite(floorMs)) return 0;
  const floorKey = dayKeyOf(floorMs);
  // 同上：未来日判据用 setDate(+1)，避免夏令时切换日 +24h 落到昨天。
  const tmr = new Date();
  tmr.setDate(tmr.getDate() + 1);
  const tomorrowKey = dayKeyOf(tmr.getTime());
  let removed = 0;
  for (const dayKey of Object.keys(snapshotDays)) {
    if (dayKey < floorKey || dayKey > tomorrowKey) { delete snapshotDays[dayKey]; removed++; }
  }
  return removed;
}

/**
 * 读 data/usage-today.json —— **当天**用量的权威值。
 *
 * ⚠️ 这是用量统计最重要的一块拼图（用户报"估算根本不更新"）：
 * 会话文件会被 keepFiles 裁掉、账本只从启用那天起记，所以两者都覆盖不了
 * 「今天早些时候」的历史。而 usage-today.json 是 #bumpTodayUsage 在每次会话
 * 结束时**累加**写下的当天总量，它**永远不被裁剪**，是当天唯一完整可信的数。
 *
 * 有了它，即使今天有 85% 的会话文件已被删除，统计也能对齐到真值 ——
 * 缺的量作为"归档补差"计入，而不是让用户对着一个偏小的数字反复刷新。
 *
 * @returns {null | {dayKey:string, promptTokens:number, completionTokens:number,
 *                   totalTokens:number, cachedTokens:number, runs:number, webSearchCount:number}}
 */
function loadUsageTodayFile() {
  try {
    const parsed = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'usage-today.json'), 'utf8'));
    if (parsed?.dayKey && typeof parsed.dayKey === 'string') {
      return {
        dayKey: parsed.dayKey,
        promptTokens: Number(parsed.promptTokens) || 0,
        completionTokens: Number(parsed.completionTokens) || 0,
        totalTokens: Number(parsed.totalTokens) || 0,
        cachedTokens: Number(parsed.cachedTokens) || 0,
        runs: Number(parsed.runs) || 0,
        webSearchCount: Number(parsed.webSearchCount) || 0,
      };
    }
  } catch { /* 无文件 = 今天还没用量 */ }
  return null;
}

/**
 * 跨天归档的每日权威总量（data/usage-archived-days.json）。
 *
 * ⚠️（2026-10-17 补完 报告3 M2 的另一半）这个文件此前**只写不读**：
 *   sessions.js 的 #archiveDayUsage 把 usage-today.json 被顶下来的旧槽位按天写进去，
 *   而下面 authoritativeGapForDay 的注释早就把它列为"权威总量来源③" —— 代码里却
 *   从来没打开过它。于是那段归档等于白写，注释与实现对不上（这正是报告点的问题）。
 *   这里补上读取：账本没覆盖到的日子，用归档里的权威值补差。
 *
 * 缓存按 (mtimeMs,size) 失效：本函数在补差循环里会被逐日调用，不能每天都读一次盘。
 * 文件不存在是**常态**（还没发生过跨天归档），不是错误。
 */
let archivedDaysCache = { sig: '', days: {} };

function loadArchivedUsageDays() {
  let sig;
  try {
    const st = fs.statSync(USAGE_ARCHIVED_FILE);
    sig = `${st.mtimeMs}:${st.size}`;
  } catch { return {}; }                       // 没有归档文件 = 没什么可补
  if (archivedDaysCache.sig === sig) return archivedDaysCache.days;
  try {
    const parsed = JSON.parse(fs.readFileSync(USAGE_ARCHIVED_FILE, 'utf8'));
    const days = parsed?.days && typeof parsed.days === 'object' ? parsed.days : {};
    archivedDaysCache = { sig, days };
    return days;
  } catch { return {}; }                       // 坏文件：当作没有，且不缓存（下次重试）
}

/** 归档里某一天的权威总量；没有该天返回 null。 */
function archivedDayTotals(dayKey) {
  const d = loadArchivedUsageDays()[dayKey];
  if (!d || typeof d !== 'object') return null;
  return {
    promptTokens: Number(d.promptTokens) || 0,
    completionTokens: Number(d.completionTokens) || 0,
    totalTokens: Number(d.totalTokens) || 0,
    cachedTokens: Number(d.cachedTokens) || 0,
    runs: Number(d.runs) || 0,
    webSearchCount: Number(d.webSearchCount) || 0,
  };
}

/**
 * 算出某一天"已经进统计行的量"与权威真值之间还差多少。
 *
 * 三个数据源取**逐字段最大值**作为真值：
 *   ① 用量账本 —— 按天留档、跨天也准（启用那天起）
 *   ② usage-archived-days.json —— 跨零点归档的权威总量
 *   ③ usage-today.json —— 当天总量（仅当天匹配时）
 *
 * ⚠️（2026-10-17）"已知覆盖"只认**调用方已经放进 rows 的量** ——
 * coveredByDay 必须已含账本逐会话补行。曾经的实现把账本当日总量同时
 * 当成"已知覆盖"（known = max(文件覆盖, 账本总量)）和"真值"
 * （truth = 账本总量）→ gap 恒等于 0 → 补差永远不触发。用户报的
 * "今日 200 次运行只算 120 次"就是这么来的：账本明明记全了，
 * 却因为对账逻辑自相矛盾，一行都补不回去。
 *
 * @param {Map<string, object>} coveredByDay 已进 rows 的覆盖量（按天，含 runs=去重会话数）
 * @param {Map<string, object>} ledgerByDay   账本汇总量
 * @param {string} dayKey
 * @returns {{promptTokens:number,completionTokens:number,cachedTokens:number,
 *            webSearchCount:number,runs:number}|null} 无差距返回 null
 */
function authoritativeGapForDay(coveredByDay, ledgerByDay, dayKey) {
  const c = coveredByDay.get(dayKey) || { promptTokens: 0, completionTokens: 0, cachedTokens: 0, webSearchCount: 0, runs: 0 };
  const num = (v) => Number(v) || 0;
  const todayFile = loadUsageTodayFile();
  const candidates = [
    ledgerByDay.get(dayKey) || null,
    archivedDayTotals(dayKey),
    (todayFile && todayFile.dayKey === dayKey) ? todayFile : null,
  ].filter(Boolean);
  if (!candidates.length) return null;
  const truth = {
    promptTokens: Math.max(...candidates.map((x) => num(x.promptTokens))),
    completionTokens: Math.max(...candidates.map((x) => num(x.completionTokens))),
    cachedTokens: Math.max(...candidates.map((x) => num(x.cachedTokens))),
    runs: Math.max(...candidates.map((x) => num(x.runs))),
    webSearchCount: Math.max(...candidates.map((x) => num(x.webSearchCount))),
  };
  const gapPrompt = Math.max(0, truth.promptTokens - num(c.promptTokens));
  const gapCompletion = Math.max(0, truth.completionTokens - num(c.completionTokens));
  const gapRuns = Math.max(0, truth.runs - num(c.runs));
  if (!gapPrompt && !gapCompletion && !gapRuns) return null;
  return {
    promptTokens: gapPrompt,
    completionTokens: gapCompletion,
    cachedTokens: Math.max(0, truth.cachedTokens - num(c.cachedTokens)),
    webSearchCount: Math.max(0, truth.webSearchCount - num(c.webSearchCount)),
    runs: gapRuns,
  };
}

/** 构造一条"来自账本/归档"的补差行（at 落在当天末尾，计价按兜底价）。 */
function ledgerGapRow(dayKey, gap) {
  const at = new Date(`${dayKey}T23:59:59`).getTime();
  return {
    promptTokens: gap.promptTokens,
    completionTokens: gap.completionTokens,
    cachedTokens: gap.cachedTokens,
    at: Number.isFinite(at) ? at : Date.now(),
    // 这一行代表的会话数。costOfRows 的 runs 按行的 runs 累加，补差行不带
    // runs 会按 1 计 —— "调用次数"照样对不上（200 次运行只算 120 次的
    // 另一半原因）。纯 token 差价的补差行 runs 为 0，不影响计数。
    runs: Number(gap.runs) || 0,
    model: '(已归档会话)',
    vendor: UNKNOWN_VENDOR,
    chatKey: '(已归档会话)',
    sessionId: '',
    exact: false,
    fromLedger: true,
  };
}

/**
 * 把一条账本记录转成统计行：一个被裁掉的会话 = 一行。
 *
 * 为什么必须逐会话转行、而不是按天合成一行：
 *   ① 次数：costOfRows 的 runs 按行累加，按天合成的一行只代表 1 次调用；
 *   ② 归属：chatKey / model / vendor / calls 都在账本记录里，逐会话转行
 *      才能让"按会话 / 按模型"两张表把补回来的量归到真正的群和模型上，
 *      而不是全塞进"(已归档会话) / 未知渠道"这种糊涂账。
 *
 * @param {object} rec 账本记录（usage-ledger.js 的 ledgerRecordOf 产出）
 */
function ledgerSessionRow(rec) {
  return {
    promptTokens: Number(rec?.promptTokens) || 0,
    completionTokens: Number(rec?.completionTokens) || 0,
    cachedTokens: Number(rec?.cachedTokens) || 0,
    at: Number(rec?.endedAt) || Date.now(),
    runs: Number(rec?.calls) || 1,      // 该会话真实的 LLM 调用次数
    model: String(rec?.model || '') || '(未知)',
    vendor: String(rec?.vendor || ''),
    chatKey: String(rec?.chatKey || '(未知)'),
    sessionId: String(rec?.id || ''),
    exact: false,
    fromLedger: true,
  };
}

/**
 * 从档案层聚合出"某一个自然日"的统计（不使用快照 —— 这是重算路径）。
 * 返回与 buildUsageStats 的 days/chats/models 三段同构的聚合体。
 */
function aggregateDayFromArchive(archive, dayKey) {
  const dayStart = new Date(dayKey + 'T00:00:00');
  if (isNaN(dayStart.getTime())) return null;
  // ⚠️ 不能写死 +24h 夏令时切换日会错 1 小时（本地 23h 或 25h 的一天），
  // 那一天的尾巴或开头会被漏掉 / 多算。用 setDate(+1) 让 Date 自己处理日界线。
  const dayEndDate = new Date(dayStart.getTime());
  dayEndDate.setDate(dayEndDate.getDate() + 1);
  const dayEnd = dayEndDate.getTime() - 1;
  if (!isFinite(dayEnd)) return null;
  const rows = [];
  let searchCount = 0;
  const toolCounts = Object.create(null);
  // 会话文件已覆盖的量（按天），供账本补差用
  const coveredByDay = new Map();
  for (const parsed of archive.values()) {
    if (!parsed || !parsed.started) continue;
    if (parsed.started >= dayStart.getTime() && parsed.started <= dayEnd) {
      searchCount += parsed.searchCount || 0;
      for (const [name, n] of Object.entries(parsed.toolCounts)) {
        toolCounts[name] = (toolCounts[name] || 0) + n;
      }
    }
    for (const r of (parsed.rows || [])) {
      if (r.at >= dayStart.getTime() && r.at <= dayEnd) rows.push(r);
    }
  }
  for (const r of rows) {
    const cur = coveredByDay.get(dayKey) || { promptTokens: 0, completionTokens: 0, cachedTokens: 0, webSearchCount: 0 };
    cur.promptTokens += Number(r.promptTokens) || 0;
    cur.completionTokens += Number(r.completionTokens) || 0;
    cur.cachedTokens += Number(r.cachedTokens) || 0;
    coveredByDay.set(dayKey, cur);
  }
  // 搜索次数是会话级计数，上面已经按会话累加过一次，这里按天记一次供补差
  {
    let s = 0;
    for (const parsed of archive.values()) {
      if (parsed?.started >= dayStart.getTime() && parsed.started <= dayEnd) s += parsed.searchCount || 0;
    }
    // ⚠️（2026-10-17 修崩溃）**不能直接 coveredByDay.get(dayKey).webSearchCount = s**：
    //    上面的累加循环只在 rows 非空时才 set(dayKey, …)，所以"这一天没有任何会话记录"
    //    （归档为空 / 该日无会话文件）时 map 里没有这个 key，get() 返回 undefined，
    //    赋值直接抛 TypeError: Cannot set properties of undefined (setting 'webSearchCount')。
    //    而"归档为空"恰恰是会话文件被外部清空后的常态 —— 于是快照路径每次必抛、
    //    被 buildUsageStats 的 catch 回落到实时聚合，表现为用量页按天只剩今天、
    //    下钻 0 行、成本 0。参考包（洛版修复版）同位置有同样的问题。
    const cur = coveredByDay.get(dayKey)
      || { promptTokens: 0, completionTokens: 0, cachedTokens: 0, webSearchCount: 0 };
    cur.webSearchCount = s;
    coveredByDay.set(dayKey, cur);
  }
  // 账本补差：会话文件被 keepFiles 裁掉的会话，其用量在这里补回来。
  // 不补的话统计会被冻结在"最近 N 个会话文件"上（用户报"200 次只算 120 次"）。
  // 与 collectUsageRows 同构：先逐会话补行，再按天对账补聚合差。
  {
    // ① 逐会话补行：账本里"文件已不在磁盘"的会话，每条转一行
    const onDiskIds = new Set([...archive.keys()].map((f) => f.replace(/\.json$/, '')));
    const pushed = [];
    for (const rec of usageLedgerPrunedRecords(dayKey, onDiskIds)) {
      const row = ledgerSessionRow(rec);
      rows.push(row);
      pushed.push(row);
    }
    // ② 覆盖量把刚补的行并进去。runs 必须**无条件**按去重会话数重算
    //    （不能只在裁了文件的日子算）—— 真值侧的 runs 是会话数，两边
    //    不同口径会让次数补差永远算不平，没裁文件的日子也会补出幽灵次数。
    {
      const cur = coveredByDay.get(dayKey)
        || { promptTokens: 0, completionTokens: 0, cachedTokens: 0, webSearchCount: 0, runs: 0 };
      // ⚠️ 上面建 coveredByDay 时没有 runs 字段，直接 += 会得到 NaN，
      //    而 num(NaN)=0 → 次数补差把整天的量再补一遍（实测 runs 翻倍）。
      if (!Number.isFinite(Number(cur.runs))) cur.runs = 0;
      const seen = new Set();
      for (const r of rows) {
        if (!r.sessionId || seen.has(r.sessionId)) continue;
        seen.add(r.sessionId);
        cur.runs += 1;
      }
      for (const k of ['promptTokens', 'completionTokens', 'cachedTokens']) {
        cur[k] += pushed.reduce((n, r) => n + (Number(r[k]) || 0), 0);
      }
      coveredByDay.set(dayKey, cur);
    }
    // ③ 与权威真值仍有差距的（账本漏记 / 账本建立之前的日子）再补一条聚合行
    const { days: ledgerByDay } = usageLedgerTotals((d) => d === dayKey);
    const gap = authoritativeGapForDay(coveredByDay, ledgerByDay, dayKey);
    if (gap) {
      rows.push(ledgerGapRow(dayKey, gap));
      searchCount += gap.webSearchCount;
    }
  }
  for (const r of rows) {
    r.vendor = String(r.vendor || '').trim() || UNKNOWN_VENDOR;
    r.modelKey = modelLabel(r.vendor, r.model);
  }
  const totals = costOfRows(rows);
  const chats = groupBy(rows, 'chatKey', 0);
  const models = groupBy(rows, 'modelKey', 0).map((m) => {
    const { vendor, model } = splitModelLabel(m.key);
    return { ...m, vendor, model };
  });
  return { totals, chats, models, searchCount, toolCounts };
}

/**
 * 把某一天的聚合体摊平成 days 维度的一条记录。
 *
 * 抽成模块级是因为快照路径与回落实时路径都要用，两边的字段约定必须一致。
 *
 * 做两件必须做的事：
 *  ① 重算派生比率 cacheHitRate / peakRatio —— 它们是「比率」不是「量」，
 *     跨日相加没有意义，聚合时一律先归零再在此处按当天自身重算
 *     （见 buildUsageStatsWithSnapshots 里 totals 的归零骨架）。
 *  ② 补 key 字段 —— chats / models 维度都有 key，前端下钻与横向条形图统一按
 *     key 取值；days 曾经只给 day，把 days 接进 usageBars 时 x.key 会是 undefined。
 *
 * @param {string} dayKey  'YYYY-MM-DD'
 * @param {object} aggTotals 该日的聚合体（costOfRows 的返回或 groupBy 的返回）
 */
function withDerived(dayKey, aggTotals) {
  const t = { ...(aggTotals || {}) };
  const prompt = Number(t.promptTokens) || 0;
  const peak = Number(t.peakTokens) || 0;
  const offPeak = Number(t.offPeakTokens) || 0;
  t.cacheHitRate = prompt ? Math.min(1, (Number(t.cachedTokens) || 0) / prompt) : 0;
  t.peakRatio = (peak + offPeak) ? peak / (peak + offPeak) : 0;
  // key 在前：保证不会被 aggTotals 里同名残留字段覆盖
  return { ...t, key: dayKey, day: dayKey };
}

/**
 * 快照加速版统计：days 维度全部走快照 + 今天实时聚合。
 * 其余维度（chats/models/totals）= 各日快照聚合 + 今天实时。
 * 任一需要的日快照缺失/失效 → 重算该日并回写快照。
 *
 * @returns {Promise<{stats: object, usedSnapshotDays: number, recomputedDays: number}>}
 */
async function buildUsageStatsWithSnapshots({ range = '7' } = {}) {
  const win = resolveRange(range);
  const todayKey = dayKeyOf(Date.now());
  const dir = path.join(DATA_DIR, 'sessions');
  let files = [];
  try { files = fs.readdirSync(dir).filter((f) => f.endsWith('.json')); } catch { files = []; }
  const dirSig = sessionsDirSignature();
  const archive = await refreshUsageArchive(dir, files, dirSig);
  // 日快照有效性判据 = 历史文件指纹（不是目录签名，原因见 historySignatureOf 注释）
  const todayStart = new Date();
  todayStart.setHours(0, 0, 0, 0);
  const historySig = historySignatureOf(archive, todayStart.getTime());

  // 需要的已完结日：窗口起点到昨天；快照里已有的更早日子只在 all 模式需要
  const snapshotDays = loadUsageDaily();
  // ⚠️ 顺序要紧：先读出快照（数据元年的判据之一），再算起点、再枚举日。
  //
  // 起点 = 「窗口起点」与「数据元年」的**较晚者**。两条同时要满足：
  //   ① 'all' 不能给 0 —— 那会从 1970-01-01 枚举两万多个空日（见元年函数注释）；
  //   ② 元年之前的日子必然是空的，枚举出来只会在快照里写一批空条目、
  //      下一次调用又按"空日裁剪"删掉 —— 一边写一边删，**每次统计都重算那几个空日**。
  //      实测（R49 / usage-daily-test 抓到的）：只有 3 天数据的部署上，
  //      7 天窗口会稳定地每次重算 3 个空日，等于把刚修好的性能又还回去一部分。
  //      枚举与裁剪用同一个下限，"写什么"就等于"留什么"，churn 自然消失。
  // 元年拿不到（= 整份数据里一条会话都没有）：'all' 干脆一天都不枚举，
  // 其他范围退回窗口起点（Math.max(start, 0) 即起点本身）。
  const floorMs = usageDataFloorMs(archive, snapshotDays);
  const fromTs = win.mode === 'all'
    ? (floorMs || Infinity)
    : Math.max(win.start, floorMs);
  const wantedDays = completedDayKeys(fromTs);
  let recomputed = 0;

  // days 维度：每日一条聚合（快照优先，缺失则重算）
  // 先攒 { dayKey, totals } 原始对，等 totals/withDerived 定义好之后再摊平
  // （见下方注释：摊平时必须重算派生比率、补 key 字段）。
  const byDayRaw = [];
  const needDays = [];
  for (const dayKey of wantedDays) {
    const snap = snapshotDays[dayKey];
    if (snap && snap.sig === historySig && snap.aggregates) {
      byDayRaw.push({ dayKey, totals: snap.aggregates.totals });
    } else {
      needDays.push(dayKey);
    }
  }
  for (const dayKey of needDays) {
    const agg = aggregateDayFromArchive(archive, dayKey);
    // ⚠️（2026-10-17）重算"算不出数据"时**不能拿零去覆盖已有快照**。
    //    触发场景：会话文件被外部清空（用户点了「清空已结束的会话记录」）→
    //    归档为空 → 所有历史日的 sig 全部失配进 needDays → 每个都重算出全零，
    //    若照旧写回 snapshotDays 再 saveUsageDaily，磁盘上那几天的真实聚合值
    //    就被永久抹成 0 了。快照本身是这些天唯一的凭据，必须保住。
    const aggHasData = agg
      && ((Number(agg.totals?.runs) || 0) > 0 || (Number(agg.totals?.totalTokens) || 0) > 0);
    if (!aggHasData) {
      const prev = snapshotDays[dayKey];
      if (prev?.aggregates) {
        byDayRaw.push({ dayKey, totals: prev.aggregates.totals });
        // ⚠️（2026-10-17 N9）**把签名一起对齐到当前归档状态** —— 让快照"自愈"。
        //
        //    只保住数据还不够：只要 sig 不更新，这个日子下一轮统计仍会进 needDays、
        //    再算一次、再判定"算不出数据"，陷入**每轮都重算**的循环。数据是保住了，
        //    但快路径永远回不来（每次打开用量页都要把整个窗口的天数过一遍）。
        //
        //    为什么这样对齐是安全的：
        //      · historySig 是"**已完结会话文件**的 数量: mtime 之和"。
        //        归档为空（会话被清空/删除）时它恒为 `h:0:0` —— 在归档回到非空前，
        //        任何一天都不可能算出数据，所以"这份快照在当前状态下已是最终值"成立。
        //      · 一旦归档恢复/新增（用户补回文件、或明天又有会话完结），
        //        historySig 立刻变 → 快照重新失配 → 正常走重算路径并覆盖。
        //        也就是说对齐只**推迟**重算，不会**阻止**重算。
        snapshotDays[dayKey] = { sig: historySig, aggregates: prev.aggregates };
      }
      continue;
    }
    byDayRaw.push({ dayKey, totals: agg.totals });
    snapshotDays[dayKey] = { sig: historySig, aggregates: agg };
    recomputed++;
  }

  // 今天（窗口含今天才需要）：实时聚合
  const includesToday = win.end >= new Date(todayKey + 'T00:00:00').getTime();
  let todayAgg = null;
  if (includesToday) {
    todayAgg = aggregateDayFromArchive(archive, todayKey);
  }

  // ⚠️ 把今天补进 days（2026-10-16 修复「按天」图表空白）。
  //
  // 背景：completedDayKeys() 从**昨天** 0 点开始往回枚举（见该函数里明写的
  // `setDate(-1)`），所以 `today` 永远不会进 wantedDays —— 这是设计，今天走
  // 实时聚合、不进日快照。而 days 维度只在 wantedDays 循环里 push，于是今天的
  // 数据**从来没进过 days 维度**。
  //
  // 为什么这是个 bug：下面 chats / models / totals **三个维度都合并了
  // todayAgg**，唯独 days 漏了。后果是顶部卡片（读 totals）数字在动，
  // 而「按天」图表（读 days）显示「这段时间没有记录」——同一份数据两个口径。
  // 只要某天的数据全在当天产生且当天没过完，图表就是空的。
  //
  // 曾经这里把展开写在 byDay.sort() 前后两次、且摊平的是聚合体原对象；
  // 现在统一在 withDerived 里做，日期升序也只排一次。
  if (todayAgg) byDayRaw.push({ dayKey: todayKey, totals: todayAgg.totals });

  // 合并各维度：已完结日快照 + 今天实时
  const mergeGroups = (groupsList) => {
    const map = new Map();
    for (const groups of groupsList) {
      for (const g of groups || []) {
        const key = String(g.key ?? '');
        // ⚠️（2026-10-17 修重复计数）建桶时必须把**所有被累加的字段**归零：
        //    旧实现只归零 runs/exactCalls/cost，而下面累加循环一共加 11 个字段
        //    （cost/peakCost/offPeakCost/peakTokens/offPeakTokens/promptTokens/
        //    completionTokens/cachedTokens/totalTokens/runs/exactCalls）——
        //    漏掉的 8 个会随 `{ ...g }` 原样进桶、再被累加循环加第二遍，
        //    导致每个键"首次出现"的日贡献翻倍（实测 7 日模型表虚高 35%、
        //    会话表虚高 75%、单日范围整表翻倍）。总量与"按天"表不走这里，不受影响。
        if (!map.has(key)) map.set(key, {
          key, ...g,
          cost: 0, peakCost: 0, offPeakCost: 0,
          peakTokens: 0, offPeakTokens: 0,
          promptTokens: 0, completionTokens: 0, cachedTokens: 0, totalTokens: 0,
          runs: 0, exactCalls: 0,
        });
        const t = map.get(key);
        t.cost += Number(g.cost) || 0;
        t.peakCost += Number(g.peakCost) || 0;
        t.offPeakCost += Number(g.offPeakCost) || 0;
        t.peakTokens += Number(g.peakTokens) || 0;
        t.offPeakTokens += Number(g.offPeakTokens) || 0;
        t.promptTokens += Number(g.promptTokens) || 0;
        t.completionTokens += Number(g.completionTokens) || 0;
        t.cachedTokens += Number(g.cachedTokens) || 0;
        t.totalTokens += Number(g.totalTokens) || 0;
        t.runs += Number(g.runs) || 0;
        t.exactCalls += Number(g.exactCalls) || 0;
      }
    }
    let out = [...map.values()];
    out.sort((a, b) => b.cost - a.cost || b.totalTokens - a.totalTokens);
    return out;
  };

  const snapAggs = [...wantedDays].map((k) => snapshotDays[k]?.aggregates).filter(Boolean);
  const totalsAggs = snapAggs.map((a) => a.totals);
  if (todayAgg) totalsAggs.push(todayAgg.totals);
  // ⚠️ 曾经首元素走 `{ ...t }` 分支（把聚合体的**全部**字段原样带进来），
  // 后续元素才走固定字段累加。后果：单日范围的 totals 字段集与多日不同
  // （多出来的 cacheHitRate/peakRatio/hasPeakModel 在单日时是原值、
  // 多日时被丢弃后重算），前端拿到两种形状的对象。
  // 现在统一形状：先铺一份全零骨架，再逐日累加固定的可加字段。
  const TOTAL_ZERO = {
    cost: 0, peakCost: 0, offPeakCost: 0, peakTokens: 0, offPeakTokens: 0,
    promptTokens: 0, completionTokens: 0, cachedTokens: 0, totalTokens: 0,
    runs: 0, exactCalls: 0, hasPeakModel: false,
    cacheHitRate: 0, peakRatio: 0,
  };
  const totals = totalsAggs.reduce((acc, t) => ({
    cost: acc.cost + (Number(t?.cost) || 0),
    peakCost: acc.peakCost + (Number(t?.peakCost) || 0),
    offPeakCost: acc.offPeakCost + (Number(t?.offPeakCost) || 0),
    peakTokens: acc.peakTokens + (Number(t?.peakTokens) || 0),
    offPeakTokens: acc.offPeakTokens + (Number(t?.offPeakTokens) || 0),
    promptTokens: acc.promptTokens + (Number(t?.promptTokens) || 0),
    completionTokens: acc.completionTokens + (Number(t?.completionTokens) || 0),
    cachedTokens: acc.cachedTokens + (Number(t?.cachedTokens) || 0),
    totalTokens: acc.totalTokens + (Number(t?.totalTokens) || 0),
    runs: acc.runs + (Number(t?.runs) || 0),
    exactCalls: acc.exactCalls + (Number(t?.exactCalls) || 0),
    hasPeakModel: acc.hasPeakModel || Boolean(t?.hasPeakModel),
    cacheHitRate: 0,   // 派生比率，循环后重算
    peakRatio: 0,
  }), { ...TOTAL_ZERO });
  // 派生比率不能相加，重算
  totals.cacheHitRate = totals.promptTokens ? Math.min(1, totals.cachedTokens / totals.promptTokens) : 0;
  totals.peakRatio = (totals.peakTokens + totals.offPeakTokens) ? totals.peakTokens / (totals.peakTokens + totals.offPeakTokens) : 0;

  // byDay 的每一条也是从聚合体摊平的，聚合体里的 cacheHitRate/peakRatio 是
  // 上面那张全零骨架带来的 0 —— 必须在入表前按该日自身的 token 重算，
  // 否则「按天」表的命中率列会整列显示 0%。
  const byDay = byDayRaw
    .map((x) => withDerived(x.dayKey, x.totals))
    .sort((a, b) => (a.day < b.day ? -1 : a.day > b.day ? 1 : 0));

  const chats = mergeGroups([...snapAggs.map((a) => a.chats), ...(todayAgg ? [todayAgg.chats] : [])]);
  const models = mergeGroups([...snapAggs.map((a) => a.models), ...(todayAgg ? [todayAgg.models] : [])])
    .map((m) => {
      const { vendor, model } = splitModelLabel(m.key);
      return { ...m, vendor, model };
    });
  let searchCount = snapAggs.reduce((a, x) => a + (x.searchCount || 0), 0) + (todayAgg?.searchCount || 0);
  const toolCounts = {};
  for (const a of snapAggs) {
    for (const [k, v] of Object.entries(a.toolCounts || {})) toolCounts[k] = (toolCounts[k] || 0) + v;
  }
  for (const [k, v] of Object.entries(todayAgg?.toolCounts || {})) toolCounts[k] = (toolCounts[k] || 0) + v;

  // 快照回写（有新增/失效重算的日子才写）
  // 顺带裁掉数据元年之前的空日：老版本被 'all' 范围灌进来的两万条空日
  // 就靠这一句自愈（正常运行时每次统计都过一遍，裁剪本身是字符串比较，可忽略）。
  const prunedDays = pruneUsageDaily(snapshotDays, floorMs);
  if (recomputed > 0 || needDays.length > 0 || prunedDays > 0) {
    // 只保留窗口需要的 + 已有的（不清老数据——删掉将来还得重算）
    saveUsageDaily(snapshotDays);
  }

  return {
    stats: {
      range: String(range),
      rangeLabel: win.label,
      mode: win.mode,
      totals,
      searchCount: searchCount || 0,
      toolCounts: toolCounts || {},
      days: byDay,
      chats,
      models
    },
    recomputedDays: recomputed,
    prunedDays,
    usedSnapshotDays: wantedDays.length - recomputed
  };
}

/** 用配置解析价格（成本只与实际调用的模型有关，与当前选中模型无关）。 */
/**
 * 取某次调用的单价。
 *
 * 按「渠道：模型 id」优先查 —— 用户可以为某个渠道下的模型单独定价
 * （A6API 的 GLM-5.3-Flash 与 OpenRouter 的可能是两个价）。
 * 查不到再退回裸模型 id（通用价），最后才是全局兜底。
 *
 * ⚠️ 必须与前端展示/批量编辑用的身份一致，否则用户设的渠道价永远不会生效。
 */
function priceOf(model, vendor) {
  const cfg = getConfig();
  if (vendor) {
    const byVendor = resolveModelPrice(modelLabel(vendor, model), cfg);
    // 命中自定义价才算数；否则退回通用价（避免渠道名干扰官方表匹配）
    if (byVendor.source === 'custom') return byVendor;
  }
  return resolveModelPrice(model, cfg);
}

/** 对一批行计价，返回总额与峰谷拆分。 */
function costOfRows(rows) {
  const cfg = getConfig();
  let cost = 0, peakCost = 0, offPeakCost = 0, peakTokens = 0, offPeakTokens = 0;
  let promptTokens = 0, completionTokens = 0, cachedTokens = 0, exactCalls = 0, hasPeakModel = false;
  for (const r of rows) {
    const p = priceOf(r.model, r.vendor);
    if (p.peak) hasPeakModel = true;
    const tier = p.peak ? priceAt({ in: p.in, out: p.out, cached: p.cached, peak: p.peak }, r.at) : p;
    const prompt = Number(r.promptTokens) || 0;
    const completion = Number(r.completionTokens) || 0;
    const cached = Math.min(Number(r.cachedTokens) || 0, prompt);
    const fresh = Math.max(0, prompt - cached);
    const c = (fresh / 1_000_000) * tier.in + (cached / 1_000_000) * tier.cached + (completion / 1_000_000) * tier.out;
    cost += c;
    const tk = prompt + completion;
    if (isPeakHour(r.at)) { peakCost += c; peakTokens += tk; } else { offPeakCost += c; offPeakTokens += tk; }
    promptTokens += prompt;
    completionTokens += completion;
    cachedTokens += cached;
    if (r.exact) exactCalls += 1;
  }
  return {
    cost, peakCost, offPeakCost, peakTokens, offPeakTokens,
    promptTokens, completionTokens, cachedTokens,
    totalTokens: promptTokens + completionTokens,
    cacheHitRate: promptTokens ? Math.min(1, cachedTokens / promptTokens) : 0,
    peakRatio: (peakTokens + offPeakTokens) ? peakTokens / (peakTokens + offPeakTokens) : 0,
    exactCalls, hasPeakModel,
    // runs = 这些行代表的 LLM 调用总数。会话文件行每次调用一行（runs 缺省 1）；
    // 账本补行带真实 calls（见 ledgerSessionRow）—— 不累加它，被裁掉的会话
    // 在"模型调用次数"里永远少算（"200 次运行只算 120 次"的一半原因）。
    runs: rows.reduce((n, r) => n + (Number(r?.runs) || 1), 0)
  };
}

/** 按某个字段分组后各自计价。 */
function groupBy(rows, field, limit = 0) {
  const map = new Map();
  for (const r of rows) {
    const k = String(r[field] ?? '(未知)');
    if (!map.has(k)) map.set(k, []);
    map.get(k).push(r);
  }
  let out = [...map.entries()].map(([key, list]) => ({ key, ...costOfRows(list) }));
  out.sort((a, b) => b.cost - a.cost || b.totalTokens - a.totalTokens);
  if (limit) out = out.slice(0, limit);
  return out;
}

/** 主统计：按天 / 按会话 / 按模型三个维度。
 * 2026-09-19 起优先走"按日快照"路径（历史日聚合固化在 data/usage-daily.json，
 * 只实时算今天），快照层出错时自动回落到旧的实时聚合 —— 用量页绝不能白屏。
 *
 * 2026-09-22 加三道闸（长期使用后"用量页卡死在加载"的治理之三）：
 *   1. 结果缓存 3 小时（用户要求）：见下方 USAGE_STATS_CACHE_TTL_MS 注释。
 *   2. 微缓存 5 秒：前端轮询 + SSE 事件都会打到这里，5 秒内的重复请求直接复用。
 *      （已被第 1 条覆盖，保留是因为它先于结果缓存判定、命中更快，也兜住
 *        "force 重算后立刻又被轮询打一次"的情况。）
 *   3. 防重入：同一 range 的统计在跑时，后续请求搭同一趟车（共享同一 Promise），
 *      避免多个统计叠加着阻塞事件循环。 */
const USAGE_STATS_MICRO_TTL_MS = 5000;

/**
 * 结果缓存 TTL（2026-09-22，用户要求）。
 *
 * 用户原话："用量界面点今日的时候会加载非常久 …… 我认为可以改成 3 小时自动
 * 统计一次，外加用户手动刷新的时候统计。"
 *
 * 为什么值得缓存整个结果：统计本身不贵了（档案增量解析 + 快照），但**入口太多**
 * —— 15 秒轮询、SSE 事件、切页签、来回点时间范围按钮，每个入口都会把
 * 「读目录 → 增量解析 → 逐日聚合 → 逐行计价 → 读 10MB 快照」重走一遍。
 * 缓存整个结果，这些入口全部退化成一次 Map.get。
 *
 * 语义要点：
 *   - 命中时 `computedAt` **保持真正算出来的时刻**，前端据此显示"数据更新于 HH:MM"
 *     —— 新鲜度是可见的，不会假装数字是刚算的。
 *   - force=true（用户点了「刷新」）跳过缓存重新统计并覆盖缓存。
 *   - 想调新鲜度：改这一个常量即可（单位毫秒）。
 */
const USAGE_STATS_CACHE_TTL_MS = 3 * 60 * 60 * 1000;
const usageStatsCache = new Map();   // `${range}#${价格指纹}` -> { at, stats }
const usageStatsInflight = new Map(); // 同上 key -> Promise（每个 key 各有各的在途统计）
let usageStatsMicro = { key: '', at: 0, stats: null };

/** 清空统计结果缓存（测试用；也留给将来"重置用量统计"这类操作）。 */
function resetUsageStatsCache() {
  usageStatsCache.clear();
  usageStatsInflight.clear();
  usageStatsMicro = { key: '', at: 0, stats: null };
}

/**
 * 计价输入的价格指纹。
 *
 * ⚠️ 为什么缓存 key 必须带它（曾经的 bug）：
 * 3 小时结果缓存的 key 原本只有 range，用户在设置里改了自定义单价之后，
 * 用量页的成本数字 3 小时内纹丝不动 —— 而这恰恰是最需要立刻生效的场景
 * （用户改价就是想看新口径）。价格指纹一变，缓存 key 就变，缓存自动失效。
 *
 * 取的是「真正影响计价的两处」：
 *   ① data/config.json 里的自定义价（mtime + 字节长度，够用且便宜）
 *   ② 远程价表 setRemotePrices 的条目数（远程价刷新会改变条目数）
 * 不做深度哈希：config.json 很小，而计价本身只在重算时发生。
 */
function priceSignature() {
  let cfgSig = '';
  try {
    const st = fs.statSync(path.join(DATA_DIR, 'config.json'));
    cfgSig = `${st.mtimeMs}:${st.size}`;
  } catch { cfgSig = 'nocfg'; }
  return `${cfgSig}|${remoteOverrideCount()}`;
}

async function buildUsageStats({ range = '7', force = false } = {}) {
  const rangeKey = String(range);
  // 缓存键带上价格指纹：改单价后旧缓存自动作废（见 priceSignature 注释）
  const key = `${rangeKey}#${priceSignature()}`;
  // force 必须**同时**绕过两层缓存。踩过的坑：微缓存判定写在前面却没看 force，
  // 于是"点刷新"在两次请求间隔 <5 秒时直接吃微缓存 —— 结果是刷新按钮按下去
  // 数字纹丝不动（实测 computedAt 完全不变），比慢更让人困惑。
  if (!force) {
    // ① 5 秒微缓存（先判，命中最快：轮询 + SSE 事件风暴不再叠加统计）
    if (usageStatsMicro.stats && usageStatsMicro.key === key
        && Date.now() - usageStatsMicro.at < USAGE_STATS_MICRO_TTL_MS) {
      return usageStatsMicro.stats;
    }
    // ② 3 小时结果缓存
    const cached = usageStatsCache.get(key);
    if (cached && Date.now() - cached.at < USAGE_STATS_CACHE_TTL_MS) {
      usageStatsMicro = { key, at: Date.now(), stats: cached.stats };
      return cached.stats;
    }
  }
  // ③ 防重入：同 key 正在算就搭同一趟车。
  // ⚠️ 曾经这里是**单个全局槽**（let usageStatsInflight），key 不同就直接
  // 新开一个 Promise 覆盖掉前一个 —— 于是切 range 时前后两个 range 会
  // 同时全量重算，把刚做的缓存优化全还回去（大档案下表现为卡顿）。
  // 改成 Map：每个 key 各有各的在途 Promise，互不覆盖。
  const inflight = usageStatsInflight.get(key);
  if (inflight) return infight;
  const promise = (async () => {
    let stats = null;
    try {
      const r = await buildUsageStatsWithSnapshots({ range });
      if (r.stats && r.stats.totals) stats = r.stats;
    } catch (error) {
      console.warn('[usage] 快照统计路径失败，回落实时聚合：', error?.message ?? error);
    }
    if (!stats) {
      const { rows, win, searchCount, toolCounts } = await collectUsageRows({ range });
      const totals = costOfRows(rows);
      // 单日/24小时场景下"按天"没有意义（只有一行），由前端决定是否隐藏
      // 按天分桶需要 dayKey 字段
      for (const r of rows) r.dayKey = dayKeyOf(r.at);
      const byDay = win.mode === 'days'
        ? groupBy(rows, 'dayKey')
            // 与快照路径同构：补 key 字段 + 重算派生比率（groupBy 不带 cacheHitRate）
            .map((x) => withDerived(x.key, x))
            .sort((a, b) => (a.day < b.day ? -1 : a.day > b.day ? 1 : 0))
        : [];
      const chats = groupBy(rows, 'chatKey', 0);
      // 不截断：截断会让"各行成本之和 ≠ 总成本"，用户核对时会困惑。
      // 行数多时由前端滚动容器处理。
      const models = groupBy(rows, 'modelKey', 0).map((m) => {
        const { vendor, model } = splitModelLabel(m.key);
        return { ...m, vendor, model };
      });
      stats = {
        range: String(range),
        rangeLabel: win.label,
        mode: win.mode,
        totals,
        // 次数类统计：只看数量，不参与成本计算
        searchCount: searchCount || 0,
        toolCounts: toolCounts || {},
        days: byDay,
        chats,
        models
      };
    }
    // 真正算出来的时刻：前端靠它显示"数据更新于 HH:MM"。缓存复用时不会被改写。
    stats.computedAt = Date.now();
    return stats;
  })();
  usageStatsInflight.set(key, promise);
  try {
    const stats = await promise;
    usageStatsCache.set(key, { at: Date.now(), stats });
    usageStatsMicro = { key, at: Date.now(), stats };
    // key 里带了价格指纹，用户每改一次价就多一组条目。虽然 TTL 判定期会
    // 让过期条目自然失效（get 时不看它、但它还占着 Map），但长时间反复改价
    // 仍会攒下垃圾。这里顺手裁掉已过期的，只保留 range 数量级的条目。
    if (usageStatsCache.size > 32) {
      const now = Date.now();
      for (const [k, v] of usageStatsCache) {
        if (now - v.at >= USAGE_STATS_CACHE_TTL_MS) usageStatsCache.delete(k);
      }
    }
    return stats;
  } finally {
    // 只清自己这一条，别把别的 range 的在途统计误清掉
    if (usageStatsInflight.get(key) === promise) usageStatsInflight.delete(key);
  }
}

/**
 * 下钻明细：在某个维度取某个值，再按另一个维度展开。
 *   dim/key 定位子集，by 决定展开方式
 * 例：dim=chat&key=group:123&by=model → 该群下各模型的成本
 */
async function buildUsageBreakdown({ range = '7', dim = '', key = '', by = '' } = {}) {
  const { rows, win } = await collectUsageRows({ range });
  for (const r of rows) r.dayKey = dayKeyOf(r.at);
  // dim/by 为 model 时按复合身份匹配（模型 + 供应商）
  const fieldOf = (d) => (d === 'day' ? 'dayKey' : d === 'model' ? 'modelKey' : 'chatKey');
  const subset = dim ? rows.filter((r) => String(r[fieldOf(dim)] ?? '') === key) : rows;
  // 同样不截断：保证明细各项之和 = 该子集总成本
  const groups = groupBy(subset, fieldOf(by) || 'chatKey', 0);
  const sum = costOfRows(subset);
  // 峰谷信息跟随子集（弹窗外部上方展示用）
  return {
    range: String(range),
    dim, key, by,
    totals: sum,
    showPeak: sum.hasPeakModel && (sum.peakCost > 0 || sum.offPeakCost > 0),
    rows: groups.map((g) => ({
      key: g.key,
      cost: g.cost,
      promptTokens: g.promptTokens,
      completionTokens: g.completionTokens,
      cachedTokens: g.cachedTokens,
      totalTokens: g.totalTokens,
      cacheHitRate: g.cacheHitRate,
      runs: g.runs,
      exactCalls: g.exactCalls
    }))
  };
}

// ── 测试钩子（仅测试 import；生产代码不得依赖）──────────────────────
/**
 * SnowLuma 控制台凭据日志的测试钩子（2026-10-17）。
 * 暴露纯函数与固定指引文本 —— 不依赖 Electron / 网络 / 真实 data 目录。
 */
export function __testSnowlumaCredLog() {
  return { formatSnowlumaCredentialLog, SNOWLUMA_MANUAL_INJECT_GUIDE };
}

/** 2026-10-17：给"密码是否失效 / OneBot 连上没有"两个纯判据留测试入口。 */
export function __testSnowlumaAuth() {
  return { decideCredentialDrift, onebotOnlineVerdict };
}

export function __testUsageDaily() {
  return {
    // 桌宠：main 进程通过 core.getDesktopPetService() 取用（等价于作者的 api-export-service）
    getDesktopPetService,
    buildUsageStatsWithSnapshots,
    buildUsageStats,
    buildUsageBreakdown,
    collectUsageRows,
    loadUsageDaily,
    saveUsageDaily,
    completedDayKeys,
    aggregateDayFromArchive,
    // 2026-09-22 新增（R68）：数据元年下限 / 快照裁剪 / 结果缓存 / 后台预热
    usageDataFloorMs,
    pruneUsageDaily,
    resetUsageStatsCache,
    warmUsageArchive,
    sessionsDirSignature,
    USAGE_STATS_CACHE_TTL_MS,
    USAGE_DAILY_FILE
  };
}
