// 睡眠与心情系统（融合版）· v0.4.1 插件
//
// ══ 这个插件是什么 ══════════════════════════════════════════════════════════
// 把原来两个互相独立、且对「睡」各有一套理解的插件合成一个：
//
//   · mood-chain（心情与生活系统）—— 自然睡眠：她自己在对话里说要睡、或作息表
//     到点掷中睡觉 → 写 self-state.json 的 sleeping。拦住的是**发送类工具**
//     （before-tool），模型照跑 —— 省的是"她半夜乱说话"，不是 token。
//   · sleep-mode（睡眠模式）—— 命令睡眠：主人 @我 + /睡觉 → orchestrator
//     suspendAll()，消息只存档不调度、**模型根本不跑**，零 token。
//
// ══ 为什么必须融合（而不是两个插件并存）════════════════════════════════════
// 1. **`message.inbound-gate` 是单提供者能力**。app.js:910 取的是
//    `getCapabilityProviders('message.inbound-gate')[0]?.fn` —— **只有第一个**。
//    两个插件都提供这个能力名时，另一个的闸门**永远不会被调用**（审计也会报
//    "能力名冲突"，见 plugin-development §11）。所以想同时拥有两条闸门，
//    只能是一个插件、一个 provider 函数，在里面合并两套判定。
//
// 2. **「谁在睡」必须只有一个真相源**。原来两套状态各自为政：
//      · mood-chain 的 sleeping 写在 self-state.json（跨群、跨重启）；
//      · sleep-mode 的 sleeping 是**模块内存态**（重启即解除）。
//    两者会打架：命令睡眠期间 mood-chain 仍会在 before-context 里判出
//    「她在睡」并缓存闸门，/起床 之后 resumeAll 补处理的消息**又被 before-tool
//    拦一次**；反过来她自然睡着时主人发 /睡觉，会得到一个"我已经在睡了"的
//    重复状态。融合后：**命令睡眠是外层（更强），自然睡眠是内层**，
//    两级共用一个查询函数 `currentSleep()`，任何决定都先问它。
//
// 3. **起床必须走同一条路**。原来 /起床 只做 resumeAll，**不改 self-state** ——
//    如果她同时是自然 sleeping，补处理的消息会被 before-tool 拦掉，表现成
//    "我叫她起床了，她还是不说话"。融合后 /起床 与主人的口令、以及
//    引擎的 markWoken 共用 `wakeUp()` 一个出口：改状态 + 清闸门缓存 + 清命令睡眠。
//
// ══ 两级拦截怎么选（核心设计）══════════════════════════════════════════════
//
//   命令睡眠（sleepCommand / /睡觉）  →  入站闸门 blocked → **模型不跑**（零 token）
//   自然睡眠（她自己说要睡/作息表）  →  睡眠闸 before-tool → 模型跑了但发不出去
//
//   为什么命令睡眠不也去写 self-state？—— 因为语义不同：
//     · 命令睡眠是**主人对机器人下的开关**（"你先别说话"），跟"她困了"无关，
//       写进 self-state 会让她之后按"刚睡醒"演，还会被作息表/疲劳逻辑读到；
//     · 自然睡眠是**她自己的状态**，要跨重启、要影响演出。
//   两者独立存储，但**查询时统一**（命令睡眠优先），避免任何一方被绕过。
//
// ══ 从 mood-chain 完整继承的东西 ═══════════════════════════════════════════
//   情绪五维 / 疲劳五段 / 愤怒三通道 / 吃醋 / 抑郁 / 满足、作息表、恢复池、
//   洗澡、活动时钟（ACTIVITY-CLOCK）、出门（OUTDOOR）、主人起床口令、
//   提示词注入、三个手调工具。
//   —— 全部原样保留，逻辑一行没改（见下方「与上游的关系」）。
//   ⚠️ 唯一被**删掉**的是 mood.snapshot 能力与 13 个 live 面板字段：
//      那个机制在 v0.4.1 已被核心整体移除，留着就是孤儿能力（见 providers 上方注释）。
//
// ══ 与上游（C2 的「心情系统插件树 v4.0」）的关系 ════════════════════════════
// 上游自述：数值核心在**宿主内核 src/** 里（每轮对话被编排器调用），
// plugins/mood-chain/ 只是管理面板 → 移植需要动 app.js/orchestrator.js/prompt.js/
// sender.js/config.js 五处接线。本插件沿用 v0.4 的 hooks 等价替换，**没有改一行核心**。
//
//   上游接线                              →  本插件
//   ─────────────────────────────────────────────────────────────────
//   orchestrator.observeTrigger()          →  hooks['before-context']
//   prompt.js 里 13 个注入块                →  hooks['before-llm-messages']
//   sender.js 出口观察她自己的话            →  hooks['after-tool']
//   orchestrator.wake 入口的 sleepGate      →  hooks['before-context'] 记录 +
//                                              hooks['before-tool'] 拦截
//   后台衰减钟 / 作息表推进                 →  activate() 的定时器
//   panel.html 15 格面板                    →  plugin.json 的 configSchema +
//                                              本文件注册的 3 个工具
//   src/config.js 的 DATA_DIR               →  lib/config.js 转发核心导出
//
// ══ 已物理删除的模块（2026-09-22 先停用，2026-10-11 删除代码）══════════════
// 情爱 / 性欲 / 色色兴奋 / 想要 / 姊妹亲密，以及**依赖它们供数**的
// 贤者时间（refractory）/ 自慰心声（solo、soloVoice）/ 用户健康台账（ownerHealth）。
// 现在：`lib/mood-chain.js` 里这些函数已整体删掉，`REMOVED_MODULES` 只作**墓碑**保留 ——
// 万一有人把旧版 lib 贴回来，engineCfg 仍会把它们钉成 enabled:false。
//
// ══ 主人起床口令 ════════════════════════════════════════════════════════════
// 睡眠闸是"睡着就不许发言"；但主人半夜叫她起床时，若要等她自然醒或先喊对名字
// 就不像命令了。于是给主人一条**口令硬通道**：主人在消息里带上配置的口令词 → 立刻起床。
//   · 引擎的 isWakeCall：喊醒词/接触词 + **必须被称呼**（谁喊都行）→ 只放行这一轮，
//     **不改状态**。语义是"睡着了被吵到，迷糊回一句"。
//   · 本口令：**只认主人**、不必点名她 → 真的把状态改成 awake 并留 wakeAt，
//     于是接下来按"刚被叫醒、迷迷糊糊"演 30 分钟（注入块引擎自带）。
// 融合新增：口令命中时**同时解除命令睡眠**（否则状态醒了、闸门还拦着，
// 主人喊了没反应 —— 这正是原来两个插件并存时最容易踩的坑）。
//
// ‼️ 遗留缺口（沿用 mood-chain 的记录，未改）：引擎导出了 markWoken()（真正把
//    "被喊醒"落成 awake + wakeAt），但通用喊醒路径从没调用过。要不要接上
//    （会让夜里被任何人喊一声就真醒，token 消耗上升）是另一个决定，故未擅自改动。
//    本插件在 debugGates() / mood_status 里暴露了内部状态，便于排查。
//
// ══ 已知的功能降级（诚实声明）═══════════════════════════════════════════════
// 1. **SOLO-VOICE 心声直发私聊**：上游绕过 LLM 直接发消息。v0.4 的插件在
//    activate/hook 里**拿不到 sender**（hook 只有 5 秒超时且明令禁止发消息），
//    故降级为「心声状态照常推进 + 由她自己在对话里说出来」。
//    ⚠️ 该功能已于 2026-09-22 随自慰模块一并移除，此条仅作历史记录。
// 2. **作息表/恢复池的推进时机**：上游在每轮对话里推进，这里改到后台心跳。
//    数值语义一致，但"正好在她说话那一刻切状态"的精度会略降。
// 3. **命令睡眠是内存态**：与上游 sleep-mode 一致，重启机器人自动解除
//    （安全默认——防止"忘了关导致机器人永远沉默"）。
// 4. **面板**：v0.4 的 injectApi/panel.html 机制本来就不存在；曾经退而求其次用
//    configSchema 的 `type:'live'` 只读字段（核心 liveValuesOf 按能力取数），
//    但 **v0.4.1 把这个机制也移除了** —— 现在数值只能通过 mood_status 工具查。
//
// 设计红线（沿用上游第 5 节）：**永远不做硬拦截**（除了睡眠这两道既定的闸）、
// 状态文件坏了/缺了就全当平静（绝不锁死）、所有失败都静默吞掉不影响正常回复。

import * as M from './lib/mood-chain.js';
import * as S from './lib/self-state.js';
import { DATA_DIR, ROOT } from './lib/config.js';
import nodeFs from 'node:fs';
import nodePath from 'node:path';
// 核心文件日志器。相对路径与 lib/config.js 取 DATA_DIR 是同一套路
// （plugins/<id>/index.js → ../../src/）。取到的是同一个单例。
import { logger as coreLogger } from '../../src/logger.js';
import * as H from './lib/hp-system.js';
import * as F from './lib/favor-link.js';
// 旅行同步（TRAVEL-SYNC，2026-10-10 用户需求）：只读 travel-whale 的存档，把
// "正在进行中的旅程"翻译成她的自身状态 —— 面板显示"在 X 旅行"，提示词也带上
// 旅途感，免得集成系统一直显示她"在家待着"。**只读，不写**（见 lib/travel-sync.js 头注）。
import * as T from './lib/travel-sync.js';
// B站刷视频（BILI-WATCH，2026-10-22）：只读 bili-whale 写的 activity 信标。
// ★ 它是**并行状态** —— 和 travel/home/wake 的注入位置**并列**，不顶掉任何一条。
import * as BW from './lib/bili-watch.js';
import * as TL from './lib/tone-link.js';
// 旅途状态池（352 条"她此刻在干什么"）。**只读、只用来记录** —— 见下面的 recordTravelMoments：
// 那些条目是 `pickState()` 用哈希现算的，任何地方都不落盘，挡位（20 分钟）一过就查不回来。
import * as TS from './lib/travel-states.js';
// [[her-ledger]] 近况账本（2026-10-22）：她"嘴上说过的生活状态"（吃过/睡了/在忙）。
// self-state 管的是引擎推演出来的"她现在在干什么"，这一层管的是"她自己宣称过什么" ——
// 后者没人管，就会出现"群里说吃过了、私聊说还没吃"。
import { noteHerState, herStateLine } from './lib/her-ledger.js';

let api = null;
let timer = null;
let ticking = false;

// ★ 2026-10-24（02.md 2.1 收尾）：心跳句柄挂 globalThis 单例槽 —— 热重载出的新实例
//   才能接管并清掉旧实例起的心跳（旧实例的 deactivate 若没被调到，它闭包里的 timer
//   谁也够不着，会变成每 tickSeconds 多跑一份 tick，双实例竞争写 mood.json）。
const TIMER_SLOT = '__qqAgentSleepMoodTimer';
function stopHeartbeat() {
  const prev = globalThis[TIMER_SLOT];
  if (prev) { try { clearInterval(prev); } catch { /* ignore */ } globalThis[TIMER_SLOT] = null; }
  if (timer) { try { clearInterval(timer); } catch { /* ignore */ } timer = null; }
}

/**
 * 把框架给的 `api.log / api.warn` 接到**核心文件日志器**上。
 *
 * ⚠️ 为什么必须接：plugin-loader.js:116-118 里，插件的日志是
 *      `log: (...args) => console.log('[skill:'+skillId+']', ...args)`
 *    —— **不走文件日志器**。而 logger.js 只做单向镜像（落盘 + console），
 *    console 的输出**不会**被反收进文件。Electron GUI 下 stdout 没人接，
 *    于是插件的日志等于丢了（实测：日志文件里零条 `[skill:sleep-mood]`）。
 *
 *    这对本插件是硬伤：入站被拦 = **不建会话 = GUI 会话列表里没有任何痕迹**，
 *    "她怎么不回消息"完全看不出来。走 coreLogger 还额外白赚两件事：
 *      · 进 logger 的内存环形缓冲 → GUI「日志」页签实时可见（SSE 推送）；
 *      · 与其他模块的日志同格式落盘，排查时一条时间线。
 *
 * 安全性：框架的 api 方法**全是箭头函数**（不依赖 `this`），所以浅拷贝后覆盖
 * log/warn 不会丢绑定。落盘失败时退回原来的 console 实现，不影响功能。
 */
function wrapApiLogging(a) {
  if (!a || typeof a !== 'object') return a;
  return {
    ...a,
    log: (...args) => {
      try { coreLogger.info('sleep-mood', ...args); } catch { try { a.log?.(...args); } catch { /* 忽略 */ } }
    },
    warn: (...args) => {
      try { coreLogger.warn('sleep-mood', ...args); } catch { try { a.warn?.(...args); } catch { /* 忽略 */ } }
    }
  };
}

/** 本轮各会话的睡眠闸判定结果（before-context 记，before-tool 用）。 */
const gateByChat = new Map();
/** 诊断：最近一次 before-context 的输入与决策（只给 debugGates 看）。 */
let lastDiag = null;
/** 她自己的发言时间戳（疲劳五段速率要用），只留最近 200 条。 */
let selfMsgTs = [];
// 注：SPUNK 的"他还嘴/她回嘴"判定**不用**她的原话 —— 见 before-context 的 ①b 块。
//     （第一版曾留过一份 `recentSelfTexts` 文本缓冲做"双向判定"，2026-10-11 实测判定过宽后删除：
//      让她自己的话参与触发 = 她演什么都能把自己点着，跑团里必然误伤。）

// ── GOODNIGHT-ECHO-FIX（2026-10-09）────────────────────────────────────────
// 场景：主人 @她说「晚安」→ 她回一句「晚安主人～」→ 自身状态机把这句里的「晚安」
// 当成"她自己宣布要睡" → 写 self-state.sleeping → 呼呼大睡。**这是回礼，不是宣告。**
// 对策：在 before-context（拿得到触发批）判断"本轮是不是别人在跟她道晚安"，是则开一个短窗；
// 窗内 after-tool 判自身状态前先把"晚安"类词**剥掉**再判。
// ★ 只剥道别词 —— 若她真说"晚安，我先去睡了"，"去睡"还在，照样判睡 ✓
const GOODNIGHT_ECHO_RE = /晚安|晚安安|安安|好梦/g;

// ── SLEEP-EVAL-GUARD（2026-10-10）──────────────────────────────────────────
// 现场（私聊 13:35）：对方说「我准备睡了」，她回了两句 ——「晚安 我接着扒饭了」和
//   「这回真去睡了啊」（说的是**对方**）。后者被 stateFromSelfText 判成"她自己要睡"，
//   而 13:35 正落在午休窗（12-15 点）⇒ 直接卧倒 45 分钟（self-state 写成"午后小睡"）。
// 病根两条：
//   ① SLEEP_STRONG_RE 里的「晚安」「去睡」**只认字面、不判主语** —— "说的是别人"那层
//      排除（SLEEP_OTHER_RE）**只有 WEAK 路径走**，STRONG 是裸奔的；
//   ② 她那句是**省主语的评价句**，连"你/他"都没有，谁都排不掉。
// 这层守卫在**入口**拦住"看着像宣告、其实在说别人"的句子。lib/self-state.js 已同步收紧，
// 但 lib 是静态 import、改它要重启 —— 这一层**热载即生效**，同时作为第二道保险。
// ⚠️ 判据必须与 lib 的 SLEEP_GOODNIGHT_RE / SLEEP_EVAL_RE 保持同一语义（改一处就要改另一处）。
const SLEEP_GOODNIGHT_WORD_RE = /晚安|安安|好梦/;
const SLEEP_EVAL_WORD_RE = /(这回|这次|倒是|果然|总算|终于|真去睡|真的去睡|真的睡)/;
const SLEEP_SELF_WORD_RE = /我/;
const SLEEP_SELF_SIGNAL_RE = /睡|困|眯|休息/;
/** 返回非空 = 这句可疑（在说别人 / 只是道别），**不该**据此判她自己要睡。 */
function sleepVerdictSuspect(text) {
  const c0 = String(text ?? '').split(/[,，。！？!?\n]/)[0] || '';
  if (!c0) return '';
  const hasSelf = SLEEP_SELF_WORD_RE.test(c0);
  // 道别词（晚安/好梦）：同句没有「我 + 睡/困/眯/休息」的自身信号 ⇒ 视为在跟别人道别
  if (SLEEP_GOODNIGHT_WORD_RE.test(c0) && !(hasSelf && SLEEP_SELF_SIGNAL_RE.test(c0))) {
    return 'goodnight-no-self';
  }
  // 评价语气（这回/果然/真去睡…）且句中无「我」⇒ 视为在评价别人
  if (SLEEP_EVAL_WORD_RE.test(c0) && !hasSelf) return 'eval-no-self';
  return '';
}
const STRIP_EDGE_PUNCT_RE = /^[\s，。、！？；：,.!?;:~～]+|[\s，。、！？；：,.!?;:~～]+$/g;
const GOODNIGHT_SIGNAL_RE = /晚安|晚安安|睡了|去睡|睡觉|困了|休息/;
const GOODNIGHT_ECHO_WINDOW_MS = 90_000;
let goodnightEchoUntil = 0;

/**
 * 本轮是不是"别人在跟她道晚安"（⇒ 她接下来那句「晚安」多半是回礼）。
 * 判据：触发批里有**非自己**的、非拍一拍的文本，命中道别词，**且 @了她**。
 * 要求 @ 是刻意的 —— 没 @她的晚安本来就唤醒不了她，谈不上"在跟她说话"。
 */
function detectGoodnightEcho(entries = [], { selfId = '', botName = '', selfNickname = '' } = {}) {
  for (const e of entries) {
    if (!e || e.self || e.isPoke) continue;
    const text = String(e.text || '');
    if (!text || !GOODNIGHT_SIGNAL_RE.test(text)) continue;
    try {
      if (atBot(text, { botName, selfNickname, selfId })) return true;
    } catch { /* 判定失败就当不是 */ }
  }
  return false;
}

/**
 * 【融合核心 ①】命令睡眠（原 sleep-mode 的模块级内存态）。
 *
 * 这是**外层闸**：开启后 orchestrator.suspendAll()，消息只存档不调度，
 * 模型根本不跑 —— 零 token。与 self-state.json 里的 sleeping **不是一回事**：
 *   · 命令睡眠 = 主人对机器人下的开关（"你先别说话"）；
 *   · 自然睡眠 = 她自己困了（写盘、跨重启、影响演出）。
 *
 * 存内存不存盘是**有意的**：防止"忘了关导致机器人永远沉默"（重启即自愈）。
 */
let commandSleep = false;
/**
 * 本轮触发批里"谁在说话"的快照（before-context 每轮刷新）。
 *
 * 为什么需要：`sleep_control` 工具那条路径**拿不到发言人身份** —— 宿主给工具 execute 的
 * ctx 只有 `chatKey / kind / chatId / chatName / model / provider / …`，**没有 senderId**。
 * 所以模型被谁说动都有可能调那个工具，光靠工具描述里写"当主人说…时使用"是软约束。
 * 这里用"这一轮主人在不在场"近似鉴权（工具在本轮 before-context 之后才执行，时序成立）。
 */
let turnSenders = [];
let turnOwnerSpeaks = false;
/** 睡眠·陪闹与低血旁白要用到"最近一条消息的发送句柄"（钩子里拿不到 sender）。 */
let lastSender = null;
// [[her-ledger]] 近况账本要靠它判"这句是群里说的还是私聊说的"：
// after-tool 的入参没有 chatKey，只能取最近一轮 before-llm-messages 记下的会话。
let lastChatKey = '';
let lastPlayClosingAt = 0;

const on = (v) => v !== false;

function settings() {
  try { return (api && typeof api.config === 'function' ? api.config() : null) || {}; } catch { return {}; }
}

/**
 * TRAVEL-SYNC：读「正在进行中的旅程」（只读 travel-whale 的群存档，见 lib/travel-sync.js）。
 * 关掉 `travelSync` 时永远返回 null ⇒ 完全退回原行为（显示她在家）。
 * 数据源 = `travelGroups` 里那几个群（默认主群）；留空则扫全部群存档，取最近出发的一趟。
 */
function travelActive(now = Date.now()) {
  try {
    const s = settings();
    if (s.travelSync === false) return null;
    return T.activeTrip(s.travelGroups, now);
  } catch { return null; }
}

/**
 * ★ 2026-10-13 HOME-SYNC：她**在庭院里**时的活动（"自己和旅伴们做点什么"）。
 * 数据同样是 travel-whale 写在自己存档里的 `homeAct`（**只读**，见 lib/travel-sync.js）。
 * 关掉 `travelSync` 时一并关掉 ⇒ 完全退回原行为（只显示"在家"）。
 * 取法：与 `travelActive` 相反 —— 哪个群**没有在途旅程**、且有 homeAct，就用那个。
 */
function homeActive(now = Date.now()) {
  try {
    const s = settings();
    if (s.travelSync === false) return null;
    const raw = s.travelGroups;
    const list = (Array.isArray(raw) ? raw : String(raw || '').split(/[\r\n,，、;；|]+/))
      .map((x) => T.normalizeChatKey(x)).filter(Boolean);
    for (const k of list) {
      const h = T.homeOf(k, now);
      if (h) return h;
    }
    return null;
  } catch { return null; }
}

/**
 * ★★ v3.7「刚吃完」：她**刚吃/喝下一样特产**之后的余味（"你现在刚吃完 xxx"）。
 *
 * 用户口径："希望食物类的在消耗之后能根据稀有度在【5/15/30】分钟内影响她的说话方式……
 * 喝了酒就会讲话醉醺醺的；吃了辣椒就会'呼…嗬…'地喘气"，并点名走这条路
 * （"直接往集成系统那边的路子走可能很顺，像'你现在刚醒'一样"）。
 * 数据同样是 travel-whale 写在自己存档里的 `foodAfter`（**只读**，见 lib/travel-sync.js）。
 * 取法与 `homeActive` 相同（遍历 `travelGroups`）；多个群都吃过就取**最近那次**。
 */
function foodAfterActive(now = Date.now()) {
  try {
    const s = settings();
    if (s.travelSync === false) return null;
    const raw = s.travelGroups;
    const list = (Array.isArray(raw) ? raw : String(raw || '').split(/[\r\n,，、;；|]+/))
      .map((x) => T.normalizeChatKey(x)).filter(Boolean);
    let best = null;
    for (const k of list) {
      const fa = T.foodAfterOf(k, now);
      if (fa && (!best || Number(fa.at) > Number(best.at))) best = fa;
    }
    return best;
  } catch { return null; }
}

// ── ★★ 2026-10-14「她的一天」流水 ①：**旅途瞬间**（给空间日记当素材）──────────────
//
// 用户口径："现在的旅途事件只是发生之后就会刷掉的随机事件……开个目录，把这些'发生'
//   在她身上的事情记录下来，提交给她作为日志的素材；先走一遍模型调用让她想想哪些开心、
//   哪些不爽、哪些无聊，筛过之后再投给日志。"
//
// ★★ 为什么必须**当时记**：`TRAVEL_STATES` 那 352 条（"蹲屋檐下躲雨"「被{mate}拽着躲进巷子」…）
//   是 `pickState()` 用**哈希**现算的（`chatKey|departAt|挡位|phase|world` → 取一条），
//   **任何地方都不落盘** ⇒ 20 分钟的挡位一过，那条就永远查不回来了（历史一条都没有）。
//   所以只能在这儿、在这个窗口里记一笔。
//
// ★ 落点 = **我们自己的 data**（`DATA_DIR/sleep-mood-moments.json`）——
//   不往 travel-whale 的存档里塞：那条纪律是"只读别人的存档"（见 lib/travel-sync.js 头注）。
//   素材只服务"写日记"，留两周足够；**筛完的"回忆"才是长期资产**（那本在 qqzone 那边）。
const MOMENTS_FILE = 'sleep-mood-moments.json';
const MOMENT_KEEP_DAYS = 14;

/** 内存里保一份（心跳 60 秒一次，没必要每轮都读盘）。进程重启后自动从盘里恢复。 */
let momentsCache = null;
function momentsState() {
  if (momentsCache) return momentsCache;
  try {
    const j = JSON.parse(nodeFs.readFileSync(nodePath.join(DATA_DIR, MOMENTS_FILE), 'utf8'));
    momentsCache = (j && Array.isArray(j.items)) ? j : { version: 1, items: [] };
  } catch { momentsCache = { version: 1, items: [] }; }
  return momentsCache;
}
function saveMoments(m) {
  try {
    nodeFs.writeFileSync(nodePath.join(DATA_DIR, MOMENTS_FILE), JSON.stringify(m));
    return true;
  } catch { return false; }
}

/** `travelGroups` → 群 chatKey 列表（与 homeActive / foodAfterActive 同一套解析）。 */
function travelKeys() {
  const raw = settings().travelGroups;
  const list = (Array.isArray(raw) ? raw : String(raw || '').split(/[\r\n,，、;；|]+/))
    .map((x) => T.normalizeChatKey(x)).filter(Boolean);
  if (list.length) return list;
  // 没配 travelGroups ⇒ 退回去扫存档目录里的群（她可能养在别的群）
  try {
    return nodeFs.readdirSync(T.chatsDir())
      .filter((f) => /^group_?\d/.test(f))
      .map((f) => `group:${f.replace(/^group_?/, '').replace(/\.json$/, '')}`);
  } catch { return []; }
}

/**
 * 记这一挡的旅途瞬间。**只在挡位翻页时追加**（同一挡调一百次也只记一条）。
 * 她不在路上（`tripOf` 返回 null）⇒ 什么都不做 —— "在家"那半由 travel-whale 记（各记各的池子）。
 * @returns {number} 这次新记了几条
 */
export function recordTravelMoments(now = Date.now()) {
  if (settings().travelSync === false) return 0;
  const keys = travelKeys();
  if (!keys.length) return 0;
  const m = momentsState();
  const added = [];
  const moodHits = [];                       // ★★ 2026-10-15：这一挡带心情标注的瞬间
  for (const key of keys) {
    let trip = null; let st = null;
    try {
      trip = T.tripOf(key, now);
      if (!trip) continue;                 // 这个群不在旅途里
      st = TS.pickState(trip, now);
    } catch { st = null; }
    if (!st) continue;
    // ⚠️ 判重只看**同一个群**的上一条（多群各记各的，不能互相顶掉）
    const mine = [...m.items].reverse().find((x) => x.key === key);
    if (mine && Number(mine.bucket) === Number(st.bucket)) continue;
    m.items.push({
      at: now, key, bucket: Number(st.bucket) || 0, id: String(st.id || ''),
      act: String(st.act || ''), detail: String(st.detail || ''),
      phase: String(st.phase || ''), world: String(st.world || ''),
      place: String(st.place || ''), mate: String(trip.companionName || '')
    });
    added.push(String(st.act || st.id || '?'));
    // ★★ 2026-10-15「旅途瞬间也影响心情」：这条瞬间带心情标注（TRAVEL_STATE_MOOD 表，
    //   或 leave／异世界初到的轻量推导）⇒ 收进来，落盘后统一结算。
    try {
      const mood = (typeof TS.stateMoodOf === 'function') ? TS.stateMoodOf(st) : null;
      if (mood && Object.keys(mood).length) {
        moodHits.push({ mood, act: String(st.act || st.id || '?') });
      }
    } catch { /* 判定失败不影响记录 */ }
  }
  if (!added.length) return 0;
  const cut = now - MOMENT_KEEP_DAYS * 86400000;
  m.items = m.items.filter((x) => Number(x.at) >= cut);
  saveMoments(m);
  try {
    coreLogger.info('sleep-mood', `[一天流水] 旅途瞬间 +${added.length}：${added.join(' / ')}`);
  } catch { /* 日志失败不影响记录 */ }
  // ★★ 结算心情：瞬间是**状态**不是事件 ⇒ delta 很小（±2~4，见 TRAVEL_STATE_MOOD），
  //   且只有带标注的条目才结算（大部分旅途瞬间保持中性）。引擎就在本插件 ⇒ 直接 stepMood。
  let settled = 0;
  for (const { mood, act } of moodHits) {
    try {
      const delta = { ...mood };
      const satisfaction = Number(delta.satisfaction) || 0;
      delete delta.satisfaction;
      const why = `旅途瞬间：${act}`;
      if (Object.keys(delta).length) {
        M.stepMood(delta, Object.fromEntries(Object.keys(delta).map((k) => [k, why])), engineCfg(), now);
      }
      if (satisfaction && typeof M.stepSatisfaction === 'function') {
        M.stepSatisfaction(satisfaction, engineCfg(), now);
      }
      settled += 1;
    } catch (e) { try { coreLogger.info('sleep-mood', `[旅途瞬间] 结算心情失败：${e?.message ?? e}`); } catch { } }
  }
  if (settled) {
    try { coreLogger.info('sleep-mood', `[旅途瞬间] 结算心情 ${settled} 条（幅度 ±2~4，轻量）`); } catch { }
  }
  return added.length;
}

/**
 * 【融合核心 ②】统一睡眠查询 —— 全插件唯一的"她现在算不算睡着"出口。
 *
 * 任何拦截判定都必须先问它，不允许各自去读 self-state.json 或 commandSleep，
 * 否则两套状态又会长出各自的判断分支（这正是融合要消灭的东西）。
 *
 * @returns {{sleeping:boolean, kind:'command'|'natural'|'none', status:string, what:string, reason:string}}
 */
function currentSleep(now = Date.now()) {
  if (commandSleep) {
    return { sleeping: true, kind: 'command', status: 'sleeping', what: '', reason: '命令睡眠（/睡觉）' };
  }
  let st = { status: 'awake', what: '' };
  try { st = S.readSelfState(now) || st; } catch { /* 状态坏了当醒着 */ }
  const status = String(st.status || 'awake');
  if (status === 'sleeping') {
    return { sleeping: true, kind: 'natural', status, what: String(st.what || ''), reason: '自然睡眠（她自己困了）' };
  }
  return { sleeping: false, kind: 'none', status, what: String(st.what || ''), reason: '' };
}

/**
 * 引擎期望的 cfg 形状是 `{ moodChain:{...}, selfState:{...} }`，
 * 未提供的键由引擎自己的 *_DEFAULTS 兜底 —— 所以这里只翻译插件级开关，
 * 不重复声明引擎那几百个默认值（重复声明反而会在上游改默认值时失同步）。
 *
 * ⚠️ 这 8 个模块的代码**已从 lib 里物理删除**（2026-10-11），所以下面这个循环现在
 * 只起**墓碑**作用：如果哪天有人把旧版 mood-chain.js 贴回来，这里仍会第一时间把它们
 * 钉成 enabled:false（旧版里 sisterFightDelta / sisterHelpGain / sisterMicroGain
 * 三个函数就漏了 enabled 判断，光靠开关并不保险）。
 */
const REMOVED_MODULES = ['love', 'lust', 'arousal', 'want', 'sister', 'solo', 'soloVoice', 'ownerHealth'];

// ── SINGLE-CHAR-WORDLIST-FIX（2026-10-10）────────────────────────────────────
// hasWord 是**子串匹配**（`t.includes(w)`），所以词表里任何「单字」都会大面积误伤。
// 用 **79503 条真实群语料**全量审计了当前**生效的四段**（mood / rage / spunk / jealousy；
// love·lust·arousal·want·sister·solo·soloVoice·ownerHealth 这 8 段已物理删除，
// 其词表不存在了，故不在范围内），修掉这些单字：
//   · mood.triggers.angry          「烦」「滚」「吵」→ 麻烦 / 回滚·摇滚·打滚 / 风扇吵（72% 的命中是误报）
//   · mood.spunk.triggerWords      「滚」→ 同上；★ spunk 是**双向判定且不受 requireAddressed 保护**，
//                                   群里一句「我回滚一下」就能把她推进吵架状态（最毒的一条）
//   · mood.jealousy.intimateWords  「头」「搂」「揉」→ 口头·外头·引用里的「她」被算成"他对别人亲密"，
//                                   误加吃醋；且该判据**同样不受 addressed 保护**，没有兜底
//   · mood.rage.snapWords          「哟」→「哎哟喂 / 怎么长大哟」全是语气助词（实测 31 条无一例外）
//   · mood.selfNegateWords         「想」→「想」在口语里无处不在，让 selfEvents 大面积**漏触发**
// **刻意保留**的单字：「呵」「啧」（啧嘴/单字嘲讽，语义明确率高，是本意）、「乖」（happy，低频且方向正确）。
//
// 落地两条路（缺一不可）：
//   ① lib/mood-chain.js 的**默认值**已同步改好 —— 治本，但 lib 是静态 import ⇒ 要**重启**才生效；
//   ② 这里额外 mutate 引擎的 MOOD_DEFAULTS —— moodChainConfig() 每次都 `{...MOOD_DEFAULTS.x}` 现展开，
//      所以改它**热载即生效**（`?t=` 只打入口，兄弟模块走 ESM 缓存，mutate 落在同一实例上）。
// ⚠️ 两处值必须一致（lib 默认值 == WORDLIST_FIXED）。
// ── SPUNK-FALSEPOSITIVE-FIX（★ 2026-10-11）──────────────────────────────────
// spunk 的触发词表比 rage 的「被骂」表**松得多**，而且按原设计**不受 addressed 保护**
// ⇒ 群里任何一句话都可能把她推进"吵架加速"状态。用 **87463 条真实存档**全量审计
// （`_qcheck/spunk-falsepositive-audit.py` 与 `-sim.py` 可复跑）：
//   原表命中 233 条 → 只删 4 个词就降到 40 条（−83%）。噪声全来自这四个：
//   · `笨蛋`  144 条（占 62%）—— 本群是**亲昵称呼**（「唉，笨蛋」「小笨蛋」「笨蛋糊狐」
//              指的是隔壁那只 bot），不是骂人；
//   · `妈的`   39 条 —— **几乎全是「妈妈的」的子串**（渡鸦妈妈 / G妈 / 「你妈妈讨厌你了」），
//              又一类 `t.includes(w)` 子串事故（与 10-10 那次单字事故同源）；
//   · `呵呵` / `无语` —— 无攻击性，纯口头禅。
// ⇒ 词表收紧后，**再叠一道"冲她说的"闸门**（见 before-context 的 spunk 块）：
//   剩下 14 条，且全部是 @她 + 真 hostile 的消息。
// ⚠️ 阈值 30 天然兼任去抖：单次命中只 +15（<30，无演出），8 分钟内第二次才跨过 ⇒
//    "一句玩笑"不会启动，"被连着怼两句"才启动。
const WORDLIST_FIXED = {
  angry: '好烦 烦死 烦人 真烦 讨厌 滚蛋 滚开 滚出去 闭嘴 啰嗦 死开 少管你 无聊 幼稚 恶心 笨死了 吵死 吵什么 别吵',
  snapWords: '呵 啧 就这？ 你行你上 说的就是你 关你什么事 少管闲事 你懂什么 不理你 行了吧 可真行 无语 懒得理你',
  spunk: '废物 白痴 智障 闭嘴 讨厌你 恨你 别理你 吵什么吵 烦死了 受够了',
  intimate: '抱抱 抱住 亲亲 亲一口 贴贴 蹭蹭 摸头 牵手 靠肩 膝枕 捏脸 摸摸',
  selfNegate: '如果 要是 假如 本来 打算 差点',
  // SAD-WORDLIST-FIX（2026-10-10）：删掉首词「算了」—— 本机 83246 条存档实测，
  // sad 词表共命中 167 条，其中「算了」独占 140 条（84%），且几乎全是日常口水话。
  sad: '不理你了 没意思 失望 委屈 讨厌我 讨厌我吗 不喜欢我了吗',
};

/** 把修正词表写进引擎的 MOOD_DEFAULTS（幂等；热载重跑也无害）。 */
function applyWordlistFixes() {
  try {
    const D = M.MOOD_DEFAULTS;
    if (!D || !D.mood) return;
    if (D.mood.triggers) D.mood.triggers.angry = WORDLIST_FIXED.angry;
    if (D.mood.triggers) D.mood.triggers.sad = WORDLIST_FIXED.sad;
    if (D.mood.rage) D.mood.rage.snapWords = WORDLIST_FIXED.snapWords;
    D.mood.selfNegateWords = WORDLIST_FIXED.selfNegate;
    if (D.mood.jealousy) D.mood.jealousy = { ...D.mood.jealousy, intimateWords: WORDLIST_FIXED.intimate };
    if (D.spunk) D.spunk.triggerWords = WORDLIST_FIXED.spunk;
  } catch { /* 改不动就退回 lib 默认值（重启后即修正） */ }
}
applyWordlistFixes();

// ── FATIGUE-INCREMENT-FIX（2026-10-10）─────────────────────────────────────
// 用户报"聊一上午疲劳就满，跑团更快，不像真人"。根因**不是参数**，是活跃加成被重复计分：
//   selfMsgTs 是只增不减的数组（上限 200 条），而 stepFatigue 每次心跳都把整个数组
//   重算一遍 ⇒ 今天她发了 594 条 ⇒ 数组恒满 ⇒ **每次心跳 +60**、心跳 60s 一次 ⇒ 秒满。
// 修法在 lib/mood-chain.js：改成「只计上次结算之后新增的发言」+ 活跃加成每小时封顶。
// 下面把三个数值参数再钉进引擎默认值，作为双保险。
// ⚠️ 为什么不用 engineCfg() 注入：moodChainConfig 的 cfg 逐键覆盖**只认已存在的数值键**，
//    而 actCapPerHour 是新键 ⇒ 注入不进去；只有 mutate MOOD_DEFAULTS 才能新增键。
const FATIGUE_TUNING = { msgGain: 0.1, denseBonus: 0.05, actCapPerHour: 6 };
function applyFatigueTuning() {
  try {
    const D = M.MOOD_DEFAULTS;
    if (!D?.fatigue || typeof D.fatigue !== 'object') return;
    // 守卫：只有 lib 已是新版（带 actCapPerHour）才注入。否则"入口热载了、兄弟模块
    // 还是旧 lib"会出现「参数调小了、重复计分的 bug 还在」的中间态，反而更难判断。
    // lib 是静态 import ⇒ 改它**必须重启**，这个守卫就是那条边界。
    if (typeof D.fatigue.actCapPerHour !== 'number') return;
    Object.assign(D.fatigue, FATIGUE_TUNING);
  } catch { /* 改不动就等重启（lib 默认值已同步改好） */ }
}
applyFatigueTuning();

// ── TRAVEL-SATISFACTION（2026-10-10）───────────────────────────────────────
// 满足感的上升来源原本全是特殊事件（R18 模块的结算加值）—— 本机不做，
// 于是 satisfaction 恒为 0，而派生量 `孤独感 = (sad + (100 − satisfaction)) / 2` 就带了
// **50 的结构性地板**（sad=0 时孤独感也是 50；线上实测 sad 72 / sat 0 / 孤独感 86 完全吻合）。
// lib 里补了一条**日常**来源：旅途中按小时累积满足感（stepSatisfactionTick，由心跳调用）。
// 这里把可调项钉进引擎默认值。
//
// ★★ 2026-10-13（TRAVEL-SAT-BASE）：累积 → **向平衡点靠拢**。用户口径："现在旅行会把满足感
//    顶满，这一条不改的话（随机事件影响心情）表现上就不会有任何变化。" —— 实测存档
//    `satisfaction.value` 长期 100，旧模型净 +8/h、12.5 小时就顶格 ⇒ 事件给的那几点全被
//    clamp 吃掉。lib 侧已改成"旅途中拉向 travelBase"，这里把两个旋钮接上设置项。
// ⚠️ 为什么 mutate 而不是 engineCfg 注入：`travelBase` 是**新键**，而 moodChainConfig
//    的 cfg 逐键覆盖只认已存在的数值键 ⇒ 注入不进去；且 satisfaction 是对象，
//    整对象替换会把其余默认值一起丢掉。
// ⚠️ 守卫：只有 lib 已是新版（带 travelBase）才注入。lib 是静态 import ⇒ 改它**必须重启**；
//    没重启时这里静默跳过，行为与改动前一致（不会出现"参数改了但功能不存在"的中间态）。
const SAT_TRAVEL_BASE_DEFAULT = 60;
const SAT_TRAVEL_PULL_DEFAULT = 4;
/**
 * 配置项取值：**把"没配"和"配了 0"分开**。
 * 本机栽过五次的老坑：`Number(null) === 0`、`Number('') === 0`、`isFinite(0) === true`
 * ⇒ `Number(x) || 默认` 会把合法的 0（= 关掉这条来源）当成"没配"。这里显式排除空值。
 */
function numOr(raw, dflt, min = 0, max = Number.MAX_SAFE_INTEGER) {
  if (raw === null || raw === undefined || raw === '') return dflt;
  const n = Number(raw);
  if (!Number.isFinite(n)) return dflt;
  return Math.max(min, Math.min(max, n));
}
function applySatisfactionTuning() {
  try {
    // ⚠️ 取的是 M.SATISFACTION_DEFAULTS，**不是 M.MOOD_DEFAULTS.satisfaction** ——
    //    满足感的默认表是独立对象（同 DEPRESS_DEFAULTS），不挂在 MOOD_DEFAULTS 上。
    //    第一版写成后者 ⇒ 读到 undefined、静默 return ⇒ 设置项完全不生效（验收时抓到）。
    const D = M.SATISFACTION_DEFAULTS;
    if (!D || typeof D !== 'object') return;                        // lib 还是旧版
    if (typeof D.travelBase !== 'number') {
      // ★ 过渡兼容（只有"入口已热载、lib 还没重启"这几个小时会走到这里）：
      //   旧 lib 只有单向累积 ⇒ 会把满足感一路顶回 100（本轮刚把它从 100 归到 60）。
      //   把速率设成 0，让它**停在原地**，至少不会再把已归位的值顶回去。
      //   重启后走下面那条新逻辑（向 travelBase 靠拢）。
      if (typeof D.travelPerHour === 'number') D.travelPerHour = 0;
      return;
    }
    const s = settings();
    D.travelBase = numOr(s.satTravelBase, SAT_TRAVEL_BASE_DEFAULT, 0, 100);
    D.travelPullPerHour = numOr(s.satTravelPullPerHour, SAT_TRAVEL_PULL_DEFAULT, 0, 60);
  } catch { /* 改不动就等重启（lib 默认值已同步改好） */ }
}

// ── JEALOUS-WORD-FIX（2026-10-10）─────────────────────────────────────────
// lib/mood-chain.js 的默认吃醋词表原本写作 `她也 cute 吗 她好 可 …`（本意是短语
// 「她也cute吗」「她好可爱」，但没加引号）→ 被 hasWord 按空格拆成单词，
// **`吗` 和 `可` 变成独立关键词**；而 hasWord 是子串匹配 ⇒ 主人任何含「吗/可」的话
// （吃了吗 / 可以 / 可爱 / 可是…）都触发吃醋，每轮 +step(30)+ownerBonus(15)=45，
// 而 jealous 的 decayMs 是 90 分钟才掉 30 ⇒ **涨远快于降 ⇒ 醋值常年顶在 100**
// （用户实测）。更荒谬的是「可爱」本该只加 happy，却同时被算成吃醋。
// 这里在**入口**覆盖一份修正词表：lib/ 是静态 import 的兄弟模块，改它要**重启**才生效；
// 而 cfg.moodChain.mood.triggers 会被 moodChainConfig **逐条覆盖**，所以走这里**热载即生效**。
// ⚠️ 两边词表必须保持一致（lib 的默认值也已同步改好）。
const JEALOUS_TRIGGERS_FIXED = '她也cute 她好可爱 别人也 姐姐好 妹妹好 你们聊 抱她 亲她 夸她';

function engineCfg() {
  const s = settings();
  if (!on(s.enabled)) return { moodChain: { enabled: false }, selfState: { enabled: false } };
  const moodChain = {
    enabled: true,
    // triggers.* 是引擎**唯一支持逐条覆盖**的一层（moodChainConfig 专门为它开了分支），
    // 所以吃醋与愤怒两张词表在这里再钉一次 —— 与 applyWordlistFixes() 的值一致，纯双保险。
    mood: { triggers: { jealous: JEALOUS_TRIGGERS_FIXED, angry: WORDLIST_FIXED.angry, sad: WORDLIST_FIXED.sad } }
  };
  for (const mod of REMOVED_MODULES) moodChain[mod] = { enabled: false };
  return {
    moodChain,
    selfState: { enabled: on(s.selfState) }
  };
}

/** 主人 QQ：优先用插件设置，其次软依赖 owner-identity 能力。取不到返回 ''。 */
function resolveOwnerQq() {
  const explicit = String(settings().ownerQq || '').trim();
  if (/^\d{5,12}$/.test(explicit)) return explicit;
  try {
    const r = api.capability('message.owner-check', {});
    if (r && Array.isArray(r.owners) && r.owners.length) return String(r.owners[0]);
    if (r && r.ownerId) return String(r.ownerId);
  } catch { /* 软依赖，没有就算了 */ }
  return '';
}

/** 口令串 → 词数组（空格 / 逗号 / 顿号 / 分号 / 换行分隔，与引擎其它词表同款写法）。 */
export function parseWakeWords(raw) {
  return String(raw || '')
    .split(/[\s,，、;；\n\r]+/)
    .map((w) => w.trim())
    .filter(Boolean);
}

/**
 * 指令关键词解析（COMMAND-KEYWORDS，2026-09-22 主人要求）。
 *
 * 原来是**单条精确指令**（`text.includes('/睡觉')`）—— 必须一字不差、还得带斜杠，
 * 手机上手打很不稳（漏个斜杠、多个空格就废）。改成**关键词组**：
 *   · 多个关键词用 空格/逗号/顿号/分号/换行 分隔（与 parseWakeWords 同款写法）；
 *   · 命中**任意一个**即触发 → 越短越容易命中（主人原话："比如提取 睡觉二字"）；
 *   · 兼容旧配置：解析结果为空时回退到老的 sleepCommand/wakeCommand 单条，
 *     所以老配置文件不改也能照跑（也能识别斜杠写法，因为 `睡觉` 是 `/睡觉` 的子串）。
 *
 * ⚠️ 与普通唤醒词（wakeWords）的区别，别混：
 *   · **本关键词 = 真的切换命令睡眠状态**（suspendAll/resumeAll），是"开关"；
 *   · wakeWords = 主人专项的"叫她起床"口令，改的是 self-state（自然睡眠）。
 *   两者都要求群内 **@机器人**（本关键词额外要求），避免路人随口两个字把机器人关掉。
 *
 * ⚠️ 误触发的代价不对称：关键词越短越容易中。
 *   「睡觉」在"我去睡觉了""你该睡觉了"里都会命中 ——
 *   所以 `sleepKeywords` 命中要求 **@机器人**；若还嫌敏感，就把它配长一点
 *   （如「睡觉吧 小鲸鱼睡觉」），或直接用 `lockWakeToOwner` 限定唤醒只能主人触发。
 */
export function parseKeywords(raw) {
  return parseWakeWords(raw);
}

/**
 * 关键词是否命中本批消息。
 * @param {string} text 消息文本
 * @param {string[]} words 关键词组（空数组 = 不命中）
 * @returns {string} 命中的那个词（'' = 未命中）—— 返回词本身便于日志写明"因何触发"
 */
export function keywordHit(text, words) {
  const t = String(text || '');
  if (!t || !Array.isArray(words) || !words.length) return '';
  for (const w of words) {
    if (w && t.includes(w)) return w;
  }
  return '';
}

/**
 * QUOTE-NO-MATCH（睡眠闸门版，2026-10-10 23:15 事故）
 *
 * 事故现场：主人**引用她自己刚说的话**（那句里含「睡了」）并 @她 ——
 *   `[引用 青色大肥鱼(QQ:2795168894)：行 睡了 明天还得接着逛] @青色大肥鱼`
 * 引用前缀把她**自己的原话**原样搬了进来，被 `keywordHit` 当成"指令"⇒ 当场倒头就睡、
 * 还发了固定模板的入睡应答。与 18:50 修的那个「引用参与情绪触发」是**同一类病**，
 * 但睡眠闸门是另一条代码路径（这里），当时没一起堵。
 *
 * 语义：**词表匹配只看「发言人自己说的话」**；`[引用 …]` 里那段是别人的话，不算指令。
 * ⚠️ 但"在跟她说话"（`atBot`）的判定继续用**原文** —— 引用她当然算在跟她说话。
 *
 * 实现优先委托 lib 的 `stripQuoteForMatch`（唯一实现）。它是静态 import 的兄弟模块，
 * **要重启才进内存**；重启前这里退回等价实现（同一条正则），行为完全一致。
 * （导出只为离线验收用，与 keywordHit 同惯例。）
 */
export function stripQuote(text) {
  const raw = String(text ?? '');
  if (!raw || !raw.includes('[引用')) return raw;
  if (typeof M.stripQuoteForMatch === 'function') {
    try { return M.stripQuoteForMatch(raw); } catch { /* 退回本地实现 */ }
  }
  let t = raw;
  for (let i = 0; i < 3; i += 1) {
    const next = t.replace(/\[引用\s[^\]]*(?:\][^\]]*)?\]/g, ' ');
    if (next === t) break;
    t = next;
  }
  return t.replace(/^\s*\]\s*/, '').replace(/\s+/g, ' ').trim();
}

/** 取关键词组：优先用户配置，配置为空则回退到旧的单条指令（兼容老配置）。 */
function keywordsOf(rawList, legacyCmd, fallback) {
  const parsed = parseKeywords(rawList);
  if (parsed.length) return parsed;
  const legacy = String(legacyCmd || '').trim();
  if (legacy) return [legacy];
  return fallback ? [fallback] : [];
}

/**
 * 主人起床口令匹配。
 *
 * 为什么不直接用引擎现成的 `isWakeCall`：
 *   · `isWakeCall` 认的是「喊醒词/接触词 **+ 被称呼**」—— 谁喊都行，但必须点名她。
 *     主人这条通道要的是**主人特权**：说了口令就算，不必 @ 她、不必带名字。
 *   · `isWakeCall` 只买到「这一轮不被拦住」，**并不改变状态**，所以喊完只是回一句，
 *     下一轮照样被拦。口令命中要的是**真的起床**：状态改 awake 并留下 wakeAt，
 *     于是接下来 30 分钟按"刚被叫醒、迷迷糊糊"演（这套注入引擎里本来就有）。
 *
 * 只认主人：群里别人喊口令不算，免得被人拿去当"叫醒开关"。
 *
 * @param {Array} entries 触发批消息
 * @param {string} ownerQq 主人 QQ（空 = 无法判定主人 → 直接不生效）
 * @param {string[]} words 口令词
 * @returns {{hit:string, text:string}|null} 命中的口令与那条原文
 */
export function ownerWakeHit(entries, ownerQq, words) {
  const owner = String(ownerQq || '').trim();
  if (!owner || !Array.isArray(words) || !words.length) return null;
  for (const e of Array.isArray(entries) ? entries : []) {
    if (!e || e.self) continue;                        // 她自己的话不算
    if (String(e.senderId || '') !== owner) continue;  // 只认主人
    const text = String(e.text ?? '');
    if (!text) continue;
    const hit = words.find((w) => text.includes(w));
    if (hit) return { hit, text };
  }
  return null;
}

/**
 * 判定本条消息是否 @了机器人（与核心指令禁言同口径）：
 * 文本里带 @昵称 / @botName，或带 CQ:at qq=自己 的段。
 */
function atBot(text, { botName = '', selfNickname = '', selfId = '' } = {}) {
  const src = String(text ?? '');
  if (!src) return false;
  if (selfNickname && src.includes(`@${selfNickname}`)) return true;
  if (botName && src.includes(`@${botName}`)) return true;
  if (selfId) {
    const esc = String(selfId).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const re = new RegExp(`\\[CQ:at(?:,[^\\]]*?)?qq=${esc}[^\\]]*\\]`);
    if (re.test(src)) return true;
  }
  return false;
}

/**
 * 【融合核心 ③】统一起床出口 —— 口令 / /起床 / 工具 全走这里。
 *
 * 为什么必须收口：原来两条起床路径各做各的（口令只改 self-state、
 * /起床 只做 resumeAll），于是"状态醒了但闸门还拦着"或"闸门开了但状态还在睡"
 * 必然出现其中一种。这里把三件事绑成一次原子操作：
 *   ① 清命令睡眠（外层闸）
 *   ② 把自然状态写 awake + wakeAt（内层闸 + 迷糊演出）
 *   ③ 清空**所有**已算好的闸门缓存
 *
 * @param {{byCommand?:boolean, reason?:string}} opts
 * @returns {{woke:boolean, wasCommand:boolean, wasNatural:boolean}}
 */
function wakeUp({ reason = '' } = {}) {
  const before = currentSleep();
  const wasCommand = commandSleep;
  let wasNatural = false;

  // ① 外层：命令睡眠解除
  commandSleep = false;

  // ② 内层：自然睡眠 → awake（保留原 at，清 what，写 wakeAt）
  try {
    const st = S.readSelfState();
    if (st.status === 'sleeping') {
      wasNatural = true;
      // ⚠️ 三个字段各有原因，别随手改：
      //   · at 保留**她原来那个**（与引擎自己的 markWoken 写法一致）：awake 下
      //     at 不参与过期计算，但"这个状态从何时开始"的语义要留住；
      //   · what 必须**清空**：睡前写进去的是"到点该睡了"这类 **note**，不是她
      //     在干的事。留着有两处害处 —— 唤醒演出会念成「（睡前在：到点该睡了）」，
      //     而且 awakeGraceMs 那条"你刚说过「X」"的提醒会把 note 当成她说的话；
      //   · wakeAt 必须写：演出靠它判"刚被叫醒"，30 分钟内按迷糊口吻说话。
      S.writeSelfState({ status: 'awake', what: '', at: st.at, wakeAt: Date.now() });
      // FATIGUE-STUCK-FIX：醒来时立刻按睡眠时长结算一次恢复，并清掉 sleptAt。
      // 引擎的 markFatigueSleep(false) 就是干这个的（内部调 stepFatigue{sleeping:true}）。
      // 不结算的话：她整夜睡着期间心跳的 sleeping 分支本会持续恢复，
      // 但"醒来"这一刻的状态切换就没人收尾，sleptAt 会一直留着旧值 ——
      // 下一次她再睡时又从头算，等于白睡。
      try { M.markFatigueSleep(false, Date.now()); } catch { /* 结算失败不致命 */ }
    }
  } catch { /* 状态写失败不致命：闸门仍会被清掉，她至少能说话 */ }

  // ③ ⚠️ 必须清掉**所有**已算好的闸门缓存。
  //    原因：before-tool 判的是「**任意**会话的闸门」（for...of gateByChat.values()），
  //    不是当前会话 —— 于是"A 群那轮把她判成睡着"留下的 {block:true}，
  //    会在主人于 B 私聊喊起床后**继续拦掉这一轮发送**：状态都改清醒了却发不出话，
  //    表现成"口令没生效"。这些闸门的前提（她在睡）此刻已经不成立，清掉即可，
  //    每轮 before-context 都会重新算。
  gateByChat.clear();

  return { woke: wasCommand || wasNatural, wasCommand, wasNatural, before, reason };
}

/** 上游 observeTrigger 要的是「取最近消息」的函数，不是数组。 */
function recentFn(ctx) {
  const store = ctx && ctx.store;
  if (!store || typeof store.recent !== 'function') return null;
  return (chatKey, opts) => store.recent(chatKey, opts);
}

// ── LOCAL-NAME-FIX（2026-10-10）─────────────────────────────────────────────
// 引擎 `isAddressedToSelf` 原来硬编码了一份固定名单（两个名字，语料里 0 命中）。
// 本机实际：她 =「青色大肥鱼／小鲸鱼」，隔壁那只被群友起哄的 bot =「黑发兽耳小狐娘／泠」。
// 判据含义 =「这句话在跟她说话」⇒ 情绪词表（requireAddressed）才生效。
// 群友爱拿她俩起哄，提到隔壁那只时她也该有反应，**所以"提到名字就绕过词表保护"这个机制刻意保留**。
// 名单在这里给全（引擎侧只留「妹妹/姐姐」泛称兜底）—— 改这里**热载即生效**，不用重启。
// 默认值取自语料实测：大肥鱼 10106 / 小狐娘 463 / 小狐狸 348 / 泠 176 / 妹妹 36 / 姐姐 54 条。
const DEFAULT_ADDRESS_NAMES =
  '青色大肥鱼 大肥鱼 小鲸鱼 黑发兽耳 小狐娘 小狐狸';
// ⚠️ 2026-10-10 用户裁掉两类：
//   · 「泠」= 隔壁那只 bot 的**旧名**，而且**另一个群里有个真人 ID 里带「泠」** ⇒ 会误伤。
//   · 「妹妹」「姐姐」= 泛称，用词频率高、指代不清（群友可能在叫别人）⇒ 整类去掉。

/** 她的各种称呼：群名片 + botName + 额外名单（设置 `addressNames`，留空 = 只用前两者）。 */
function selfNamesOf(ctx) {
  const base = [ctx && ctx.selfNickname, ctx && ctx.botName]
    .map((v) => String(v || '').trim())
    .filter(Boolean);
  // 只有"设置里根本没这一项"才用默认；显式清空（空串）= 真的不要额外名单。
  const raw = settings().addressNames;
  const extra = parseWakeWords(raw === undefined || raw === null ? DEFAULT_ADDRESS_NAMES : raw);
  return [...new Set([...base, ...extra])];
}

/** 安全调用引擎的注入块生成器；返回非空字符串才收。 */
function block(out, fn, ...args) {
  try {
    const t = fn(...args);
    if (t && String(t).trim()) out.push(String(t).trim());
  } catch { /* 单个注入块失败不影响其它块 */ }
}

// ══════════════════════════════════════════════════════════════════════════
// 生命周期
// ══════════════════════════════════════════════════════════════════════════


function dashboardFile() {
  return nodePath.join(ROOT, 'ui', 'mood-dashboard.json');
}

function seedMoodIfEmpty(now = Date.now()) {
  try {
    const st = M.readMoodChain(now) || {};
    const moods = st.moods || {};
    const hasMood = Object.keys(moods).some((key) => {
      const raw = moods[key];
      const value = raw && typeof raw === 'object' ? (raw.level ?? raw.value) : raw;
      return Number(value) > 0;
    });
    if (hasMood || st.moodSeededAt) return false;
    const hour = new Date(now).getHours();
    const base = { happy: 50, excited: 30, angry: 0, jealous: 0, sad: 0 };
    if (hour >= 6 && hour < 12) {
      base.happy = 58; base.excited = 38;
    } else if (hour >= 12 && hour < 18) {
      base.happy = 55; base.excited = 42;
    } else if (hour >= 18 && hour < 23) {
      base.happy = 50; base.excited = 30;
    } else {
      base.happy = 42; base.excited = 18; base.sad = 8;
    }
    st.moods = moods;
    for (const [key, value] of Object.entries(base)) {
      if (!st.moods[key]) st.moods[key] = { level: value, why: '启用心情系统时自动设定', at: now };
    }
    st.moodSeededAt = now;
    return M.writeMoodChain(st);
  } catch {
    return false;
  }
}

function dashboardSnapshotBase() {
  const now = Date.now();
  const cfg = engineCfg();
  const snap = M.moodSnapshot(cfg, now);
  let self = { status: 'awake', what: '', at: 0 };
  try { self = S.readSelfState(now) || self; } catch { /* 忽略 */ }
  // TRAVEL-SYNC：她正在外面旅行时，把"人在哪"叠加到展示层 ——
  // self.what 原地换成旅行描述（现有 UI 读的就是它，零改动即可显示），
  // 原值留在 self.whatBase；结构化信息另放 self.travel。
  const selfOut = { status: String(self.status || 'awake'), what: String(self.what || ''), at: Number(self.at) || 0 };
  try {
    const tv = travelActive(now);
    if (tv) {
      selfOut.whatBase = selfOut.what;
      selfOut.what = T.travelShort(tv, now);
      selfOut.travel = T.travelPublic(tv, now);
    } else {
      // ★ 2026-10-13 HOME-SYNC：没出远门 ⇒ 看看她此刻在**自家院子**里做什么。
      //   没有就什么都不做（退回原来的"在家"说法）—— 绝不让面板开天窗。
      const hv = homeActive(now);
      if (hv) {
        selfOut.whatBase = selfOut.what;
        selfOut.what = T.homeShort(hv);
        selfOut.home = T.homePublic(hv, now);
      }
    }
  } catch { /* 读不到旅行状态就按原样显示，绝不影响面板 */ }
  const sleep = currentSleep(now);
  const clamp = (value) => {
    const n = Number(value);
    return Number.isFinite(n) ? Math.max(0, Math.min(100, Math.round(n))) : 0;
  };
  const moods = snap.moods || {};
  const happy = clamp(moods.happy);
  const excited = clamp(moods.excited);
  const angry = clamp(moods.angry);
  const jealous = clamp(moods.jealous);
  const sad = clamp(moods.sad);
  const fatigue = clamp(snap.fatigue);
  const spunk = clamp(snap.spunk);
  const depress = clamp(snap.depress);
  const satisfaction = clamp(snap.satisfaction);
  const derived = {
    energy: 100 - fatigue,
    stress: Math.round((angry + sad + fatigue) / 3),
    stability: 100 - Math.round((angry + jealous + sad + depress) / 4),
    focus: 100 - Math.round((fatigue + spunk) / 2),
    health: 100 - Math.round((fatigue + depress + spunk) / 3),
    comfort: Math.round((happy + satisfaction + (100 - depress)) / 3),
    loneliness: Math.round((sad + (100 - satisfaction)) / 2),
    security: 100 - Math.round((jealous + sad + depress) / 3),
    social: Math.round((happy + excited + satisfaction) / 3)
  };
  const item = (key, label, icon, value, tone, derivedItem) => ({
    key, label, icon, value: clamp(value), tone: tone || 'neutral', derived: !!derivedItem
  });
  const items = [
    item('happy', '心情值', '💗', happy, 'good'),
    item('energy', '精力值', '⚡', derived.energy, 'good', true),
    item('fatigue', '疲劳度', '😴', fatigue, 'bad'),
    item('stress', '压力值', '😰', derived.stress, 'bad', true),
    item('stability', '情绪稳定', '🧘', derived.stability, 'good', true),
    item('focus', '专注力', '🎯', derived.focus, 'good', true),
    item('satisfaction', '满足感', '🫶', satisfaction, 'good'),
    item('depress', '抑郁度', '🌧️', depress, 'bad'),
    item('excited', '兴奋度', '✨', excited, 'good'),
    item('angry', '生气值', '😤', angry, 'bad'),
    item('jealous', '吃醋值', '💔', jealous, 'bad'),
    item('sad', '难过值', '😢', sad, 'bad'),
    item('spunk', '吵架速度', '🔥', spunk, 'bad'),
    item('health', '健康值', '❤️', derived.health, 'good', true),
    item('comfort', '舒适度', '🛋️', derived.comfort, 'good', true),
    item('loneliness', '孤独感', '🫂', derived.loneliness, 'bad', true),
    item('security', '安全感', '🛡️', derived.security, 'good', true),
    item('social', '社交需求', '💬', derived.social, 'neutral', true)
  ];
  return {
    ok: true,
    at: now,
    enabled: !!api && on(settings().enabled),
    commandSleep,
    sleep,
    self: selfOut,
    dominant: snap.dominant
      ? { emotion: snap.dominant.emotion, word: snap.dominant.word, level: clamp(snap.dominant.level) }
      : { emotion: 'calm', word: '平静', level: 0 },
    moods: { happy, excited, angry, jealous, sad },
    meters: { fatigue, spunk, depress, satisfaction },
    items
  };
}

/**
 * 对外快照 = 引擎原有字段 + 三大系统汇总（生命值 / 压力池 / 陪闹 / 清空计划 / 变化日志）。
 *
 * 导出名保持不变：`providers['mood.dashboard']`、`publishDashboard()`、控制台「心情」页
 * 都读这个名字，所以这里只是**包一层**（原实现改名为 dashboardSnapshotBase）。
 */
export function dashboardSnapshot() {
  const base = dashboardSnapshotBase();
  const now = Date.now();
  try {
    const s = settings();
    const snapLike = {
      moods: base.moods || {},
      fatigue: base.meters?.fatigue,
      spunk: base.meters?.spunk,
      depress: base.meters?.depress,
      satisfaction: base.meters?.satisfaction
    };
    base.hp = H.hpSummary({ settings: s, snap: snapLike, sleeping: !!base.sleep?.sleeping, now });
    base.systems = {
      sleep: { sleeping: !!base.sleep?.sleeping, kind: base.sleep?.kind || 'none', what: base.sleep?.what || '' },
      mood: { dominant: base.dominant || null, moods: base.moods || {}, meters: base.meters || {} },
      hp: { value: base.hp?.value ?? 0, max: base.hp?.max ?? 0, percent: base.hp?.percent ?? 0, weak: !!base.hp?.weak, critical: !!base.hp?.critical }
    };
    base.favor = F.favorLinkSummary({ settings: s, now });
    base.systems.favor = {
      enabled: !!base.favor?.enabled,
      hpBonus: !!base.favor?.hpBonus,
      lastCount: Array.isArray(base.favor?.last) ? base.favor.last.length : 0
    };
    base.version = '1.1.1-favor';
  } catch (e) {
    try { api?.warn?.('快照扩展失败', e?.message ?? e); } catch { /* 忽略 */ }
  }
  return base;
}
function publishDashboard(extra = {}) {
  try {
    const payload = { ...dashboardSnapshot(), ...extra, publishedAt: Date.now() };
    const file = dashboardFile();
    const tmp = file + '.tmp';
    nodeFs.mkdirSync(nodePath.dirname(file), { recursive: true });
    nodeFs.writeFileSync(tmp, JSON.stringify(payload, null, 2), 'utf8');
    nodeFs.renameSync(tmp, file);
  } catch (e) {
    try { api?.warn?.('心情面板快照写入失败', e?.message ?? e); } catch { /* 忽略 */ }
  }
}

export function setup(a) {
  // 接管日志：让本插件的 log/warn 真正落盘并进 GUI 日志页（见 wrapApiLogging）
  api = wrapApiLogging(a);
  try {
    M.migrateStateOnce();
  } catch (e) {
    api.warn('状态迁移失败（不影响使用）', e?.message ?? e);
  }
  registerMoodTools(a);
  registerHpTools(a);
  registerFavorTools(a);
}

/** 同步返回：异步探测会在可用性链上被当成 truthy 而误报"生效中"。 */
export function available() {
  if (!on(settings().enabled)) return { ok: false, reason: '插件已关闭' };
  return { ok: true };
}

/** 起后台心跳。热重载会先 deactivate 再 setup，所以这里必须可重复起停。 */
export function activate() {
  stopHeartbeat();   // 先清旧槽（幂等）：含旧实例留下的那一份心跳
  try { seedMoodIfEmpty(); } catch { /* 初始化失败不影响主流程 */ }
  const s = settings();
  if (!on(s.enabled)) return;
  const everySec = Math.min(600, Math.max(15, Number(s.tickSeconds) || 60));
  timer = setInterval(() => { tick().catch(() => {}); }, everySec * 1000);
  timer.unref?.();
  globalThis[TIMER_SLOT] = timer;
  api.log(`睡眠情绪好感度生命值集成系统已启用：心跳 ${everySec}s，数据根 ${DATA_DIR}`);
  try {
    const hp = H.hpSummary({ settings: s, snap: M.moodSnapshot(engineCfg(), Date.now()) });
    api.log(`集成系统 v1.1.1：生命值 ${hp.value}/${hp.max} · 压力池 ${hp.stress}`
      + ` · 疲劳连锁 ${String(s.cascadeScheme || 'A+C')}`
      + ` · 陪闹 ${on(s.playAlongEnabled) ? `开（${Math.round(Number(s.playAlongMaxReplies) || 0)} 条）` : '关'}`
      + ` · 归零清空记忆 ${hp.wipe.enabled ? `已开启（${hp.wipe.mode}）` : '未开启'}`);
  } catch { /* 忽略 */ }
  publishDashboard();
  // 起床口令配了、但主人 QQ 认不出来 → 口令永远不会命中。这种"静默不生效"
  // 最难排查（人会以为是口令写错了），所以启动时就明确喊一声。
  if (parseWakeWords(s.wakeWords).length && !resolveOwnerQq()) {
    api.warn('配了「主人起床口令」但没能确定主人 QQ —— 口令不会生效。请在设置里填「主人 QQ 号」，'
      + '或安装 owner-identity 插件。');
  }
}

/**
 * 停心跳并**放弃命令睡眠**。
 *
 * ⚠️ 热重载/卸载时必须把 suspendAll 的后果交代清楚：命令睡眠是内存态，
 * 插件卸载后没有任何代码会去 resumeAll，机器人会**永久沉默**。
 * 所以这里主动恢复调度（若还挂着）。这是融合版特有的收尾 —— 原 sleep-mode
 * 是模块级 `sleeping` 变量，卸载时随模块一起消失且无人恢复调度。
 */
export function deactivate() {
  try { publishDashboard({ enabled: false }); } catch { /* ignore */ }
  stopHeartbeat();
  if (commandSleep) {
    try { api?.warn?.('插件被停用/重载，但命令睡眠还开着 —— 已自动恢复调度，避免机器人永久沉默'); } catch { /* 忽略 */ }
    try { resumeOrchestrator(); } catch { /* 忽略 */ }
  }
  commandSleep = false;
  gateByChat.clear();
}

export function dispose() {
  deactivate();
}

/**
 * 诊断出口：插件内部状态快照。
 *
 * 存在的理由：插件加载器用 `import(url + '?t=' + Date.now())` 动态导入（见
 * plugin-loader.js:301），**每次热重载都是一个全新的模块实例**。所以测试脚本
 * 里 `import()` 到的是另一个实例、拿不到这里的内部状态；工具也只是同一实例内的视图。
 * 这个函数让"到底拦没拦、为什么没拦"可以被外部直接问出来。
 */
export function debugGates() {
  const sleep = currentSleep();
  return {
    apiSet: !!api,
    settings: settings(),
    sleep: { ...sleep, commandSleep, cachedGates: gateByChat.size },
    gates: [...gateByChat.entries()].map(([chatKey, g]) => ({ chatKey, ...(g || {}) })),
    lastContext: lastDiag
  };
}

/**
 * 后台心跳。做三件事：
 *   ① 疲劳 —— 按五段速率推进（睡着才恢复）
 *   ② 愤怒速度线 —— 非战斗轮让它自然衰减
 *   ③ 全局自身状态机 —— 作息表推进 / 恢复池 / 户外自动回家
 * 情绪五维的衰减不在这里：引擎是**读时惰性结算**的
 * （decayAll 在 currentMood/stepMood/各 Block 内部跑），多算一次反而会重复扣。
 */
/** 疲劳增量（引擎的 stepFatigue 只管"自然推进"，这里给"被吵醒/玩闹结束"这类外加量用）。 */
function addFatigue(amount, why = '') {
  const add = Number(amount) || 0;
  if (!add) return false;
  try {
    const st = M.readMoodChain() || {};
    const cur = Math.max(0, Math.min(100, Math.round(Number(st?.fatigue?.value) || 0) + add));
    st.fatigue = { ...(st.fatigue || {}), value: cur, at: Date.now(), updatedAt: Date.now() };
    M.writeMoodChain(st);
    try { api?.log?.(`疲劳 ${add > 0 ? '+' : ''}${add} → ${cur}${why ? `（${why}）` : ''}`); } catch { /* 忽略 */ }
    return true;
  } catch { return false; }
}

/** 把引擎 stepMood 需要的增量落盘（hp 模块只算不写情绪存档）。 */
function applyMoodDeltas(deltas, why, cfg, now) {
  try {
    if (!deltas || !Object.keys(deltas).length) return false;
    M.stepMood(deltas, why || {}, cfg, now);
    return true;
  } catch { return false; }
}

/**
 * ★★ 2026-10-13「随机事件真正影响她的心情」—— 把旅行里发生的好事/坏事结算成心情。
 *
 * 用户口径："我希望那些随机事件能真正'影响'她的心情，而不是现在的'因为在旅行所以心情一直很好'
 *   —— 太一刀切了 —— 遇到好事心情上升，遇到坏事心情下降。"
 *
 * 数据方向：travel-whale 只写自己的存档（`moodEvents`），我们**只读**；
 *   游标存在我们自己这边（`lib/travel-sync.js` 的 readMoodCursor/writeMoodCursor）。
 * ⚠️ 情绪必须走引擎的 `M.stepMood`（**绝不能**直接写 mood.json —— 两个写入者会互相覆盖），
 *   满足感走 `M.stepSatisfaction`。
 */
function applyTravelEventMood(now = Date.now()) {
  if (!on(settings().travelEventMood)) return 0;
  const r = T.newTravelEvents(settings().travelGroups, T.readMoodCursor(), now);
  if (!r.events.length) return 0;                 // 没有新事件 ⇒ 游标也不动（不做空推进）
  const cfg = engineCfg();
  let n = 0;
  for (const ev of r.events) {
    const def = T.TRAVEL_EVENT_MOOD[ev.kind];
    if (!def) continue;
    const why = T.eventWhy(ev);
    try {
      // ★★ 2026-10-15「庭院活动也影响心情」：`home-act` 事件**自带 delta**（来自 home.js
      //   的 `HOME_ACT_MOOD` 表，幅度 ±2~4 比旅行事件轻一档）—— 有就优先用它；
      //   老 kind 没有 deltas 字段 ⇒ 行为逐字节不变。
      const raw = (ev.deltas && typeof ev.deltas === 'object' && Object.keys(ev.deltas).length)
        ? ev.deltas : (def.delta || {});
      const delta = { ...raw };
      const satisfaction = Number(delta.satisfaction) || Number(def.satisfaction) || 0;
      delete delta.satisfaction;                 // 满足感不走五维（stepSatisfaction 单独结算）
      if (Object.keys(delta).length) {
        M.stepMood(delta, Object.fromEntries(Object.keys(delta).map((k) => [k, why])), cfg, now);
      }
      if (satisfaction && typeof M.stepSatisfaction === 'function') {
        M.stepSatisfaction(satisfaction, cfg, now);
      }
      n += 1;
    } catch (e) { try { api?.warn?.('旅行事件结算心情失败', e?.message ?? e); } catch { /* 忽略 */ } }
  }
  T.writeMoodCursor(r.cursor);                    // 逐条都不抛 ⇒ 到这里就是全处理完了
  if (n) { try { api?.log?.(`旅行事件结算心情 ${n} 条（取到 ${r.total} 条，最旧的可能被截断）`); } catch { /* 忽略 */ } }
  return n;
}

/**
 * 恢复 / 作息事项的**情绪面**结算（★ 2026-10-11 接线：SATISFACTION-WIRING + DEPRESS-EXIT）。
 *
 * 病根：`S.settleRecovery()` 的返回值一直被**丢弃**（`if (pick) S.settleRecovery(pick, cfg);`
 * 只调不接），于是引擎里那两条"做了件舒服的事"的出口全都没接线 ——
 * 满足感不涨、抑郁度不解，两个数一个恒低一个只涨不跌。
 *
 * 本函数只接**情绪面**（满足感 +6 / 抑郁 −5，都由 `M.applyRecoveryMood` 一次做完）。
 * ⚠️ 刻意**不动**疲劳与开心 —— 那是 `applyRecoveryEffect` 的活，它还带着自己的未接线问题，
 *    这次不一起改，免得好几处数值同时动、出了问题分不清是谁。
 * ⚠️ 只对 effects 表里认得的事项生效（`S.settleRecovery(name)` 能返回东西才算），
 *    所以作息表里的「刷牙 / 煮面 / 睡觉」这类不会白送满足感。
 */
function settleActivityMood(name, cfg, now = Date.now()) {
  try {
    if (typeof M.applyRecoveryMood !== 'function') return null;   // 旧 lib（没重启）→ 静默跳过
    if (!S.settleRecovery(name, cfg)) return null;                // 不在 effects 表里 → 不算
    const r = M.applyRecoveryMood(cfg, now);
    if (r) {
      try {
        api?.log?.(`恢复事项「${name}」结算 → 满足感 ${Math.round(r.before.satisfaction)}→${Math.round(r.satisfaction)}`
          + `｜抑郁度 ${Math.round(r.before.depress)}→${Math.round(r.depress)}`);
      } catch { /* 忽略 */ }
    }
    return r;
  } catch { return null; }
}

/**
 * 生命值推进（每 tick 一次，挂在心跳里）。
 *
 * 职责分工：`lib/hp-system.js` 只做"数值与状态"（压力池、扣血、回血、归零判定），
 * 情绪增量与疲劳写回**必须**走引擎自己的 stepMood / mood.json —— 否则两个写入者
 * 会互相覆盖（引擎的情绪是"读时惰性结算 + 整写"的）。
 */
function hpTick(now = Date.now()) {
  const s = settings();
  if (!on(s.enabled) || !on(s.hpEnabled)) return null;
  const cfg = engineCfg();
  const sleep = currentSleep(now);
  const snap = M.moodSnapshot(cfg, now);
  const r = H.stepHp({
    settings: s,
    snap,
    sleeping: sleep.sleeping,
    now,
    tickSeconds: Number(s.tickSeconds) || 60
  });
  if (!r) return null;

  applyMoodDeltas(r.moodDeltas, r.why, cfg, now);

  // 疲劳反噬（压力池爆发）：hp 模块不碰 mood.json，这里补写
  if (Number(r.state?.burstFatigueBack) > 0) {
    addFatigue(Number(r.state.burstFatigueBack), '疲劳爆发反噬');
    r.state.burstFatigueBack = 0;
    H.writeHp(r.state);
  }

  for (const ev of (r.events || [])) {
    try { api?.log?.(`生命值：${ev.kind}${ev.value ? ` ${ev.value}` : ''}${ev.why ? ` —— ${ev.why}` : ''}`); } catch { /* 忽略 */ }
  }
  if (r.zeroed) handleZeroHp(now, r);
  return r;
}

/**
 * 生命值归零：强制休息 + 旁白 + （仅在双开关打开时）清空聊天记忆。
 *
 * ⚠️ 安全设计（用户明确要求"需要开关 + 管理员在设置界面确认"）：
 *   · `wipeOnZeroEnabled` 与 `wipeOnZeroArmed` **同时**为真才算开启（hpCfg.wipeEnabled）；
 *   · `wipeMode` 默认 `dry`：只列出"将会删什么"，一个文件都不删；
 *   · `execute` 模式下默认**先整包备份**（`wipeBackupFirst`）；
 *   · 无论哪种情况都写日志 + 告警，绝不静默删数据。
 */
function handleZeroHp(now, r) {
  const s = settings();
  try { api?.warn?.(`生命值归零（${Math.round(r?.state?.value ?? 0)}/${r?.state?.max ?? 0}）：强制进入睡眠休息`); } catch { /* 忽略 */ }

  // ① 强制休息：写成自然睡眠（命令睡眠是主人的开关，不动它）
  try {
    const st = S.readSelfState(now);
    if (st.status !== 'sleeping') {
      S.writeSelfState({ status: 'sleeping', what: '身体撑不住了', at: now });
      try { M.markFatigueSleep(true, now); } catch { /* 忽略 */ }
    }
  } catch { /* 忽略 */ }

  // ② 发一条虚弱旁白（拿得到最近会话就用它；拿不到就只记日志）
  try {
    const words = H.pickWords(s.hpWeakWords, 1);
    if (words.length && lastSender) confirmText(lastSender, lastChatKey, words[0]);
  } catch { /* 忽略 */ }

  // ③ 可选：清空全部聊天记忆（默认关闭 / 默认干跑）
  try {
    const cfgH = H.hpCfg(s);
    const plan = H.wipePlan({ settings: s, now });
    if (!cfgH.wipeEnabled) {
      api?.warn?.(`生命值归零：清空记忆未开启（wipeOnZeroEnabled=${s.wipeOnZeroEnabled} / wipeOnZeroArmed=${s.wipeOnZeroArmed}）——只发旁白，未删除任何文件`);
      return;
    }
    const since = now - (Number(H.readHp(now).wipeAt) || 0);
    if (since < cfgH.wipeCooldownMin * 60000) {
      api?.warn?.(`生命值归零：距上次清空不足 ${cfgH.wipeCooldownMin} 分钟，跳过本次（防止反复触发）`);
      return;
    }
    if (cfgH.wipeMode !== 'execute') {
      api?.warn?.(`生命值归零：当前是干跑模式（wipeMode=dry）——将会删除 ${plan.files} 个文件 / ${plan.bytes} 字节：`
        + plan.groups.map((g) => `${g.scope}:${g.files}`).join(' '));
      return;
    }
    const res = H.wipeExecute({ settings: s, now, dryRun: false });
    api?.warn?.(`生命值归零：已清空聊天记忆（${res.removed} 个文件 / ${res.bytes} 字节）`
      + `${res.backupDir ? `，备份在 ${res.backupDir}` : '（未备份）'}；建议重启应用以彻底生效`);
    if (on(s.wipeNotifyOwner) && lastSender) {
      confirmText(lastSender, lastChatKey, '（她昏过去了，醒来时把之前的事都忘干净了…）');
    }
  } catch (e) {
    try { api?.warn?.('归零清空记忆失败（未删数据）', e?.message ?? e); } catch { /* 忽略 */ }
  }
}
/**
 * 好感度联动（甜点层）：把 `lib/favor-link.js` 算出来的"一点点"落到引擎自己的存档上。
 *
 * 分工与 hp-system 一致：favor-link 只算（含每小时上限与每人冷却），
 * 情绪走 M.stepMood()、疲劳走 addFatigue()（都落在 mood.json），HP 只在显式开启时加一点点。
 */
function favorLinkTick(entries, s, cfg, now = Date.now()) {
  const r = F.favorTick({ api, entries, settings: s, now });
  if (!r) return null;
  const keys = Object.keys(r.deltas || {});
  if (keys.length) {
    const why = {};
    for (const k of keys) why[k] = '好感互动（甜点层）';
    try { M.stepMood(r.deltas, why, cfg, now); } catch { /* 情绪写失败不影响别的 */ }
  }
  if (Number(r.fatigueRelief) > 0) addFatigue(-Number(r.fatigueRelief), '好感互动（解乏）');
  if (Number(r.hpPercent) > 0) {
    try {
      const st = H.readHp(now);
      const max = Number(st.max) || 100;
      st.value = Math.min(max, Number(st.value) || 0 + max * Number(r.hpPercent) / 100);
      H.writeHp(st);
    } catch { /* 忽略 */ }
  }
  if (r.events?.length && on(s.favorLinkLogEnabled)) {
    for (const ev of r.events) {
      try {
        api?.log?.(`好感联动：${ev.name || ev.userId} ${ev.band}(${Math.round(ev.favor)})`
          + ` → ${Object.entries(ev.effects || {}).filter(([, v]) => v > 0).map(([k, v]) => `${k}+${Math.round(v * 10) / 10}`).join(' ')}`);
      } catch { /* 忽略 */ }
    }
  }
  if (r.events?.length) publishDashboard();
  return r;
}
async function tick() {
  if (ticking) return;
  ticking = true;
  try {
    const cfg = engineCfg();
    if (!on(settings().enabled)) return;
    const now = Date.now();

    // 【融合】她现在是不是睡着（疲劳恢复的前提）—— 统一走 currentSleep()。
    // 原来这里单独读 S.readSelfState，命令睡眠期间 fatigue 不会恢复
    //（因为命令睡眠不写 self-state）。融合后命令睡眠也算"睡着"，
    // 于是被主人关掉的这段时间她的疲劳照常恢复，语义更合理。
    const sleep = currentSleep(now);
    const sleeping = sleep.sleeping;

    try { M.stepFatigue({ selfMsgTs, sleeping, cfg, now }); } catch { /* 疲劳推进失败无所谓 */ }
    try { M.stepSpunk({ fighting: false, hisGapMs: 0, cfg, now }); } catch { /* 同上 */ }
    // TRAVEL-SATISFACTION：满足感的**周期结算**（自然衰减 + 旅途中按小时累积）。
    // 为什么放心跳：原版只在特殊事件里调 stepSatisfaction，而它每次都重置 `at`
    // ⇒ 没事件时衰减永不发生、日常也完全没有上升途径（详见 lib 的 stepSatisfactionTick）。
    // ⚠️ typeof 守卫：lib 是静态 import、要重启才生效；旧 lib 下这里静默跳过，
    //    行为与改动前一致，绝不会因为"入口热载了"而报错。
    try {
      if (typeof M.stepSatisfactionTick === 'function') {
        applySatisfactionTuning();                 // 设置项改动即时生效（每次读最新配置）
        let traveling = false;
        try { traveling = !!travelActive(now); } catch { traveling = false; }
        M.stepSatisfactionTick({ traveling, cfg, now });
      }
    } catch { /* 满足感结算失败不影响其它推进 */ }
    // ★★ 2026-10-13「随机事件影响心情」：把"路上真发生的好事/坏事"结算成情绪与满足感
    //   （用户口径：好事升、坏事降）。与上面那条是**两条独立通道**（一个写 moods、一个写 satisfaction）。
    try { applyTravelEventMood(now); } catch { /* 事件结算失败不影响其它推进 */ }
    // ★★ 2026-10-14「她的一天」流水 ①：把这一挡的**旅途瞬间**记一笔（详见 recordTravelMoments）。
    //   为什么放心跳里、不放渲染函数里：渲染函数每轮都跑、还可能跑好几次；
    //   这里按 20 分钟的挡位去重，一天最多 72 条 —— 干净、可观测、也不会把 IO 打满。
    try { recordTravelMoments(now); } catch { /* 记不上不影响任何推进 */ }
    // 生命值推进（疲劳连锁 A/B/C → 压力池爆发 → 低频低伤扣血 → 睡眠/平静回血 → 归零处理）
    try { hpTick(now); } catch (e) { try { api?.warn?.('生命值推进失败', e?.message ?? e); } catch { /* 忽略 */ } }

    // 【融合】命令睡眠期间不推进作息表 —— 否则她在"被关掉"的这段时间里
    // 自己掷中睡觉/做事，/起床 之后表现成"刚醒却又在忙着洗澡"，状态错乱。
    if (on(settings().selfState) && !commandSleep) {
      try {
        // 作息表：到点且掷中才换事项（引擎内部自带概率与冷却）。
        // ⚠️ 返回形状是 { pick, note, sleep? }，pick==='__sleep__' 表示"该睡了" ——
        //    不能整个展开写进状态，否则状态文件里会多出 pick/note 这些野字段。
        const pick = S.pickScheduled(cfg, now);
        if (pick && pick.sleep) {
          // 主人刚喊过起床 → 迷糊窗（默认 30 分钟）内不许按作息表自己睡回去。
          // 为什么必须挡：writeSelfState 是**整文件覆盖**，会把作息冷却字段
          //（recovery.lastPickAt）一起抹掉，于是"刚起床"紧接着就可能被掷中睡觉 ——
          // 表现成"我叫她起床，十分钟后她又睡了"，功能等于没生效。
          // 只挡"自己睡回去"这一条；她**自己说**要去睡（stateFromSelfText）照旧尊重。
          const st = S.readSelfState(now);
          if (!S.inWakeGrace(st, cfg, now)) {
            S.writeSelfState({ status: 'sleeping', what: String(pick.note || ''), at: now });
            // FATIGUE-STUCK-FIX：记入睡时刻到 mood.json 的 fatigue.sleptAt。
            // 不记的话疲劳恢复路径 `cur.sleptAt || cur.at || now` 会退化成 sleptMs=0，
            // 疲劳只增不减、永远钉在 100（详见 lib/mood-chain.js stepFatigue 的注释）。
            try { M.markFatigueSleep(true, now); } catch { /* 记不上不影响睡觉 */ }
          } else {
            lastDiag = { ...(lastDiag || {}), sleepSuppressed: 'wakeGrace' };
          }
        } else if (pick && pick.pick) {
          S.writeSelfState({ status: 'busy', what: String(pick.pick), at: now });
          // ★ 2026-10-11：作息表选中的**也是**"做了件事"，认得的事项一样攒满足感/解抑郁。
          settleActivityMood(String(pick.pick), cfg, now);
        }
      } catch { /* 忽略 */ }
      try {
        // 疲劳到阈值且闲着 → 掷一次恢复行为
        const st = S.readSelfState(now);
        const pick = S.pickRecovery(cfg, Number(st?.fatigue) || 0, now);
        if (pick) {
          S.settleRecovery(pick, cfg);
          // ★ 2026-10-11：把恢复事项的情绪面真正落盘（原来返回值被丢弃）
          settleActivityMood(pick, cfg, now);
        }
      } catch { /* 忽略 */ }
      try {
        // 出门太久没人理 → 自己回家
        const st = S.readSelfState(now);
        if (S.shouldAutoReturnHome(st, [], cfg, now)) {
          S.writeSelfState({ status: 'awake', what: '', at: now });
        }
      } catch { /* 忽略 */ }
    }
    publishDashboard();
  } catch (e) {
    try { api?.warn?.('心跳出错', e?.message ?? e); } catch { /* 连日志都失败就算了 */ }
  } finally {
    ticking = false;
  }
}

/** 拿到 orchestrator（能力 provider 里随入参传入；工具路径用缓存的最近一次）。 */
let lastOrchestrator = null;

function resumeOrchestrator() {
  try {
    return lastOrchestrator?.resumeAll?.({ limit: Math.max(1, Number(settings().resumeCount) || 20) }) ?? 0;
  } catch { return 0; }
}

/** 向触发群发一条确认消息（失败只记日志，不阻塞主流程）。 */
/**
 * 生成结果兜底清洗：单行、去包裹引号、限 60 字；**含机制词一律作废**（退回固定文案）。
 *
 * 为什么要有这一步：模型偶尔会把"要求"本身复述回来（"我会存档消息不回复…"），
 * 或者输出多行/带引号。宁可退回那条固定文案，也不要发出一句露馅的话。
 */
function sanitizeSleepLine(raw, maxLen = 60) {
  let t = String(raw ?? '').replace(/\s+/g, ' ').trim();
  if (!t) return '';
  t = t.replace(/^["'“”‘’「『【]+/, '').replace(/["'“”‘’」』】]+$/, '').trim();
  if (!t) return '';
  // 机制词一律作废：入睡侧防"我会存档消息不回复"，唤醒侧另加"会话/积压/条数"这类
  // 调度腔（她醒来的那句话里报数字最露馅）。
  if (/(存档|不回复|零 ?token|提示词|系统|指令|机制|代码|插件|模型|会话|积压|线程|条数)/.test(t)) return '';
  if (t.length > maxLen) return '';
  return t;
}

/** 只在第一次走 llm.js 兜底时报一次日志，避免每轮刷屏。 */
let llmFallbackLogged = false;
/** ② 兜底路径的模块加载器 —— 抽成变量是为了让验收脚本能注入假实现（别写死 import）。 */
let llmModuleLoader = () => import('../../src/llm.js');

/**
 * 调一次模型拿文案。**两条路，先官方后兜底**（2026-10-09 实测后重写，别退回单路）。
 *
 * ① 软依赖 `ai.ask`（指令前置提供）—— 但它实现的第一行是 `need(getHost())`，而那个 `host`
 *    只在**每条消息走到 app.js 的 `[[command-gateway:dispatch]]` 块**时才被赋值，
 *    并且**任何一次插件重扫都会让 CG 重新 import ⇒ host 归零**。
 *    本插件的入站闸门跑在那一步**之前** ⇒ 实测"重扫后的第一条消息"里
 *    **host 一直是 null**（重试 450ms 也等不到，日志实证 `ai.ask：核心句柄尚未就绪`）。
 * ② 直接走宿主的模型链路 `src/llm.js` 的 `chatCompletionWithRetry` ——
 *    这正是 `ai.ask` 内部调用的**同一个函数**（CG 的 `ctx.chat` 也是这么调的，见 app.js:1047），
 *    所以行为一致（同样的 key / 模型 / 代理 / 重试 / 计费），只是绕开了那个脆弱的 host 间接层。
 *    ⚠️ 这是**插件直接 import src/**（违反"插件不该 import src"的约定），属于本项目定制插件的
 *    务实取舍：上游若删/改名 `llm.js`，这里会安全退回固定文案，睡眠本身不受影响。
 *
 * @returns {Promise<{text:string, via:'ai.ask'|'llm.js'|'none', error?:string}>}
 */
async function callModel({ system = '', prompt = '', temperature = null, maxTokens = 0 } = {}) {
  // ① 官方路径：**只试一次**。重试没意义 —— host 要么已经就绪（立刻成），
  //    要么这一整条消息里都不会就绪（那就该走 ②，等的每一毫秒都是白等）。
  let askError = '';
  try {
    const r = await api?.capability?.('ai.ask', { system, prompt, temperature, maxTokens });
    const text = String(r?.text ?? '').trim();
    if (text) return { text, via: 'ai.ask' };
    askError = '返回空';
  } catch (e) {
    askError = String(e?.message ?? e);
  }
  // ② 兜底：直接用宿主的模型链路
  try {
    const { chatCompletionWithRetry } = await llmModuleLoader();
    const messages = [
      ...(system ? [{ role: 'system', content: system }] : []),
      { role: 'user', content: prompt }
    ];
    // ★ THINKING-BUDGET（2026-10-10 23:15 事故）：本机主模型是**思考模型** ——
    //   `reasoning_content` 先吃 token 预算。实测 maxTokens=120 时
    //   `completion_tokens=120 / reasoning_tokens=120 / finishReason='length' / content 全空`
    //   ⇒ 入睡应答**每次都退回固定模板**（日志原文：「入睡应答生成失败（llm.js）→ 退回固定文案：模型返回空」）。
    //   命中"被推理吃光"就放大预算重试一次；仍然空才算真失败。
    let r = await chatCompletionWithRetry({ messages, temperature, maxTokens });
    let text = String(r?.message?.content ?? '').trim();
    if (!text && String(r?.finishReason ?? '').toLowerCase().startsWith('len')) {
      const bigger = Math.max(512, (Number(maxTokens) || 0) * 4);
      const r2 = await chatCompletionWithRetry({ messages, temperature, maxTokens: bigger });
      const t2 = String(r2?.message?.content ?? '').trim();
      if (t2) {
        try { api?.log?.(`应答文案：首次被推理吃光预算（maxTokens=${maxTokens}）→ 用 ${bigger} 重试成功`); } catch { /* 忽略 */ }
      }
      r = r2;
      text = t2;
    }
    if (!llmFallbackLogged) {
      llmFallbackLogged = true;
      // 首次走兜底时把"为什么 ai.ask 不可用"记全，便于排障（含 dispatch 能力是否可达）。
      let capInfo = '';
      try {
        capInfo = `dispatch 能力=${api?.hasCapability?.('command.dispatch')} ai.ask 能力=${api?.hasCapability?.('ai.ask')}`;
      } catch { /* 忽略 */ }
      try {
        api?.log?.(`应答文案：ai.ask 不可用（${askError}）→ 已改用 src/llm.js 直连`
          + (capInfo ? `（${capInfo}）` : ''));
      } catch { /* 忽略 */ }
    }
    return text ? { text, via: 'llm.js' } : { text: '', via: 'llm.js', error: '模型返回空' };
  } catch (e) {
    return { text: '', via: 'none', error: String(e?.message ?? e) };
  }
}

/**
 * 让模型现场编一句「睡前应答」。
 *
 * 为什么：原来那条应答是**写死的模板**（"收到，我先睡一会儿～期间的消息我会存档但不回复。…"），
 * 读起来像系统通知、不像她在说话。主人明确要求改成让模型跑一次、说句自然的话。
 *
 * 契约与降级 —— **任何一步失败都退回固定文案，文案问题绝不影响睡眠本身**：
 *   · 走软依赖 `ai.ask`（京玉版指令前置提供）。注意它只是**一次裸模型调用**：
 *     不含会话上下文、不含人设，所以口吻靠设置里的 `sleepLineBrief`/`sleepLineExamples` 定；
 *   · `naturalConfirm === false` 或 `sleepLineBrief` 留空 → 直接不生成；
 *   · 返回结果要过 `sanitizeSleepLine()`，不合格也退回固定文案。
 *
 * @param {{triggerText?:string, fallback:string}} args
 * @returns {Promise<string>} 一定是可用的文案（最差就是 fallback）
 */
async function makeSleepLine({ triggerText = '', fallback = '' } = {}) {
  const s = settings();
  if (s.naturalConfirm === false) return fallback;
  const brief = String(s.sleepLineBrief || '').trim();
  if (!brief) return fallback;
  try {
    const examples = String(s.sleepLineExamples || '').trim();
    const r = await callModel({
      system: examples ? `${brief}\n\n语气参考（只用来定调，别照抄）：\n${examples}` : brief,
      prompt: `对方刚对你说：${triggerText || '（去睡吧）'}\n`
        + '只输出你要发出去的那一句话本身，不要前后缀、不要引号、不要解释。',
      temperature: 1,
      // ⚠️ 别调回 120：本机主模型是**思考模型**，reasoning 先把预算吃光 ⇒ content 全空、退回固定模板
      //    （2026-10-10 23:15 实测：mt=120 → reasoning_tokens=120、content=""）。
      maxTokens: 512
    });
    if (!r.text && r.error) {
      try { api?.warn?.(`入睡应答生成失败（${r.via}）→ 退回固定文案：${r.error}`); } catch { /* 忽略 */ }
    }
    return sanitizeSleepLine(r.text) || fallback;
  } catch {
    return fallback;
  }
}

/**
 * 让模型现场编一句「醒来应答」。
 *
 * 为什么：原来那条是写死的 `好的，我醒啦～正在补看 N 个群的最近消息。`，
 * 读起来同样是系统通知。主人要求跟入睡应答一起改成自然口吻。
 *
 * ⚠️ 与入睡应答的**关键差异**：唤醒时闸门是**放行**的（`return { blocked:false }`），
 * 所以主模型**这一轮也会自己说一句**。也就是说这条生成的是"被叫醒时先应的那一声"，
 * 之后她会照常聊天 —— 口吻要短促、迷糊、只一声，别像在汇报。
 * （"补看 N 个群"这类调度信息不写进正文，只留在日志里。）
 *
 * 降级：`naturalConfirm === false` / `wakeLineBrief` 留空 / 能力不可用 / 生成不合格
 * → 一律退回固定文案，唤醒本身不受影响。
 *
 * @param {{triggerText?:string, touched?:number, fallback:string}} args
 * @returns {Promise<string>}
 */
async function makeWakeLine({ triggerText = '', touched = 0, fallback = '' } = {}) {
  const s = settings();
  if (s.naturalConfirm === false) return fallback;
  const brief = String(s.wakeLineBrief || '').trim();
  if (!brief) return fallback;
  try {
    const examples = String(s.wakeLineExamples || '').trim();
    const hint = touched > 0
      ? `你睡着这段时间有 ${touched} 处会话在等你。如果顺口，可以带一句"好像有人找我"的意思，`
        + '但**不要报数字**，也不要提"会话/群/积压/条数"这类词。'
      : '你睡着这段时间没人找你，提不提都行。';
    const r = await callModel({
      system: examples ? `${brief}\n\n语气参考（只用来定调，别照抄）：\n${examples}` : brief,
      prompt: `对方刚把你叫醒，说的是：${triggerText || '（起床）'}\n${hint}\n`
        + '只输出你要发出去的那一句话本身，不要前后缀、不要引号、不要解释。',
      temperature: 1,
      // 同 makeSleepLine：思考模型下 120 会被 reasoning 吃光 ⇒ 512 起。callModel 里还有兜底重试。
      maxTokens: 512
    });
    if (!r.text && r.error) {
      try { api?.warn?.(`醒来应答生成失败（${r.via}）→ 退回固定文案：${r.error}`); } catch { /* 忽略 */ }
    }
    return sanitizeSleepLine(r.text, 40) || fallback;
  } catch {
    return fallback;
  }
}

/**
 * 进入命令睡眠的应答。
 *
 * ⚠️ 故意**不 await**（调用方 fire-and-forget）：闸门要立刻返回 blocked，
 * 一句话晚一两秒到没关系；而等模型可能要好几秒，会把"她到底睡没睡"的决定一起拖住。
 * 内部已全兜底，所以外面不需要 catch 逻辑，只留一条日志。
 */
async function sendSleepConfirm({ sender, chatKey, ok, wakeWord, triggerText }) {
  const fallback = ok
    ? `收到，我先睡一会儿～期间的消息我会存档但不回复。想叫醒我：@我 并发送「${wakeWord || '/起床'}」。`
    : '（睡眠模式已生效，但部分调度未暂停，可稍后重试）';
  const text = await makeSleepLine({ triggerText, fallback });
  confirmText(sender, chatKey, text);
}

/**
 * 起床应答（命令睡眠被唤醒关键词解除）。
 *
 * ⚠️ 同样**不 await**：调用方要立刻 `return { blocked:false }` 放行本轮，
 * 不能被一次模型调用拖住。生成失败就退回原来那条固定文案（含积压信息）。
 */
async function sendWakeConfirm({ sender, chatKey, touched = 0, triggerText }) {
  const fallback = touched > 0
    ? `好的，我醒啦～正在补看 ${touched} 个群的最近消息。`
    : '好的，我醒啦～（刚才好像没人找我）';
  const text = await makeWakeLine({ triggerText, touched, fallback });
  confirmText(sender, chatKey, text);
}

function confirmText(sender, chatKey, text) {
  if (!chatKey || !sender || !text) return;
  Promise.resolve()
    .then(() => sender.sendTextBatch(chatKey, [text]))
    .catch((e) => { try { api?.log?.(`确认消息发送失败：${e?.message ?? e}`); } catch { /* 忽略 */ } });
}

// ══════════════════════════════════════════════════════════════════════════
// 能力（给核心消费）
// ══════════════════════════════════════════════════════════════════════════

/**
 * 入站闸门（融合版）：把「命令睡眠」与「自然睡眠」两套判定合到一个函数里。
 *
 * 返回 { blocked } 的语义：blocked=true → 本批消息不送模型。
 *
 * 判定顺序：
 *   ① 命令睡眠中：
 *        · 命中 /起床（且鉴权通过）→ 真正起床 + resumeAll 补处理 → 放行本轮；
 *        · 命中主人起床口令 → 同上；
 *        · 否则 → blocked（除非 commandSleepHard=false 且这是"被喊醒"的消息）。
 *   ② 命令睡眠未开：
 *        · 命中 /睡觉（且 @了机器人）→ suspendAll + 标记命令睡眠 → blocked；
 *        · 她在自然睡眠且**没被喊醒** → blocked + 标记已读（SLEEP-IGNORE-FIX）；
 *        · 否则 → 放行。
 *
 * ⚠️ SLEEP-IGNORE-FIX（2026-09-22）：自然睡眠**也在这道闸拦**。
 *
 * 原设计把自然睡眠放在**内层闸**（before-tool 拦发送），理由是"让模型跑起来，
 * 才能演'被吵醒后迷糊回一句'"。但那意味着**每条消息都要先烧一遍 token**
 * 才会被拦下 —— 实测一次触发 23.3k tok / 2 次调用（模型被拦后还会换个工具
 * 再试一次，白烧两轮），而她睡 8 小时可能收到几十上百条。
 * 主人明确要求"完全底层的忽略"→ 改成入口就拦，模型**根本不跑**。
 *
 * 唤醒演出并没有丢：**喊醒词/接触词 + 被称呼**的消息仍然放行（见下面 (c)），
 * 她照样能用迷糊口吻回一句 —— 只是"普通消息"不再触发模型。
 * （喊醒词/接触词是主人 2026-09-17 明确要求保留的行为，不能砍。）
 *
 * ⚠️ SLEEP-UNREAD（2026-09-22，主人要求）：blocked 的同时**不标已读**，
 *   消息原样**保持未读**，她醒来后统一补看（详见下面 (d) 分支的注释）。
 *
 *   · 好处：睡着只是"听不到"，不是"没发生过" —— 她醒了能看到这段时间说了什么；
 *   · 代价：醒来那一刻会一次性 drainUnread 补处理积压，睡越久积压越多。
 *     所以忽略日志里会报出当前积压条数（`当前积压 N 条`），
 *     积压过多时可以考虑用命令睡眠（/睡觉 + /起床，带 resumeCount 上限）代替自然睡眠。
 *   · 注：一度改成 blocked 时就 markAllRead（防积压），后来又按主人要求改回保持未读。
 *
 * ‼️ 这是本插件**唯一**的能力名（单提供者）。原 mood-chain 还声明过
 *    `mood.snapshot`（给控制台"心情面板"的 live 字段供数），但那个机制在
 *    v0.4.1 里已经被整体移除了（manager.liveValuesOf 不存在、UI 无渲染器、
 *    routes.js 无引用）→ 声明它只会被审计判为"孤儿能力"。
 *    所以融合版不再声明该能力，数值改由 sleep-mood__mood_status 工具暴露（见下）。
 */
export const providers = {
  'message.inbound-gate': ({
    kind, chatKey, text = '', senderId = '', store, orchestrator, sender, onebot, botName = ''
  } = {}) => {
    // 记下最近一次拿到发送句柄的会话：钩子路径（after-tool）要发收尾台词时用它
    if (sender) lastSender = sender;
    if (chatKey) lastChatKey = chatKey;
    const c = settings();
    const resumeCount = Math.max(1, Number(c.resumeCount) || 20);
    const confirm = c.confirm !== false;
    const hard = c.commandSleepHard !== false;
    const selfNickname = onebot?.selfNickname || '';
    const selfId = onebot?.selfId || '';
    // ★ QUOTE-NO-MATCH：**所有词表匹配**都用这个（已剥掉 `[引用 …]` 里别人的话）。
    //   `atBot`/"在跟她说话"仍用**原文** text —— 引用她当然算在跟她说话。
    const matchText = stripQuote(text);

    // ── 关键词组（COMMAND-KEYWORDS）：多个关键词任一命中即触发 ──
    //    旧配置（单条 sleepCommand/wakeCommand）由 keywordsOf 自动回退兼容。
    const sleepWords = keywordsOf(c.sleepKeywords, c.sleepCommand, '/睡觉');
    const wakeWords = keywordsOf(c.wakeKeywords, c.wakeCommand, '/起床');

    // 记住 orchestrator：工具（sleep-mood__mood_reset 等）路径拿不到它，
    // 而唤醒之后要用它 resumeAll。能力 provider 每次入站都会被调用，足够新。
    if (orchestrator) lastOrchestrator = orchestrator;

    const atMe = atBot(text, { botName, selfNickname, selfId });
    const ownerQq = resolveOwnerQq();
    const isOwner = !!ownerQq && String(senderId) === ownerQq;
    // ── 陪闹窗口（睡眠·被吵醒）：心情好时她答应陪你闹一小会儿 ──
    // 窗口内**放行**（她正常回话），额度由 after-tool 逐条扣，用完了发收尾台词再回睡。
    // 命令睡眠（主人明确关掉她）期间不陪闹。
    try {
      const play = H.playActive(Date.now());
      if (play && !commandSleep && (!play.chatKey || String(play.chatKey) === String(chatKey))) {
        return { blocked: false };
      }
    } catch { /* 误判就按正常流程走 */ }

    // ── ① 命令睡眠中 ───────────────────────────────────────────────────
    if (commandSleep) {
      // 唤醒关键词：群里 @我 + 命中任一唤醒词（可选仅主人）
      // ★ QUOTE-NO-MATCH：用 matchText —— 有人引用一条含「起床」的老消息并 @她，不该把她叫醒。
      const wakeHit = kind === 'group' && atMe ? keywordHit(matchText, wakeWords) : '';
      const ownerLocked = c.lockWakeToOwner === true;
      if (wakeHit && (!ownerLocked || isOwner)) {
        const r = wakeUp({ reason: '命令唤醒关键词' });
        let touched = 0;
        try { touched = orchestrator?.resumeAll?.({ limit: resumeCount }) ?? 0; } catch (e) {
          try { api?.log?.(`唤醒失败：${e?.message ?? e}`); } catch { /* 忽略 */ }
        }
        try {
          api?.log?.(`命令睡眠解除（关键词「${wakeHit}」）：${touched} 个会话安排补处理（每群最新 ${resumeCount} 条）`);
        } catch { /* 忽略 */ }
        if (confirm) {
          // 应答文案：默认让**模型现编一句**（与入睡应答同一套机制：naturalConfirm 总开关
          // + 口吻说明 + 参考语气），失败/能力不可用自动退回固定文案。
          // 不 await —— 见 sendWakeConfirm 的注释（闸门要立刻放行，别被一次模型调用拖住）。
          sendWakeConfirm({ sender, chatKey, touched, triggerText: text })
            .catch((e) => { try { api?.log?.(`唤醒应答生成失败（已退回固定文案）：${e?.message ?? e}`); } catch { /* 忽略 */ } });
        }
        return { blocked: false };   // 本轮唤醒指令本身放行（让她能立刻应一声）
      }

      // 主人起床口令：优先于一切（**融合新增** —— 原来两个插件并存时，
      // 口令能改 self-state 却解不开 suspendAll，主人喊了没反应）。
      // ⚠️ 这一条**故意仍用原文 text**（不剥引用）：它是主人的显式命令、且已被 ownerQq 限定，
      //    误判代价只是"多醒一次"；剥掉反而可能漏掉主人引用着说话的口令。宁可偏宽松。
      if (kind === 'group' || kind === 'private') {
        const w = ownerWakeHit(
          [{ senderId, text, self: false }],
          ownerQq,
          parseWakeWords(c.wakeWords)
        );
        if (w) {
          wakeUp({ reason: '主人起床口令' });
          let touched = 0;
          try { touched = orchestrator?.resumeAll?.({ limit: resumeCount }) ?? 0; } catch { /* 忽略 */ }
          try { api?.log?.(`命令睡眠期间主人口令命中「${w.hit}」→ 已起床，补处理 ${touched} 个会话`); } catch { /* 忽略 */ }
          return { blocked: false };
        }
      }

      // 被喊醒式消息：默认仍然拦（省 token 是命令睡眠的全部意义）。
      // commandSleepHard=false 时放行，让模型按"被吵到"演一句。
      if (!hard && kind === 'group' && atMe) {
        // 判定交给引擎的 isWakeCall（要求被称呼 + 喊醒词/接触词）
        try {
          const wake = S.isWakeCall([{ senderId, text, isAtMe: true }], {
            selfNickname, botName, selfId, isPrivate: kind === 'private'
          });
          if (wake) {
            // 放行但**不解除**命令睡眠：只让她迷糊应一句，下一条还是静默。
            return { blocked: false };
          }
        } catch { /* 判定失败按拦住处理 */ }
      }

      return { blocked: true };
    }

    // ── ② 命令睡眠未开：检测开启关键词 ──────────────────────────────────
    // 必须 @机器人，防止陌生人随手两个字把机器人关掉（关键词越短越需要这道保险）。
    // ★ QUOTE-NO-MATCH（2026-10-10 23:15 事故的正面修复）：用 matchText，**被引用的原文不参与**。
    //   原样用 text 时，别人「引用她自己说过的一句『睡了』」+ @她 = 当场倒头就睡。
    const sleepHit = kind === 'group' && atMe ? keywordHit(matchText, sleepWords) : '';
    // ★★ 2026-10-09 修（用户实测报的致命 bug）：入眠路径原来**没有任何权限判定** ——
    //   任何群友 @她 带「睡觉 / 睡了 / 晚安」类词就立刻倒头就睡；而**唤醒**路径有
    //   lockWakeToOwner（本机已开）⇒ 两条路径组合起来是：
    //        「**谁都能让她闭嘴，但只有主人能叫醒她**」
    //   一句玩笑 = 全群静音直到主人出现，代价完全不对称。这里补上与唤醒侧对应的守卫。
    //
    //   ⚠️ 默认**锁**（写成 `!== false`，缺省即锁）：存在被静音的滥用面，安全默认必须偏严。
    //      确实想让群友也能关掉她，再把 lockSleepToOwner 显式配成 false（面板「总览」里有）。
    //   ⚠️ 主人 QQ 解析不出来时**照样锁**（fail-closed）：宁可这个功能暂时用不了，
    //      也不能退回到"谁都能静音"——下面那条日志会写明原因，便于排查。
    const sleepLocked = c.lockSleepToOwner !== false;
    if (sleepHit && sleepLocked && !isOwner) {
      try {
        api?.log?.(`忽略非主人（${senderId}）的睡眠关键词「${sleepHit}」：`
          + (ownerQq ? '仅主人可触发命令睡眠' : '当前未解析出主人 QQ，已按安全默认锁住（检查 ownerQq 配置）'));
      } catch { /* 忽略 */ }
    }
    if (sleepHit && (!sleepLocked || isOwner)) {
      let ok = false;
      try { ok = orchestrator?.suspendAll?.() === true; } catch (e) {
        try { api?.log?.(`进入睡眠失败：${e?.message ?? e}`); } catch { /* 忽略 */ }
      }
      commandSleep = true;
      // ★ FATIGUE-RECOVER-FIX（2026-10-10）：命令睡眠**也必须**记入睡时刻！
      //   原来只有自然睡眠会调 markFatigueSleep(true)，命令睡眠这条路什么都不记 ⇒
      //   整夜 sleptAt=0 ⇒ 恢复公式 `from = cur.sleptAt || cur.at` 退化成 `at`，
      //   而 `at` 每 2 分钟被心跳刷成 now ⇒ sleptMs≈0 ⇒ **睡一整夜疲劳一点都不恢复**
      //   （用户实测：@她说晚安睡了一晚，早上起来疲劳度还是满的）。
      //   醒来侧不用管 —— wakeUp() 里的 markFatigueSleep(false) 会按 sleptAt 结算。
      try { M.markFatigueSleep(true, Date.now()); } catch { /* 记不上不影响睡觉 */ }
      // 进入命令睡眠时清掉自然睡眠的闸门缓存：否则命令睡眠解除后，
      // 那些"她在睡"的旧判定会继续拦发送（陈旧缓存的经典坑）。
      gateByChat.clear();
      try {
        api?.log?.(`进入命令睡眠（关键词「${sleepHit}」）：消息照常存档但不处理；`
          + `@我并发送「${wakeWords[0] || '/起床'}」即可唤醒`);
      } catch { /* 忽略 */ }
      if (confirm) {
        // 应答文案：默认让**模型现编一句**（自然口吻），失败/能力不可用则自动退回固定文案。
        // 不 await —— 见 sendSleepConfirm 的注释（闸门要立刻返回，别被一次模型调用拖住）。
        sendSleepConfirm({ sender, chatKey, ok, wakeWord: wakeWords[0], triggerText: text })
          .catch((e) => { try { api?.log?.(`入睡应答生成失败（已退回固定文案）：${e?.message ?? e}`); } catch { /* 忽略 */ } });
      }
      return { blocked: true };
    }

    // ── ③ 自然睡眠（她自己困了）：睡着且没被喊醒 → **底层拦掉，模型根本不跑** ──
    //    这是主人明确要求的"完全底层的忽略"（SLEEP-IGNORE-FIX，见 provider 上方注释）。
    //    开关 ignoreWhileSleeping=false 可退回旧行为（只在内层闸拦发送）。
    const sleep = currentSleep();
    if (sleep.sleeping && sleep.kind === 'natural' && c.ignoreWhileSleeping !== false) {
      // (a) 唤醒关键词：@我 + 命中任一唤醒词（可选仅主人）→ 真的起床（写 awake + wakeAt + 清闸门）
      const wHit = kind === 'group' && atMe ? keywordHit(text, wakeWords) : '';
      if (wHit && (c.lockWakeToOwner !== true || isOwner)) {
        wakeUp({ reason: '自然睡眠中收到唤醒关键词' });
        try { api?.log?.(`自然睡眠中收到唤醒关键词「${wHit}」→ 已起床`); } catch { /* 忽略 */ }
        return { blocked: false };
      }

      // (b) 主人起床口令 → 真的起床（只认主人、不必 @她、不必带名字）
      const words = parseWakeWords(c.wakeWords);
      if (words.length) {
        const w = ownerWakeHit([{ senderId, text, self: false }], ownerQq, words);
        if (w) {
          wakeUp({ reason: '自然睡眠中主人起床口令' });
          try { api?.log?.(`自然睡眠中主人口令命中「${w.hit}」→ 已起床`); } catch { /* 忽略 */ }
          return { blocked: false };
        }
      }

      // (c) 被喊醒（喊醒词 / 接触词 **+ 被称呼**）→ 放行**这一轮**，让她迷糊回一句。
      //     状态**不改**（下一轮还是睡）—— 与引擎 isWakeCall 的原语义一致：
      //     "睡着了被吵到，迷糊回一句"。
      let woken = false;
      try {
        woken = S.isWakeCall([{ senderId, text, isAtMe: atMe }], {
          selfNickname, botName, selfId, isPrivate: kind === 'private'
        });
      } catch { /* 判定失败按"没喊醒"处理：宁可漏放一轮，也不要白烧 token */ }
      if (woken) {
        // 【v1.1.0】被喊醒不再是"无条件放行"：
        //   ① 掷一次"可被吵醒概率"（心情好更容易被叫起来，但同一窗口内被吵醒越多越难醒）
        //   ② 无论醒没醒，都按当次心情值给代价（疲劳 + 概率 debuff）
        //   ③ 醒了且心情够好 → 开"陪闹窗口"；否则只迷糊回一句
        const s2 = settings();
        const cfgW = engineCfg();
        const nowW = Date.now();
        const snapW = M.moodSnapshot(cfgW, nowW);
        // 好感度微调：亲近的人来吵「必陪闹」；反感及以下的人来吵「更难被叫醒、醒来更来气」
        const tune = F.favorWakeTuning({ api, settings: s2, senderId, now: nowW });
        const s2w = tune && tune.wakeFactor !== 1
          ? { ...s2, wakeChancePercent: Math.max(0, Number(s2.wakeChancePercent ?? 40) * tune.wakeFactor) }
          : s2;
        const s2d = tune && tune.debuffFactor !== 1
          ? { ...s2, wakeDebuffChanceBase: Math.max(0, Number(s2.wakeDebuffChanceBase ?? 25) * tune.debuffFactor) }
          : s2;
        try {
          if (tune) {
            const extra = tune.forcePlay
              ? ' → 亲近，必陪闹'
              : (tune.wakeFactor !== 1 ? ` → 更难醒(×${tune.wakeFactor})、更来气(×${tune.debuffFactor})` : '');
            api?.log?.(`被吵醒判定：${senderId} 好感 ${Math.round(tune.favor)}（${tune.band}）${extra}`);
          }
        } catch { /* 忽略 */ }
        const att = H.wakeAttempt({ settings: s2w, snap: snapW, now: nowW });
        const pen = H.wakePenalty({ settings: s2d, snap: snapW, count: att.count, now: nowW });
        if (pen.fatigue) addFatigue(pen.fatigue, att.allow ? '被吵醒' : '被吵醒（没醒）');
        applyMoodDeltas(pen.moodDeltas, pen.why, cfgW, nowW);

        if (!att.allow) {
          try {
            api?.log?.(`被吵醒失败（概率 ${att.chance}% / 本窗口第 ${att.count} 次）→ 继续睡`
              + `${Object.keys(pen.moodDeltas || {}).length ? '，且有点来气' : ''}`);
          } catch { /* 忽略 */ }
          if (on(s2.wakeFailReplyEnabled)) {
            const mumble = H.pickWords('唔…让我再睡会儿…\n（她哼了一声，把被子拉上来蒙住脸）\n（迷迷糊糊）……再五分钟', 1);
            if (mumble.length) confirmText(sender, chatKey, mumble[0]);
          }
          return { blocked: true };
        }

        const happy = Number(snapW?.moods?.happy) || 0;
        const cfgH = H.hpCfg(s2);
        const forcePlay = !!(tune && tune.forcePlay);
        if (cfgH.playAlongEnabled && (forcePlay || happy >= cfgH.playMoodThreshold) && cfgH.playAlongMaxReplies > 0) {
          H.startPlay({ settings: s2, chatKey, now: nowW });
          try {
            api?.log?.(`被吵醒了（第 ${att.count} 次 / 概率 ${att.chance}% / 心情 ${Math.round(happy)}）`
              + `→ 陪闹窗口开：最多回 ${cfgH.playAlongMaxReplies} 条，${cfgH.playWindowMin} 分钟内收尾`);
          } catch { /* 忽略 */ }
        } else {
          try {
            api?.log?.(`被吵醒了（第 ${att.count} 次 / 概率 ${att.chance}% / 心情 ${Math.round(happy)}）`
              + `→ 只迷糊回这一句（心情未达陪闹线 ${cfgH.playMoodThreshold}）`);
          } catch { /* 忽略 */ }
        }
        return { blocked: false };
      }

      // (d) 其余一律**忽略**：不建会话、不调模型、零 token。
      //
      // ⚠️ SLEEP-UNREAD（2026-09-22，主人要求）：这里**不标已读**，消息原样保持未读。
      //    语义：她睡着的这段时间只是"听不到"，不是"没发生过" —— 等她醒来
      //    （喊醒 / 口令 / 午睡到点 / 睡满 sleepAutoMs 自然醒），这些未读会被
      //    下一次触发一次性 drainUnread 取走，她**统一补看**这段时间说了什么。
      //
      //    为什么上一版标了已读：怕她睡 8 小时堆几百条未读、醒来一次全灌给模型。
      //    权衡后主人要"别把我的话吞掉"→ 保留未读。代价是醒来那一下会补处理积压，
      //    所以唤醒日志里会报出积压条数，方便判断要不要收（见 SKILL.md §9.5）。
      //
      //    顺带：不标已读也就**没有**"唤醒批被后来的普通消息标掉"这个竞态了，
      //    所以上一版的 wakeAllowUntil 保护窗已删除（不再需要）。
      //
      // 记一行日志：blocked 意味着**不建会话**，GUI 会话列表里不会留下任何痕迹 ——
      // 不记的话"她怎么不回消息"完全看不出来，容易误判成插件没生效。
      let backlog = 0;
      try { backlog = Number(store?.unreadCount?.(chatKey)) || 0; } catch { /* 数不到就不报条数 */ }
      try {
        api?.log?.(`睡眠忽略：${chatKey} 已拦（模型未调用，省一次 API）`
          + `，消息保持未读${backlog ? `（当前积压 ${backlog} 条，醒来补看）` : ''}`);
      } catch { /* 忽略 */ }
      return { blocked: true };
    }

    // ── ③.5 低血：可能"回不动话"，只发一条虚弱旁白（旁白词库由管理员在设置里改）──
    //    放在睡眠分支之后、正常放行之前；@我 发睡眠/唤醒关键词这类"操作指令"永远放行
    //    （否则她虚弱时会被彻底关死，连叫醒都叫不动 —— 那是最危险的失败模式）。
    try {
      const s3 = settings();
      if (on(s3.enabled) && on(s3.hpEnabled) && text) {
        const wr = H.weakRoll({ settings: s3, now: Date.now() });
        const isCmd = !!keywordHit(matchText, sleepWords) || !!keywordHit(matchText, wakeWords);
        if (wr.block && !(isOwner && isCmd)) {
          const words = H.pickWords(s3.hpWeakWords, 1);
          try {
            api?.log?.(`低血（${wr.value}/${wr.max}，${wr.critical ? '濒危' : '虚弱'}）：本轮不进模型，只发虚弱旁白`);
          } catch { /* 忽略 */ }
          if (words.length) confirmText(sender, chatKey, words[0]);
          return { blocked: true };
        }
      }
    } catch { /* 判定失败 → 正常放行 */ }
    // ── ④ 一切正常：放行 ──
    return { blocked: false };
  },

  // 控制台「心情」页的数据源；由插件写入静态 JSON，前端不经过 LLM。
  'mood.dashboard': () => dashboardSnapshot()
};

// ══════════════════════════════════════════════════════════════════════════
// 钩子
// ══════════════════════════════════════════════════════════════════════════

/**
 * 暴露给核心的插件内部句柄（`src/routes.js` 保存设置后会 await
 * `internals.onSettingsChanged || publishStatus`）——保存设置后立刻重算面板快照，
 * 控制台不用等下一次心跳；`hpPlan()` 供排查「将会删除什么」。
 */
export const internals = {
  publishStatus: () => { try { publishDashboard(); return true; } catch { return false; } },
  snapshot: () => { try { return dashboardSnapshot(); } catch { return null; } },
  // 入睡应答（自然口吻）的口子：给验收脚本用，能直接测"生成 / 清洗 / 降级"三步。
  sleepLine: {
    generate: (o) => makeSleepLine(o),
    sanitize: (t) => sanitizeSleepLine(t)
  },
  // 醒来应答（自然口吻）的口子：同上。
  wakeLine: {
    generate: (o) => makeWakeLine(o),
    sanitize: (t, n) => sanitizeSleepLine(t, n)
  },
  /** 验收脚本用：替换/还原 ② 兜底路径的模块加载器（不传 = 还原成真的 import src/llm.js）。 */
  setLlmLoader: (fn) => {
    llmModuleLoader = typeof fn === 'function' ? fn : (() => import('../../src/llm.js'));
    llmFallbackLogged = false;
  },
  /** 验收脚本用：给定 ctx 返回「在叫她」的完整名单（群名片 + botName + 设置）。 */
  addressNames: (ctx = {}) => { try { return selfNamesOf(ctx); } catch { return []; } },
  /** 验收脚本用：GOODNIGHT-ECHO 的判据（本轮是不是别人在跟她道晚安）。 */
  detectGoodnightEcho: (entries, opts) => detectGoodnightEcho(entries, opts),
  debug: () => {
    try {
      return {
        ...(debugGates() || {}),
        hp: H.hpSummary({ settings: settings(), snap: M.moodSnapshot(engineCfg(), Date.now()) }),
        play: H.playActive(Date.now())
      };
    } catch { return null; }
  },
  hpPlan: () => { try { return H.wipePlan({ settings: settings() }); } catch { return null; } },
  wipe: (opts = {}) => {
    try { return H.wipeExecute({ settings: settings(), dryRun: opts.dryRun !== false }); } catch (e) { return { ok: false, error: String(e?.message ?? e) }; }
  }
};
export const hooks = {
  /**
   * 时机：组装提示词之前 —— 对应上游 orchestrator 每触发轮的动作。
   * 做三件事：① 记录情绪/愤怒/吃醋增量 ② 处理主人起床口令 ③ 判定睡眠闸并存给 before-tool。
   *
   * ⚠️ 钩子有 5 秒超时且禁止网络/副作用；这里全部是本地正则与文件读写，安全。
   */
  'before-context'(ctx = {}) {
    const s0 = settings();
    lastDiag = {
      apiSet: !!api,
      enabled: s0.enabled,
      blockWhileSleeping: s0.blockWhileSleeping,
      chatKey: ctx.chatKey,
      kind: ctx.kind,
      entries: Array.isArray(ctx.triggerEntries) ? ctx.triggerEntries.length : -1,
      commandSleep
    };
    // 每轮都要**重置**"谁在说话"，且必须放在下面任何 return 之前 ——
    // 否则上一轮的值会残留，被 sleep-mood__sleep_control 工具读到（拿旧的主人在场骗过一次鉴权）。
    turnSenders = (Array.isArray(ctx.triggerEntries) ? ctx.triggerEntries : [])
      .filter((e) => e && !e.self)
      .map((e) => String(e.senderId || ''));
    turnOwnerSpeaks = false;
    if (!on(s0.enabled)) { lastDiag.earlyReturn = 'enabled=false'; return; }
    const cfg = engineCfg();
    const chatKey = String(ctx.chatKey || '');
    const entries = Array.isArray(ctx.triggerEntries) ? ctx.triggerEntries : [];
    const selfNames = selfNamesOf(ctx);
    const selfId = String(ctx.selfId || '');
    // 主人 QQ 只解析一次：口令匹配与 observeTrigger 的护亲判定用的是同一个值，
    // 解析两次会在软依赖（owner-identity 能力）上白跑一次。
    const ownerQq = resolveOwnerQq();
    // 供 sleep-mood__sleep_control 工具鉴权：这一轮主人有没有在说话（详见 turnSenders 的注释）。
    turnOwnerSpeaks = !!ownerQq && turnSenders.includes(ownerQq);

    // GOODNIGHT-ECHO-FIX：本轮是别人在跟她道晚安 → 开窗。
    // 窗口内 after-tool 判自身状态时会先剥掉她回礼的「晚安」，避免"回一句晚安就睡死"。
    try {
      if (detectGoodnightEcho(entries, {
        selfId,
        botName: String(ctx.botName || ''),
        selfNickname: String(ctx.selfNickname || (selfNames && selfNames[0]) || '')
      })) {
        goodnightEchoUntil = Date.now() + GOODNIGHT_ECHO_WINDOW_MS;
      }
    } catch { /* 忽略 */ }

    // ① 观察（冷落结算 → 情绪增量 → RAGE 三通道 → 吃醋）
    const recent = recentFn(ctx);
    // ★ 2026-10-11：抑郁度/满足感的变化**原来是完全静默的**（引擎不写日志、插件也没记），
    //   排查时只能翻 mood.json 或 session 存档。这里在调用前后各取一次快照打一行差异，
    //   让"恢复了抑郁 / 被冷落掉了满足感"这些通路在日志里可见。
    let snapBefore = null;
    try { snapBefore = M.moodSnapshot ? M.moodSnapshot(cfg, Date.now()) : null; } catch { snapBefore = null; }
    try {
      M.observeTrigger(entries, {
        recent,
        chatKey,
        cfg,
        ownerQq,
        selfNames,
        selfId
      });
    } catch (e) {
      try { api?.warn?.('observeTrigger 失败', e?.message ?? e); } catch { /* 忽略 */ }
    }
    try {
      const after = snapBefore && M.moodSnapshot ? M.moodSnapshot(cfg, Date.now()) : null;
      if (snapBefore && after) {
        const dd = Math.round((Number(after.depress) - Number(snapBefore.depress)) * 10) / 10;
        const ds = Math.round((Number(after.satisfaction) - Number(snapBefore.satisfaction)) * 10) / 10;
        if (dd || ds) {
          api?.log?.(`心情通路：抑郁度 ${snapBefore.depress}→${after.depress}`
            + `（${dd > 0 ? '+' : ''}${dd}）｜满足感 ${snapBefore.satisfaction}→${after.satisfaction}`
            + `（${ds > 0 ? '+' : ''}${ds}）`);
        }
      }
    } catch { /* 忽略 */ }

    // ①b 吵架速度（SPUNK）的**增长端** —— ★ 2026-10-11 接线 + SPUNK-FALSEPOSITIVE-FIX。
    //     原来这条线只降不涨（`spunkFightHit` 是孤儿导出、`stepSpunk` 只在心跳以
    //     fighting:false 调）。判定放在这里而不是 observeTrigger 里，是为了进宿主日志。
    //     三道闸（按 87463 条真实存档实测误判率逐级收窄，见 WORDLIST_FIXED 上方注释）：
    //       ① 词表已收紧（删 `笨蛋`/`妈的`/`呵呵`/`无语`）；
    //       ② **必须"冲她说的"**（私聊 / @她 / 正文含她的名字，复用引擎同一个判据）——
    //          跑团里 KP 与玩家的角色台词、群里对别人的吐槽，全都过不了这道闸；
    //       ③ 阈值 30 兼任去抖：单次命中只 +15（不演出），8 分钟内第二次才跨档。
    //     herLastGapMs = 他这条消息距**她上一条发言**的间隔（真正"贴着她回"）。
    //     ⚠️ 刻意**不用**"他两条消息之间的间隔"：群里/跑团习惯把一句话拆成短句连发，
    //        那个间隔恒 < 15s ⇒ 会变成永久 ×1.5 加成（用户 2026-10-11 指出的坑）。
    try {
      if (typeof M.spunkFightHit === 'function' && typeof M.stepSpunk === 'function' && M.isAddressedToSelf) {
        const addrCtx = { selfNames, selfId, isPrivate: chatKey.startsWith('private:') };
        const texts = entries
          .filter((e) => e && !e.self)
          .filter((e) => {
            // ② 闸门：只认"冲她说的"（过不了的直接不看 —— 跑团/吐槽全在这里被挡掉）
            try { return M.isAddressedToSelf(e, addrCtx); } catch { return false; }
          })
          .map((e) => M.stripQuoteForMatch(String(e?.text ?? '')))
          .filter(Boolean);
        if (texts.length && M.spunkFightHit(texts, cfg)) {
          let herLastGapMs = 0;
          try {
            const lastSelf = Number(selfMsgTs[selfMsgTs.length - 1]) || 0;
            if (lastSelf) herLastGapMs = Math.max(0, Date.now() - lastSelf);
          } catch { herLastGapMs = 0; }
          const r = M.stepSpunk({ fighting: true, hisGapMs: herLastGapMs, cfg, now: Date.now() });
          try {
            api?.log?.(`吵架判定命中（冲她说的攻击词；她 ${Math.round(herLastGapMs / 1000)}s 前说过话）`
              + ` → 吵架速度 ${Math.round(r?.value ?? 0)}${r?.fast ? '（已到演出档）' : ''}`);
          } catch { /* 忽略 */ }
        }
      }
    } catch (e) {
      try { api?.warn?.('吵架推进失败（已跳过）', e?.message ?? e); } catch { /* 忽略 */ }
    }

    publishDashboard();

    // ④ 好感度联动（甜点层）：只对本轮真正说话的人，按档位给一点点情绪/疲劳。
    //    硬约束：每小时上限 + 每人冷却 + 默认不碰 HP —— 详细口径见 lib/favor-link.js 顶部注释。
    try { favorLinkTick(entries, s0, cfg, Date.now()); } catch (e) {
      try { api?.warn?.('好感联动失败（已跳过）', e?.message ?? e); } catch { /* 忽略 */ }
    }
    // ② 主人起床口令：命中就**真的起床**（写状态 + 清命令睡眠 + 清闸门缓存）。
    //    必须排在睡眠闸之前 —— 状态改成 awake 后，下面 sleepGate 读到的就是清醒的，
    //    闸门自然放行；否则就得在闸门里再加一处特判，而那正是将来会对不上的分支。
    //    【融合】这段现在走统一的 wakeUp()，因此命令睡眠也一并解除。
    try {
      const words = parseWakeWords(s0.wakeWords);
      if (words.length) {
        const w = ownerWakeHit(entries, ownerQq, words);
        if (w) {
          const before = currentSleep();
          if (before.sleeping) {
            const r = wakeUp({ reason: '主人起床口令' });
            lastDiag.wokeByOwner = w.hit;
            lastDiag.wokeKind = before.kind;
            // 命令睡眠期间口令命中 → 也要补处理积压（否则消息一直挂着未读）
            if (r.wasCommand) {
              try {
                const n = lastOrchestrator?.resumeAll?.({ limit: Math.max(1, Number(s0.resumeCount) || 20) }) ?? 0;
                lastDiag.wokeResumed = n;
              } catch { /* 忽略 */ }
            }
            // 日志单独 try：起床已经落盘了，不能因为写日志抛错而让调用方以为失败
            try { api?.log?.(`主人起床口令命中「${w.hit}」→ ${chatKey} 已起床（${before.kind}）`); } catch { /* 忽略 */ }
          } else {
            // 没在睡：口令什么都不做（否则会把"在忙某件事"之类的状态误清掉）
            lastDiag.wakeNoop = `status=${before.status}`;
          }
        }
      }
    } catch (e) {
      try { api?.warn?.('起床口令处理失败', e?.message ?? e); } catch { /* 忽略 */ }
    }

    // ③ 睡眠闸：上游是在 wake 入口拦，v0.4 的钩子在 wake 之后触发，
    //    所以这里只做判定，真正的拦截交给 before-tool（见下）。
    //    【融合】命令睡眠已经在入站闸门拦掉了（模型根本不跑），走到这里说明
    //    是"放行"的情况（比如 hard=false 时被喊醒的那轮）——此时不缓存闸门，
    //    让她能正常回一句。
    if (on(settings().blockWhileSleeping) && !commandSleep) {
      try {
        const g = S.sleepGate({
          entries,
          selfNickname: String(ctx.selfNickname || ''),
          botName: String(ctx.botName || ''),
          selfId,
          cfg,
          isPrivate: ctx.kind === 'private'
        });
        gateByChat.set(chatKey, g);
        // 陪闹窗口里不拦发送（她正在陪他玩）；额度用完的收尾由 after-tool 结算
        try {
          if (H.playActive(Date.now())) {
            gateByChat.delete(chatKey);
            if (lastDiag) lastDiag.playWindow = true;
          }
        } catch { /* 忽略 */ }
        // ⚠️ 日志单独 try：曾经这里写成 `api.log(...)`，一旦日志层面抛错就会落到下面的
        //    catch，而 catch 里的 delete 会把**刚刚 set 好的、算得完全正确的闸门删掉** ——
        //    结果是"睡眠闸莫名其妙不生效"。set 之后不容许任何可能抛错的东西裸奔。
        if (g?.block) { try { api?.log?.(`睡眠闸：${chatKey} 已拦（${g.reason}）`); } catch { /* 日志失败不影响闸门 */ } }
      } catch (e) {
        // 只有 sleepGate 本身失败才该丢弃闸门；判定不出来时选择"不拦"（宁可让她说话，
        // 也不要因为一个判定错误把她永久禁言）。
        gateByChat.delete(chatKey);
        if (lastDiag) lastDiag.gateError = String(e?.stack ?? e?.message ?? e);
        try { api?.warn?.('睡眠闸判定失败（本次不拦）', e?.message ?? e); } catch { /* 忽略 */ }
      }
    } else {
      gateByChat.delete(chatKey);
    }

    // ★ [[phone-gate]] 2026-10-22「刷手机」：自然睡眠的**轻一档**版本。
    //   和睡眠闸共用同一个 gateByChat 通道（before-tool 只认这一个），但：
    //     · 独立开关（phoneGate），不依赖 blockWhileSleeping；
    //     · 只在**没睡着**、**没在陪闹**时才生效；
    //     · 被她点名/私聊/@ → 直接抬头（不进概率）；
    //     · 连叫几次会越来越容易抬头（见 lib/bili-watch.js 的 phoneGate）。
    //   ⚠️ 命令睡眠时不判（那条线在入站闸门就拦掉了，模型根本没跑）。
    if (on(s0.phoneGate) && !commandSleep) {
      const cur = gateByChat.get(chatKey);
      let playing = false;
      try { playing = H.playActive(Date.now()); } catch { playing = false; }
      if (!cur?.block && !playing) {
        try {
          const pg = BW.phoneGate({
            chatKey,
            entries,
            selfNickname: String(ctx.selfNickname || ''),
            botName: String(ctx.botName || ''),
            isPrivate: chatKey.startsWith('private:'),
            baseChance: Number(s0.phoneIgnoreChance),
            // ★ 2026-10-23：默认不替她决定（见 lib/bili-watch.js 的 phoneGate）
            selfDecide: s0.phoneSelfDecide !== false
          });
          if (pg?.block) {
            gateByChat.set(chatKey, pg);
            try { api?.log?.(`刷手机闸：${chatKey} 没抬头（${pg.reason}）`); } catch { /* 日志失败不影响闸门 */ }
          } else if (cur) {
            gateByChat.delete(chatKey);      // 抬头了：把上面那条 block:false 的睡眠闸也清掉
          }
        } catch (e) {
          // 判定不出来 → 不拦（宁可让她说话，也不要因为一个判定错误把她禁言）
          try { api?.warn?.('刷手机闸判定失败（本次不拦）', e?.message ?? e); } catch { /* 忽略 */ }
        }
      }
    }
  },

  /**
   * 时机：发给模型之前 —— 对应上游 prompt.js 里那 13 个注入块。
   *
   * 注入位置选在**消息数组末尾**（追加到最后一条 user 消息上）：
   * 这样前面那一大段静态前缀的缓存不受影响，只有尾巴变 —— 成本最优。
   */
  'before-llm-messages'(ctx = {}) {
    const s = settings();
    if (!on(s.enabled) || !on(s.inject)) return;
    const messages = ctx.messages;
    if (!Array.isArray(messages) || !messages.length) return;

    const cfg = engineCfg();
    const out = [];

    // 注意：引擎里没有 soloVoiceBlock / jealousBlock，
    // 「醋」的注入块真名是 jealousyTierBlock（醋意分档）。
    // 已物理删除的 8 个模块（情爱/性欲/色色兴奋/贤者/自慰/想要/姊妹/用户健康）不再注入 ——
    // 它们的 Block 已经不存在了，这里只调真正在用的这几块。
    block(out, M.moodChainBlock, cfg);
    block(out, M.fatigueBlock, cfg);
    block(out, M.jealousyTierBlock, cfg);
    block(out, M.depressBlock, cfg);
    block(out, M.satisfactionBlock, cfg);
    // [[her-ledger]] 她自己刚宣称过的生活状态（吃过/睡了/在忙）：只给事实，不给命令。
    // 放在心情/疲劳之后 —— 那两块讲"身体感觉"，这块讲"她说出口的话"，后者更硬，
    // 排在后面不容易被前面的语气块盖掉。
    try {
      const ctxChatKey = String(ctx.chatKey || '');
      if (ctxChatKey) lastChatKey = ctxChatKey;      // 供 after-tool 判可见性用
      const ledgerLine = herStateLine({ isPrivate: ctx.kind === 'private', chatKey: ctxChatKey });
      if (ledgerLine) out.push(ledgerLine);
    } catch { /* 账本读不出来不能影响别的块 */ }
    // 生命值注入：虚弱/濒危时让她**自己**演得像（旁白、短句、慢节奏）
    if (on(s.hpEnabled) && on(s.hpWeakInjectPrompt)) {
      try {
        const sum = H.hpSummary({
          settings: s,
          snap: M.moodSnapshot(engineCfg(), Date.now()),
          sleeping: currentSleep().sleeping
        });
        if (sum.enabled && (sum.weak || sum.percent <= 50)) {
          out.push(sum.critical
            ? `【身体状态】你现在虚弱到极点（生命值 ${sum.value}/${sum.max}）：说话要短、要断续，多用旁白式的身体描写（括号里的动作与状态），不要硬撑长篇回应，能不调用工具就别调用。`
            : `【身体状态】你有点虚弱（生命值 ${sum.value}/${sum.max}）：语气放软、节奏放慢，像没太有力气；可以带一点旁白式的身体描写。`);
        }
        if (sum.playing) {
          out.push(`【刚被吵醒】你本来在睡，被闹醒后答应陪他闹一会儿（还剩 ${sum.playing.left} 条）：开心归开心，到点就停下回去睡，别越玩越精神。`);
        }
      } catch { /* 注入失败不影响别的块 */ }
    }
    if (on(s.selfState)) {
      // TRAVEL-SYNC：在途时用"在路上"顶掉"在家/在忙"那套自身状态，连"在家的作息
      // 参考"（scheduleBlock）一起收掉 —— 否则会出现"我在土耳其旅行"和"这个点
      // 你平时在洗澡"两块同时描述她位置的自相矛盾。
      //
      // ⚠️ 但「刚被叫醒」优先级最高、不许顶：她旅行途中照样会睡（一趟 14 小时，
      //    中间大概率睡一觉），被叫醒那一下若换成"你在旅行"，醒来时的迷糊与
      //    没睡够的演出就没了，她会表现得像一直在路上精神抖擞。
      //    判据：selfStateBlock 吐的是 wake 类文案（"刚被叫醒/才睡着就被叫醒/刚说过"）。
      let selfLine = null;
      try { selfLine = S.selfStateBlock(cfg); } catch { /* 自身状态坏了 → 当没有 */ }
      const isWake = !!selfLine && /刚被叫醒|才睡着就被叫醒|刚说过/.test(selfLine);
      let line = null;
      let fact = '';                                  // ★ 被叫醒时的"事实兜底行"
      try {
        const tv = travelActive();
        if (tv) {
          // ★ 2026-10-13：拆成两层 —— 氛围可以让位给"困"，**事实不许丢**。
          //   原来 isWake 时整个返回 null，于是"身边是谁"也一起没了
          //   （实测她在被叫醒时被问"是不是带着小狐狸"，答"真没啊"）。
          if (isWake) fact = T.travelFactLine(tv);
          else line = T.travelPromptText(tv, Date.now());
        }
      } catch { /* 旅行状态读不到/坏了 → 退回原来的自身状态注入 */ }
      if (line) {
        out.push(line);                                // 在途：旅途感优先
      } else {
        if (selfLine) out.push(selfLine);
        if (fact) out.push(fact);                      // 刚被叫醒也得知情：人在哪、带着谁
        // ★ 2026-10-13 HOME-SYNC：在家时补一层「她在庭院里和旅伴做什么」。
        //   与 `selfStateBlock` **不冲突**：那条讲"困/忙/在外面"，这条讲"在院子里的具体生活"。
        //   ⚠️ 两条不加的时候：① 刚被叫醒（那一下该是迷糊的，不该精神抖擞讲自己在院子里忙什么）；
        //      ② `selfStateBlock` 已经说了"正在做的事/在外面"（那是更硬的当下，别抢戏）。
        if (!isWake && !(selfLine && /正在做的事|在外面/.test(selfLine))) {
          try {
            const hv = homeActive();
            if (hv) {
              const hl = T.homePromptText(hv, Date.now());
              if (hl) out.push(hl);
            }
          } catch { /* 读不到就只注入上面的自身状态 */ }
        }
        if (!isWake) block(out, S.scheduleBlock, cfg); // 刚被叫醒时不套在家的作息参考
      }
      // ★★ v3.7「刚吃完」：**在途 / 在家 / 刚被叫醒都叠加** ——
      //   嘴里还留着酒味这件事，跟她在哪、困不困都无关（所以刻意放在 if/else 之外）。
      //   ⚠️ `typeof` 包装：热载期间"新入口 + 旧兄弟模块"会让 T.foodAfterPromptText 是 undefined，
      //     裸调会 TypeError —— 被下面的 catch 吞掉就是**静默失效**（本项目栽过多次）。
      //   ⚠️ **注入成功/失败都要留痕** —— 不然"到底注入没有"只能靠猜（这正是 15:48 那次实测卡住的原因）。
      try {
        const fa = foodAfterActive();
        if (fa && typeof T.foodAfterPromptText === 'function') {
          const faLine = T.foodAfterPromptText(fa, Date.now());
          if (faLine) {
            out.push(faLine);
            coreLogger.info('sleep-mood', `【刚吃完】已注入：${fa.name}（${fa.flavor}/${fa.tier}）`);
          }
        } else if (fa) {
          coreLogger.warn('sleep-mood', '【刚吃完】读到了 foodAfter，但 travel-sync 里没有 foodAfterPromptText（兄弟模块是旧版？要重启）');
        }
      } catch (e) {
        coreLogger.warn('sleep-mood', `【刚吃完】注入失败：${e?.message || e}`);
      }
    }
    // ★★ [[bili-watch]] 2026-10-22「她这会儿在 B 站刷视频」：
    //   为什么不放进上面那个 if/else —— 因为它**不是位置、不是状态机的一位**，
    //   而是"手上正开着什么"。她在摩尔曼斯克刷 B 站、被叫醒后接着刷、在家沙发刷，
    //   全都不矛盾。所以和「刚吃完」同一层：谁都不顶，只叠加。
    //   ⚠️ 唯独睡觉不叠加：睡着还在刷视频是自相矛盾，还会把"困"的演出盖掉。
    //   ⚠️ 注入成功/失败都留痕（本项目栽过"静默失效"好几次）。
    if (on(s.selfState)) {
      try {
        const bwLine = BW.biliWatchPromptText(Date.now());
        if (bwLine) {
          let st = null;
          try { st = S.readSelfState(); } catch { /* 读不到就照常注入 */ }
          if (!st || st.status !== 'sleeping') {
            out.push(bwLine);
            coreLogger.info('sleep-mood', `【手上】已注入：B站刷视频（selfState=${(st && st.status) || 'awake'}）`);
          }
        }
      } catch (e) {
        coreLogger.warn('sleep-mood', `【手上】B站状态注入失败：${e?.message || e}`);
      }
    }
    // ★ 关系 × 语气（TONE-LINK，2026-10-12）：必须放在**所有块的最后**。
    //   上面那些讲的是"你现在是什么状态"（HP 虚弱 / 疲劳 / 抑郁 / 旅行 / 刚被叫醒 ——
    //   全是**压制型**）；这一块讲的是"你**对他**是什么态度"。语气档排在它们之后，
    //   才不会把"虚弱时话短"这类状态描述盖掉。
    //   关系取自 favor-core（`favorOfPerson`），状态取自 mood-chain，余温取自 favor 的
    //   最近事件 —— 全部现成，不新增存档。详见 lib/tone-link.js 头注释。
    //   ⚠️ 拿不到"谁在说话"时整块**不注入**：猜错关系（把生人当熟人哄）比不说更糟。
    try {
      const partnerId = turnSenders.length ? turnSenders[turnSenders.length - 1] : '';
      const tone = TL.affectionToneBlock({ api, settings: s, partnerId, now: Date.now() });
      if (tone) out.push(tone);
    } catch (e) {
      try { api?.warn?.('关系语气块失败', e?.message ?? e); } catch { /* 忽略 */ }
    }
    if (!out.length) return;

    const text = ['【心情与当前状态】（本地数值演算，按它调整语气与节奏，不要直接复述数值）',
      '如果这一轮对话明显改变了你的心情，可以调用「调整心情数值」工具，只调整 1-3 个最相关的项（0-100）；没有明显变化不要调用，也不要为了报数而调用。',
      ...out].join('\n\n');

    try {
      for (let i = messages.length - 1; i >= 0; i -= 1) {
        const m = messages[i];
        if (!m || m.role !== 'user') continue;
        if (typeof m.content === 'string') {
          m.content = `${m.content}\n\n${text}`;
          return;
        }
        if (Array.isArray(m.content)) {
          m.content.push({ type: 'text', text });
          return;
        }
      }
      // 没有 user 消息（少见）→ 单独补一条
      messages.push({ role: 'user', content: text });
    } catch (e) {
      try { api?.warn?.('注入失败', e?.message ?? e); } catch { /* 忽略 */ }
    }
  },

  /**
   * 时机：每次工具调用之前 —— 承担上游 wake 入口 sleepGate 的**拦截**职责。
   *
   * 为什么能在这里拦：上游是"睡着就不调模型"（省 token），v0.4 的钩子触发在
   * wake 之后，已经没有"不跑"这个选项了；但 `before-tool` 是唯一能返回
   * `{block:true}` 的地方，所以改成"睡着时发不出去"—— 效果等价，
   * 而且这正是官方文档 §12 quiet-hours 示例的做法。
   *
   * 【融合】命令睡眠不在这里判（它在入站闸门就拦了，模型压根没跑）；
   * 这里只负责自然睡眠的内层闸。两道闸各管一段，互不重复。
   */
  'before-tool'({ toolName } = {}) {
    const s = settings();
    if (!on(s.enabled) || !on(s.blockWhileSleeping)) return;
    // 工具 id 是 `<skillId>__<工具名>`，取最后一段
    const bare = String(toolName || '').split('__').pop();
    if (!['send_message', 'send_sticker', 'send_poke', 'send_image'].includes(bare)) return;

    for (const g of gateByChat.values()) {
      if (g && g.block) {
        // [[phone-gate]] 区别两种"没回"：睡着 vs 低头刷手机。
        // 给模型不同的理由，她的反应才不会一样（睡着是被吵醒，刷手机是没抬头）。
        if (g.kind === 'phone') {
          return { block: true, reason: '她这会儿低着头在刷手机，这条她没抬头（不是睡着）。先安静着，别换个工具绕过去，也别解释成一大段。' };
        }
        return { block: true, reason: '她睡着了（没被喊醒）。安静是正常的，不要改用别的工具绕过去。' };
      }
    }
  },

  /**
   * 时机：每次工具调用之后 —— 对应上游 sender.js 出口那组「观察她自己的话」。
   * 拿到的文本喂给：自身状态机（睡/busy）、情绪自增、洗澡结算、疲劳时间戳。
   */
  'after-tool'({ toolName, argsRaw, result } = {}) {
    if (!on(settings().enabled)) return;
    const bare = String(toolName || '').split('__').pop();
    if (bare !== 'send_message') return;
    if (result && result.isError) return;

    const text = extractSentText(argsRaw);
    if (!text) return;

    // [[her-ledger]] 记一笔：这句话里有没有"我吃过了 / 我先睡了 / 我在忙"这类自我宣称。
    // 排在状态机之前 —— 账本是**事实登记**，不该被后面任何一步的成败影响。
    try { noteHerState(text, { chatKey: lastChatKey }); } catch { /* 记账失败不影响状态机 */ }
    const cfg = engineCfg();
    const now = Date.now();

    try {
      selfMsgTs.push(now);
      if (selfMsgTs.length > 200) selfMsgTs = selfMsgTs.slice(-200);
    } catch { /* 忽略 */ }

    // ⚠️ 引擎里有一类函数是「只计算、不落盘」，调用方必须自己写回去。
    //    这里踩过两次坑，逐个标注清楚：
    //    · stateFromSelfText(text, now, cfg) → 返回新状态 | null（**不写盘**）
    //    · selfMoodDelta(text, cfg, now)     → 返回 {delta, why} | null（**不写盘**）
    //    对照组：stepMood / settleBath / writeBathState 都是直接落盘的。

    // 自身状态机（说"我睡了"→sleeping；说"我在干X"→busy）
    try {
      const prev = S.readSelfState(now);
      // GOODNIGHT-ECHO-FIX：窗口内（= 本轮是别人在跟她道晚安）先把她回礼的「晚安」剥掉再判；
      // 剥完为空就不判（纯回礼不入睡）。她真说"晚安，我先去睡了"时"去睡"还在，照旧判睡。
      // ⚠️ 必须**连标点一起清**：「晚安，我先去睡了」剥完是「，我先去睡了」，
      //    而 stateFromSelfText 只看第一分句（firstClause）→ 前导逗号会让它拿到空串、漏判。
      const judged = now < goodnightEchoUntil
        ? text.replace(GOODNIGHT_ECHO_RE, '').replace(STRIP_EDGE_PUNCT_RE, '')
        : text;
      // SLEEP-EVAL-GUARD：可疑句（在说别人 / 单纯道别）不进状态机 —— 详见上面的注释
      const suspect = judged ? sleepVerdictSuspect(judged) : '';
      if (suspect) {
        try { api.log(`[sleep-mood] 自身状态判定跳过（${suspect}）：「${String(judged).slice(0, 40)}」`); } catch { /* 忽略 */ }
      }
      const next = (judged && !suspect) ? S.stateFromSelfText(judged, now, cfg) : null;
      if (next) {
        S.writeSelfState(next);
        // FATIGUE-STUCK-FIX：只在**真正发生 awake→sleeping 跃迁**时记入睡时刻。
        //   · 不判跃迁的话，她睡着后又说了句"我去倒杯水"之类被忽略、
        //     或重复宣告，会不断把 sleptAt 推后 → 睡了一整夜也恢复不了；
        //   · 午睡（nap）也走这条路 —— stateFromSelfText 会带 wakeAt，
        //     恢复量在 stepFatigue 里按 napRecoverFactor 减半，语义已在引擎里。
        if (next.status === 'sleeping' && prev.status !== 'sleeping') {
          try { M.markFatigueSleep(true, now); } catch { /* 记不上不影响睡觉 */ }
        }
      }
    } catch { /* 忽略 */ }

    // 洗澡：开始 / 结束（双人标记两条路都要带）
    try {
      if (S.bathStartFromSelfText(text)) S.writeBathState({ now });
      else if (S.bathDoneFromSelfText(text)) S.settleBath();
    } catch { /* 忽略 */ }

    // 她自己的话也会改变情绪（增量打 selfFactor 折，也要自己 step）
    try {
      const d = M.selfMoodDelta(text, cfg, now);
      if (d) { M.stepMood(d.delta, d.why, cfg, now); publishDashboard(); }
    } catch { /* 忽略 */ }

    // ── 陪闹结算：她每发一条就扣一个额度，扣完发收尾台词并**回睡** ──
    // 为什么在 after-tool：这是唯一能观察"她自己说了什么"的地方。
    // 发消息本身用最近一次入站缓存的 sender（钩子 ctx 里没有 sender）。
    try {
      const play = H.playActive(now);
      if (play) {
        const s4 = settings();
        const cfgH4 = H.hpCfg(s4);
        const left = H.consumePlayReply(now);
        try { api?.log?.(`陪闹：本条已回，剩余额度 ${left.left} 条`); } catch { /* 忽略 */ }
        if (left.done && now - lastPlayClosingAt > 3000) {
          lastPlayClosingAt = now;
          const words = H.pickWords(s4.playClosingWords, cfgH4.playClosingCount);
          for (const w of words) confirmText(lastSender, play.chatKey || lastChatKey, w);
          const end = H.endPlay({ settings: s4, snap: M.moodSnapshot(engineCfg(), now), now });
          if (end.fatigue) addFatigue(end.fatigue, '陪闹结束');
          applyMoodDeltas(end.moodDeltas, end.why, engineCfg(), now);
          try { api?.log?.(`陪闹额度用完 → 收尾并回睡（${words.join(' / ') || '（收尾台词为空）'}）`); } catch { /* 忽略 */ }
        }
      }
    } catch { /* 陪闹结算失败不影响正常流程 */ }
  }
};

/** 从 send_message 的 argsRaw 里抠出她实际发出去的文本。argsRaw 可能是字符串或对象。 */
function extractSentText(argsRaw) {
  let args = argsRaw;
  if (typeof args === 'string') {
    try { args = JSON.parse(argsRaw); } catch { return String(argsRaw || '').trim(); }
  }
  if (!args || typeof args !== 'object') return '';
  const m = args.messages ?? args.message;
  if (Array.isArray(m)) return m.map((x) => String(x ?? '')).filter(Boolean).join('\n').trim();
  return String(m ?? '').trim();
}

// ══════════════════════════════════════════════════════════════════════════
// 工具（替代上游的 panel.html；融合版新增 sleep-mood__sleep_control）
// ══════════════════════════════════════════════════════════════════════════

/** 可手调的 mod 白名单 → 该 mod 在 mood.json 里的字段名。
 *  已物理删除的模块（love/lust/arousal/want/sister…）不在白名单里 ——
 *  它们已停用，手调了也不会被任何注入块读到，留着只会误导模型。 */
const ADJUSTABLE = {
  happy: 'moods.happy', excited: 'moods.excited', angry: 'moods.angry',
  jealous: 'moods.jealous', sad: 'moods.sad',
  fatigue: 'fatigue',
  spunk: 'spunk', depress: 'depress', satisfaction: 'satisfaction'
};

const num = (v, d) => { const n = Number(v); return Number.isFinite(n) ? n : d; };

function registerMoodTools(a) {
  a.registerTool({
    id: 'mood_status',
    name: '查看心情与状态',
    description: '读出她此刻的心情数值和生活状态（情绪五维 / 疲劳 / 吵架速度 / 抑郁 / 满足 / 睡眠与在做的事 / 命令睡眠开关）。当主人问"她现在什么心情""状态怎么样"，或你想确认某个数值再决定怎么说话时使用。',
    category: 'query',
    icon: '🌡️',
    defaultEnabled: true,
    // 无参数的工具省略 required —— 空数组是冗余声明，审计会判为不合法
    parameters: { type: 'object', properties: {} },
    async execute() {
      try {
        const now = Date.now();
        // 用 moodSnapshot 而不是直接读盘：拿到的是**衰减后**的当前值。
        // 直接读盘只能得到"上次变动时的值"，跟提示词注入里用的现值对不上 ——
        // 她会说"我很累"，而工具报 fatigue=0。
        const snap = M.moodSnapshot(engineCfg(), now);
        const sleep = currentSleep(now);
        const self = S.readSelfState(now);
        const lines = [];
        const moods = snap.moods || {};
        const parts = Object.keys(moods)
          .map((k) => `${k}=${Math.round(num(moods[k], 0))}`)
          .join(' ');
        lines.push(`情绪五维：${parts || '（都很平静）'}`);
        if (snap.dominant) lines.push(`主导情绪：${snap.dominant.word}`);
        const one = (label, v) => `${label}=${Math.round(num(v, 0))}`;
        lines.push([
          one('疲劳', snap.fatigue),
          one('吵架速度', snap.spunk), one('抑郁', snap.depress),
          one('满足', snap.satisfaction)
        ].join(' '));
        // 【融合】睡眠状态分两级说清楚，方便判断是哪道闸在生效
        // 生命值 / 压力池 / 陪闹 / 清空计划（生命值版新增）
        try {
          const hp = H.hpSummary({ settings: settings(), snap, sleeping: sleep.sleeping, now });
          lines.push(`生命值：${hp.value}/${hp.max}（压力池 ${hp.stress} · debuff 负载 ${hp.load} · 疲劳压力 ${hp.pressure}%）`
            + `${hp.critical ? '【濒危】' : (hp.weak ? '【虚弱】' : '')}`);
          if (hp.playing) lines.push(`陪闹中：还剩 ${hp.playing.left} 条（${new Date(hp.playing.until).toLocaleTimeString()} 前收尾）`);
          if (hp.wipe.enabled) lines.push(`归零清空记忆：已开启（模式 ${hp.wipe.mode} · 范围 ${hp.wipe.scope} · 已触发 ${hp.wipe.count} 次）`);
          else if (on(settings().wipeOnZeroEnabled)) lines.push('归零清空记忆：开关已开但**未二次确认**（wipeOnZeroArmed=false），不会执行');
          const tail = (hp.log || []).slice(0, 3).map((l) => `${l.kind}${l.delta ? ` ${l.delta}` : ''}`).join('，');
          if (tail) lines.push(`最近变化：${tail}`);
        } catch { /* 忽略 */ }
        lines.push(`命令睡眠：${commandSleep ? '开（不送模型，零 token）' : '关'}`);
        lines.push(`当前状态：${self?.status || 'awake'}${self?.what ? ` —— ${self.what}` : ''}`);
        if (sleep.sleeping) lines.push(`睡眠判定：睡着（${sleep.reason}）`);
        const g = [...gateByChat.values()].find((x) => x && x.block);
        if (g) lines.push(`睡眠闸：已拦（${g.reason}）`);
        return { content: lines.join('\n') };
      } catch (e) {
        return { content: `读取失败：${e?.message ?? e}`, isError: true };
      }
    }
  });

  a.registerTool({
    id: 'mood_adjust',
    name: '调整心情数值',
    description: '把某一项心情数值直接设成指定值（0-100）。当主人明确要求调整，或这一轮对话明显改变了你的心情时使用；自己判断时只调 1-3 个最相关的项，不要每轮调用。可用项：happy/excited/angry/jealous/sad/fatigue/spunk/depress/satisfaction。这个操作直接改磁盘数值，不可撤销（但会被自然衰减拉回）。',
    category: 'system',
    icon: '🎚️',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        mod: { type: 'string', description: '要调整的项，例如 happy / fatigue / depress / jealous' },
        value: { type: 'number', description: '目标数值，0-100（超出会夹到范围内）' },
        reason: { type: 'string', description: '简短原因，例如被夸了、被冷落、吵架了（可选）' }
      },
      required: ['mod', 'value']
    },
    async execute(_ctx, args) {
      try {
        const key = String(args?.mod ?? '').trim();
        if (!ADJUSTABLE[key]) {
          return { content: `没有 ${key} 这一项。可用：${Object.keys(ADJUSTABLE).join('/')}`, isError: true };
        }
        const v = Math.max(0, Math.min(100, Math.round(num(args?.value, NaN))));
        if (!Number.isFinite(v)) return { content: 'value 必须是数字', isError: true };

        const now = Date.now();
        const st = M.readMoodChain(now) || {};
        const path = ADJUSTABLE[key];
        if (path.startsWith('moods.')) {
          const em = path.split('.')[1];
          st.moods = st.moods || {};
          const prev = st.moods[em] || {};
          st.moods[em] = { level: v, why: String(args?.reason || '自己判断').slice(0, 80), at: now, decayMs: prev.decayMs };
        } else {
          const prev = st[path] || {};
          st[path] = { ...prev, value: v, at: now };
        }
        const okWrite = M.writeMoodChain(st);
        if (okWrite) publishDashboard();
        return okWrite
          ? { content: `已把 ${key} 设为 ${v}。不要输出汇报式总结，自然回应主人即可。` }
          : { content: '写入状态文件失败（磁盘权限或路径问题）', isError: true };
      } catch (e) {
        return { content: `调整失败：${e?.message ?? e}`, isError: true };
      }
    }
  });

  a.registerTool({
    id: 'mood_reset',
    name: '重置心情到平静',
    description: '把所有心情数值清零、并让她回到清醒状态（同时解除命令睡眠）。当主人说"把她心情重置一下""忘掉刚才的不愉快""恢复到默认"时使用。这个操作会丢掉当前所有累积数值，不可撤销。',
    category: 'system',
    icon: '↩️',
    defaultEnabled: true,
    // 无参数的工具省略 required —— 空数组是冗余声明，审计会判为不合法
    parameters: { type: 'object', properties: {} },
    async execute() {
      try {
        const okWrite = M.writeMoodChain({});
        if (okWrite) publishDashboard();
        try { S.writeSelfState({ status: 'awake', what: '', at: Date.now() }); } catch { /* 自身状态重置失败不致命 */ }
        // 【融合】重置也要管命令睡眠 —— 否则"重置了但还是不说话"。
        // 若之前开着命令睡眠，把调度恢复回来（否则机器人永久沉默）。
        const wasCommand = commandSleep;
        if (wasCommand) {
          try { lastOrchestrator?.resumeAll?.({ limit: Math.max(1, Number(settings().resumeCount) || 20) }); } catch { /* 忽略 */ }
          commandSleep = false;
        }
        gateByChat.clear();
        return okWrite
          ? { content: `已重置为平静状态${wasCommand ? '（并解除了命令睡眠）' : ''}。不用汇报，正常说话。` }
          : { content: '写入状态文件失败', isError: true };
      } catch (e) {
        return { content: `重置失败：${e?.message ?? e}`, isError: true };
      }
    }
  });

  /**
   * 【融合新增】睡眠总开关工具 —— 让模型/主人用自然语言控制命令睡眠，
   * 不用非得在群里 @ 机器人发 /睡觉。
   *
   * 为什么值得加：/睡觉 是"确定性触发"（必须 @ + 精确指令），适合主人自己按键；
   * 但主人也可能说"你先睡一会儿""别说话了" —— 那是**自然语言**，
   * 只有注册成工具模型才会去调。两者最终都落到同一对 suspendAll/resumeAll 上。
   */
  a.registerTool({
    id: 'sleep_control',
    name: '控制命令睡眠',
    description: '开关【命令睡眠】：开启后机器人只存档消息、完全不送大模型（零 token 消耗），直到解除。当主人说"你先睡一会儿""别说话了""安静一下"或"醒醒""可以说话了"时使用。注意：这与她自己困了去睡（自然睡眠）不是一回事，命令睡眠是主人对机器人下的停机开关。',
    category: 'system',
    icon: '😴',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        action: {
          type: 'string',
          enum: ['sleep', 'wake', 'status'],
          description: 'sleep=开启命令睡眠（不回复）；wake=解除并补处理积压消息；status=只查询当前状态'
        }
      },
      required: ['action']
    },
    async execute(_c, args) {
      try {
        const action = String(args?.action ?? '').trim();
        const resumeCount = Math.max(1, Number(settings().resumeCount) || 20);

        if (action === 'status') {
          return {
            content: `命令睡眠：${commandSleep ? '开启中（消息只存档不回复）' : '未开启'}；`
              + `自然睡眠状态：${currentSleep().status}`
          };
        }

        if (action === 'sleep') {
          // ★★ 2026-10-09 修（与关键词闸同一处 bug 的第二扇门）：工具路径原来**没有权限判定**，
          //    而宿主给工具 execute 的 ctx 里没有发言人身份 ⇒ 理论上谁把模型说动都能关掉她。
          //    用 before-context 每轮刷新的"本轮主人是否在场"近似鉴权（时序：钩子先于工具执行）。
          //    ⚠️ 与关键词闸同款默认：锁（`!== false`）；主人不在场时一律拒绝。
          if (settings().lockSleepToOwner !== false && !turnOwnerSpeaks) {
            return {
              content: '命令睡眠只能由主人开启：这一轮说话的人里没有主人，我没有关掉自己。'
                + '（禁用这条限制：集成系统面板 → 总览 → 「仅主人可触发睡眠」）',
              isError: true
            };
          }
          if (commandSleep) return { content: '命令睡眠已经是开启状态。' };
          let ok = false;
          try { ok = lastOrchestrator?.suspendAll?.() === true; } catch { /* 忽略 */ }
          commandSleep = true;
          // ★ FATIGUE-RECOVER-FIX：与关键词闸同款 —— 命令睡眠也要记入睡时刻（见上面那处注释）。
          try { M.markFatigueSleep(true, Date.now()); } catch { /* 记不上不影响睡觉 */ }
          gateByChat.clear();
          publishDashboard();
          return {
            content: ok
              ? '已进入命令睡眠：消息照常存档但不再送模型。主人说"醒醒"或 @我 /起床 即可解除。'
              : '已标记命令睡眠，但调度暂停未确认成功（可能机器人未运行或 orchestrator 不可用）。'
          };
        }

        if (action === 'wake') {
          if (!commandSleep) {
            return { content: `命令睡眠本来就没开（自然睡眠状态：${currentSleep().status}）。如果她不说话，可能是自然睡眠的睡眠闸拦着，需要用起床口令或等她自然醒。` };
          }
          wakeUp({ reason: '工具唤醒' });
          publishDashboard();
          let touched = 0;
          try { touched = lastOrchestrator?.resumeAll?.({ limit: resumeCount }) ?? 0; } catch { /* 忽略 */ }
          return { content: `已解除命令睡眠${touched > 0 ? `，正在补看 ${touched} 个群的最近消息` : ''}。` };
        }

        return { content: `不认识的 action：${action}。可用：sleep / wake / status`, isError: true };
      } catch (e) {
        return { content: `操作失败：${e?.message ?? e}`, isError: true };
      }
    }
  });
}

/**
 * 生命值相关工具（生命值版新增）。
 * 与 sleep-mood__mood_adjust 一样：只在"主人明确要求"或模型自己判断该调时用，参数简单、动作可预期。
 */
function registerHpTools(a) {
  a.registerTool({
    id: 'hp_status',
    name: '查看生命值',
    description: '读出她当前的生命值 / 压力池 / debuff 负载 / 疲劳压力 / 是否在陪闹 / 归零清空记忆开关与最近几次变化原因。主人问"她身体怎么样""还剩多少血""为什么掉血"时使用。',
    category: 'query',
    icon: '❤️',
    defaultEnabled: true,
    parameters: { type: 'object', properties: {} },
    async execute() {
      try {
        const hp = H.hpSummary({ settings: settings(), snap: M.moodSnapshot(engineCfg(), Date.now()) });
        const lines = [
          `生命值：${hp.value}/${hp.max}（${hp.percent}%）${hp.critical ? '【濒危】' : (hp.weak ? '【虚弱】' : '【健康】')}`,
          `压力池：${hp.stress}/100（疲劳 ${hp.fatigue}，压力系数 ${hp.pressure}%）`,
          `debuff 负载：${hp.load}/100（生气/吃醋/难过/抑郁/吵架速度加权）`,
          `睡眠：${hp.sleeping ? '睡着' : '醒着'}${hp.playing ? ` · 陪闹中（剩 ${hp.playing.left} 条）` : ''}`,
          `归零清空记忆：${hp.wipe.enabled ? `已开启（${hp.wipe.mode} · ${hp.wipe.scope}）` : '未开启（或未二次确认）'}`
        ];
        const tail = (hp.log || []).slice(0, 5).map((l) => `${new Date(l.at).toLocaleTimeString()} ${l.kind} ${l.delta > 0 ? '+' : ''}${l.delta}${l.why ? `（${l.why}）` : ''}`);
        if (tail.length) lines.push('最近变化：', ...tail);
        return { content: lines.join('\n') };
      } catch (e) {
        return { content: `读取失败：${e?.message ?? e}`, isError: true };
      }
    }
  });

  a.registerTool({
    id: 'hp_adjust',
    name: '调整生命值',
    description: '把生命值设成指定值或增减一定量（0 到上限）。主人明确要求"给她回血/扣血"时使用；也可以在她被照顾、休息、受伤后按剧情调整。这是直接改磁盘数值，不可撤销。',
    category: 'system',
    icon: '💗',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        value: { type: 'number', description: '目标生命值（0 到上限）。与 delta 二选一' },
        delta: { type: 'number', description: '增减量，例如 -5 表示扣 5 点。与 value 二选一' },
        reason: { type: 'string', description: '简短原因，例如被照顾了、熬夜了、生病了（可选）' }
      }
    },
    async execute(_ctx, args) {
      try {
        const st = H.readHp();
        const before = st.value;
        if (args && args.value !== undefined && args.value !== null) st.value = Number(args.value);
        else if (args && args.delta !== undefined && args.delta !== null) st.value = Number(st.value) + Number(args.delta);
        else return { content: '需要提供 value 或 delta 之一', isError: true };
        st.value = Math.max(0, Math.min(Number(st.max) || 100, Math.round(st.value)));
        st.at = Date.now();
        const log = Array.isArray(st.log) ? st.log : [];
        log.push({ at: Date.now(), kind: 'manual', delta: Math.round((st.value - before) * 10) / 10, why: String(args?.reason || '手动调整') });
        st.log = log.slice(-30);
        const okWrite = H.writeHp(st);
        publishDashboard();
        return {
          content: `生命值：${Math.round(before)} → ${Math.round(st.value)}/${st.max}`
            + `${okWrite ? '' : '（写入失败，重启后可能回退）'}`
            + `${args?.reason ? `（${args.reason}）` : ''}`
        };
      } catch (e) {
        return { content: `调整失败：${e?.message ?? e}`, isError: true };
      }
    }
  });

  a.registerTool({
    id: 'hp_wipe_plan',
    name: '查看清空记忆计划（干跑）',
    description: '只读：列出"生命值归零清空记忆"如果执行会删除哪些目录、多少文件、多少字节，以及哪些路径绝对不会碰。用于让主人先看清楚再决定是否开启。不会删除任何东西。',
    category: 'query',
    icon: '🧪',
    defaultEnabled: true,
    parameters: { type: 'object', properties: {} },
    async execute() {
      try {
        const plan = H.wipePlan({ settings: settings() });
        const lines = [
          `开关：${plan.enabled ? `已开启（模式 ${plan.mode}）` : '未开启（或未二次确认）'}`,
          `范围：${plan.scope.join(' / ') || '（空）'}`,
          `将删除：${plan.files} 个文件 / ${plan.bytes} 字节`,
          ...plan.groups.map((g) => `  · ${g.scope} → ${g.dir}（${g.files} 个文件，${g.bytes} 字节）`),
          `备份：${plan.backupFirst ? '会先备份' : '不备份（危险）'}`,
          `绝不碰：${plan.protectedPaths.join('、')}`
        ];
        return { content: lines.join('\n') };
      } catch (e) {
        return { content: `读取失败：${e?.message ?? e}`, isError: true };
      }
    }
  });

  a.registerTool({
    id: 'hp_wipe_restore',
    name: '还原清空记忆的备份',
    description: '把「生命值归零清空记忆」的备份（_wipe-backup-*）还原回 data 目录。不带参数 = 只读列出可还原的备份；带 index 选第几份（0=最旧，默认最近一份）；真正执行必须再传 confirm:true（破坏性双保险）。还原时现有目录会先改名让路（*.pre-restore-*，不丢数据），备份目录本身保留。',
    category: 'utility',
    icon: '🩹',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        index: { type: 'integer', description: '可选：还原第几份备份（0=最旧；缺省=最近一份）' },
        confirm: { type: 'boolean', description: 'true 才真正执行；缺省只返回只读预览' }
      }
    },
    async execute(ctx, args) {
      try {
        // ★ 仅限主人（02.md 4.2）：恢复会把备份盖回 data/，属破坏性操作。
        //   fail-closed（与命令睡眠同口径）：解析不出主人 QQ 一律拒绝；
        //   群聊里不认（分不清是谁让模型调的），只认主人的私聊会话。
        const ownerQq = resolveOwnerQq();
        if (!ownerQq) {
          return { content: '还原备份需要先知道主人是谁（设置里填「主人 QQ 号」或装 owner-identity 插件），当前不可用。', isError: true };
        }
        if (String(ctx?.chatKey || '') !== `private:${ownerQq}`) {
          return { content: '还原备份仅限在主人的私聊里使用（群里分不清是谁在操作）。请到与我的私聊中再试一次。', isError: true };
        }
        const r = H.wipeRestore({ index: args?.index, confirm: args?.confirm === true });
        if (!r.ok) return { content: r.reason, isError: true };
        if (r.needConfirm) {
          const all = H.wipeBackups();
          return {
            content: `可还原的备份（0=最旧 → ${all.length - 1}=最新，本次将用：${r.backup}）：\n`
              + all.map((b, i) => `  · [${i}] ${b}`).join('\n')
              + `\n${r.note}`
          };
        }
        const lines = [
          `已从 ${r.backup} 还原：${r.restored.join('、') || '（空）'}`,
          ...(r.aside.length ? [`让路改名（原目录没删）：${r.aside.join('、')}`] : []),
          r.note
        ];
        return { content: lines.join('\n') };
      } catch (e) {
        return { content: `还原失败：${e?.message ?? e}`, isError: true };
      }
    }
  });
}

/**
 * 好感度联动工具（只读）：让主人/模型能问"她对某个人的好感是多少、这一轮联动给了什么"。
 * 不提供"改好感"的入口 —— 改分属于 favor-core 的管理页/它自己的工具，这里只读。
 */
function registerFavorTools(a) {
  a.registerTool({
    id: 'favor_link_status',
    name: '查看好感度联动',
    description: '读出好感度联动（甜点层）的当前状态：开关、每小时额度剩余、最近几轮联动给了谁什么效果（开心/生气/吃醋/解乏）。可选传 QQ 号查某人的好感档位。主人问"她对我好感多少""她最近对谁态度变了"时使用。',
    category: 'query',
    icon: '💞',
    defaultEnabled: true,
    parameters: {
      type: 'object',
      properties: {
        userId: { type: 'string', description: '可选：要查的 QQ 号（纯数字）' }
      }
    },
    async execute(_ctx, args) {
      try {
        const s = settings();
        const sum = F.favorLinkSummary({ settings: s });
        const lines = [
          `好感度联动：${sum.enabled ? '开' : '关'}（HP 影响：${sum.hpBonus ? '开（仅亲近档极小回血）' : '关（默认）'}，每人冷却 ${sum.cooldownMin} 分钟）`,
          `每小时额度：开心 ${sum.acc.happy || 0}/${sum.caps.happy} · 生气 ${sum.acc.angry || 0}/${sum.caps.angry}`
            + ` · 吃醋 ${sum.acc.jealous || 0}/${sum.caps.jealous} · 解乏 ${sum.acc.fatigue || 0}/${sum.caps.fatigue}`,
          `睡眠微调：${sum.wakeTuning ? '开（亲近必陪闹 / 反感更难叫醒）' : '关'}`
        ];
        const uid = String(args?.userId || '').trim();
        if (uid) {
          const one = F.favorOfPerson({ api, userId: uid });
          if (one) lines.push(`指定 QQ ${uid}：好感 ${one.favor}（${one.band}）${one.name ? ` · ${one.name}` : ''}`);
          else lines.push(`指定 QQ ${uid}：查不到好感档案（或 favor-core 不可用）`);
        }
        if (sum.last?.length) {
          lines.push('最近联动：');
          for (const ev of sum.last.slice(-5).reverse()) {
            const eff = Object.entries(ev.effects || {}).filter(([, v]) => v > 0).map(([k, v]) => `${k}+${Math.round(v * 10) / 10}`).join(' ');
            lines.push(`  ${new Date(ev.at).toLocaleTimeString()} ${ev.name || ev.userId} ${ev.band}(${Math.round(ev.favor)}) → ${eff || '（无）'}`);
          }
        } else lines.push('最近联动：（还没有触发过）');
        return { content: lines.join('\n') };
      } catch (e) {
        return { content: `读取失败：${e?.message ?? e}`, isError: true };
      }
    }
  });
}
