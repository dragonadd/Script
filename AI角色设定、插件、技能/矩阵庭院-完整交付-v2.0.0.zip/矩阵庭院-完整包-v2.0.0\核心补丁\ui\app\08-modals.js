// 〔通用弹窗外壳 / 模型选择 / 人设 / 白名单 / saveConfig〕——M9 拆分第 9 段
'use strict';

/* ── API 协议下拉（2026-10-19）────────────────────────────────────────────
   「模型管理 → 添加/编辑提供商」里的 API 协议选择。与后端 src/api-protocols.js
   的目录保持一致（id 必须逐一对应）。
   ⚠️ UI 是经典脚本共享全局作用域 —— 本常量名带 QA_ 前缀防撞（ui-globals-check 口径）。 */
const QA_API_PROTOCOLS = [
  { id: 'openai', label: 'OpenAI (Chat Completions)' },
  { id: 'openai-responses', label: 'OpenAI (Responses API)' },
  { id: 'anthropic', label: 'Anthropic' },
  { id: 'google', label: 'Google' },
  { id: 'mistral', label: 'Mistral' }
];
// 选协议后 Base URL 还空着时自动填的官方默认端点（与后端 PROTOCOL_DEFAULT_BASES 对应）
const QA_PROTOCOL_DEFAULT_BASES = {
  openai: '',
  'openai-responses': 'https://api.openai.com/v1',
  anthropic: 'https://api.anthropic.com/v1',
  google: 'https://generativelanguage.googleapis.com/v1beta',
  mistral: 'https://api.mistral.ai/v1'
};
function qaProtocolSelectHtml(selected) {
  const sel = String(selected || 'openai');
  return QA_API_PROTOCOLS.map((p) =>
    `<option value="${p.id}" ${p.id === sel ? 'selected' : ''}>${p.label}</option>`
  ).join('');
}

/* ── body 滚动锁（2026-10-10 r86 修 P2）────────────────────────────────────
   弹窗打开时锁住背后页面的滚动，关闭时还原。

   为什么需要：无边框透明窗里，弹窗遮罩是 position:fixed 铺满视口，但**背后的
   滚动容器仍在**。鼠标滚轮在遮罩上滑动会穿透到背后把列表滚走 —— 关掉弹窗后
   用户发现自己刚才看的那一行不见了。移动端（触摸板惯性滚动）更明显。

   ⚠️ 用**计数器**：弹窗会叠（模型选择 → 添加模型 → 人设选择），必须等全部关完
      才解锁；用布尔量会被"第一个关掉的弹窗"提前解开。
   ⚠️ 还原的是**打开前的原值**，不是写死 ''：页面可能本来就设了 overflow。 */
let __modalScrollLocks = 0;
let __modalPrevBodyOverflow = null;
function lockBodyScroll() {
  if (__modalScrollLocks === 0) {
    __modalPrevBodyOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
  }
  __modalScrollLocks += 1;
}
function unlockBodyScroll(overlay) {
  // 同一个 overlay 只解锁一次（closeModelModal 可能被多条路径调用）
  if (overlay && overlay._scrollLocked) {
    overlay._scrollLocked = false;
  } else if (!overlay) {
    // 无 overlay 参数 = 强制全量解锁（异常兜底）
    __modalScrollLocks = 0;
  }
  if (__modalScrollLocks > 0) __modalScrollLocks -= 1;
  if (__modalScrollLocks === 0) {
    document.body.style.overflow = __modalPrevBodyOverflow || '';
    __modalPrevBodyOverflow = null;
  }
}

/* ── 模态框焦点陷阱（2026-10-10 r86 修 P2）────────────────────────────────
   让 Tab / Shift+Tab 在**最上层弹窗内**首尾循环，并把被程序性移出的焦点拽回。

   为什么需要：无边框透明窗里弹窗打开后，焦点仍可 Tab 到背后的顶栏按钮
   （最小化 / 关闭）——"弹窗还开着，回车却按到了后面"。读屏用户更难察觉。

   设计：文档级**单例**。全局只装一次监听，弹窗通过 register/unregister 登记；
   每次拦截时现算"最上层 overlay"是谁，不依赖各 overlay 自己保存状态。
   ⚠️ 现算 topmost 而不是缓存：弹窗会叠、会异步退场，缓存的"当前顶层"很容易过期。 */
const __focusTraps = new Set();
let __trapInstalled = false;
// ⚠️ readonly 输入框**不算**可编辑焦点目标：人设弹窗的「选择人设」框
// （#gp-pick / #pcp-pick）就是 readonly，焦点落在它上面时 Ctrl+V 等原生编辑
// 命令会被 Chromium 静默吞掉（无 paste 事件、无反馈）—— 2026-10-18 修
// 「人设界面 Ctrl+V 时灵时不灵」：Tab 循环与 focusin 兜底都不该把焦点
// 往只读框上拽。
const __FOCUSABLE = 'a[href], button:not([disabled]), input:not([type=hidden]):not([readonly]):not([disabled]),' +
  ' select:not([disabled]), textarea:not([readonly]):not([disabled]), [tabindex]:not([tabindex="-1"])';

// 「可编辑」焦点目标：接受 Ctrl+V/Ctrl+C/Ctrl+X/Ctrl+A 等原生编辑命令的控件。
// 2026-10-18 修「Ctrl+V 时灵时不灵」一族问题的统一口径 —— 焦点停在 readonly
// 输入框（各「选择人设/选择模型」框）、按钮或 body 上时，Chromium 对原生编辑
// 命令静默无操作（不报错、无反馈）。三个使用点：弹窗打开自动聚焦、
// requestClose 续编辑焦点拉回、closeModelModal 的只读顺延兜底。
const __EDITABLE_SEL = 'input:not([type=hidden]):not([readonly]):not([disabled]),' +
  ' textarea:not([readonly]):not([disabled]), select:not([disabled])';

/** scope 内第一个**可见且可编辑**的控件（无则 null）。 */
function focusFirstEditableIn(scope) {
  if (!scope || typeof scope.querySelector !== 'function') return null;
  const el = Array.from(scope.querySelectorAll(__EDITABLE_SEL))
    .find((n) => n.offsetParent !== null);
  if (el) { try { el.focus({ preventScroll: true }); } catch { /* ignore */ } }
  return el || null;
}

/** anchor 之后（同表单/文档序）第一个可见可编辑控件；没有则回落表单第一个。
 *  用于「选择器子弹窗关闭 + 页面重渲染后」的焦点归还：锚点本身通常是
 *  readonly 选择框（#cfg-model-pick 等），不能停。anchor 自身是只读框时用
 *  compareDocumentPosition 找它后面的第一个（readonly 不在可编辑集合里）。
 *  返回 null = 无可聚焦目标。 */
function focusFirstEditableAfter(anchor) {
  if (!anchor || !anchor.isConnected) return null;
  const root = anchor.closest('form') || anchor.closest('.model-modal') || document.body;
  const all = Array.from(root.querySelectorAll(__EDITABLE_SEL))
    .filter((el) => el.offsetParent !== null);
  const after = all.find((el) => anchor.compareDocumentPosition(el) & Node.DOCUMENT_POSITION_FOLLOWING);
  const next = after || all[0];
  if (next) { try { next.focus({ preventScroll: true }); } catch { /* ignore */ } }
  return next || null;
}

/** 当前最上层的弹窗遮罩（按 DOM 顺序取最后一个「未在退场」的）。 */
function __topModalOverlay() {
  const all = document.querySelectorAll('.model-modal-overlay:not(.closing)');
  return all.length ? all[all.length - 1] : null;
}
/** overlay 内可见且可聚焦的元素（tabindex="-1" 与隐藏节点排除）。 */
function __focusablesIn(overlay) {
  if (!overlay) return [];
  return Array.from(overlay.querySelectorAll(__FOCUSABLE)).filter((n) =>
    n.offsetParent !== null || n === document.activeElement);
}
function registerFocusTrap(overlay) {
  if (!overlay) return;
  __focusTraps.add(overlay);
  installModalFocusTrap();
}
function unregisterFocusTrap(overlay) {
  if (overlay) __focusTraps.delete(overlay);
}
function installModalFocusTrap() {
  if (__trapInstalled) return;
  __trapInstalled = true;

  /* ③ 自动登记：任何进入 DOM 的 .model-modal-overlay 都纳入陷阱约束，
        不必要求创建方记得调用 registerFocusTrap。
        ⚠️ 这是"兜底中的兜底"：modelModalShell 是正规入口，但全项目存在
           （且将来可能新增）直接手搓遮罩的路径 —— 焦点陷阱属于**安全/可达性
           底线**，不该因为某条路径忘了登记就整体失效。
        观察 body 的直接子节点增删即可（遮罩都是挂 body 下的一层）。 */
  try {
    new MutationObserver((muts) => {
      for (const m of muts) {
        for (const n of m.addedNodes) {
          if (n.nodeType === 1 && n.classList && n.classList.contains('model-modal-overlay')) {
            __focusTraps.add(n);
          }
        }
        for (const n of m.removedNodes) {
          if (n.nodeType === 1 && n.classList && n.classList.contains('model-modal-overlay')) {
            __focusTraps.delete(n);
          }
        }
      }
    }).observe(document.body, { childList: true });
  } catch { /* 极老环境无 MutationObserver → 仍可依赖显式 register */ }

  // ① Tab 循环：在最上层弹窗内首尾相接
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Tab') return;
    // 启动引导（.ob-overlay）压在所有弹窗之上时让路：引导不在 model-modal 体系里，
    // 不豁免的话焦点会被下面那层的陷阱拽回去，引导按钮点不动（2026-10-18）。
    if (document.querySelector('.ob-overlay')) return;
    const overlay = __topModalOverlay();
    if (!overlay) return;
    const items = __focusablesIn(overlay);
    const cur = document.activeElement;
    if (!items.length) { e.preventDefault(); return; }
    const first = items[0];
    const last = items[items.length - 1];
    // 焦点跑到弹窗外（或落在弹窗容器自身）→ 拉回对应边界
    if (!overlay.contains(cur)) {
      e.preventDefault();
      (e.shiftKey ? last : first).focus({ preventScroll: true });
      return;
    }
    if (e.shiftKey && cur === first) { e.preventDefault(); last.focus({ preventScroll: true }); }
    else if (!e.shiftKey && cur === last) { e.preventDefault(); first.focus({ preventScroll: true }); }
  }, true);

  // ② focusin 兜底：代码 / 鼠标把焦点挪到弹窗外 → 立刻拽回最上层弹窗。
  //    捕获阶段监听，先于任何聚焦到达目标前就能感知。
  document.addEventListener('focusin', (e) => {
    // 引导层在场时让路（同 Tab 循环的处理，2026-10-18）
    if (document.querySelector('.ob-overlay')) return;
    const overlay = __topModalOverlay();
    if (!overlay) return;
    if (overlay.contains(e.target)) return;
    const items = __focusablesIn(overlay);
    try { (items[0] || overlay).focus?.({ preventScroll: true }); } catch { /* ignore */ }
  }, true);
}

// ── 模型选择/添加/删除 模态框 ──
function closeModelModal(overlay) {
  if (!overlay) return;
  // R73：所有关闭路径（点遮罩 / 右上角 × / Esc / 自己的按钮）都在这里汇合 ——
  //   统一派发 qa-close，让 09-dialogs.js 的 Promise 型对话框知道"我被关掉了"。
  //   此前 Esc / × / 点遮罩三条路径只移除 DOM、不通知调用方 ——
  //   `await qaConfirm(...)` 会永远挂在那里不 settle（2026-09-24 UI 审查 P2）。
  try { overlay.dispatchEvent(new CustomEvent('qa-close')); } catch { /* ignore */ }
  // 先摘掉全局键盘监听并把焦点还给打开它的元素（可访问性）
  // ⚠️ removeEventListener 的第三参必须与 addEventListener 一致（都是捕获 true），
  //    否则监听器不会被解绑 —— 弹窗关了却还在抢 Esc。
  if (overlay._keyHandler) {
    document.removeEventListener('keydown', overlay._keyHandler, true);
    overlay._keyHandler = null;
  }
  // 焦点陷阱：从全局登记表里摘掉（真逻辑与监听器由 installModalFocusTrap 统一持有）
  unregisterFocusTrap(overlay);
  // ── body 滚动锁（2026-10-10 r86 修 P2）──
  // 弹窗打开时锁住背后的页面滚动，关闭时还原。
  // ⚠️ 用**计数器**而不是布尔量：弹窗会叠（模型选择 → 添加模型 → 人设选择），
  //    逐个关闭时只有全部关完才能解锁；用布尔量会被"第一个关掉的弹窗"提前解开，
  //    于是上层弹窗还在，背景却又能滚了。
  // ⚠️ 记录并还原**原值**而不是写死 ''：页面本身若因别的原因设了 overflow，
  //    硬写 '' 会把它一并抹掉。
  unlockBodyScroll(overlay);
  const back = overlay._prevFocus;
  let restored = false;
  if (back && typeof back.focus === 'function' && back.isConnected && back !== document.body) {
    try { back.focus({ preventScroll: true }); restored = true; } catch { /* ignore */ }
    // ⚠️ 2026-10-18：back 是 readonly 选择框（#gp-pick / #mc-model-pick /
    //    .fb-model-pick / #cfg-mem-model-pick …）时，焦点停在只读框上，之后
    //    弹窗/页面里所有 Ctrl+V、Ctrl+C 都被 Chromium 静默吞掉。子弹窗都是点
    //    这些只读框打开的，机械归还必然复现 —— 顺延到同一容器内第一个可编辑
    //    控件（弹窗内 → .model-modal；页面上 → form），从根上覆盖所有选择器。
    if (typeof back.matches === 'function' && back.matches('input[readonly], textarea[readonly]')) {
      focusFirstEditableAfter(back)
        || focusFirstEditableIn(back.closest('.model-modal') || back.closest('form') || document.body);
    }
  }
  if (!restored) {
    // back 不可用（是 body、或已随页面重渲染被移除）→ 焦点不能留在 body 上
    // （留在 body = 之后所有原生编辑命令静默失效）。落到"关掉本弹窗后的新
    // 最上层"；没有叠层则还给设置页表单第一个可编辑控件。
    const nextTop = Array.from(document.querySelectorAll('.model-modal-overlay:not(.closing)'))
      .filter((o) => o !== overlay).pop();
    if (nextTop) {
      if (!focusFirstEditableIn(nextTop)) {
        const btn = nextTop.querySelector('.model-modal-foot button:not([disabled])') || nextTop.querySelector('.model-modal-close');
        try { btn?.focus({ preventScroll: true }); } catch { /* ignore */ }
      }
    } else {
      focusFirstEditableIn(document.querySelector('#settings-form'));
    }
  }
  /* 平滑退场：遮罩淡出 + 面板下沉缩小，动画结束后再移除 DOM。
     与入场 popIn 对称，避免"砰"地消失。 */
  overlay.classList.add('closing');
  const modal = overlay.querySelector('.model-modal');
  let done = false;
  const finish = () => { if (!done) { done = true; overlay.remove(); } };
  if (modal) modal.addEventListener('animationend', finish, { once: true });
  setTimeout(finish, 400);   // 兜底：动画被 prefers-reduced-motion 压掉时也能关掉
}

/**
 * 弹窗外壳。
 * 主体方向判定：body **以 `<div class="model-modal-left"` 开头**才加 .row（横向），
 * 其余一律纵向堆叠。
 * ⚠️ 曾经只要 body 里"包含" model-modal-left 就加 row —— 但复合结构的弹窗
 *    （顶部工具栏 + 中部双栏 + 底部提示，如批量价格编辑、模型添加）需要的是
 *    外层纵向、双栏在 .ma-body 内部横向。误判成 row 后，工具栏与提示文
 *    两个 flex 项把宽度吃光，.ma-body（flex:1, basis 0）被挤成 0 宽，
 *    整个内容区隐形（2026-09-05 批量价格弹窗"空白"事故）。
 */
/**
 * @param {object} opts
 * @param {string} opts.head  标题
 * @param {string} opts.body  正文 HTML（调用方负责转义）
 * @param {string} [opts.foot] 底部按钮 HTML
 * @param {boolean} [opts.danger] 危险配色
 * @param {boolean} [opts.closeOnBackdrop=true] 点遮罩是否关闭。
 *   **编辑型弹窗必须传 false**：人设编辑器这类"填一半内容"的界面，误触外部
 *   直接关掉太伤体验（2026-10-18 用户反馈「点外边直接关闭」）。传 false 后仍有
 *   × / 取消 / Esc 三条明确退出路径，且未保存改动守卫照常提示。
 */
function modelModalShell({ head, body, foot = '', danger = false, closeOnBackdrop = true }) {
  const overlay = document.createElement('div');
  overlay.className = 'model-modal-overlay';
  overlay.innerHTML = `
    <div class="model-modal ${danger ? 'danger' : ''}" role="dialog" aria-modal="true" aria-label="${esc(String(head || '对话框'))}">
      <div class="model-modal-head">
        <span>${esc(String(head ?? ''))}</span>
        <button class="model-modal-close" type="button" aria-label="关闭" title="关闭（Esc）">×</button>
      </div>
      <!-- body / foot 按 HTML 契约原样插入（调用方负责其内部转义）——
           head 是**标题语义**，走 esc()，与上面的 aria-label 保持一致。
           2026-10-07：原先 head 也未转义，一旦有调用方把会话标题/群名当 title
           传进来，就能借 <img src> 打出外传信标（脚本执行被 CSP 的 script-src 'self' 挡住，
           但 img-src 放行了 http/https）。 -->
      <div class="model-modal-body${/^\s*<div class="model-modal-left"/.test(String(body)) ? ' row' : ''}">${body}</div>
      <div class="model-modal-foot">${foot || ''}</div>
    </div>`;
  document.body.appendChild(overlay);
  // 锁住背后页面滚动（r86 修 P2），与 closeModelModal 的 unlockBodyScroll 成对
  lockBodyScroll();
  overlay._scrollLocked = true;
  // ── 未保存改动守卫（2026-10-17）──
  // 群友反馈"管理员附加规则没法自动保存"：人设类弹窗是"改完点保存"的显式保存
  // 模型（不能混进表单自动保存链，原因见 06-settings-render.js saveToMap 注释），
  // 但此前 Esc / 点遮罩 / × 三条被动关闭路径会**静默丢弃**刚写的输入 ——
  // 写了一半的规则随手一关就没了，感知上就是"没保存上"。
  //
  // 通用化：除 pcp/gp 等已显式挂 overlay.__dirtyGuard()（返回 true=有未保存改动）的
  // 弹窗外，给**所有可编辑控件**自动挂监听 —— 用户真实编辑（e.isTrusted === true，
  // 可精确排除程序化 dispatchEvent 的回填）就把 __userEdited 置真。requestClose 据此
  // 弹确认，一次性覆盖所有"靠保存按钮落盘、但被动关闭会静默丢输入"的弹窗
  // （人设/记忆印象/社区配置/广播/Doctor 等）。
  //   · type=search 与 readonly/disabled 字段排除（过滤框是瞬态，不视为数据）。
  //   · 个别已自带实时保存的弹窗（如反馈草稿）可设 overlay._noDirtyGuard = true 退出。
  //   · 主动关闭（保存/取消等按钮直接调 closeModelModal）不经过守卫，语义不变。
  let __closing = false;
  let __userEdited = false;
  if (!overlay._noDirtyGuard) {
    // 用**捕获阶段委托**而非逐元素挂监听：既能覆盖弹窗里**动态插入**的输入框，
    // 也避免重复遍历 DOM。type=search 与 readonly/disabled 字段排除（过滤框属瞬态）。
    overlay.addEventListener('input', (e) => {
      const t = e.target;
      if (!t || typeof t.matches !== 'function') return;
      if (!t.matches('textarea, input:not([type=search]):not([readonly]):not([disabled]), select')) return;
      if (e.isTrusted) __userEdited = true;   // 排除程序化 dispatchEvent 的回填
    }, { capture: true, passive: true });
    overlay.addEventListener('change', (e) => {
      const t = e.target;
      if (!t || typeof t.matches !== 'function') return;
      if (!t.matches('textarea, input:not([type=search]):not([readonly]):not([disabled]), select')) return;
      if (e.isTrusted) __userEdited = true;
    }, { capture: true, passive: true });
  }
  const __isDirty = () => (typeof overlay.__dirtyGuard === 'function') ? overlay.__dirtyGuard() : __userEdited;
  const requestClose = async (force = false) => {
    if (__closing || !overlay.isConnected) return;
    // 确认框的开合会把焦点带走：点遮罩触发时 activeElement 已是 body（遮罩不可
    // 聚焦，先 blur 了文本框），按 × 触发时是 × 按钮本身。「继续编辑」后焦点若
    // 落在 body / 按钮上，弹窗里随后所有 Ctrl+V 都会静默失效（没有可编辑焦点
    // 目标）—— 2026-10-18 修「人设界面 Ctrl+V 时灵时不灵」的第三条路径。
    // 先记下进入时的焦点，续编辑时拉回弹窗内的可编辑控件。
    const focusBack = document.activeElement;
    if (!force && !overlay._noDirtyGuard && __isDirty()) {
      let ok = false;
      try {
        ok = await qaConfirm({
          title: '未保存的修改',
          message: '弹窗里有未保存的修改，关闭后将丢失。确定关闭吗？',
          confirmText: '丢弃修改',
          cancelText: '继续编辑'
        });
      } catch { ok = true; }   // 确认框自身异常时保持旧行为（直接关）
      if (!ok) {
        const t = (focusBack && overlay.contains(focusBack) && typeof focusBack.matches === 'function' && focusBack.matches(__EDITABLE_SEL))
          ? focusBack
          : (focusFirstEditableIn(overlay) || overlay.querySelector('.model-modal-close'));
        try { t?.focus({ preventScroll: true }); } catch { /* ignore */ }
        return;
      }
    }
    __closing = true;
    closeModelModal(overlay);
  };
  // 点遮罩关闭（编辑型弹窗会显式关掉这个行为，见 closeOnBackdrop 的注释）
  if (closeOnBackdrop) {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) requestClose();
    });
  }
  overlay.querySelector('.model-modal-close').addEventListener('click', () => requestClose());

  // ── 可访问性：Esc 关闭 + 焦点管理 ──
  // 此前全项目只有一处 Escape 监听，且位于一个从未被调用的死函数里 ——
  // 键盘用户打开弹窗后既关不掉、焦点也留在背景上，屏幕阅读器不播报对话框。
  const prevFocus = document.activeElement;
  const onKey = (e) => {
    if (e.key === 'Escape') {
      // ⚠️ 必须在**捕获阶段**（见下方 addEventListener 第三参 true）拦下 Esc。
      //    （2026-10-10 r86 修 P0）此前挂冒泡阶段 → 与 14-chrome.js:727 的
      //    document 级 keydown（启动时注册，**先注册先执行**）打架：
      //    14-chrome 先跑，读 e.defaultPrevented 仍是 false（本处理器还没轮到），
      //    于是 closeBigPage() 把全屏页也关了 —— 按一次 Esc 两层同关。
      //    捕获阶段从 document 向下传播时最先执行，preventDefault() 生效后
      //    14-chrome 的冒泡处理器就能读到 true 而自行跳过。
      //    （2026-10-17）改走 requestClose：有未保存改动时先弹确认，不再静默丢弃。
      e.preventDefault();
      e.stopPropagation();
      requestClose();
    }
  };
  // 只让"最上层"的弹窗响应 Esc：弹窗可以叠（模型选择 → 添加模型）
  overlay._onKey = onKey;
  overlay._prevFocus = prevFocus;
  const isTopmost = () => {
    const all = $$('.model-modal-overlay');
    return all[all.length - 1] === overlay;
  };
  const keyHandler = (e) => { if (isTopmost()) onKey(e); };
  overlay._keyHandler = keyHandler;
  // 第三参 true = 捕获阶段：先于所有冒泡监听器（含 14-chrome 的关全屏页）执行
  document.addEventListener('keydown', keyHandler, true);

  // ── 焦点陷阱（2026-10-10 r86 修 P2）──
  // 此前弹窗只做了两件事：打开时把焦点移进去、关闭时还给调用方。
  // 中间的 Tab 完全没管 —— 无边框窗里焦点一旦 Tab 出弹窗，就会跑到背后的
  // 顶栏最小化/关闭按钮上，"弹窗还开着，回车却按到了后面的按钮"。
  //
  // ⚠️ 实现放在**文档级**（见文件末尾 installModalFocusTrap），而不是给每个
  //    overlay 各挂一份：
  //    ① 弹窗可以叠，只有最上层该拦 —— 集中在一处判断最上层比自己各管各的更简单；
  //    ② 全项目还有别的代码直接用 `class="model-modal-overlay"` 手搓遮罩
  //       （老代码路径、以及测试），它们没走 modelModalShell 也应当被同样的规则约束。
  //    这里只登记"这个 overlay 存在"，真正的拦截逻辑全局只有一份。
  registerFocusTrap(overlay);

  // 打开后把焦点移进弹窗（优先第一个**可编辑**输入框，否则关闭按钮）
  // ⚠️ 选择器必须排除 readonly / disabled：人设弹窗（openGlobalPersonaModal /
  //    openPerChatPersonaModal）body 里第一个可聚焦元素是 readonly 的
  //    「选择人设」框（#gp-pick / #pcp-pick），焦点落在只读框上时 Ctrl+V
  //    粘贴被 Chromium 静默吞掉 —— 群友反馈"打开人设设置直接 Ctrl+V 粘不
  //    进去"的最高频路径（2026-10-18）。
  setTimeout(() => {
    if (!overlay.isConnected) return;
    if (focusFirstEditableIn(overlay)) return;   // 优先第一个可编辑控件（排除只读/禁用）
    const first = overlay.querySelector('.model-modal-foot button:not([disabled])')
      || overlay.querySelector('.model-modal-close');
    try { first?.focus({ preventScroll: true }); } catch { /* ignore */ }
  }, 0);
  return overlay;
}

/**
 * 调用明细弹窗：点「调用次数」卡片打开，列出各类工具分别被调用了多少次。
 *
 * 这东西对省钱没什么实际帮助 —— 但一张纯数字的成本表太无聊了，
 * 而"机器人这周发了 133 条消息、戳了 6 次、翻了 3 次聊天记录"这类数字
 * 恰恰是最能反映它"活成什么样"的。所以做出来，纯粹因为好看又好玩。
 */
// 弹窗之间跳转的挂起标记。
//
// 背景（2026-09-20 用户报障「填完模型地址后无法拉取模型列表」）：
//   旧流程有一个死循环 —— 「添加提供商」强制要求至少填一个模型 id，
//   而「拉取模型列表」按钮只在**已存在的提供商**的右列里。
//   于是新用户没有 Model id 就建不了提供商，也就不可能点到拉取按钮。
//   这里连同下面 openProviderAddModal 的改动一起打破它。
let pendingOpenModelManage = false;

/**
 * 关闭当前弹窗后打开「模型管理」。
 *
 * 不能直接在当前弹窗里再开一个：两个遮罩会**同层重叠**（.model-modal-overlay
 * 的层号全项目只有一处，见 style.css 0.5 段的 --z-model-modal-overlay），
 * 新旧两个 DOM 摞在一起，中间那段既点得到旧的关闭按钮、又点得到新的内容，
 * 视觉上也是一团糊。统一"先关后开"。
 * ⚠️ 原文此处写的是"样式表给它 +20 的 z-index 覆盖链，两个叠着开会出现
 *    新的在下面" —— 核实过：样式表与 JS 里都没有这条覆盖链，层号始终相同。
 *    真实理由是上面的同层重叠，不必据此推断层叠关系。
 */
function scheduleOpenModelManage() {
  pendingOpenModelManage = true;
  const opens = [...document.querySelectorAll('.model-modal-overlay:not(.closing)')];
  const top = opens[opens.length - 1];
  if (top) closeModelModal(top);
  // 等退场动画走完（closeModelModal 是淡出 400ms 后移除 DOM）。
  // 提前开会叠成两个遮罩：新的在下面、旧的淡出后还要再点一次。
  setTimeout(() => {
    if (!pendingOpenModelManage) return;
    pendingOpenModelManage = false;
    openModelManageModal();
  }, top ? 420 : 0);
}

function openToolBreakdown() {
  const counts = (state.usageStats && state.usageStats.toolCounts) || {};
  const entries = Object.entries(counts).filter(([, n]) => Number(n) > 0);
  const total = entries.reduce((a, [, n]) => a + n, 0);

  if (!total) {
    modelModalShell({
      head: '调用明细',
      body: '<div class="empty-hint">这个时间区间内还没有任何工具调用记录。</div>'
    });
    return;
  }

  const max = Math.max(...entries.map(([, n]) => n));

  // 按分类分组，分类内按次数降序
  const byCat = new Map();
  for (const [key, n] of entries) {
    const meta = TOOL_META[key] || { name: key, cat: '其他', icon: '🔧' };
    if (!byCat.has(meta.cat)) byCat.set(meta.cat, []);
    byCat.get(meta.cat).push({ key, n, ...meta });
  }
  const cats = TOOL_CAT_ORDER.filter((c) => byCat.has(c));
  for (const c of byCat.keys()) if (!cats.includes(c)) cats.push(c);

  const rows = cats.map((cat) => {
    const items = byCat.get(cat).sort((a, b) => b.n - a.n);
    const catTotal = items.reduce((a, x) => a + x.n, 0);
    return `
      <div class="tb-cat">
        <div class="tb-cat-head">
          <span>${esc(cat)}</span>
          <span class="tb-cat-sum">${catTotal} 次 · ${(catTotal / total * 100).toFixed(0)}%</span>
        </div>
        ${items.map((it) => `
          <div class="tb-row">
            <span class="tb-icon">${it.icon}</span>
            <span class="tb-name">${esc(it.name)}</span>
            <span class="tb-code">${esc(it.key)}</span>
            <span class="tb-bar"><i style="width:${(it.n / max * 100).toFixed(1)}%"></i></span>
            <span class="tb-n">${it.n}</span>
          </div>`).join('')}
      </div>`;
  }).join('');

  // 一句话小结（让这堆数字有个"人味"的结论）
  const say = counts.send_message ? `发了 ${counts.send_message} 条消息` : '一条都没发';
  const poke = counts.send_poke ? `、戳了 ${counts.send_poke} 次` : '';
  // 表情工具已抽成 plugins/sticker，工具 id 变成 sticker__send_sticker；
  // 兼容旧会话档案里没有前缀的历史计数。
  const stickerN = Number(counts['sticker__send_sticker'] || counts.send_sticker) || 0;
  const sticker = stickerN ? `、贴了 ${stickerN} 张表情` : '';
  const search = (Number(counts.web_search) || 0) + (Number(counts.web_fetch) || 0);
  const searchTxt = search ? `、联网查了 ${search} 次` : '';

  modelModalShell({
    head: `调用明细（${state.usageStats?.rangeLabel || ''} · 共 ${total} 次）`,
    body: `
      <div class="tool-breakdown">
        <div class="tb-lead">这段时间里，机器人${say}${poke}${sticker}${searchTxt}。</div>
        ${rows}
      </div>`,
    foot: '<div class="muted" style="font-size:11.5px">工具调用本身不额外计费，成本来自它们消耗的 token。</div>'
  });
}

// ── 人设选择/添加 模态框 ──

/** 选择人设：弹窗列出所有人设（含自定义），点击后填入角色设定文本框。 */
/**
 * 「选择人设」弹窗：把选中的人设文本填回某个「角色设定」编辑器。
 *
 * ⚠️ 必须能指定**填回目标**（`target`）：
 *   默认目标是设置页统一编辑器（`#cfg-*`），但那个编辑器只在「统一人设」模式下在场；
 *   从人设/分会话人设弹窗里点「选择人设」时，得填进弹窗自己的 `#gp-roletext` / `#pcp-roletext`。
 *   以前写死 `$('#cfg-roletext')` —— 元素不在场时 `null.value` 直接抛错（或静默无效），
 *   分群模式下「添加人设」填不进去就是这么来的。
 *
 * @param {{roleSel?:string, rulesSel?:string, pickSel?:string, hintSel?:string}} target
 */
function openPersonaPicker(target = {}) {
  const T = {
    roleSel: '#cfg-roletext',
    rulesSel: '#cfg-customrules',
    pickSel: '#cfg-persona-pick',
    hintSel: '#persona-pick-hint',
    ...target
  };
  const roleEl = document.querySelector(T.roleSel);
  const entries = Object.entries(state.personaTemplates || {});
  if (!entries.length) {
    const h = document.querySelector(T.hintSel);
    if (h) h.textContent = '人设列表为空';
    return;
  }
  const overlay = modelModalShell({
    head: '选择人设',
    body: `<div class="model-modal-right" id="persona-list" style="flex:1"></div>`,
    foot: `<button class="btn" id="persona-cancel">取消</button>`
  });
  const listEl = overlay.querySelector('#persona-list');

  /**
   * 渲染人设列表（2026-10-18 改）。
   * 群友反馈：原先要"先选中 → 回编辑弹窗 → 点「删除当前自定义人设」"，而选中
   * 就会关掉本弹窗，等于删个人设要绕一大圈。现在每行右侧直接给「删除」。
   * 只对自定义人设（custom_*）显示 —— 内置的不给删，与后端约束一致。
   * 用事件委托绑定：删除后原地重绘列表，不需要重新挂监听。
   */
  const renderList = () => {
    const list = Object.entries(state.personaTemplates || {});
    listEl.innerHTML = list.map(([id, p]) => `
      <div class="mm-model" data-id="${esc(id)}">
        <span class="mm-check">${(String(p?.text ?? '').trim() === String(roleEl?.value ?? '').trim()) ? '✓' : ''}</span>
        <span>${esc(p.name)}</span>
        <span class="muted" style="font-size:11px">${p.builtin ? '内置' : '自定义'}</span>
        ${p.builtin ? '' : `<button class="btn btn-small btn-danger mm-del" type="button" data-del="${esc(id)}" style="margin-left:auto" title="删除这个自定义人设">删除</button>`}
      </div>`).join('');
  };

  listEl.addEventListener('click', async (e) => {
    // ── 行内「删除」：拦截，不能让它冒泡成"选中这一行并关窗" ──
    const delBtn = e.target.closest('.mm-del');
    if (delBtn) {
      e.stopPropagation();
      const id = delBtn.dataset.del;
      const tpl = state.personaTemplates?.[id];
      if (!tpl) return;
      const ok = await qaConfirm({
        danger: true,
        title: '删除人设',
        message: `确定删除自定义人设「${tpl.name}」？\n\n删除后不可恢复。如果它正在被使用，角色设定会回落到内置默认。`,
        confirmText: '删除',
        cancelText: '取消'
      });
      if (!ok) return;
      try {
        await api(`/api/persona-templates/${encodeURIComponent(id)}`, { method: 'DELETE', body: '{}' });
        // 正在用的就是它 → 回落到内置默认（与「删除当前自定义人设」同一口径）
        const usedNow = roleEl && String(roleEl.value).trim() === String(tpl.text ?? '').trim();
        const fallback = state.personaTemplates?.xiaojingyu;
        if (usedNow && fallback) {
          roleEl.value = fallback.text;
          const pickEl = document.querySelector(T.pickSel);
          if (pickEl) pickEl.value = fallback.name;
          roleEl.dispatchEvent(new Event('input', { bubbles: true }));
        }
        await loadSettings();   // 刷新全局模板列表（本弹窗读的就是 state.personaTemplates）
        // ⚠️ 2026-10-18：loadSettings() 里 state.personaTemplates 的更新在
        //    Promise.all().then 慢路径（未 await）——只等它会出现"后端删了、
        //    列表里还在"（群友实测）。删除后必须显式拉一次模板列表再重绘。
        try {
          const t = await api('/api/persona-templates');
          const map = {};
          for (const x of (t.templates || [])) map[x.id] = { name: x.name, text: x.text, builtin: !!x.builtin };
          state.personaTemplates = map;
        } catch {
          delete state.personaTemplates[id];   // 拉不到就本地删，至少这次界面是对的
        }
        renderList();           // 原地重绘，弹窗不关
        const h = document.querySelector(T.hintSel);
        if (h) h.textContent = `人设「${tpl.name}」已删除${usedNow ? '，当前角色设定已回落到内置默认' : ''}`;
      } catch (err) {
        const h = document.querySelector(T.hintSel);
        if (h) h.textContent = `删除失败：${err.message}`;
      }
      return;
    }

    // ── 行点击 = 选中这个人设 ──
    const row = e.target.closest('.mm-model');
    if (!row) return;
    {
      const id = row.dataset.id;
      const tpl = state.personaTemplates[id];
      if (tpl) {
        if (roleEl) roleEl.value = tpl.text;
        // ⚠️ 2026-10-16 修：内置人设没有 customRules 字段，旧写法
        // `rulesEl.value = tpl.customRules || ''` 会在用户每选一次内置人设时，
        // 把编辑器里已经写好的「管理员附加规则」静默抹成空串 —— 选完直接保存
        // 即永久丢失。改为只在模板**自带**附加规则时才覆盖，没有就不动用户的值。
        const rulesEl = document.querySelector(T.rulesSel);
        if (rulesEl && String(tpl.customRules ?? '').trim()) rulesEl.value = tpl.customRules;
        const pickEl = document.querySelector(T.pickSel);
        if (pickEl) pickEl.value = tpl.name;
        // ⚠️ 程序化赋值不触发 input/change 事件 → 自动保存不会启动。
        //    这是"选了人设但改了不生效/切走就丢"的根因之一：用户以为点选
        //    完就保存了，实际上防抖窗口从未开启，切页签的 flush 也无从发起。
        //    一律派发：填的是设置页元素时它触发自动保存；填的是弹窗元素时
        //    到不了 #settings-form（弹窗挂在 body 下，弹窗自己走 POST 保存），
        //    但弹窗内部的监听器（如"删除当前自定义人设"的显隐）靠它同步。
        if (roleEl) roleEl.dispatchEvent(new Event('input', { bubbles: true }));
      }
      closeModelModal(overlay);
      // ⚠️ 2026-10-18：closeModelModal 会把焦点还给打开本弹窗前的元素 —— 用户是
      //    点 readonly 的「选择人设」框进来的，焦点回到只读框上，之后弹窗里所有
      //    Ctrl+V 都被 Chromium 静默吞掉（群友反馈"人设界面有时粘不进去"的路径
      //    之一）。显式把焦点交还调用方指定的可编辑目标（人设文本框）。
      const focusEl = T.focusSel && document.querySelector(T.focusSel);
      if (focusEl) { try { focusEl.focus({ preventScroll: true }); } catch { /* ignore */ } }
      // ⚠️ 这里**不能**调 syncPersonaButtons()：它是 07-settings-events.js 里
      //    bindSettingsEvents() 的**局部函数**，本文件够不到 —— 以前直接调用会抛
      //    ReferenceError（弹窗已经关了所以只表现为 console 报错）。页面重渲染时
      //    bindSettingsEvents 自己会同步一次按钮状态，这里不需要补。
    }
  });
  renderList();
  overlay.querySelector('#persona-cancel').addEventListener('click', () => closeModelModal(overlay));
}

/** 添加人设：弹窗填写人设名称、角色设定、管理员附加规则。
 *  支持把 .txt/.md 文件直接拖进「角色设定」框 —— 自动读文件填入（名称为空时用文件名）。
 *  @param target 同 openPersonaPicker：加完要填回哪个编辑器（默认设置页统一编辑器）。 */
function openPersonaCreateModal(target = {}) {
  const T = {
    roleSel: '#cfg-roletext',
    rulesSel: '#cfg-customrules',
    pickSel: '#cfg-persona-pick',
    hintSel: '#persona-pick-hint',
    ...target
  };
  // 提示语优先写进调用方指定的提示位（弹窗里自带一个），页面上才退回全局提示位
  const setHint = (msg) => {
    const h = document.querySelector(T.hintSel);
    if (h) h.textContent = msg;
  };
  const overlay = modelModalShell({
    head: '添加人设',
    // 编辑型弹窗（要粘一大段人设文本）：点外部不关闭，防误触清空
    closeOnBackdrop: false,
    body: `
      <div class="field" style="flex:1;min-width:0">
        <label>人设名称</label>
        <input type="text" id="new-persona-name" placeholder="例如：毒舌老哥" />
      </div>
      <div class="field" style="flex:1;min-width:0">
        <label>角色设定</label>
        <textarea id="new-persona-text" class="persona-role-text" style="min-height:220px" placeholder="人设文本（把 .txt 文件拖进这个框可以自动读取）"></textarea>
      </div>
      <div class="field" style="flex:1;min-width:0">
        <label>管理员附加规则（可选）</label>
        <textarea id="new-persona-rules" style="min-height:90px" placeholder="可选：追加到系统提示的规则"></textarea>
      </div>`,
    foot: `<button class="btn" id="persona-add-cancel">取消</button>
           <button class="btn btn-primary" id="persona-add-apply">确认添加</button>`
  });
  overlay.querySelector('#persona-add-cancel').addEventListener('click', () => closeModelModal(overlay));
  // ── 拖入 txt/md 自动读取 ──
  // 目标是「角色设定」textarea 本身（用户直觉就是往文本框里丢文件）。
  // dragover 必须 preventDefault 才允许 drop；高亮态挂在 textarea 上，离开/放下即撤。
  const textEl = overlay.querySelector('#new-persona-text');
  const nameEl = overlay.querySelector('#new-persona-name');
  const readDropFile = async (file) => {
    if (!file) return;
    if (file.size > 512 * 1024) {
      setHint('文件太大（上限 512KB），请先拆分再拖入。');
      return;
    }
    try {
      const content = await file.text();
      textEl.value = content;
      // 程序化赋值不触发事件——这里不需要自动保存（弹窗还没确认），但名称留空时顺手用文件名
      if (!nameEl.value.trim()) nameEl.value = file.name.replace(/\.(txt|md|markdown)$/i, '');
      textEl.dispatchEvent(new Event('input', { bubbles: true }));
      setHint(`已读取「${file.name}」（${content.length} 字），确认添加后生效。`);
    } catch (e) {
      setHint(`读取文件失败：${e.message}`);
    }
  };
  textEl.addEventListener('dragover', (e) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
    textEl.classList.add('persona-drop-hot');
  });
  textEl.addEventListener('dragleave', () => textEl.classList.remove('persona-drop-hot'));
  textEl.addEventListener('drop', (e) => {
    e.preventDefault();
    textEl.classList.remove('persona-drop-hot');
    readDropFile(e.dataTransfer?.files?.[0]);
  });
  // ⚠️ 2026-10-18：打开就把焦点放到「角色设定」框 —— 用户进这个弹窗的主操作
  //    就是粘贴一大段人设文本（.txt 拖读也是为它设计的）。modelModalShell 的
  //    自动聚焦会落到第一个可编辑元素「人设名称」上，整段 Ctrl+V 会灌进名称框
  //    —— 群友反馈的"没法正常粘贴进去"也包含这一路径。本 setTimeout 后注册，
  //    覆盖 shell 的自动聚焦。
  setTimeout(() => { try { textEl.focus({ preventScroll: true }); } catch { /* ignore */ } }, 0);
  overlay.querySelector('#persona-add-apply').addEventListener('click', async () => {
    const name = overlay.querySelector('#new-persona-name').value.trim();
    const text = overlay.querySelector('#new-persona-text').value.trim();
    const customRules = overlay.querySelector('#new-persona-rules').value.trim();
    if (!name) { setHint('人设名称不能为空'); return; }
    if (!text) { setHint('角色设定不能为空'); return; }
    try {
      await api('/api/persona-templates', {
        method: 'POST',
        body: JSON.stringify({ name, text, customRules })
      });
      closeModelModal(overlay);
      const roleEl = document.querySelector(T.roleSel);
      const rulesEl = document.querySelector(T.rulesSel);
      const pickEl = document.querySelector(T.pickSel);
      if (roleEl) roleEl.value = text;
      // ⚠️ 2026-10-16：与 openPersonaPicker 同款 —— 新建人设没填附加规则时
      // （customRules 为空）**不要**覆盖编辑器里已写好的规则，否则"添加人设"
      // 会静默抹掉用户的「管理员附加规则」。只在新建时确实填了才覆盖。
      if (rulesEl && customRules) rulesEl.value = customRules;
      if (pickEl) pickEl.value = name;
      // 同 openPersonaPicker：程序化赋值不触发 input 事件，自动保存不会启动 ——
      // 主动派发一次，否则"添加完人设切走页签"就丢（保存从未发起）。
      // 只对在设置表单里的元素派发（弹窗自己走 POST，派发无意义）。
      if (roleEl && document.getElementById('settings-form')?.contains(roleEl)) {
        roleEl.dispatchEvent(new Event('input', { bubbles: true }));
      }
      // 拉动人设模板列表，让「选择人设」里立刻能看到刚加的这条
      await loadSettings();
      // loadSettings 会重渲染整个表单；重渲染用的是 state.config（含刚派发
      // 事件触发的自动保存最终值）。自动保存在途时渲染守卫会拦下并补绘，不会丢。
      setHint(`人设「${name}」已添加并填入表单，自动保存稍后生效（也可切走页签前确认）。`);
    } catch (e) {
      setHint(`添加失败：${e.message}`);
    }
  });
}

/**
 * 「模型配置」模态框（2026-09-18 改版）：收纳原页面的
 * 模型目录 / Base URL / API Key / 图片视频专用模型 / 图片视频开关 / 视频理解方式。
 * 保存按钮 = 把这些字段 PATCH 到 /api/config（掩码 Key 不回传，与主页面同语义）。
 */
function openModelConfigModal() {
  const c = state.config || {};
  const currentProvider = (state.providers || []).find((p) => p.id === c.api?.provider);
  const displayOf = (modelId) => {
    const m = String(modelId || '').trim();
    if (!m) return '';
    for (const p of (state.providers || [])) {
      if ((p.modelNames || {})[m]) return p.modelNames[m];
    }
    return m;
  };
  const overlay = modelModalShell({
    head: '模型配置',
    closeOnBackdrop: false,   // 编辑型：点外部不关闭，防误触丢内容
    body: `
      <div class="field"><label>模型目录（点击选择）</label>
        <div style="display:flex;gap:8px">
          <input type="text" id="mc-model-pick" readonly placeholder="点击选择模型" value="${esc(currentProvider ? ((currentProvider.modelNames || {})[c.api.model] || c.api.model || '') : '')}" style="flex:1;cursor:pointer" />
          <button class="btn btn-small" id="mc-test-btn">测试连通性</button>
        </div>
        <div class="hint" id="mc-test-result" style="margin-top:4px"></div></div>
      <div class="field-row">
        <div class="field"><label>当前 Base URL</label>
          <div style="display:flex;gap:8px">
            <input type="text" id="mc-baseurl" readonly value="${esc(c.api?.baseUrl || '')}" style="flex:1" />
            <button class="btn btn-small" id="mc-fetch-models" type="button" title="从当前提供商的端点自动拉取可用模型列表（使用已保存的 API Key；新输入未保存的 Key 不参与）">⟳ 拉取模型</button>
          </div></div>
        <div class="field"><label>当前 API Key</label>
          <div style="display:flex;gap:8px">
            <input type="password" id="mc-apikey" value="${esc((currentProvider?.hasKey || c.api?.apiKey) ? '******' : '')}" placeholder="输入新 Key 可替换；留空保持不变" autocomplete="new-password" style="flex:1" />
            <button class="btn btn-small" id="mc-apikey-toggle" type="button">显示</button>
            <button class="btn btn-small btn-danger" id="mc-apikey-clear" type="button" title="清除已保存的 API Key（留空保存并不会清除，必须点这个按钮）">清除</button>
          </div></div>
      </div>
      <div class="field"><label>网络代理（可选，接入国外 API 用）</label>
        <input type="text" id="mc-proxy" placeholder="http://127.0.0.1:7890（留空 = 直连）" value="${esc(c.api?.proxy || '')}" style="width:100%" />
        <div class="hint" style="margin-top:4px">填本机代理地址后，对话 / 拉取模型 / 连通性测试都会走它。仅支持 http:// 代理；网页阅读与 QQ 协议端不走此项。</div></div>
      <div class="checkbox-row"><input type="checkbox" class="sw" id="mc-vision" ${c.api?.vision !== false ? 'checked' : ''} />
        <label for="mc-vision">图片输入（关闭则移除看图工具）</label>
        <span id="mc-vision-hint" class="muted" style="font-size:12px;align-self:center"></span></div>
      <div class="checkbox-row"><input type="checkbox" class="sw" id="mc-video" ${c.api?.video === true ? 'checked' : ''} />
        <label for="mc-video">视频输入（GIF 转视频发给模型）</label></div>
      <div class="field-row">
        <div class="field"><label>图片输入专用模型（留空用主模型）</label>
          <div style="display:flex;gap:8px">
            <input type="text" id="mc-vision-model-pick" readonly placeholder="点击选择" value="${esc(displayOf(c.api?.visionModel))}" style="flex:1;cursor:pointer" />
            <button class="btn btn-small" id="mc-vision-model-clear" type="button">清空</button>
          </div></div>
        <div class="field"><label>视频输入专用模型（留空用主模型）</label>
          <div style="display:flex;gap:8px">
            <input type="text" id="mc-video-model-pick" readonly placeholder="点击选择" value="${esc(displayOf(c.api?.videoModel))}" style="flex:1;cursor:pointer" />
            <button class="btn btn-small" id="mc-video-model-clear" type="button">清空</button>
          </div></div>
      </div>
      <div class="field"><label>视频理解方式</label>
        <select id="mc-video-mode">
          ${[
            ['auto', '自动：配了视频专用模型就原生读视频，否则抽帧'],
            ['native', '原生：把视频直接交给全模态模型（需模型支持）'],
            ['frames', '抽帧：把视频变成若干张图片（任何视觉模型都能用）'],
            ['off', '关闭：只读时长/分辨率等元信息']
          ].map(([v, l]) => `<option value="${v}" ${(c.api?.videoMode || 'auto') === v ? 'selected' : ''}>${l}</option>`).join('')}
        </select></div>`,
    foot: `<button class="btn" id="mc-cancel">取消</button>
           <button class="btn btn-primary" id="mc-save">保存</button>`
  });

  // 模型选择：复用主模型选择器语义，但选完只写本弹窗的表单（不立即 POST）
  overlay.querySelector('#mc-model-pick').addEventListener('click', async () => {
    const providers = state.providers || [];
    // 空目录时给一条**可走的路**：就近关掉本弹窗并打开「模型管理」。
    // 原先只说"请先用「模型管理」添加提供商" —— 而这里没有任何按钮能过去，
    // 用户只能自己猜「模型管理」在哪个菜单里（实测就卡在这一步）。
    if (!providers.length) {
      if (await qaConfirm('模型目录还是空的。\n\n现在去「模型管理」添加提供商吗？\n（填 Base URL + API Key 后即可拉取模型列表）')) {
        scheduleOpenModelManage();
      }
      return;
    }
    const pickOverlay = modelModalShell({
      head: '选择模型',
      body: `
        <div class="model-modal-left" id="mcp-left"></div>
        <div class="model-modal-right" id="mcp-right"></div>`,
      foot: `<button class="btn" id="mcp-cancel">取消</button>`
    });
    const pl = pickOverlay.querySelector('#mcp-left');
    const pr = pickOverlay.querySelector('#mcp-right');
    let activePid = c.api?.provider || providers[0].id;
    const renderLeft = () => {
      pl.innerHTML = providers.map((p) =>
        `<div class="mm-prov ${p.id === activePid ? 'active' : ''}" data-pid="${esc(p.id)}">${esc(p.displayName || p.id)}</div>`).join('');
      pl.querySelectorAll('.mm-prov').forEach((el) => el.addEventListener('click', () => { activePid = el.dataset.pid; renderLeft(); renderRight(); }));
    };
    const renderRight = () => {
      const p = providers.find((x) => x.id === activePid);
      if (!p) { pr.innerHTML = ''; return; }
      const names = p.modelNames || {};
      pr.innerHTML = p.models.map((m) => `
        <div class="mm-model" data-model="${esc(m)}">
          <span>${esc(names[m] || m)}</span>
          ${(names[m] || m) !== m ? `<span class="muted" style="font-size:11px">${esc(m)}</span>` : ''}
        </div>`).join('') || '<div class="muted" style="padding:10px">该提供商下没有模型</div>';
      pr.querySelectorAll('.mm-model').forEach((el) => el.addEventListener('click', () => {
        overlay.querySelector('#mc-model-pick').value = (names[el.dataset.model] || el.dataset.model);
        overlay.querySelector('#mc-picked').value = `${activePid}|||${el.dataset.model}`;
        overlay.querySelector('#mc-baseurl').value = p.baseURL || '';
        closeModelModal(pickOverlay);
      }));
    };
    renderLeft();
    renderRight();
    pickOverlay.querySelector('#mcp-cancel').addEventListener('click', () => closeModelModal(pickOverlay));
  });
  // 隐藏字段：选中模型的 pid|||model（未选择时为空 = 保持现状）
  const hidden = document.createElement('input');
  hidden.type = 'hidden';
  hidden.id = 'mc-picked';
  overlay.querySelector('.model-modal-body').appendChild(hidden);

  // 「⟳ 拉取模型」：从当前提供商的端点自动拉取可用模型列表（R37 用户需求）。
  // 复用模型管理的整套链路：POST /api/providers/fetch-models 拉列表 →
  // openModelAddModal 勾选搜索 → 并入提供商目录。之后点「模型目录」即可选到新模型。
  // ⚠️ Key 口径与模型管理一致：用后端**已保存**的 Key —— 弹窗里新输入、还没保存的不参与。
  overlay.querySelector('#mc-fetch-models').addEventListener('click', async () => {
    const btn = overlay.querySelector('#mc-fetch-models');
    const provider = (state.providers || []).find((p) => p.id === state.config?.api?.provider)
      || (state.providers || [])[0];
    if (!provider) {
      if (await qaConfirm('还没有提供商，无法拉取模型。\n\n现在去「模型管理」添加提供商吗？')) scheduleOpenModelManage();
      return;
    }
    btn.disabled = true;
    btn.textContent = '拉取中…';
    try {
      const r = await api('/api/providers/fetch-models', {
        method: 'POST',
        body: JSON.stringify({ baseUrl: provider.baseURL, providerId: provider.id })
      });
      if (!(r.models || []).length) {
        qaAlert('端点没有返回任何模型。\n请检查 Base URL / API Key 是否正确（新 Key 要先保存才会用于拉取）。');
        return;
      }
      openModelAddModal(provider.baseURL, '', r.models || [], provider.id);
    } catch (e) {
      qaAlert(`拉取失败：${e.message}`);
    } finally {
      btn.disabled = false;
      btn.textContent = '⟳ 拉取模型';
    }
  });

  // 专用模型选择（写隐藏字段，保存时带走）
  const pickSpecial = (which) => {
    const providers = state.providers || [];
    if (!providers.length) { qaAlert('模型目录为空。'); return; }
    const fieldId = which === 'vision' ? 'mc-vision-model-pick' : 'mc-video-model-pick';
    const pickOverlay = modelModalShell({
      head: which === 'vision' ? '选择图片输入模型' : '选择视频输入模型',
      body: `
        <div class="model-modal-left" id="msp-left"></div>
        <div class="model-modal-right" id="msp-right"></div>`,
      foot: `<button class="btn" id="msp-cancel">取消</button>`
    });
    const pl = pickOverlay.querySelector('#msp-left');
    const pr = pickOverlay.querySelector('#msp-right');
    let activePid = providers[0].id;
    const renderLeft = () => {
      pl.innerHTML = providers.map((p) =>
        `<div class="mm-prov ${p.id === activePid ? 'active' : ''}" data-pid="${esc(p.id)}">${esc(p.displayName || p.id)}</div>`).join('');
      pl.querySelectorAll('.mm-prov').forEach((el) => el.addEventListener('click', () => { activePid = el.dataset.pid; renderLeft(); renderRight(); }));
    };
    const renderRight = () => {
      const p = providers.find((x) => x.id === activePid);
      if (!p) { pr.innerHTML = ''; return; }
      const names = p.modelNames || {};
      pr.innerHTML = p.models.map((m) => `
        <div class="mm-model" data-model="${esc(m)}">
          <span>${esc(names[m] || m)}</span>
          ${(names[m] || m) !== m ? `<span class="muted" style="font-size:11px">${esc(m)}</span>` : ''}
        </div>`).join('') || '<div class="muted" style="padding:10px">该提供商下没有模型</div>';
      pr.querySelectorAll('.mm-model').forEach((el) => el.addEventListener('click', () => {
        overlay.querySelector('#' + fieldId).value = (names[el.dataset.model] || el.dataset.model);
        overlay.querySelector('#' + fieldId).dataset.model = el.dataset.model;
        closeModelModal(pickOverlay);
      }));
    };
    renderLeft();
    renderRight();
    pickOverlay.querySelector('#msp-cancel').addEventListener('click', () => closeModelModal(pickOverlay));
  };
  overlay.querySelector('#mc-vision-model-pick').addEventListener('click', () => pickSpecial('vision'));
  overlay.querySelector('#mc-video-model-pick').addEventListener('click', () => pickSpecial('video'));
  overlay.querySelector('#mc-vision-model-clear').addEventListener('click', () => {
    const el = overlay.querySelector('#mc-vision-model-pick');
    el.value = ''; delete el.dataset.model;
  });
  overlay.querySelector('#mc-video-model-clear').addEventListener('click', () => {
    const el = overlay.querySelector('#mc-video-model-pick');
    el.value = ''; delete el.dataset.model;
  });

  // Key 显示/清除：与主页面同款（fetchRealKey 走 /api/providers/key）
  overlay.querySelector('#mc-apikey-toggle').addEventListener('click', async () => {
    const input = overlay.querySelector('#mc-apikey');
    const btn = overlay.querySelector('#mc-apikey-toggle');
    const show = input.type === 'password';
    if (show) {
      try {
        const pid = c.api?.provider;
        const r = pid ? await api(`/api/providers/key?providerId=${encodeURIComponent(pid)}`) : await api('/api/api-key');
        input.type = 'text';
        input.value = String(r.apiKey || '（无）');
        btn.textContent = '隐藏';
      } catch (e) { qaAlert(`读取密钥失败：${e.message}`); }
    } else {
      input.type = 'password';
      input.value = '******';
      btn.textContent = '显示';
    }
  });
  overlay.querySelector('#mc-apikey-clear').addEventListener('click', async () => {
    // ⚠️（2026-10-10 r86 修 P2）清除凭据 → danger:true
    if (!await qaConfirm({
      danger: true,
      confirmText: '清除 Key',
      message: '确定清除已保存的 API Key？'
    })) return;
    try {
      const pid = c.api?.provider;
      if (pid) {
        await api('/api/providers/set-key', { method: 'POST', body: JSON.stringify({ providerId: pid, apiKey: '' }) });
      } else {
        await api('/api/config', { method: 'POST', body: JSON.stringify({ api: { apiKey: '' } }) });
      }
      const input = overlay.querySelector('#mc-apikey');
      input.value = '';
      input.placeholder = '输入新 Key 可替换';
      // ⚠️ 2026-10-20（与模型管理右列同一坑）：loadSettings() 里的 providers 在慢路径、
      //    没有被 await —— 不清这一次的话 state.providers 还认为 hasKey=true，
      //    紧接着打开的「模型管理 / 模型配置」会显示"已保存密钥"的旧状态。
      await refreshProvidersState();
      await loadSettings();
    } catch (e) { qaAlert(`清除失败：${e.message}`); }
  });

  // 连通性测试：与主页面 runConnectivityTest 同款逻辑（读弹窗里的表单值）
  overlay.querySelector('#mc-test-btn').addEventListener('click', async () => {
    const btn = overlay.querySelector('#mc-test-btn');
    const out = overlay.querySelector('#mc-test-result');
    btn.disabled = true;
    btn.textContent = '测试中…';
    out.textContent = '';
    try {
      const picked = overlay.querySelector('#mc-picked').value;
      // 2026-10-20：弹窗里选中的模型可能来自**另一家**提供商（比如主提供商是 openai，
      //   这里挑了个 anthropic 的模型）。不把它的协议一起带上，服务端就会拿主提供商的
      //   协议去请求，端点/鉴权头全错 → 明明配置没问题也报 4xx。
      const [pickedPid, pickedModel] = picked ? String(picked).split('|||') : ['', ''];
      const pickedProv = (state.providers || []).find((x) => x.id === pickedPid);
      const model = picked ? pickedModel : (c.api?.model || '');
      const keyInput = overlay.querySelector('#mc-apikey');
      const raw = (keyInput.value || '').trim();
      const apiKey = (raw && raw !== '******') ? raw : '';
      const r = await api('/api/providers/test-chat', {
        method: 'POST',
        body: JSON.stringify({
          baseUrl: overlay.querySelector('#mc-baseurl').value.trim(),
          apiKey,
          model,
          apiProtocol: pickedProv?.apiProtocol || ''
        })
      });
      const res = r.result || {};
      out.textContent = res.ok ? `✓ 测试通过（${res.latencyMs}ms）` : `✗ ${res.note || '测试失败'}`;
    } catch (e) {
      out.textContent = `测试失败：${e.message}`;
    }
    btn.disabled = false;
    btn.textContent = '测试连通性';
  });

  overlay.querySelector('#mc-cancel').addEventListener('click', () => closeModelModal(overlay));
  overlay.querySelector('#mc-save').addEventListener('click', async () => {
    const patch = {
      vision: overlay.querySelector('#mc-vision').checked,
      video: overlay.querySelector('#mc-video').checked,
      videoMode: overlay.querySelector('#mc-video-mode').value
    };
    const picked = overlay.querySelector('#mc-picked').value;
    if (picked) {
      const [pid, model] = picked.split('|||');
      patch.provider = pid;
      patch.model = model;
      const p = (state.providers || []).find((x) => x.id === pid);
      if (p?.baseURL) patch.baseUrl = p.baseURL;
    } else if (overlay.querySelector('#mc-baseurl').value.trim() !== (c.api?.baseUrl || '')) {
      patch.baseUrl = overlay.querySelector('#mc-baseurl').value.trim();
    }
    // 专用模型：dataset.model 里是干净的 id（没选过就删属性 = 走"保持原值"分支）
    const vEl = overlay.querySelector('#mc-vision-model-pick');
    const dEl = overlay.querySelector('#mc-video-model-pick');
    if (vEl.dataset.model !== undefined || vEl.value === '') patch.visionModel = vEl.dataset.model || '';
    if (dEl.dataset.model !== undefined || dEl.value === '') patch.videoModel = dEl.dataset.model || '';
    // Key：只在用户输入了非掩码明文时才回传（掩码/留空 = 保持）
    const raw = (overlay.querySelector('#mc-apikey').value || '').trim();
    if (raw && raw !== '******') patch.apiKey = raw;
    // 网络代理（2026-10-19）：与 baseUrl 同级回传，空串 = 清除代理恢复直连
    patch.proxy = (overlay.querySelector('#mc-proxy')?.value || '').trim();
    try {
      await api('/api/config', { method: 'POST', body: JSON.stringify({ api: patch }) });
      closeModelModal(overlay);
      loadSettings();
    } catch (e) {
      qaAlert(`保存失败：${e.message}`);
    }
  });
}

/** 选择模型：左提供商 / 右模型，点击模型后保存到当前 api 配置并关闭。 */
/**
 * 主动刷新 state.providers。
 *
 * ⚠️ 2026-10-18 修「添加完提供商但模型管理左栏还是空的」：
 *    loadSettings() 的 providers 更新在内部的 Promise.all().then 里（慢路径，
 *    没有 await）—— `await loadSettings()` 返回时 state.providers 仍是旧值。
 *    于是紧随其后的 onDone()（renderLeft/renderRight）读到空数组，界面显示
 *    "还没有提供商"；自动选主模型也因目录为空而跳过。
 *    添加/拉取模型之后必须显式拉一次，不能赌 loadSettings 的时序。
 */
async function refreshProvidersState() {
  try {
    const d = await api('/api/providers');
    state.providers = d.providers || [];
  } catch { /* 拉不到就沿用旧值，不阻塞主流程 */ }
}

/**
 * 还没有主模型、但提供商目录里已经有模型时，把"选模型"这一步收掉。
 *
 * 背景（2026-10-18 用户反馈）：在「模型管理」里配置完提供商后，还要自己去
 * 「模型配置」点「模型目录（点击选择）」选一次模型才算能用 —— 萌新根本不知道
 * 还有这一步，配置永远停在半路（OOBE 引导也因此一直不变绿）。
 *
 * 规则：
 *   · 已有主模型 → 不动（加备用提供商不打扰）；
 *   · 目录里只有 1 个模型 → **直接选它**（零操作，这是新手最常见的路径）；
 *   · 多个模型 → 弹「选择模型」让用户自己挑（必须让人知道选了哪个）。
 *
 * @returns {Promise<boolean>} true = 已自动选定 / 已弹出选择器
 */
async function autoPickMainModelIfNeeded() {
  const cfg = state.config || {};
  if (String(cfg.api?.model || '').trim()) return false;
  // 兜底：state.providers 可能因 loadSettings 的慢路径尚未刷新（见 refreshProvidersState 注释）
  if (!(state.providers || []).length) await refreshProvidersState();
  const providers = state.providers || [];
  const all = [];
  for (const p of providers) {
    for (const m of (p.models || [])) all.push({ provider: p.id, model: m, baseUrl: p.baseURL || '' });
  }
  if (!all.length) return false;
  if (all.length === 1) {
    const pick = all[0];
    try {
      await api('/api/config', {
        method: 'POST',
        body: JSON.stringify({ api: { provider: pick.provider, model: pick.model, baseUrl: pick.baseUrl } })
      });
      await loadSettings();
      // 提示一句"已自动选定"，否则用户不知道模型被谁选的
      const hint = $('#provider-hint');
      if (hint) hint.textContent = `已自动选用模型：${pick.model}（随时可在「模型配置」里更换）`;
    } catch { /* 自动选失败就退回让用户手动选 */ }
    return true;
  }
  openModelPicker();
  return true;
}

function openModelPicker() {
  const providers = state.providers || [];
  if (!providers.length) {
    $('#provider-hint').textContent = '模型目录为空：请先在下方的“手动添加提供商”里添加。';
    return;
  }
  const overlay = modelModalShell({
    head: '选择模型',
    body: `
      <div class="model-modal-left" id="mm-left"></div>
      <div class="model-modal-right" id="mm-right"></div>`,
    foot: `<button class="btn" id="mm-cancel">取消</button>`
  });
  const left = overlay.querySelector('#mm-left');
  const right = overlay.querySelector('#mm-right');
  const current = state.config?.api?.provider;
  let activePid = current || providers[0].id;
  function renderLeft() {
    left.innerHTML = providers.map((p) =>
      `<div class="mm-prov ${p.id === activePid ? 'active' : ''}" data-pid="${esc(p.id)}">${esc(p.displayName || p.id)}</div>`).join('');
    left.querySelectorAll('.mm-prov').forEach((el) => {
      el.addEventListener('click', () => { activePid = el.dataset.pid; renderLeft(); renderRight(); });
    });
  }
  function renderRight() {
    const p = providers.find((x) => x.id === activePid);
    if (!p) { right.innerHTML = ''; return; }
    const names = p.modelNames || {};
    right.innerHTML = p.models.map((m) => `
      <div class="mm-model" data-pid="${esc(p.id)}" data-model="${esc(m)}">
        <span class="mm-check">${m === state.config?.api?.model && p.id === current ? '✓' : ''}</span>
        <span>${esc(names[m] || m)}</span>
        ${(names[m] || m) !== m ? `<span class="muted" style="font-size:11px">${esc(m)}</span>` : ''}
      </div>`).join('') || '<div class="muted" style="padding:10px">该提供商下没有模型</div>';
    right.querySelectorAll('.mm-model').forEach((el) => {
      el.addEventListener('click', async () => {
        const pid = el.dataset.pid;
        const model = el.dataset.model;
        // 同步规则：图片/视频专用模型如果指向**其它提供商**的旧模型，
        // 主模型一换就再也对不上（识别请求会发到已弃用的端点）。
        // 这里随主模型一起切换：专用模型属于同一提供商 → 跟随主模型 id；
        // 属于别的提供商（用户特意挑的跨渠道视觉模型）→ 清空回退主模型。
        // 用户在设置里明确填写的专用模型仍然优先，只有"跟随主模型"的
        // 旧值才被替换 —— 判定依据：旧专用模型属于当前主提供商（跟随态）。
        const cfg = state.config || {};
        const oldProvider = cfg.api?.provider;
        const oldVision = String(cfg.api?.visionModel || '').trim();
        const oldVideo = String(cfg.api?.videoModel || '').trim();
        const followsMain = (spec, oldPid) => spec === oldPid;
        const visionModel = oldVision && followsMain(oldVision, oldProvider)
          ? (pid === oldProvider ? model : '')
          : oldVision;
        const videoModel = oldVideo && followsMain(oldVideo, oldProvider)
          ? (pid === oldProvider ? model : '')
          : oldVideo;
        try {
          // 只更新 provider/model/baseUrl；apiKey 保持当前已保存值，不把密钥回写到接口请求里
          await api('/api/config', {
            method: 'POST',
            body: JSON.stringify({ api: { provider: pid, model, baseUrl: p.baseURL, ...(visionModel !== oldVision ? { visionModel } : {}), ...(videoModel !== oldVideo ? { videoModel } : {}) } })
          });
          closeModelModal(overlay);
          try { await loadSettings(); } catch { /* 刷新失败不遮断焦点归还，也别误报"选择失败"（POST 已成功） */ }
          // loadSettings 重渲染整个表单，焦点会掉回 body（之后 Ctrl+V 全废）——
          // 显式还给主模型选择框之后第一个可编辑控件（2026-10-18）。
          focusFirstEditableAfter($('#cfg-model-pick'));
        } catch (e) {
          $('#provider-hint').textContent = `选择失败：${e.message}`;
          closeModelModal(overlay);
        }
      });
    });
  }
  renderLeft();
  renderRight();
  overlay.querySelector('#mm-cancel').addEventListener('click', () => closeModelModal(overlay));
}

/**
 * 添加自定义搜索服务：与「模型配置」同款的"入口按钮 → 专门弹窗"形态
 * （2026-09-21 用户要求：原来的 <details> 折叠条看着不像能点）。
 * 字段 id 沿用页面时代的 new-sp-* / add-search-provider-btn / add-search-provider-hint
 * —— 07-settings-events.js 里的旧页面绑定已随表单一并搬走（弹窗内容是点击后才
 * 创建的，页面绑定根本抓不到，必须在这里自带）。字段语义与校验一字未改。
 */
function openAddSearchProviderModal() {
  const overlay = modelModalShell({
    head: '添加自定义搜索服务',
    closeOnBackdrop: false,   // 编辑型：点外部不关闭，防误触丢内容
    body: `
      <div class="field-row">
        <div class="field"><label>名称（自己辨认用）</label>
          <input type="text" id="new-sp-name" placeholder="例如：自建 SearXNG" /></div>
        <div class="field"><label>类型</label>
          <select id="new-sp-type">
            <option value="openai">JSON 搜索接口（POST）</option>
            <option value="bing">网页解析（Bing 结果格式）</option>
          </select></div>
      </div>
      <div class="field"><label>接口地址 / 搜索页地址</label>
        <input type="text" id="new-sp-baseurl" placeholder="JSON 类型：https://your-search.example.com/search；网页类型：https://your-searx.example.com/search" style="width:100%" /></div>
      <div class="field-row">
        <div class="field"><label>API Key（可选）</label>
          <input type="password" id="new-sp-apikey" placeholder="多数自建服务留空即可" autocomplete="new-password" style="width:100%" /></div>
        <div class="field"><label>模型名（可选）</label>
          <input type="text" id="new-sp-model" placeholder="Responses API 风格才需要" /></div>
      </div>`,
    foot: `
      <span id="add-search-provider-hint" class="muted" style="font-size:12px"></span>
      <button class="btn" id="add-search-provider-btn">＋ 添加并选中</button>`
  });
  overlay.querySelector('#add-search-provider-btn').addEventListener('click', async () => {
    const hint = overlay.querySelector('#add-search-provider-hint');
    const baseUrl = (overlay.querySelector('#new-sp-baseurl')?.value || '').trim();
    if (!baseUrl) { if (hint) hint.textContent = '请先填接口地址'; return; }
    if (hint) hint.textContent = '添加中…';
    try {
      const r = await api('/api/search-providers', {
        method: 'POST',
        body: JSON.stringify({
          name: (overlay.querySelector('#new-sp-name')?.value || '').trim(),
          type: overlay.querySelector('#new-sp-type')?.value || 'openai',
          baseUrl,
          apiKey: (overlay.querySelector('#new-sp-apikey')?.value || '').trim(),
          model: (overlay.querySelector('#new-sp-model')?.value || '').trim()
        })
      });
      // 添加后直接选中它（省一次手动切换）
      await api('/api/config', {
        method: 'POST',
        body: JSON.stringify({ webSearch: { provider: `custom:${r.provider.id}` } })
      });
      if (hint) hint.textContent = '已添加并选中 ✓';
      // 重渲染设置页：下拉框里立刻出现新服务且处于选中态
      await loadSettings();
      // 让用户看到 ✓ 再关（model-modal 退场动画 400ms，这里停 600ms）
      setTimeout(() => closeModelModal(overlay), 600);
    } catch (e) {
      if (hint) hint.textContent = `添加失败：${e.message}`;
    }
  });
}

/** 选择记忆整理专用模型：复用模型目录选择器，保存到 config.memory.provider/model。 */
function openMemoryModelPicker() {
  const providers = state.providers || [];
  if (!providers.length) {
    $('#mem-model-hint').textContent = '模型目录为空：请先到「模型 API」页签添加提供商。';
    return;
  }
  const overlay = modelModalShell({
    head: '选择记忆整理模型',
    body: `
      <div class="model-modal-left" id="mm-left"></div>
      <div class="model-modal-right" id="mm-right"></div>`,
    foot: `<button class="btn" id="mm-cancel">取消</button>`
  });
  const left = overlay.querySelector('#mm-left');
  const right = overlay.querySelector('#mm-right');
  // 从 DOM 的隐藏字段读当前值（而非 state.config）：
  // 用户可能刚选过但还没保存，或 state 还没刷新，DOM 才是最新真相。
  const currentProvider = $('#cfg-mem-provider')?.value || state.config?.memory?.provider || '';
  const currentModel = $('#cfg-mem-model')?.value || state.config?.memory?.model || '';
  let activePid = currentProvider || providers[0].id;
  function renderLeft() {
    left.innerHTML = providers.map((p) =>
      `<div class="mm-prov ${p.id === activePid ? 'active' : ''}" data-pid="${esc(p.id)}">${esc(p.displayName || p.id)}</div>`).join('');
    left.querySelectorAll('.mm-prov').forEach((el) => {
      el.addEventListener('click', () => { activePid = el.dataset.pid; renderLeft(); renderRight(); });
    });
  }
  function renderRight() {
    const p = providers.find((x) => x.id === activePid);
    if (!p) { right.innerHTML = ''; return; }
    const names = p.modelNames || {};
    right.innerHTML = p.models.map((m) => `
      <div class="mm-model" data-pid="${esc(p.id)}" data-model="${esc(m)}">
        <span class="mm-check">${m === currentModel && p.id === currentProvider ? '✓' : ''}</span>
        <span>${esc(names[m] || m)}</span>
        ${(names[m] || m) !== m ? `<span class="muted" style="font-size:11px">${esc(m)}</span>` : ''}
      </div>`).join('') || '<div class="muted" style="padding:10px">该提供商下没有模型</div>';
    right.querySelectorAll('.mm-model').forEach((el) => {
      el.addEventListener('click', async () => {
        const pid = el.dataset.pid;
        const model = el.dataset.model;
        try {
          // 必须把"是否跟随聊天模型"的当前勾选状态一并提交。
          // 否则：用户取消勾选（→ 只改了 DOM，state.config 仍是 true）后直接点模型，
          // 这次提交不带 useChatModel，随后 loadSettings() 又按 state.config(true)
          // 重新渲染 —— 复选框被打回"已勾选"，迫使必须先保存一次才能选模型。
          const useChatBox = $('#cfg-mem-usechat');
          const useChatModel = useChatBox ? !!useChatBox.checked
            : (state.config?.memory?.useChatModel !== false);
          await api('/api/config', {
            method: 'POST',
            body: JSON.stringify({ memory: { provider: pid, model, useChatModel } })
          });
          closeModelModal(overlay);
          try { await loadSettings(); } catch { /* 同上：刷新失败不误报 */ }
          // 同 openModelPicker：重渲染后焦点显式归还（2026-10-18）。
          focusFirstEditableAfter($('#cfg-mem-model-pick'));
        } catch (e) {
          $('#mem-model-hint').textContent = `选择失败：${e.message}`;
          closeModelModal(overlay);
        }
      });
    });
  }
  renderLeft();
  renderRight();
  overlay.querySelector('#mm-cancel').addEventListener('click', () => closeModelModal(overlay));
}

/**
 * 选择图片/视频专用模型：复用模型目录选择器。
 * 与主模型不同点：
 *   · 不换 provider —— 专用模型只记模型 id（llm.js 检测到对应模态时替换主模型 id，
 *     端点仍用主模型的）；跨提供商挑模型也允许（很多网关同一 baseUrl 下全量模型）。
 *   · 选中后直接写 DOM 隐藏字段（cfg-vision-model / cfg-video-model），
 *     随后的自动保存（saveConfig 'api' 分支读这些字段）把它带走 —— 与主模型
 *     选择器"立即 POST"不同，这里走统一表单流，避免两条保存路径打架。
 *   · 顶部多一个「跟随主模型（清空）」选项，对应"留空用主模型"的旧语义。
 */
function openSpecialModelPicker(which) {
  const isVision = which === 'vision';
  const fieldId = isVision ? 'cfg-vision-model' : 'cfg-video-model';
  const pickId = isVision ? 'cfg-vision-model-pick' : 'cfg-video-model-pick';
  const providers = state.providers || [];
  if (!providers.length) { qaAlert('模型目录为空：请先在「模型 API」页添加提供商。'); return; }
  const currentModel = ($('#' + fieldId)?.value || '').trim();
  const overlay = modelModalShell({
    head: isVision ? '选择图片输入模型' : '选择视频输入模型',
    body: `
      <div class="model-modal-left" id="mm-left"></div>
      <div class="model-modal-right" id="mm-right"></div>`,
    foot: `<button class="btn" id="mm-cancel">取消</button>`
  });
  const left = overlay.querySelector('#mm-left');
  const right = overlay.querySelector('#mm-right');
  let activePid = providers[0].id;
  function renderLeft() {
    left.innerHTML = providers.map((p) =>
      `<div class="mm-prov ${p.id === activePid ? 'active' : ''}" data-pid="${esc(p.id)}">${esc(p.displayName || p.id)}</div>`).join('');
    left.querySelectorAll('.mm-prov').forEach((el) => {
      el.addEventListener('click', () => { activePid = el.dataset.pid; renderLeft(); renderRight(); });
    });
  }
  function apply(model) {
    const input = $('#' + fieldId);
    const pick = $('#' + pickId);
    if (input) input.value = model;
    if (pick) {
      // 显示名与 renderApiSection 的 displayOf 同口径
      let label = model;
      for (const p of (state.providers || [])) {
        if ((p.modelNames || {})[model]) { label = p.modelNames[model]; break; }
      }
      pick.value = model ? label : '';
    }
    // 触发表单监听：自动保存按 'api' 分支读取隐藏字段
    input?.dispatchEvent(new Event('input', { bubbles: true }));
    closeModelModal(overlay);
  }
  function renderRight() {
    const p = providers.find((x) => x.id === activePid);
    if (!p) { right.innerHTML = ''; return; }
    const names = p.modelNames || {};
    right.innerHTML = `
      <div class="mm-model" data-model="">
        <span class="mm-check">${currentModel ? '' : '✓'}</span>
        <span>（跟随主模型）</span>
        <span class="muted" style="font-size:11px">留空 = 图片/视频也用主模型</span>
      </div>
      ${p.models.map((m) => `
      <div class="mm-model" data-model="${esc(m)}">
        <span class="mm-check">${m === currentModel ? '✓' : ''}</span>
        <span>${esc(names[m] || m)}</span>
        ${(names[m] || m) !== m ? `<span class="muted" style="font-size:11px">${esc(m)}</span>` : ''}
      </div>`).join('')}`;
    right.querySelectorAll('.mm-model').forEach((el) => {
      el.addEventListener('click', () => apply(el.dataset.model || ''));
    });
  }
  renderLeft();
  renderRight();
  overlay.querySelector('#mm-cancel').addEventListener('click', () => closeModelModal(overlay));
}

/**
 * “获取列表”后的勾选添加弹窗。
 *
 * 两个针对中转站的优化：
 *   1. 搜索框：中转站常返回几百上千个模型，没有搜索就没法用
 *   2. 双列模式：若模型 id 普遍带 "/"（OpenRouter 风格的 vendor/model），
 *      拆成左厂商 / 右模型两列，比一长条列表好找得多；否则保持单列 + 搜索
 */
function openModelAddModal(baseUrl, apiKey, remoteModels, knownProviderId) {
  const providers = state.providers || [];
  // 已知提供商 id 优先（模型管理里"拉取模型列表"传来的），否则按 baseUrl 匹配
  const existingProvider = providers.find((p) => p.id === knownProviderId)
    || providers.find((p) => (p.baseURL || '').replace(/\/+$/, '') === String(baseUrl || '').replace(/\/+$/, ''));
  const existingIds = new Set(existingProvider?.models || []);
  const all = (remoteModels || []).slice();

  // 有多少比例的 id 是 vendor/model 形式？超过一半就启用双列
  const slashed = all.filter((m) => String(m).includes('/'));
  const dual = all.length > 0 && slashed.length / all.length >= 0.5;

  // 预先按厂商分组（仅双列模式用）
  const groups = new Map();
  for (const m of all) {
    const s = String(m);
    const vendor = dual ? (s.includes('/') ? s.slice(0, s.indexOf('/')) : '(其他)') : '';
    if (!groups.has(vendor)) groups.set(vendor, []);
    groups.get(vendor).push(s);
  }
  const vendorList = [...groups.keys()].sort((a, b) => {
    if (a === '(其他)') return 1;
    if (b === '(其他)') return -1;
    return groups.get(b).length - groups.get(a).length;
  });

  const countText = `共 ${all.length} 个模型${dual ? ` · ${vendorList.length} 个厂商` : ''}`;

  const overlay = modelModalShell({
    head: '勾选模型加入列表',
    body: `
      <div class="ma-toolbar">
        <input type="text" id="ma-search" placeholder="搜索模型或厂商…" autocomplete="off" />
        <span class="muted" id="ma-count" style="font-size:12px;white-space:nowrap">${esc(countText)}</span>
      </div>
      <div class="ma-body ${dual ? 'dual' : 'single'}">
        ${dual ? '<div class="model-modal-left" id="ma-left"></div>' : ''}
        <div class="model-modal-right" id="ma-right"></div>
      </div>`,
    foot: `<button class="btn" id="ma-cancel">取消</button>
           <button class="btn btn-primary" id="ma-apply">加入列表</button>`
  });

  const searchEl = overlay.querySelector('#ma-search');
  const countEl = overlay.querySelector('#ma-count');
  const right = overlay.querySelector('#ma-right');
  const left = dual ? overlay.querySelector('#ma-left') : null;

  let activeVendor = dual ? vendorList[0] : '';
  let keyword = '';

  // 渲染成 checkbox 行
  const rowHtml = (m) => {
    const added = existingIds.has(m);
    const modelPart = dual && String(m).includes('/') ? String(m).slice(String(m).indexOf('/') + 1) : String(m);
    return `
      <label class="mm-model">
        <input type="checkbox" class="ma-check" value="${esc(m)}" ${added ? 'checked disabled' : ''} />
        <span class="mm-model-text">${esc(modelPart)}</span>
        ${added ? '<span class="muted" style="font-size:11px">已添加</span>' : ''}
      </label>`;
  };

  function matches(m) {
    if (!keyword) return true;
    return String(m).toLowerCase().includes(keyword);
  }

  function renderRight() {
    const pool = dual ? (groups.get(activeVendor) || []) : all;
    const list = pool.filter(matches);
    right.innerHTML = list.length
      ? list.map(rowHtml).join('')
      : '<div class="muted" style="padding:10px">没有匹配的模型</div>';
    // 更新计数：显示当前筛选出来的数量
    countEl.textContent = keyword
      ? `${list.length} / ${dual ? pool.length : all.length}`
      : countText;
  }

  function renderLeft() {
    if (!left) return;
    const vendors = vendorList.filter((v) => (groups.get(v) || []).some(matches));
    left.innerHTML = vendors.length
      ? vendors.map((v) => `
          <div class="mm-prov ${v === activeVendor ? 'active' : ''}" data-vendor="${esc(v)}">
            ${esc(v)} <span class="muted" style="font-size:11px">${(groups.get(v) || []).filter(matches).length}</span>
          </div>`).join('')
      : '<div class="muted" style="padding:10px">没有匹配的厂商</div>';
    left.querySelectorAll('.mm-prov').forEach((el) => {
      el.addEventListener('click', () => {
        activeVendor = el.dataset.vendor;
        renderLeft();
        renderRight();
      });
    });
    // 当前厂商被搜索过滤掉了 → 自动切到第一个可见的
    if (vendors.length && !vendors.includes(activeVendor)) {
      activeVendor = vendors[0];
      renderLeft();
      renderRight();
    }
  }

  // 搜索：输入时同时刷两列（双列模式下左列的计数也要跟着变）
  searchEl.addEventListener('input', () => {
    keyword = String(searchEl.value || '').trim().toLowerCase();
    renderLeft();
    renderRight();
  });

  renderLeft();
  renderRight();

  overlay.querySelector('#ma-cancel').addEventListener('click', () => closeModelModal(overlay));
  overlay.querySelector('#ma-apply').addEventListener('click', async () => {
    const picked = [...overlay.querySelectorAll('.ma-check:checked')].map((el) => el.value);
    const newModels = picked.filter((m) => !existingIds.has(m));
    if (!newModels.length) {
      closeModelModal(overlay);
      return;
    }
    try {
      const body = existingProvider
        ? { providerId: existingProvider.id, models: newModels.map((m) => ({ id: m, name: m })) }
        : { baseUrl, apiKey, models: newModels.map((m) => ({ id: m, name: m })) };
      const endpoint = existingProvider ? '/api/providers/models' : '/api/providers';
      await api(endpoint, { method: 'POST', body: JSON.stringify(body) });
      // 同 openProviderAddModal：先显式刷新 providers，再渲染/自动选模型
      await refreshProvidersState();
      closeModelModal(overlay);
      // 2026-09-19（M9 清理）：旧 #provider-action-hint 元素已随改版消失；写不存在的
      // 元素会在 catch 里二次抛错（未处理 rejection）。改写存活的 #provider-hint。
      $('#provider-hint').textContent = `已加入 ${newModels.length} 个模型。`;
      await loadSettings();
      // 2026-10-18：补拉模型之后同样把"选主模型"这步收掉（单模型自动选定 /
      // 多模型弹选择器）—— "先建提供商、后拉模型"是新手最常见的路径。
      await autoPickMainModelIfNeeded();
    } catch (e) {
      $('#provider-hint').textContent = `加入失败：${e.message}`;
      closeModelModal(overlay);
    }
  });
}

/** 删除模型：左提供商 / 右模型（带删除按钮），暗红色调。 */
/**
 * 「模型管理」模态框（2026-09-18 改版）：左右两列。
 * 左列 = 提供商列表 + 添加提供商 / 删除提供商按钮；
 * 右列 = 选中提供商的 baseURL、API Key（掩码）、模型列表（ID + 显示名）、
 *        拉取模型列表 / 删除模型按钮。
 * 替代了页面上原来的「删除模型 / 提供商」按钮和「手动添加提供商」整块表单。
 */
function openModelManageModal() {
  const overlay = modelModalShell({
    head: '模型管理',
    body: `
      <div class="model-modal-left" id="mg-left"></div>
      <div class="model-modal-right" id="mg-right"></div>`,
    foot: `<button class="btn" id="mg-close">关闭</button>`
  });
  const left = overlay.querySelector('#mg-left');
  const right = overlay.querySelector('#mg-right');
  const cfgProvider = String(state.config?.api?.provider || '');
  let activePid = cfgProvider || (state.providers || [])[0]?.id || '';

  function renderLeft() {
    const providers = state.providers || [];
    // 选中项兜底：openModelManageModal 只在**打开那一刻**算过一次 activePid，
    // 之后添加/删除提供商都不会重算。于是"空目录打开 → 添加提供商"这条路
    // 走到这里 activePid 仍是 ''，renderRight 拿不到 provider →
    // 右列只显示"左侧选中一个提供商后…"，连「拉取模型列表」按钮都不出现。
    // 这里每次渲染都重新对齐：activePid 失效（被删/为空）就回退到第一个。
    if (!providers.some((p) => p.id === activePid)) {
      activePid = (cfgProvider && providers.some((p) => p.id === cfgProvider))
        ? cfgProvider
        : (providers[0]?.id || '');
    }
    left.innerHTML = `
      <div style="padding:6px 0 8px;display:flex;gap:6px;flex-wrap:wrap">
        <button class="btn btn-small" id="mg-add-prov">＋ 添加提供商</button>
        <button class="btn btn-small btn-danger" id="mg-del-prov">删除提供商</button>
      </div>
      ${providers.map((p) => `
        <div class="mm-prov ${p.id === activePid ? 'active' : ''}" data-pid="${esc(p.id)}">
          ${esc(p.displayName || p.id)}${p.id === cfgProvider ? ' <span class="muted" style="font-size:11px">（当前）</span>' : ''}
        </div>`).join('') || '<div class="muted" style="padding:10px;font-size:12px">还没有提供商。<br />点上方「＋ 添加提供商」，只填 Base URL + API Key 也行 —— 添加后就能「拉取模型列表」。</div>'}`;
    left.querySelectorAll('.mm-prov').forEach((el) => {
      el.addEventListener('click', () => { activePid = el.dataset.pid; renderLeft(); renderRight(); });
    });
    // 添加提供商：弹子模态框（Base URL + Key → 拉取/勾选模型 → POST /api/providers）
    left.querySelector('#mg-add-prov').addEventListener('click', () => {
      openProviderAddModal(() => { renderLeft(); renderRight(); });
    });
    // 删除提供商：删当前选中的那个（confirm 在右列的删除按钮上做过了，这里再拦一道）
    left.querySelector('#mg-del-prov').addEventListener('click', async () => {
      const p = (state.providers || []).find((x) => x.id === activePid);
      if (!p) { qaAlert('请先在列表里选中一个提供商。'); return; }
      const modelCount = (p.models || []).length;
      // ⚠️（2026-10-10 r86 修 P2）破坏性 → danger:true
      if (!await qaConfirm({
        danger: true,
        confirmText: '删除提供商',
        message: `确定删除整个提供商「${p.displayName || p.id}」？\n\n将一并删除它的 API Key 与 ${modelCount} 个模型。此操作不可撤销。`
      })) return;
      try {
        await api('/api/providers', { method: 'DELETE', body: JSON.stringify({ providerId: p.id }) });
        // 删的是当前主提供商 → 后端会清空选中模型，刷新设置页提示重新选
        activePid = cfgProvider === p.id ? '' : activePid;
        // ⚠️ 同上：必须先拉 providers，否则左列还列着刚删掉的那一项。
        await refreshProvidersState();
        await loadSettings();
        renderLeft();
        renderRight();
      } catch (err) {
        qaAlert(`删除提供商失败：${err.message}`);
      }
    });
  }

  function renderRight() {
    const p = (state.providers || []).find((x) => x.id === activePid);
    if (!p) { right.innerHTML = '<div class="muted" style="padding:12px;font-size:12px">左侧选中一个提供商后，这里显示它的端点、密钥与模型。</div>'; return; }
    const names = p.modelNames || {};
    right.innerHTML = `
      <div class="field"><label>Base URL</label>
        <input type="text" id="mg-baseurl" value="${esc(p.baseURL || '')}" readonly style="width:100%" /></div>
      <div class="field"><label>API 协议</label>
        <div style="display:flex;gap:8px">
          <select id="mg-protocol" style="flex:1">${qaProtocolSelectHtml(p.apiProtocol || 'openai')}</select>
          <button class="btn btn-small" id="mg-protocol-save" type="button" title="保存协议修改（改完立即对下一次对话生效）">保存</button>
          <span id="mg-protocol-state" style="font-size:11px;align-self:center;white-space:nowrap"></span>
        </div>
        <div class="hint" style="margin-top:4px">默认 OpenAI (Chat Completions)。多数中转站无需改动；直连 Claude / Gemini 官方端点才需要换。拉取模型与连通性测试都会按此协议走。</div></div>
      <div class="field"><label>API Key</label>
        <div style="display:flex;gap:8px">
          <input type="password" id="mg-apikey" value="${esc(p.hasKey ? '******' : '')}" readonly placeholder="${p.hasKey ? '' : '（未保存）'}" style="flex:1" />
          <button class="btn btn-small" id="mg-apikey-toggle" type="button">显示</button>
          <button class="btn btn-small btn-danger" id="mg-apikey-clear" type="button" title="清除已保存的 API Key">清除密钥</button>
        </div></div>
      <div class="field"><label>模型（${(p.models || []).length} 个）</label>
        <div style="display:flex;gap:6px;margin-bottom:6px">
          <button class="btn btn-small" id="mg-fetch-models">拉取模型列表</button>
          <button class="btn btn-small btn-danger" id="mg-del-model">删除模型</button>
        </div>
        <div style="max-height:220px;overflow-y:auto;border:1px solid var(--border);border-radius:8px">
          ${(p.models || []).map((m) => `
            <label class="mm-model" style="cursor:pointer">
              <input type="radio" name="mg-model" value="${esc(m)}" />
              <span style="flex:1">${esc(names[m] || m)}</span>
              ${(names[m] || m) !== m ? `<span class="muted" style="font-size:11px">${esc(m)}</span>` : ''}
            </label>`).join('') || '<div class="muted" style="padding:10px">该提供商下没有模型，点「拉取模型列表」。</div>'}
        </div></div>`;

    // Key 显示/隐藏：走 /api/providers/key 取明文（与主页面同款）
    right.querySelector('#mg-apikey-toggle').addEventListener('click', async () => {
      const input = right.querySelector('#mg-apikey');
      const btn = right.querySelector('#mg-apikey-toggle');
      const show = input.type === 'password';
      try {
        const r = await api(`/api/providers/key?providerId=${encodeURIComponent(p.id)}`);
        if (show) {
          input.type = 'text';
          input.value = String(r.apiKey || '（无）');
          btn.textContent = '隐藏';
        } else {
          input.type = 'password';
          input.value = p.hasKey ? '******' : '';
          btn.textContent = '显示';
        }
      } catch (e) {
        qaAlert(`读取密钥失败：${e.message}`);
      }
    });
    // Key 清除
    right.querySelector('#mg-apikey-clear').addEventListener('click', async () => {
      if (!p.hasKey) return;
      // ⚠️（2026-10-10 r86 修 P2）清除凭据 → danger:true
      if (!await qaConfirm({
        danger: true,
        confirmText: '清除 Key',
        message: `确定清除「${p.displayName || p.id}」的 API Key？`
      })) return;
      try {
        await api('/api/providers/set-key', { method: 'POST', body: JSON.stringify({ providerId: p.id, apiKey: '' }) });
        // ⚠️ 同协议保存那个坑：loadSettings() 不等 providers，不先拉一次就会拿旧
        //    hasKey 重画右列（"清除了但还显示 ******"）。
        await refreshProvidersState();
        await loadSettings();
        renderLeft();
        renderRight();
      } catch (e) {
        qaAlert(`清除失败：${e.message}`);
      }
    });
    /* ── 保存协议修改 ────────────────────────────────────────────────
       ⚠️ 2026-10-20 修「选了协议、点了保存，又变回原来的」（多人反馈）：
          **保存一直是成功的** —— 用隔离数据目录直接把 5 种协议逐个存过一遍，
          配置里 apiProtocol 确实写进去了（verify-protocol-save.mjs 22/22）。
          问题出在旧代码保存后这一句 `await loadSettings(); renderRight();`：
          `loadSettings()` 把 providers 塞在**慢路径** Promise.all 里，压根不等
          （见 05-memory-settings.js 的函数头注释：config 单独先行，其余接口慢到无所谓），
          所以它 resolve 时 `state.providers` 还是旧的，`renderRight()` 于是把下拉框
          画回旧协议 —— 用户看到的就是"选了、保存了、又变回去了"，自然判定没保存上。
          「添加提供商」那条路 2026-10-18 已经踩过同一个坑并加了 refreshProvidersState
          （见那段注释），这里当时漏了。

          现在的做法：
            · 保存前先记下想要的值；保存后**显式**拉一次 providers（不等慢路径）；
            · 正常情况下界面本来就是用户选中的那个值，**不再重画右列**
              （重画是旧 bug 的触发点，能省则省）；
            · 只有后端回读跟我们想要的不一致（归一化回落等罕见情况）才重画，
              让界面与事实对齐；
            · 给一句「已保存 ✓」的即时反馈 —— 旧代码保存成功是**完全静默**的，
              这也是"感觉没保存"的一半原因。
          · 另外：改下拉即保存（change）+ 保留「保存」按钮（同一个提交函数，
            幂等）。用户选完直接关窗口也不会丢，不必猜"还要再点一次按钮吗"。 */
    const protocolSaveBtn = right.querySelector('#mg-protocol-save');
    const protocolSel = right.querySelector('#mg-protocol');
    let protocolBusy = false;
    const paintTip = (text, color) => {
      const tip = right.querySelector('#mg-protocol-state');
      if (!tip) return;
      tip.textContent = text;
      tip.style.color = color;
      clearTimeout(right.__protocolTipTimer);
      if (text) {
        right.__protocolTipTimer = setTimeout(() => {
          const t = right.querySelector('#mg-protocol-state');
          if (t) t.textContent = '';
        }, 2600);
      }
    };
    async function commitProtocol() {
      if (protocolBusy) return;
      const want = protocolSel.value;
      const saved = (state.providers || []).find((x) => x.id === p.id)?.apiProtocol || 'openai';
      if (want === saved) { paintTip('已是当前值', 'var(--muted)'); return; }
      protocolBusy = true;
      protocolSaveBtn.disabled = true;
      const oldText = protocolSaveBtn.textContent;
      protocolSaveBtn.textContent = '保存中…';
      let done = false;
      try {
        await api('/api/providers/protocol', {
          method: 'POST',
          body: JSON.stringify({ providerId: p.id, apiProtocol: want })
        });
        await refreshProvidersState();          // ← 关键：把真实值拉回来再判断
        const now = (state.providers || []).find((x) => x.id === p.id)?.apiProtocol || 'openai';
        if (now !== want) {
          // 后端没按我们给的值存（归一化/回落）→ 重画，让界面显示事实
          renderLeft();
          renderRight();
          paintTip(`已保存为 ${now}`, 'var(--muted)');
        } else {
          paintTip('已保存 ✓', 'var(--green)');
        }
        done = true;
        // state.config 里的 providers 也顺手对齐（后台，不挡这次交互）
        loadSettings();
      } catch (e) {
        paintTip('保存失败', 'var(--red, #e5484d)');
        qaAlert(`保存协议失败：${e.message}`);
      } finally {
        protocolBusy = false;
        // 没被 renderRight 换掉才需要复位（换掉了就是另一个新按钮，别去动旧节点）
        if (protocolSaveBtn.isConnected) {
          protocolSaveBtn.disabled = false;
          protocolSaveBtn.textContent = oldText;
        }
      }
      // 保存期间用户又改了下拉 → 再提交一次，否则界面显示的和存下来的不一致
      if (done && protocolSel.isConnected && protocolSel.value !== want) commitProtocol();
    }
    protocolSaveBtn.addEventListener('click', commitProtocol);
    protocolSel.addEventListener('change', () => { commitProtocol(); });
    // 拉取模型：从该提供商的端点拉（Key 用后端保存的）
    right.querySelector('#mg-fetch-models').addEventListener('click', async () => {
      const btn = right.querySelector('#mg-fetch-models');
      btn.disabled = true;
      btn.textContent = '拉取中…';
      try {
        const r = await api('/api/providers/fetch-models', {
          method: 'POST',
          body: JSON.stringify({ baseUrl: p.baseURL, providerId: p.id, apiProtocol: right.querySelector('#mg-protocol').value })
        });
        // 复用勾选加入弹窗（把新模型并进该提供商）
        openModelAddModal(p.baseURL, '', r.models || [], p.id);
      } catch (e) {
        qaAlert(`拉取失败：${e.message}`);
      } finally {
        btn.disabled = false;
        btn.textContent = '拉取模型列表';
      }
    });
    // 删除模型：删当前选中的单选模型
    right.querySelector('#mg-del-model').addEventListener('click', async () => {
      const picked = right.querySelector('input[name="mg-model"]:checked');
      if (!picked) { qaAlert('请先在列表里选中一个要删除的模型。'); return; }
      const model = picked.value;
      // ⚠️（2026-10-10 r86 修 P2）删除模型 → danger:true
      if (!await qaConfirm({
        danger: true,
        confirmText: '删除模型',
        message: `确定从「${p.displayName || p.id}」删除模型 ${model}？`
      })) return;
      try {
        await api('/api/providers/models', {
          method: 'DELETE',
          body: JSON.stringify({ providerId: p.id, modelId: model })
        });
        // ⚠️ 同协议保存：loadSettings() 不等 providers，不先拉一次的话右列还列着
        //    刚删掉的那个模型，用户再点一次删除反而报"模型不存在"。
        await refreshProvidersState();
        await loadSettings();
        renderLeft();
        renderRight();
      } catch (e) {
        qaAlert(`删除失败：${e.message}`);
      }
    });
  }

  renderLeft();
  renderRight();
  // 2026-10-18：静默刷新一次 providers —— 用户可能在别处刚添加过、state 还没跟上
  //（loadSettings 的慢路径不保证时序），否则会出现"明明有提供商，打开却显示还没有"。
  // 刷新到位后原地重绘；弹窗已关则跳过。
  refreshProvidersState().then(() => {
    if (!overlay.isConnected) return;
    renderLeft();
    renderRight();
  }).catch(() => { /* 内部已兜底；这里只保证链上异常不会变成 unhandledRejection */ });
  overlay.querySelector('#mg-close').addEventListener('click', () => {
    closeModelModal(overlay);
    // 关闭时兜底：目录里已有模型但还没选主模型（比如旧版本添加完没接着选）→
    // 自动选定 / 弹选择器，别让用户停在这个半成品状态（2026-10-18）。
    autoPickMainModelIfNeeded();
  });
}

/** 模型管理里的「添加提供商」子模态框：Base URL + Key → 拉取勾选模型 → 添加。 */
function openProviderAddModal(onDone) {
  const overlay = modelModalShell({
    head: '添加提供商',
    closeOnBackdrop: false,   // 编辑型：点外部不关闭，防误触丢内容
    body: `
      <div class="field"><label>API 协议</label>
        <select id="pa-protocol" style="width:100%">${qaProtocolSelectHtml('openai')}</select>
        <div class="hint" style="margin-top:4px">默认 OpenAI (Chat Completions)，多数中转站对各家模型都提供该兼容协议。此项不总与模型相关联——直连 Claude / Gemini 官方端点时才需要选对应协议，选中会自动填官方地址。Mistral 官方 API 本身就是 OpenAI 兼容格式。</div></div>
      <div class="field"><label>Base URL</label>
        <div style="display:flex;gap:8px">
          <input type="text" id="pa-baseurl" placeholder="例如 https://api.deepseek.com/v1" style="flex:1" />
          <button class="btn btn-small" id="pa-fetch" type="button" title="用本弹窗里填的 Base URL + API Key 从端点拉取可用模型列表，勾选后随「添加」一并保存（无需先建提供商）">⟳ 拉取模型</button>
        </div></div>
      <div class="field"><label>API Key</label>
        <input type="password" id="pa-apikey" placeholder="sk-..." autocomplete="new-password" style="width:100%" /></div>
      <div class="field"><label>模型 id（可先留空；填好上方两项后点「⟳ 拉取模型」自动勾选）</label>
        <div id="pa-fetched-box"></div>
        <div id="pa-model-rows"></div>
        <button class="btn btn-small" id="pa-add-row" style="margin-top:6px">＋ 添加一行</button></div>`,
    foot: `<button class="btn" id="pa-cancel">取消</button>
           <button class="btn btn-primary" id="pa-confirm">添加</button>`
  });
  let rows = [{ id: '', name: '' }];
  // R39：「拉取模型」搬进本弹窗 —— 新用户填完 Base URL + Key 就能原地拉列表勾选，
  // 不必"先建提供商 → 去模型管理 → 再拉取"绕一圈（R37 的按钮只覆盖了已存在的提供商）。
  let fetched = []; // [{ id, name, checked }]
  const fetchedBox = overlay.querySelector('#pa-fetched-box');
  function renderFetched() {
    if (!fetched.length) { fetchedBox.innerHTML = ''; return; }
    fetchedBox.innerHTML = `
      <div style="border:1px solid var(--border);border-radius:8px;padding:6px 8px;margin-bottom:8px;max-height:180px;overflow:auto">
        <div class="muted" style="font-size:12px;margin-bottom:4px">拉取到 ${fetched.length} 个模型（勾选要添加的，也可与手填行并用）：</div>
        ${fetched.map((m, i) => `
          <label style="display:flex;gap:6px;align-items:center;padding:2px 0;font-size:12px;cursor:pointer">
            <input type="checkbox" class="pa-ck" data-i="${i}" ${m.checked ? 'checked' : ''} />
            <span>${esc(m.id)}</span>${m.name && m.name !== m.id ? `<span class="muted">${esc(m.name)}</span>` : ''}
          </label>`).join('')}
        <button class="btn btn-small" id="pa-fetch-toggle" type="button" style="margin-top:4px">全选 / 全不选</button>
      </div>`;
    fetchedBox.querySelectorAll('.pa-ck').forEach((el) => el.addEventListener('change', () => { fetched[Number(el.dataset.i)].checked = el.checked; }));
    fetchedBox.querySelector('#pa-fetch-toggle').addEventListener('click', () => {
      const allOn = fetched.every((m) => m.checked);
      fetched.forEach((m) => { m.checked = !allOn; });
      renderFetched();
    });
  }
  // 选协议时 Base URL 还空着 → 自动填官方默认端点（Anthropic / Gemini 官方地址长、手写易错）
  overlay.querySelector('#pa-protocol').addEventListener('change', () => {
    const proto = overlay.querySelector('#pa-protocol').value;
    const baseInput = overlay.querySelector('#pa-baseurl');
    if (!baseInput.value.trim() && QA_PROTOCOL_DEFAULT_BASES[proto]) {
      baseInput.value = QA_PROTOCOL_DEFAULT_BASES[proto];
    }
  });
  overlay.querySelector('#pa-fetch').addEventListener('click', async () => {
    const btn = overlay.querySelector('#pa-fetch');
    const baseUrl = overlay.querySelector('#pa-baseurl').value.trim();
    const apiKey = overlay.querySelector('#pa-apikey').value.trim();
    const apiProtocol = overlay.querySelector('#pa-protocol').value;
    if (!baseUrl) { qaAlert('请先填写 Base URL，再拉取模型列表'); return; }
    if (!apiKey) { qaAlert('请先填写 API Key（拉取模型列表需要密钥鉴权）'); return; }
    btn.disabled = true;
    btn.textContent = '拉取中…';
    try {
      // Key 口径：本弹窗是"新建"场景、提供商还不存在 → 显式带明文 Key
      // （后端 fetch-models 的 Key 解析顺序就是 显式明文 > providerId 已存 > 顶层）。
      const r = await api('/api/providers/fetch-models', {
        method: 'POST',
        body: JSON.stringify({ baseUrl, apiKey, apiProtocol })
      });
      if (!(r.models || []).length) {
        qaAlert('端点没有返回任何模型。\n请检查 Base URL / API Key 是否正确。');
        return;
      }
      fetched = (r.models || []).map((m) => ({ id: String(m.id || m), name: String(m.name || m.id || m), checked: true }));
      renderFetched();
    } catch (e) {
      qaAlert(`拉取失败：${e.message}`);
    } finally {
      btn.disabled = false;
      btn.textContent = '⟳ 拉取模型';
    }
  });
  const rowsBox = overlay.querySelector('#pa-model-rows');
  function renderRows() {
    rowsBox.innerHTML = `
      <table class="model-rows-table">
        ${rows.map((row, i) => `
          <tr>
            <td><input type="text" class="pa-mr-id" data-i="${i}" placeholder="如 glm-5.3-flash" value="${esc(row.id)}" /></td>
            <td><input type="text" class="pa-mr-name" data-i="${i}" placeholder="显示名（可选）" value="${esc(row.name)}" /></td>
            <td style="width:56px;text-align:right"><button class="btn btn-small btn-danger pa-mr-del" data-i="${i}" ${rows.length <= 1 ? 'disabled' : ''}>删除</button></td>
          </tr>`).join('')}
      </table>`;
    rowsBox.querySelectorAll('.pa-mr-id').forEach((el) => el.addEventListener('input', () => { rows[Number(el.dataset.i)].id = el.value; }));
    rowsBox.querySelectorAll('.pa-mr-name').forEach((el) => el.addEventListener('input', () => { rows[Number(el.dataset.i)].name = el.value; }));
    rowsBox.querySelectorAll('.pa-mr-del').forEach((el) => el.addEventListener('click', () => {
      if (rows.length <= 1) return;
      rows.splice(Number(el.dataset.i), 1);
      renderRows();
    }));
  }
  renderRows();
  overlay.querySelector('#pa-add-row').addEventListener('click', () => { rows.push({ id: '', name: '' }); renderRows(); });
  overlay.querySelector('#pa-cancel').addEventListener('click', () => closeModelModal(overlay));
  overlay.querySelector('#pa-confirm').addEventListener('click', async () => {
    const baseUrl = overlay.querySelector('#pa-baseurl').value.trim();
    const apiKey = overlay.querySelector('#pa-apikey').value.trim();
    const apiProtocol = overlay.querySelector('#pa-protocol').value;
    // 勾选的拉取模型在前、手填行在后，按 id 去重（重复手填同一 id 不产生两份）
    const seen = new Set();
    const models = [
      ...fetched.filter((m) => m.checked).map((m) => ({ id: m.id, name: m.name || m.id })),
      ...rows.map((r) => ({ id: r.id.trim(), name: (r.name || r.id).trim() })).filter((m) => m.id)
    ].filter((m) => !seen.has(m.id) && seen.add(m.id));
    if (!baseUrl) { qaAlert('请填写 Base URL'); return; }
    if (!apiKey) { qaAlert('请填写 API Key（提供商必须带密钥才能测试连通性）'); return; }
    // ⚠️ 这里曾经强制要求至少填一个模型 id，与上面标签写的「可先留空」自相矛盾，
    //    更致命的是它构成了死循环：「拉取模型列表」按钮只在**已存在的提供商**里，
    //    于是新用户没有模型 id 就建不了提供商 → 永远点不到拉取按钮。
    //    后端 upsertProvider 的 models 默认就是 []，允许空目录没有任何问题 ——
    //    改为放行，并在添加成功后直接把用户送到「拉取模型列表」。
    try {
      await api('/api/providers', { method: 'POST', body: JSON.stringify({ baseUrl, apiKey, models, apiProtocol }) });
      // 先显式刷新 providers：loadSettings 的慢路径不保证时序，不刷新的话
      // 下面的 onDone（左栏渲染）和自动选模型都会读到旧空数组（见 refreshProvidersState）。
      await refreshProvidersState();
      closeModelModal(overlay);
      // ⚠️ 必须**先等 loadSettings 完成**再回调 onDone：onDone 是模型管理的
      //    renderLeft/renderRight，它们读的是 state.providers。旧写法把
      //    loadSettings() 放在 onDone() 之后（且都没 await），回调渲染时
      //    state.providers 还是空数组 —— 表现为"添加成功了，但左列看不到它、
      //    右列也没有「拉取模型列表」按钮"，用户以为没添加成功。
      await loadSettings();
      if (onDone) onDone();
      // 一个模型都没带（既没勾拉取的、也没手填）才送去「模型管理」补拉；
      // 现在拉取入口就在本弹窗里，多数添加会直接带着勾选的模型落地。
      if (!models.length) { scheduleOpenModelManage(); return; }
      // 2026-10-18：把"还要再选一次主模型"这一步收掉 —— 单个模型直接选定，
      // 多个模型弹选择器（见 autoPickMainModelIfNeeded 的注释）。
      await autoPickMainModelIfNeeded();
    } catch (e) {
      qaAlert(`添加失败：${e.message}`);
    }
  });
}

// ── 白名单可视化选择器 ──
async function openWhitelistPicker(kind) {
  const isGroups = kind === 'groups';
  $('#pick-result').textContent = '拉取中…';
  let list;
  try {
    const data = await api(`/api/onebot/${kind}`);
    list = isGroups ? data.groups : data.friends;
  } catch (e) {
    $('#pick-result').textContent = `拉取失败：${e.message}（OneBot 未连接？）`;
    return;
  }
  if (!list?.length) {
    $('#pick-result').textContent = isGroups ? '没拉到群列表（检查 SnowLuma）' : '没拉到好友列表';
    return;
  }
  const inputEl = $(isGroups ? '#cfg-allowgroups' : '#cfg-allowprivate');
  const selected = new Set(parseList(inputEl.value));
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `
    <div class="modal">
      <div class="modal-head">选择${isGroups ? '群' : '好友'}（已选 ${selected.size} 个）</div>
      <div class="modal-list">
        ${list.map((g) => `
          <label class="pick-item">
            <input type="checkbox" value="${esc(g.id)}" ${selected.has(g.id) ? 'checked' : ''} />
            <span>${esc(g.name)}</span>
            <span class="muted">${esc(g.id)}</span>
          </label>`).join('')}
      </div>
      <div class="modal-foot">
        <button class="btn btn-primary" id="pick-apply">确定</button>
        <button class="btn" id="pick-cancel">取消</button>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  $('#pick-cancel', overlay).addEventListener('click', () => overlay.remove());
  $('#pick-apply', overlay).addEventListener('click', () => {
    const picked = $$('input[type=checkbox]:checked', overlay).map((el) => el.value);
    inputEl.value = picked.join(',');
    // ⚠️ 2026-10-18：程序化赋值**不会**触发 input 事件 —— 表单自动保存靠
    // #settings-form 的 input 委托（07-settings-events.js:340）启动，不派发的话
    // 用户点完「确定」其实什么都没保存。旧文案还让人去找一个根本不存在的
    // "保存设置"按钮（设置页是 600ms 防抖自动保存，早就没有保存按钮了）。
    // 这里主动派发一次 + 文案改成"已自动保存"，与真实行为一致。
    inputEl.dispatchEvent(new Event('input', { bubbles: true }));
    $('#pick-result').textContent = `已选 ${picked.length} 个${isGroups ? '群' : '好友'}（已自动保存）`;
    overlay.remove();
  });
}

// 拆分逗号/空白分隔的列表，并统一剥掉 `group:` / `private:` 前缀落成**裸号**
// （与后端权威格式一致 —— src/store.js allowed() 直接 includes(String(id))）。
// 这里必须归一化：openWhitelistPicker 用 g.id（裸号）比对勾选态，而输入框里的
// 存量脏值可能是 group:xxx；不剥前缀就会「勾不上已加白名单的群，点确定把老项丢掉」。
function parseList(s) {
  return String(s || '').split(/[,，\s]+/).map((x) => x.trim()).filter(Boolean).map(bareAllowId);
}

async function saveConfig({ quiet = false } = {}) {
  const c = state.config;
  // 只在当前区块的元素存在时才读取，避免“每个区块保存时读取其他区块元素”导致的 null 报错。
  const el = (sel) => document.querySelector(sel);
  const val = (sel, fallback = '') => {
    const node = el(sel);
    return node ? node.value : fallback;
  };
  const chk = (sel, fallback = false) => {
    const node = el(sel);
    return node ? node.checked : fallback;
  };
  /**
   * 读数值输入框。
   * ⚠️（2026-10-10 r86 修）**不要**写成 `Number(val(...)) || fallback` ——
   *    `||` 会把合法的 0 当成"空值"而回落到 fallback。概率这一项 UI 上
   *    min="0"、明确允许 0（表示"从不主动发起话题"），用户填 0 却被静默
   *    存成 0.25 —— 界面显示一个值、后端存另一个值，且没有任何提示。
   *    正确做法：先判"框是否存在 + 是否可解析为有限数"，再判范围。
   * @param {string} sel 选择器
   * @param {number} fallback 框不存在或值非法时的回落值
   * @param {{min?:number,max?:number}} [range] 可选钳位范围（含端点）
   */
  const num = (sel, fallback, range) => {
    const node = el(sel);
    if (!node) return fallback;
    const raw = String(node.value ?? '').trim();
    if (raw === '') return fallback;              // 空串 = 用户没填 → 用原值
    const n = Number(raw);
    if (!Number.isFinite(n)) return fallback;     // 非数字 → 用原值
    if (range) {
      let v = n;
      if (typeof range.min === 'number') v = Math.max(range.min, v);
      if (typeof range.max === 'number') v = Math.min(range.max, v);
      return v;
    }
    return n;
  };
  const sec = state.settingsSection || 'api';

  const patch = {};

  // ── [[command-gateway:save-config]] 「指令前置」插件自动维护，不要手改这一段 ──
  // 插件自带的设置页：核心不认识它的字段，所以"把界面读成补丁"这件事交给插件模块的
  // read(ctx)，核心只负责写进它自己的命名空间（服务端还会按清单再过滤一次键）。
  if (String(sec).startsWith('plugin:')) {
    const pluginPatch = (typeof pluginSection?.module?.read === 'function')
      ? pluginSection.module.read(pluginSection.ctx)
      : null;
    if (!pluginPatch || typeof pluginPatch !== 'object') return { config: state.config };
    if (!Object.keys(pluginPatch).length) return { config: state.config };
    const r = await api(`/api/skills/${encodeURIComponent(pluginSection.pluginId)}`, {
      method: 'POST',
      body: JSON.stringify({ settings: pluginPatch })
    });
    if (r?.config) state.config = r.config;
    if (!quiet) $('#model-label').textContent = `模型：${state.config.api.model || '未设置'}`;
    return r;
  }
  // ── [[/command-gateway:save-config]] ──


  // ⚠️ 分区已合并（菜单 9 项 → 5 项）：收集条件必须同时认「宿主 id」和「被并掉的
  //    旧 id」，否则合并页里另一半表单不会被保存（静默丢配置）。
  //    val()/chk() 都是 null 安全的，多跑一个分支不会误写 —— 元素不在 DOM 就返回 fallback。
  if (sec === 'persona' || sec === 'memory') {
    patch.memory = {
      ...(c.memory || {}),
      consolidateEnabled: chk('#cfg-mem-consolidate', c.memory?.consolidateEnabled !== false),
      useChatModel: chk('#cfg-mem-usechat', c.memory?.useChatModel !== false),
      provider: val('#cfg-mem-provider', c.memory?.provider || '').trim(),
      model: val('#cfg-mem-model', c.memory?.model || '').trim(),
      consolidateMinIntervalMs: Number(val('#cfg-mem-interval', c.memory?.consolidateMinIntervalMs ?? 21600000)) || 21600000
    };
  }

  if (sec === 'api' || sec === 'search') {
    patch.api = {
      ...(c.api || {}),
      // 思考强度/温度/最大工具轮数已移入「信息发送配置」模态框（openSendConfigModal，
      // 保存时直接 POST api patch）。此处不再收集这三个字段 —— deepMerge 不写
      // 就保留服务端旧值，模态框保存过的值不会被这里覆盖。
      visionModel: val('#cfg-vision-model', c.api.visionModel || '').trim(),
      videoModel: val('#cfg-video-model', c.api.videoModel || '').trim(),
      videoMode: (() => {
        const v = val('#cfg-video-mode', c.api.videoMode || 'auto');
        return ['auto', 'native', 'frames', 'off'].includes(v) ? v : 'auto';
      })(),
      // 成本核算：官方价开关（走中转站时通常要关掉开关自己填）
      useOfficialPrice: chk('#cfg-useofficialprice', c.api.useOfficialPrice !== false),
      // 远程价格表 URL：留空 = 只用内置表
      // 全局兜底单价：仅当没有模型级价格时生效
      priceInputPerM: Number(val('#cfg-price-in', c.api.priceInputPerM ?? 0)) || 0,
      priceOutputPerM: Number(val('#cfg-price-out', c.api.priceOutputPerM ?? 0)) || 0,
      priceCachedPerM: Number(val('#cfg-price-cached', c.api.priceCachedPerM ?? 0)) || 0,
      // 模型身份三件套：正常路径由模型目录选择器直接 POST（openModelPicker），
      // 这里把隐藏字段 / 只读框的当前值一并带上 —— 保证"选完模型又在
      // 本区块改了单价"的合并保存不会把 model/provider/baseUrl 丢掉。
      // （deepMerge 下不写就保留服务端旧值，写了就与隐藏字段一致，两个方向都安全。）
      model: val('#cfg-model', c.api.model || '').trim(),
      provider: val('#cfg-provider', c.api.provider || '').trim(),
      baseUrl: val('#cfg-baseurl-value', c.api.baseUrl || '').trim(),
      // 备选模型列表：从 DOM 实时读取（fallbackRows 是 bindSettingsEvents 的局部变量，
      // 顶层 saveConfig 访问不到，所以这里直接查 DOM），过滤掉空行。
      // 提供商列已删：model 输入框显示"提供商名 · 模型id"，但存的是纯 id +
      // 提供商由 fallbackRows 内部维护 —— 显示格式不能进配置。
      // 改为从显示值反解太脆（模型 id 本身可含 ·），所以这里读 data-* 属性
      // （renderFallbackRows 渲染时把真值放在 data-model / data-provider 上）。
      fallbackModels: $$('#fallback-model-rows .fb-model-pick').map((el) => ({
        model: String(el.dataset.model || '').trim(),
        provider: String(el.dataset.provider || '').trim()
      })).filter((r) => r.model)
    };
    // 把当前模型的单价存进 modelPrices[模型]（只影响这一个模型，不动内置官方表）。
    // 若开关是打开的，则不应写入 —— 那时输入框是禁用的，读到的值就是官方价，
    // 写进去会凭空产生一条自定义价。
    //
    // ⚠️ 模型名与开关状态都必须读**界面实时值**（c.api 是上次保存的旧值）：
    // 用户可能改了模型/开关但还没保存过，用旧值会把价格存到错误的模型名下。
    const curModel = String(($('#cfg-model')?.value ?? c.api?.model) || '').trim();
    const officialOn = ($('#cfg-useofficialprice')?.checked) ?? (c.api?.useOfficialPrice !== false);
    if (curModel) {
      const isLocked = officialOn;   // 锁定只跟开关绑定
      if (!isLocked) {
        const nextMap = { ...(c.api?.modelPrices || {}) };
        const i = Number(val('#cfg-price-in', 0)) || 0;
        const o = Number(val('#cfg-price-out', 0)) || 0;
        const ca = Number(val('#cfg-price-cached', 0)) || 0;
        if (i || o || ca) {
          nextMap[curModel] = { in: i, out: o, cached: ca || i };
        } else {
          delete nextMap[curModel];   // 全 0 = 清除自定义，回落到官方表
        }
        // 同样需要整体替换，否则 delete 掉的那一项会在合并时复活
        patch.api.modelPrices = { __replace__: nextMap };
      }
    }
    // 当前 API Key：2026-09-18 改版后 Key 输入框在「模型配置」弹窗里自带保存逻辑
    // （mc-apikey → providers/set-key），表单里旧 #cfg-apikey 已不存在 —— 这段
    // 兜底读取随之删除；顶层的 patch.api.apiKey 分支只服务于"非目录提供商"的
    // 旧配置，那种情况现在也走弹窗。
  }

  if (sec === 'api' || sec === 'search') {
    // 搜索 API Key：****** = 保持原 Key 不变；明文或新输入才更新
    const enteredDsKey = val('#cfg-ds-searchkey', '').trim();
    const enteredZhipuKey = val('#cfg-zhipu-key', '').trim();
    const enteredBochaKey = val('#cfg-bocha-key', '').trim();
    const enteredBaiduKey = val('#cfg-baidu-key', '').trim();
    const enteredMetasoKey = val('#cfg-metaso-key', '').trim();
    patch.webSearch = {
      ...(c.webSearch || {}),
      enabled: chk('#cfg-websearch', c.webSearch?.enabled !== false),
      provider: val('#cfg-searchprovider', c.webSearch?.provider || 'bing'),
      searchUrl: val('#cfg-searchurl', c.webSearch?.searchUrl || 'https://cn.bing.com/search').trim() || 'https://cn.bing.com/search',
      deepseek: {
        ...(c.webSearch?.deepseek || {}),
        ...(enteredDsKey && enteredDsKey !== '******' ? { apiKey: enteredDsKey } : {}),
        model: val('#cfg-ds-searchmodel', c.webSearch?.deepseek?.model || 'deepseek-v4-flash').trim() || 'deepseek-v4-flash'
      },
      zhipu: {
        ...(c.webSearch?.zhipu || {}),
        ...(enteredZhipuKey && enteredZhipuKey !== '******' ? { apiKey: enteredZhipuKey } : {}),
        engine: val('#cfg-zhipu-engine', c.webSearch?.zhipu?.engine || 'search_std')
      },
      bocha: {
        ...(c.webSearch?.bocha || {}),
        ...(enteredBochaKey && enteredBochaKey !== '******' ? { apiKey: enteredBochaKey } : {})
      },
      baidu: {
        ...(c.webSearch?.baidu || {}),
        ...(enteredBaiduKey && enteredBaiduKey !== '******' ? { apiKey: enteredBaiduKey } : {})
      },
      metaso: {
        ...(c.webSearch?.metaso || {}),
        ...(enteredMetasoKey && enteredMetasoKey !== '******' ? { apiKey: enteredMetasoKey } : {})
      },
      // 自定义搜索服务：列表由「添加/删除」按钮维护（POST /api/search-providers），
      // 但**当前选中那家的 Key 编辑框**在这里随表单提交 —— 用户改 Key 的主路径
      // 就是这个框。按 id 定位条目原地更新；掩码/留空 = 不动，明文 = 覆盖。
      providers: (c.webSearch?.providers || []).map((p) => {
        const sel = val('#cfg-searchprovider', '');
        if (sel !== `custom:${p.id}`) return p;
        const entered = val('#cfg-custom-sp-key', '').trim();
        if (entered && entered !== '******') return { ...p, apiKey: entered };
        return p;
      }),
      // 自定义服务 Key 的「清除」不走表单（专用按钮直接 POST），这里不处理空串。
    };
  }

  if (sec === 'persona' || sec === 'memory') {
    // ⚠️ 2026-10-16 修「切换人设不成功」（用户大量反馈的根因）：
    // 人设编辑器已收进弹窗（#gp-* / #pcp-*），页面上 #cfg-botname /
    // #cfg-roletext 等输入框**已全部移除**（06-settings-render.js 摘要卡改版）。
    // 旧写法 `val('#cfg-roletext', c.persona.roleText)` 在元素不在场时回落到
    // state.config 的**旧值**整段回传 —— 而 state.config 在弹窗/市场保存后的
    // 一段时间内是陈旧的（见 loadSettings 拆快慢、弹窗保存直接回写 config 的
    // 修复）。这段窗口内的任何一次保存（切页签 flush / 关窗 beforeunload /
    // 切分区 flush / 600ms 防抖到点）都会把旧 persona 深合并回服务端，
    // 把刚切换的人设静默还原 —— 表现为"保存成功了一切页签又变回旧人设"。
    // 修法：**元素不在场就不写该键**，deepMerge 自然保留服务端现值，
    // 从根上消除回滚面。页面若将来重新铺开这些输入框，逻辑自动恢复收集。
    const personaPatch = {};
    const botNameEl = $('#cfg-botname');
    if (botNameEl) personaPatch.botName = botNameEl.value.trim() || '小鲸鱼';
    const selfNickEl = $('#cfg-selfnick');
    if (selfNickEl) personaPatch.selfNickname = selfNickEl.value.trim();
    const participationEl = $('#cfg-participation');
    if (participationEl) personaPatch.participation = participationEl.value;
    const roleTextEl = $('#cfg-roletext');
    if (roleTextEl) personaPatch.roleText = roleTextEl.value;
    const rulesEl = $('#cfg-customrules');
    if (rulesEl) personaPatch.customRules = rulesEl.value;
    const sysPromptEl = $('#cfg-sysprompt');
    if (sysPromptEl) personaPatch.systemPromptOverride = sysPromptEl.value;
    if (Object.keys(personaPatch).length) patch.persona = personaPatch;
    // 统一人设开关：编辑器随开关二选一在场，读不到的保持旧值。
    patch.personaUnified = chk('#cfg-persona-unified', c.personaUnified !== false);
    // personaByChat 不在这里收集：独立人设模态框已改为**直接 POST 落盘**（openPerChatPersonaModal
    // 的 saveToMap），不再走"隐藏 JSON → 表单保存链"——那条链的 change 事件根本到不了 form
    // 监听器，而且 loadSettings 重建 DOM 会把没保存的值吹掉。这里如果再把（可能过期的）
    // 隐藏 JSON 值 POST 一遍，会把 modal 刚存的条目用旧值覆盖回去。
    // ⚠️ 统一开关"关闭"时后端语义：personaByChat 里的条目仍然生效（personaForChat
    //    逐会话合并），开关只控制 UI 形态。运行行为由配置数据决定，不由开关决定。
  }

  if (sec === 'allow' || sec === 'chat') {
    patch.allow = {
      groups: parseList(val('#cfg-allowgroups', (c.allow?.groups || []).join(','))),
      private: parseList(val('#cfg-allowprivate', (c.allow?.private || []).join(',')))
    };
    patch.deny = { groups: [], private: [] };
    // 原先这里硬编码 false：只要点过保存就把该开关永久重置，
    // 而 UI 里根本没有输入控件 —— 只能手改 JSON，改完一保存就丢。改为读取复选框。
    const allowAllBox = $('#cfg-allowallwhenempty');
    patch.allowAllWhenEmpty = allowAllBox ? !!allowAllBox.checked : (c.allowAllWhenEmpty === true);
  }

  if (sec === 'allow' || sec === 'chat') {
    // 2026-09-18 改版：运行节奏/发送保护/档位/峰谷/禁言/温度/思考强度 全部收进
    // 「信息发送配置」与「活跃设置」两个模态框（openSendConfigModal / openActiveConfigModal），
    // 模态框各自保存时直接 POST。本区块剩下的表单控件：主动话题。（表情包设置已移到 plugins/sticker 插件卡的设置弹窗。）
    patch.proactive = {
      ...(c.proactive || {}),
      enabled: chk('#cfg-proactive', !!c.proactive?.enabled),
      // 间隔：0ms 无意义 → 钳到 ≥1000，回落原值/默认（沿用旧的 `|| 默认` 语义）
      checkIntervalMinMs: num('#cfg-pro-min', c.proactive?.checkIntervalMinMs ?? 1800000, { min: 1000 }) || 1800000,
      checkIntervalMaxMs: num('#cfg-pro-max', c.proactive?.checkIntervalMaxMs ?? 5400000, { min: 1000 }) || 5400000,
      // ⚠️ 概率允许 0（= 从不主动发起）→ 必须走 num()，不能用 `|| 0.25`
      probability: num('#cfg-pro-prob', c.proactive?.probability ?? 0.25, { min: 0, max: 1 })
    };
  }

  // 'app'（界面与应用）与 'desktop'/'onebot'（兼容别名）共享同一批字段读取；
  // val()/chk() 均为 null 安全——当前页不存在的输入框回退到 c 里的原值，不会误写。
  if (sec === 'desktop' || sec === 'onebot' || sec === 'app') {
    patch.server = {
      ...c.server,
      autoStart: chk('#cfg-autostart', !!c.server?.autoStart),
      closeToTray: chk('#cfg-closetray', c.server?.closeToTray !== false)
    };
    patch.ui = {
      ...(c.ui || {}),
      // 主题在点选项时就已应用并写入 localStorage，这里把它一并存到后端以便跨设备保留
      theme: getThemePref(),
      showVision: chk('#cfg-showvision', c.ui?.showVision !== false),
      refreshMs: Number(val('#cfg-refreshms', c.ui?.refreshMs ?? 15000)) || 15000,
      // 外观个性化（R40）：颜色只接受合法 hex（手填一半如 "#5b8" 时不写，避免整条
      // CSS 声明失效）；背景图不在页面上（由原生对话框选好后即时落盘），这里只原样保留。
      accent: isHexColor(val('#cfg-accent-hex', c.ui?.accent ?? '')) ? val('#cfg-accent-hex', '').trim() : '',
      bgColor: isHexColor(val('#cfg-bgcolor-hex', c.ui?.bgColor ?? '')) ? val('#cfg-bgcolor-hex', '').trim() : '',
      frameAlpha: clampInt(val('#cfg-framealpha', c.ui?.frameAlpha ?? 100), 30, 100, 100),
      bgImage: String(c.ui?.bgImage || ''),
      bgFit: val('#cfg-bgfit', c.ui?.bgFit || 'cover'),
      bgDim: clampInt(val('#cfg-bgdim', c.ui?.bgDim ?? 0), 0, 85, 0),
      winOpacity: clampInt(val('#cfg-winopacity', c.ui?.winOpacity ?? 100), 30, 100, 100)
    };
    patch.memberNotes = {
      ...(c.memberNotes || {})
    };
    // ── 桌面悬浮小窗（2026-10-20）──
    // 只收集设置项；位置/尺寸在主进程侧落 window-state.json，不经过这里。
    // enabled 关着时其余项照常收集（下次打开即生效），UI 上整组只是置灰。
    const widgetSize = val('#cfg-widget-size', c.widget?.size || 'm');
    patch.widget = {
      ...(c.widget || {}),
      enabled: chk('#cfg-widget-enabled', !!c.widget?.enabled),
      alwaysOnTop: chk('#cfg-widget-top', c.widget?.alwaysOnTop !== false),
      clickThrough: chk('#cfg-widget-click', !!c.widget?.clickThrough),
      edgeHide: chk('#cfg-widget-edgehide', c.widget?.edgeHide !== false),
      opacity: num('#cfg-widget-opacity', c.widget?.opacity ?? 100, { min: 30, max: 100 }) || 100,
      transparent: chk('#cfg-widget-transparent', !!c.widget?.transparent),
      size: ['s', 'm', 'l'].includes(widgetSize) ? widgetSize : 'm',
      refreshMs: num('#cfg-widget-refresh', c.widget?.refreshMs ?? 2500, { min: 1000, max: 60000 }) || 2500
    };
  }

  if (sec === 'desktop' || sec === 'onebot' || sec === 'app') {
    // ⚠️ 令牌是脱敏回传的（值是 ******，真实值只在后端）：
    //    留空 / ****** = 保持原值不变；只有输入了新明文才更新。
    //    曾经直接把输入框的值（脱敏后为空）写进 patch，
    //    结果"保存一次别的设置，OneBot 令牌就被清空"。
    const enteredWsToken = val('#cfg-obtoken', '').trim();
    const enteredHttpToken = val('#cfg-obhttptoken', '').trim();
    patch.snowluma = {
      dir: val('#cfg-snowlumadir', c.snowluma?.dir || '').trim(),
      autoLaunch: chk('#cfg-snowlumalaunch', !!c.snowluma?.autoLaunch),
      wsUrl: val('#cfg-wsurl', c.snowluma?.wsUrl || '').trim(),
      httpUrl: val('#cfg-httpurl', c.snowluma?.httpUrl || '').trim(),
      ...(enteredWsToken && enteredWsToken !== '******' ? { accessToken: enteredWsToken } : {}),
      ...(enteredHttpToken && enteredHttpToken !== '******' ? { httpAccessToken: enteredHttpToken } : {})
    };
  }

  if (sec === 'tools') {
    // 工具配置直接从 state.config.tools 读取（事件绑定已实时更新）
    patch.tools = state.config.tools || { enabled: true, overrides: {}, categories: {} };
  }

  // ── POST 之前的最后防线：去掉"空 patch"造成的无谓请求 ──
  // 变动监听挂在整个 #settings-form 上，点击 readonly 输入框、拖动滑条
  // 等不产生真实改动的操作也会触发一次保存。空 patch（没有任何顶层键）
  // 直接跳过 —— 它不会破坏数据，但每次都会让后端全量落盘 + 广播 status。
  if (Object.keys(patch).length === 0) {
    return { ok: true, config: state.config };
  }

  // keepalive：页面卸载（关窗/刷新）后请求仍能完成 —— beforeunload 的
  // 兜底 flush 依赖这一点，普通 fetch 会随页面一起被浏览器中止。
  // ⚠️ 但 keepalive 有 64KB body 上限，超限时 fetch 直接抛 "Failed to fetch"
  // （连请求都不发）。设置 patch 多数很小，但关键词表/模型列表/工具 overrides
  // 可能超 —— 按体积自适应：大 body 退回普通 fetch（卸载兜底本来也只是尽力而为）。
  const bodyStr = JSON.stringify(patch);
  const useKeepalive = bodyStr.length < 60_000;
  const data = await api('/api/config', { method: 'POST', body: bodyStr, ...(useKeepalive ? { keepalive: true } : {}) });
  state.config = data.config;
  if (!quiet) $('#model-label').textContent = `模型：${state.config.api.model || '未设置'}`;
  return data;
}

/* 装载焦点陷阱（2026-10-10 r86 修 P2）：本脚本以 defer 加载，执行时 body 已解析完，
   直接装即可。装好后由 MutationObserver 自动登记后续所有 .model-modal-overlay，
   无需每个创建方显式登记。 */
try { installModalFocusTrap(); } catch { /* 环境不支持则退化为无陷阱 */ }
