// 集成系统 · 插件侧小面板（完整设置已搬到顶栏「集成系统」独立页）
// 这里只做三件事：① 实时状态一眼看；② 6 个最常用开关；③ 一个按钮跳到完整页面。
// 契约不变：render(ctx) / bind(root, ctx)。
const BASIC = [
  { key: 'enabled', t: 'bool', l: '总开关', d: '关掉后不再观察/不推进/不注入（数值留在磁盘）' },
  { key: 'ignoreWhileSleeping', t: 'bool', l: '睡眠时底层忽略（省 token）', d: '睡着时普通消息入站就拦，零 token，醒来补看' },
  { key: 'wakeChancePercent', t: 'num', l: '可被吵醒的概率（%）', d: '默认 40；同一窗口内被吵醒越多越难醒' },
  { key: 'playAlongMaxReplies', t: 'num', l: '陪闹可回复条数', d: '心情好被吵醒时陪你玩几条，然后收尾回睡' },
  { key: 'hpDamagePercent', t: 'num', l: '单次扣血（%上限）', d: '默认 2；低频低伤，日常扣血不致命' },
  { key: 'favorLinkEnabled', t: 'bool', l: '好感度联动（甜点层）', d: '好感只给一点点情绪/疲劳：有上限、默认不碰生命值' }
];
const esc = (v) => String(v == null ? '' : v).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const num = (v, d) => (Number.isFinite(Number(v)) ? Number(v) : d);

async function loadView(ctx) {
  const stored = (typeof ctx.pluginConfig === 'function' ? ctx.pluginConfig() : null) || {};
  let defaults = {};
  try {
    const m = await fetch('/plugin-assets/sleep-mood/plugin.json', { cache: 'no-store' }).then((r) => r.json());
    if (m?.settings && typeof m.settings === 'object') defaults = m.settings;
  } catch { /* 忽略 */ }
  let dash = null;
  try { dash = await fetch('/mood-dashboard.json?t=' + Date.now(), { cache: 'no-store' }).then((r) => r.json()); } catch { dash = null; }
  return { cfg: { ...defaults, ...stored }, dash };
}

function liveHtml(d) {
  if (!d) return '<div class="sm-desc">读不到实时数据（插件未启用或还没跑过心跳）</div>';
  const hp = d.hp || {}; const sys = d.systems || {}; const sl = sys.sleep || {}; const fav = d.favor || {};
  const tone = hp.critical ? 'sm-bad' : (hp.weak ? 'sm-warn' : 'sm-ok');
  return '<div class="sm-live-strip">'
    + '<span class="sm-chip ' + tone + '">❤️ 生命值 <b>' + Math.round(num(hp.value, 0)) + '/' + Math.round(num(hp.max, 0)) + '</b></span>'
    + '<span class="sm-chip">🧠 ' + esc((d.dominant && d.dominant.word) || '平静') + '</span>'
    + '<span class="sm-chip">😴 ' + (sl.sleeping ? (sl.kind === 'command' ? '命令睡眠' : '自然睡眠') : '醒着') + '</span>'
    + '<span class="sm-chip">💞 好感联动 ' + (fav.enabled ? '开' : '关') + '</span>'
    + '</div>';
}

export async function render(ctx) {
  const { cfg, dash } = await loadView(ctx);
  const fields = BASIC.map((f) => {
    const v = cfg[f.key];
    const id = 'sm-basic-' + f.key;
    if (f.t === 'bool') {
      return '<div class="sm-field sm-bool"><label for="' + id + '"><input type="checkbox" id="' + id + '" data-sm="' + esc(f.key) + '"' + (v === true ? ' checked' : '') + '> <b>' + esc(f.l) + '</b></label><div class="sm-desc">' + esc(f.d) + '</div></div>';
    }
    return '<div class="sm-field"><label for="' + id + '"><b>' + esc(f.l) + '</b></label><div class="sm-desc">' + esc(f.d) + '</div><input type="number" id="' + id + '" data-sm="' + esc(f.key) + '" value="' + esc(v == null ? '' : v) + '"></div>';
  }).join('');
  return '<style>'
    + '.sm-live-strip{display:flex;flex-wrap:wrap;gap:6px;margin:6px 0 12px}'
    + '.sm-chip{font-size:11.5px;padding:3px 8px;border-radius:999px;background:rgba(128,128,128,.14)}'
    + '.sm-chip.sm-ok{background:rgba(79,191,122,.20)}.sm-chip.sm-warn{background:rgba(224,164,60,.24)}.sm-chip.sm-bad{background:rgba(217,92,92,.26)}'
    + '.sm-field{margin:8px 0}.sm-field label{font-size:12.5px}'
    + '.sm-field input[type=number]{width:100%;max-width:200px;padding:5px 7px;border-radius:6px;border:1px solid var(--border,#444);background:var(--bg-2,transparent);color:inherit}'
    + '.sm-desc{color:var(--muted,#888);font-size:11.5px;line-height:1.6}'
    + '.sm-actions{display:flex;gap:10px;align-items:center;margin-top:14px;flex-wrap:wrap}.sm-msg{font-size:12px;color:var(--muted,#888)}'
    + '</style>'
    + '<div><h3 style="margin:0 0 4px">睡眠情绪好感度生命值集成系统</h3>'
    + '<div class="sm-desc">这里只放最常用的 6 项；<b>完整设置（5 个分区）在顶栏「集成系统」页</b>。</div>'
    + liveHtml(dash) + fields
    + '<div class="sm-actions"><button class="btn" id="sm-save" type="button">保存这几项</button>'
    + '<button class="btn" id="sm-open" type="button">打开「集成系统」完整设置</button>'
    + '<span class="sm-msg" id="sm-msg"></span></div></div>';
}

export function bind(root, ctx) {
  const msg = root.querySelector('#sm-msg');
  const say = (t, bad) => { if (msg) { msg.textContent = t; msg.style.color = bad ? '#d95c5c' : ''; } };
  const collect = () => {
    const patch = {};
    for (const el of root.querySelectorAll('[data-sm]')) {
      const key = el.getAttribute('data-sm');
      if (el.type === 'checkbox') patch[key] = !!el.checked;
      else patch[key] = el.value === '' ? 0 : Number(el.value);
    }
    return patch;
  };
  const onSave = async () => {
    say('保存中…');
    try {
      await ctx.api('/api/skills/sleep-mood', { method: 'POST', body: JSON.stringify({ settings: collect() }) });
      say('已保存；完整设置见顶栏「集成系统」页');
      try { await ctx.reload(); } catch { /* 忽略 */ }
    } catch (e) { say('保存失败：' + (e?.message || e), true); }
  };
  const onOpen = () => {
    try { if (typeof window.switchTab === 'function') { window.switchTab('integrated'); return; } } catch { /* 忽略 */ }
    say('请在顶栏点「集成系统」页签');
  };
  const saveBtn = root.querySelector('#sm-save');
  const openBtn = root.querySelector('#sm-open');
  saveBtn?.addEventListener('click', onSave);
  openBtn?.addEventListener('click', onOpen);
  return () => { saveBtn?.removeEventListener('click', onSave); openBtn?.removeEventListener('click', onOpen); };
}
