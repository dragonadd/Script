// 音乐搜索服务（点歌用）—— 零依赖，Node 20+。
//
// 职责：接收一个歌名，返回"用户想听的那首歌"的可点开链接。
//
// ── 为什么不能只查网易云 ──────────────────────────────────────────────
// 实测（本机，2026-09）：搜「晴天」时，网易云公开搜索接口 /api/search/get 翻 400 条
// 都没有周杰伦原唱（它的官方网页搜索页同样搜不到），给出的全是同名翻唱；而 QQ 音乐
// 第一条就是周杰伦《叶惠美》原唱。所以只查网易云会稳定给出劣质结果，必须两边都查。
//
// ── 怎么判断"哪条是原唱" ──────────────────────────────────────────────
//   1) 网易云详情接口 GET /api/song/detail?ids=[id,...] 的 originCoverType：
//      1=原唱, 2=翻唱(改编)；翻唱还会带 originSongSimpleData 指回原曲。
//      这是权威标记，比按歌名猜可靠得多。
//   2) 平台搜索位次：第 1 名基本就是这家认为的正主（QQ 音乐对主流歌很准）。
//   3) 歌名里的"翻唱/伴奏/DJ/钢琴版"等字样（QQ 音乐没有原唱标记时的兜底）。
//
// ── 挑选规则（按优先级）──────────────────────────────────────────────
//   1) 必须先"像那首歌"：归一化歌名完全相同，或一方完整包含另一方（≥2 字）
//   2) 原唱优先于翻唱/伴奏；用户提到的歌手优先
//   3) 平台位次高、网易云热度高者优先
//   4) 同一首歌（归一化歌名 + 主歌手）只输出一条，平手时按平台偏好（默认网易云）
//   5) 两个接口都不可用 → 退化成"搜索页链接"，至少让用户能点进去自己选
//
// ── 已知限制 ─────────────────────────────────────────────────────────
//   只给歌名、不给歌手时（例如"想听晴天"），网易云由于隐藏了主流版权曲，可能给出
//   另一首同名的冷门原创。服务会把 QQ 音乐的原唱排在前面优先输出；同时也会把网易云
//   的同名条目一并列出，供上游选择。模型拿到 results 后应优先发 results[0]。
//
// 启动：node music-service.mjs            （默认 127.0.0.1:3457，只监听本机）
//       PORT=4000 node music-service.mjs  （换端口）
// 自测：node music-service.mjs --selftest 晴天
//       node music-service.mjs --selftest --debug 晴天   （打印全部候选与分数）
//
// 接口：
//   GET /health                  → { ok:true, ... }
//   GET /music?q=晴天&limit=3    → { ok:true, query, pick, results:[...], notice }
//
// 每条结果：
//   { platform, name, artists, album, durationSec, url, searchUrl, cover, kind, popularity }
//   platform: 'netease' | 'qq'
//   kind    : 'origin'（原唱）| 'cover'（翻唱/伴奏/改编）
//   url     : 歌曲详情页链接（用户点开就能听）
//   searchUrl: 该平台的搜索页链接（详情页失效时用）


const PORT = Math.max(1, Number(process.env.PORT) || 3457);
const HOST = '127.0.0.1';
const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';

// 歌名里的翻唱/改编标记（originCoverType 拿不到时的兜底信号，QQ 音乐那边没有该字段）
const COVER_WORDS = [
  '翻唱', 'cover', '伴奏', 'remix', 'dj', '纯音乐', '钢琴', '吉他', '八音盒', '口琴', '古筝',
  '抖音', '女声', '男声', '童声', '清唱', 'demo', 'live', '现场', '演唱会', '串烧', '铃声',
  '合唱版', '深情版', '治愈版', '摇滚版', '改编', '哼唱'
];

// ────────────────────────────── 小工具 ──────────────────────────────

function cleanQuery(input) {
  return String(input ?? '')
    .replace(/\[CQ:[^\]]*\]/gi, ' ')
    .replace(/[\u0000-\u001f\u007f]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 80);
}

/** 带 UA/Referer 和超时的 JSON GET；失败抛错，由调用方兜。 */
async function getJson(url, { referer = '', timeoutMs = 8000 } = {}) {
  const res = await fetch(url, {
    headers: {
      'user-agent': UA,
      accept: 'application/json, text/plain, */*',
      'accept-language': 'zh-CN,zh;q=0.9',
      ...(referer ? { referer } : {})
    },
    signal: AbortSignal.timeout(timeoutMs)
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const text = await res.text();
  try {
    return JSON.parse(text);
  } catch {
    throw new Error(`返回了非 JSON 内容（前 80 字：${text.slice(0, 80).replace(/\s+/g, ' ')}）`);
  }
}

function fmtDuration(ms) {
  const total = Math.round(Number(ms) / 1000);
  if (!Number.isFinite(total) || total <= 0) return '';
  return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, '0')}`;
}

function neteaseSearchUrl(q) {
  return `https://music.163.com/#/search/m/?s=${encodeURIComponent(q)}&type=1`;
}

function qqSearchUrl(q) {
  return `https://y.qq.com/n/ryqq/search?w=${encodeURIComponent(q)}&t=song&remoteplace=txt.yqq.top`;
}

/** 归一化歌名：去掉 (深情版)/【Live】 这类后缀与标点，用于匹配与归组。 */
function baseTitle(name) {
  return String(name ?? '')
    .replace(/[（(\[【][^）)\]】]*[）)\]】]/g, '')
    .replace(/[\s·・'"“”‘’,，.。!！?？\-_]/g, '')
    .trim()
    .toLowerCase();
}

/**
 * 从搜索结果反推：搜索词里哪一段是歌手、哪一段是歌名。
 *
 * 「孤勇者 陈奕迅」和「陈奕迅 孤勇者」两种写法都要支持，光靠"最后一段是歌名"
 * 会把歌手当歌名（搜"陈奕迅"回来一堆他的别的歌），排序就全错了。
 * 判定办法很直接：哪一段**出现在结果的演唱者里**，哪一段就是歌手。
 * 拿不准时按"最后一段是歌名"的老规矩。
 */
function splitIntent(query, songs = []) {
  const q = String(query).trim();
  const parts = q.split(/\s*[-–—]\s*|\s+/).filter(Boolean);
  if (parts.length < 2) return { title: q, artist: '', tokens: parts.length ? parts : [q] };

  const artistsText = songs
    .flatMap((s) => s.artists || [])
    .join(' ')
    .toLowerCase();
  const inArtists = (p) => {
    const n = String(p).toLowerCase();
    return n.length >= 2 && artistsText.includes(n);
  };
  const firstIsArtist = inArtists(parts[0]);
  const lastIsArtist = inArtists(parts[parts.length - 1]);

  if (firstIsArtist && !lastIsArtist) {
    return { title: parts.slice(1).join(' '), artist: parts[0], tokens: parts };
  }
  if (lastIsArtist && !firstIsArtist) {
    return { title: parts.slice(0, -1).join(' '), artist: parts[parts.length - 1], tokens: parts };
  }
  // 两边都像歌手（罕见）或都不像 → 沿用"最后一段是歌名"
  return { title: parts[parts.length - 1], artist: parts.slice(0, -1).join(' '), tokens: parts };
}

/** 歌名里的翻唱标记兜底判断。 */
function looksLikeCoverName(name) {
  const lower = String(name ?? '').toLowerCase();
  return COVER_WORDS.some((w) => lower.includes(w));
}

// ───────────────────────────── 网易云 ─────────────────────────────

async function searchNetease(query, want) {
  const url =
    'https://music.163.com/api/search/get?s=' +
    encodeURIComponent(query) +
    `&type=1&limit=${Math.min(100, Math.max(20, want * 10))}&offset=0`;
  const data = await getJson(url, { referer: 'https://music.163.com/' });
  if (Number(data?.code) !== 200) {
    throw new Error(`网易云返回 code=${data?.code}${data?.message ? `（${data.message}）` : ''}`);
  }
  const raw = data?.result?.songs || data?.result?.song || [];
  return raw
    .filter((s) => s && s.id)
    .map((s, rank) => {
      const artists = (s.artists || s.ar || []).map((a) => a?.name).filter(Boolean);
      const name = String(s.name ?? '').trim();
      return {
        platform: 'netease',
        id: String(s.id),
        rank,
        name,
        artists,
        album: String(s.album?.name ?? s.al?.name ?? '').trim(),
        durationSec: fmtDuration(s.duration ?? s.dt),
        url: `https://music.163.com/song?id=${s.id}`,
        searchUrl: neteaseSearchUrl(`${name} ${artists.join(' ')}`.trim()),
        cover: String(s.album?.picUrl ?? s.al?.picUrl ?? ''),
        kind: looksLikeCoverName(name) ? 'cover' : 'origin',
        popularity: 0,
        coverOf: null // { id, name, artist }
      };
    });
}

/**
 * 批量取歌曲详情，返回归一化后的数组。
 *
 * 优先用 /api/v3/song/detail：字段更全（pop / originCoverType / originSongSimpleData /
 * al.picUrl / ar / dt），而且旧的 /api/song/detail 会莫名开始返回 code 405
 * （实测：调试打频繁后被限流，连单条都 405）。所以 v3 当主路径，旧接口只作兜底。
 */
async function fetchNeteaseSongDetails(ids) {
  const list = (ids || []).map(String).filter(Boolean);
  if (!list.length) return [];

  const normalize = (s, v3) => {
    const origin = s?.originSongSimpleData || null;
    return {
      id: String(s?.id ?? ''),
      name: String(s?.name ?? '').trim(),
      artists: ((v3 ? s?.ar : s?.artists) || []).map((a) => a?.name).filter(Boolean),
      album: String((v3 ? s?.al?.name : s?.album?.name) ?? '').trim(),
      // 1 = 原唱；2/其它 = 翻唱或改编
      isOrigin: Number(s?.originCoverType) === 1 || Number(s?.originCoverType) === 0,
      coverOf: origin
        ? {
            id: String(origin.songId ?? ''),
            name: String(origin.name ?? ''),
            artist: (origin.artists || []).map((a) => a?.name).filter(Boolean)[0] || ''
          }
        : null,
      durationSec: fmtDuration(v3 ? s?.dt : s?.duration),
      popularity: Number(v3 ? s?.pop : s?.popularity) || 0,
      cover: String((v3 ? s?.al?.picUrl : s?.album?.picUrl) ?? s?.album?.blurPicUrl ?? '').replace(/^http:/, 'https:')
    };
  };

  // 1) v3
  try {
    const c = JSON.stringify(list.map((id) => ({ id: Number(id) || id })));
    const data = await getJson(
      `https://music.163.com/api/v3/song/detail?c=${encodeURIComponent(c)}`,
      { referer: 'https://music.163.com/' }
    );
    if (Number(data?.code) === 200 && Array.isArray(data?.songs) && data.songs.length) {
      return data.songs.map((s) => normalize(s, true));
    }
  } catch {
    // 落到旧接口
  }

  // 2) 旧接口兜底
  try {
    const data = await getJson(`https://music.163.com/api/song/detail?ids=[${list.join(',')}]`, {
      referer: 'https://music.163.com/'
    });
    return (data?.songs || []).map((s) => normalize(s, false));
  } catch {
    return [];
  }
}

/**
 * 批量补详情：拿 originCoverType（权威原唱标记）、翻唱指回的原曲、专辑、时长、封面、热度。
 * 失败不影响主流程（返回空 Map）。
 */
async function enrichNeteaseDetails(songs) {
  const map = new Map();
  const ids = songs.map((s) => s.id).filter(Boolean);
  if (!ids.length) return map;

  // 分批，避免 URL 过长
  const chunkSize = 50;
  for (let i = 0; i < ids.length; i += chunkSize) {
    const chunk = ids.slice(i, i + chunkSize);
    const details = await fetchNeteaseSongDetails(chunk);
    for (const d of details) map.set(d.id, d);
  }
  return map;
}

function applyNeteaseDetails(songs, detailMap) {
  return songs.map((s) => {
    const d = detailMap.get(s.id);
    if (!d) return s;
    return {
      ...s,
      name: d.name || s.name,
      artists: d.artists.length ? d.artists : s.artists,
      album: d.album || s.album,
      durationSec: d.durationSec || s.durationSec,
      cover: d.cover || s.cover,
      popularity: d.popularity,
      kind: d.isOrigin ? 'origin' : 'cover',
      coverOf: d.coverOf
    };
  });
}

// ──────────────────────────── QQ 音乐 ────────────────────────────

async function searchQQ(query, want) {
  const url =
    'https://c.y.qq.com/soso/fcgi-bin/client_search_cp?w=' +
    encodeURIComponent(query) +
    `&format=json&n=${Math.min(60, Math.max(20, want * 10))}&p=1&cr=1&new_json=1`;
  const data = await getJson(url, { referer: 'https://y.qq.com/' });
  if (data?.code !== 0 && data?.code !== undefined) {
    throw new Error(`QQ音乐返回 code=${data.code}`);
  }
  const raw = data?.data?.song?.list || [];
  return raw
    .map((s, rank) => {
      const mid = String(s?.mid ?? s?.songmid ?? '');
      const name = String(s?.name ?? s?.title ?? s?.songname ?? '').trim();
      const artists = (s?.singer || []).map((x) => x?.name).filter(Boolean);
      if (!mid || !name) return null;
      // 封面：QQ 音乐搜索只给专辑 mid，封面 URL 要自己拼（实测可下载）
      const albumMid = String(s?.album?.mid ?? '').trim();
      const cover = albumMid ? `https://y.qq.com/music/photo_new/T002R300x300M000${albumMid}.jpg?max_age=2592000` : '';
      return {
        platform: 'qq',
        id: mid,
        rank,
        name,
        artists,
        album: String(s?.album?.name ?? s?.albumname ?? '').trim(),
        durationSec: fmtDuration((Number(s?.interval) || 0) * 1000),
        url: `https://y.qq.com/n/ryqq/songDetail/${mid}`,
        searchUrl: qqSearchUrl(`${name} ${artists.join(' ')}`.trim()),
        cover,
        // QQ 音乐搜索没有原唱标记，只能用歌名里的翻唱字样兜底
        kind: looksLikeCoverName(name) ? 'cover' : 'origin',
        popularity: 0,
        coverOf: null
      };
    })
    .filter(Boolean);
}

// ──────────────────── 打分 · 归组 · 挑选（核心） ────────────────────

/**
 * 歌名是否"像用户要的那首"。
 * 只认两种：归一化后完全相同，或一方完整包含另一方（且短的那方至少 2 个字）。
 * 「晴天」vs「晴」不算 —— 少一个字就是另一首歌。
 */
function titleMatch(song, intent) {
  const bt = baseTitle(song.name);
  const it = baseTitle(intent.title);
  if (!bt || !it) return 'none';
  if (bt === it) return 'exact';
  const shorter = bt.length <= it.length ? bt : it;
  const longer = bt.length <= it.length ? it : bt;
  if (shorter.length >= 2 && longer.includes(shorter)) return 'partial';
  return 'none';
}

/** 歌手是否在搜索词里被提到。 */
function artistMentioned(song, intent) {
  const artists = (song.artists || []).join(' ').toLowerCase();
  return intent.tokens.some((t) => {
    const needle = String(t).toLowerCase();
    return needle.length >= 2 && artists.includes(needle);
  });
}

/**
 * 打分。所有平台用同一把尺子，不掺平台偏好（偏好只在分差很小时做裁决）。
 * 主要权重：
 *   - 歌名：完全相同 100，包含 40，都不是 → 直接淘汰
 *   - 原唱/翻唱：+18 / -30（网易云靠 originCoverType 判定，很可靠）
 *   - 歌手在搜索词里被提到：+40
 *   - 平台的搜索位次：第 1 名 +30，逐位递减到 0
 *     （位次是"这家平台自己认为的正主"，对主流歌很准：QQ 搜「晴天」第一条就是
 *      周杰伦原唱。网易云对隐藏曲不给原唱，但这条规则能把它那些冷门同名曲压下去）
 *   - 网易云热度：最多 +10（QQ 音乐没这字段，恒 0）
 */
function hasVariantSuffix(name, album = '') {
  const hay = `${String(name ?? '')} ${String(album ?? '')}`.toLowerCase();
  return COVER_WORDS.some((w) => hay.includes(w));
}

function scoreSong(song, intent) {
  const tm = titleMatch(song, intent);
  if (tm === 'none') return -1000;

  let score = tm === 'exact' ? 100 : 40;
  score += song.kind === 'origin' ? 18 : -30;
  if (hasVariantSuffix(song.name, song.album)) score -= 40;
  if (artistMentioned(song, intent)) score += 40;
  score += Math.max(0, 30 - 3 * Math.min(10, Number(song.rank) || 0));
  score += Math.min(10, Math.round((Number(song.popularity) || 0) / 10));
  // 不到 90 秒的基本是片段/铃声，不是完整歌（搜「告白气球」时撞到过 0:55 的条目）
  const secs = (() => {
    const m = /^(\d+):(\d{2})$/.exec(String(song.durationSec ?? ''));
    return m ? Number(m[1]) * 60 + Number(m[2]) : null;
  })();
  if (secs !== null && secs < 90) score -= 45;
  return score;
}

/**
 * 同一首歌的归组 key：归一化歌名 + 主歌手。
 *
 * 为什么带上歌手，而不是只按歌名：「晴天」在库里同时存在周杰伦的原唱和大量同名
 * 原创/翻唱（空匪、夏天Alex…）。只按歌名分组会把它们挤成一组、只能留一条，于是
 * 要么丢掉原唱、要么丢掉用户真正在找的那个歌手。带上歌手后它们各自成组，都能展示。
 *
 * 网易云把周杰伦这类主流版权曲从**搜索结果**里藏掉了（翻 400 条都没有原唱），
 * 所以同名不同歌手的条目之间无法自动判优 —— 这也是为什么结果里会同时出现多条，
 * 由用户自己挑。见 README 里"已知限制"。
 */
function songKey(song) {
  const artist = String(song.artists?.[0] ?? '')
    .toLowerCase()
    .replace(/\s+/g, '');
  return `ttl:${baseTitle(song.name)}|${artist}`;
}

const PLATFORM_TIE_BAND = 8;

/**
 * 挑结果。
 *   1) 分数明显更高者胜（歌名/原唱/歌手/位次/热度都算在分数里）
 *   2) 分差在 PLATFORM_TIE_BAND 内 → 视为平手，按平台偏好（网易云优先）
 * 这样"网易云优先"是偏好而不是铁律：网易云只有翻唱、别家有原唱时，原唱胜出。
 */
function pickResults(all, intent, limit, prefer = 'netease') {
  const scored = all
    .map((s) => ({ song: s, score: scoreSong(s, intent) }))
    .filter((x) => x.score > -1000)
    .sort((a, b) => b.score - a.score);

  const groups = new Map();
  for (const item of scored) {
    const key = songKey(item.song);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(item);
  }

  const output = [];

  for (const [, items] of groups) {
    const best = items[0];
    // 与最优分"平手"的候选里，优先选用户偏好的平台
    const tied = items.filter((x) => best.score - x.score <= PLATFORM_TIE_BAND);
    const preferred = tied.find((x) => x.song.platform === prefer);
    const winner = preferred || best;
    // 另一平台的同一首歌，附在结果里（上游想给两个链接时可以用）
    winner.song.alternatives = items
      .filter((x) => x.song !== winner.song && x.song.platform !== winner.song.platform)
      .slice(0, 2)
      .map((x) => ({ platform: x.song.platform, url: x.song.url }));
    output.push(winner.song);
  }

  output.sort((a, b) => scoreSong(b, intent) - scoreSong(a, intent));
  const notes = [];
  const picked = output.slice(0, limit);

  // 只在"整份结果都来自非偏好平台"时才提示，避免每条都念一遍
  if (picked.length && picked.every((s) => s.platform !== prefer)) {
    notes.push(`网易云搜不到这几首的原唱，结果来自 ${picked[0].platform === 'qq' ? 'QQ 音乐' : '另一平台'}`);
  }
  return { results: picked, notice: notes.join('；') };
}

// ──────────────────────────── 主流程 ────────────────────────────

/** 一次"两边都搜 + 补详情"的完整查询。 */
async function queryBothPlatforms(query, limit) {
  const errors = [];
  const [neSettled, qqSettled] = await Promise.allSettled([
    searchNetease(query, limit),
    searchQQ(query, limit)
  ]);

  let netease = neSettled.status === 'fulfilled' ? neSettled.value : [];
  const qq = qqSettled.status === 'fulfilled' ? qqSettled.value : [];
  if (neSettled.status === 'rejected') errors.push(`网易云：${neSettled.reason?.message ?? neSettled.reason}`);
  if (qqSettled.status === 'rejected') errors.push(`QQ音乐：${qqSettled.reason?.message ?? qqSettled.reason}`);

  // 补齐网易云的原唱标记（关键一步：originCoverType 才是权威判据）
  if (netease.length) {
    const detailMap = await enrichNeteaseDetails(netease);
    netease = applyNeteaseDetails(netease, detailMap);
  }
  return { netease, qq, errors };
}

/** 歌手名精确匹配某条结果（比 artistMentioned 严：只看 artists 数组，不看歌名）。 */
function artistExactly(song, intent) {
  const wanted = intent.tokens.map((t) => String(t).toLowerCase()).filter((t) => t.length >= 2);
  return (song.artists || []).some((a) => {
    const n = String(a).toLowerCase();
    return wanted.some((w) => n === w || n.includes(w) || w.includes(n));
  });
}

/** "这条结果就是用户要的那位歌手唱的原唱"。 */
function isArtistOriginal(song, intent) {
  return song.kind === 'origin' && !hasVariantSuffix(song.name, song.album) && artistExactly(song, intent);
}

async function searchMusic(query, limit = 3) {
  // 先按"整串都是歌名"去搜（保证召回：带歌手名一起搜往往召回更差），
  // 拿到候选后再反推哪一段是歌手，才做精确排序。
  const first = await queryBothPlatforms(query, limit);
  let { netease, qq, errors } = first;

  if (!netease.length && !qq.length) {
    return { results: [], notice: errors.join('；') || '两个平台都没搜到结果', degraded: true };
  }

  const intent = splitIntent(query, [...netease, ...qq]);
  let { results, notice } = pickResults([...netease, ...qq], intent, limit);
  // 注：这里曾调用 attachNeteaseCounterparts 给 QQ音乐的歌映射网易云 id 以发卡片。
  // 实测该映射会稳定落到同名翻唱上（网易云隐藏主流原唱），故整体弃用，见 buildCard 注释。

  // 兜底：用户带了歌手，但结果里没有"这位歌手唱的原唱"
  // （网易云会隐藏原唱，QQ 有时也搜不到带歌手词的组合；带歌手词的搜索反而只剩翻唱）
  // → 退回只用歌名再搜一次，通常就能把原唱找回来。救「孤勇者 陈奕迅」这类查询。
  if (results.length && intent.artist && !results.some((r) => isArtistOriginal(r, intent))) {
    const retry = await queryBothPlatforms(intent.title, limit);
    const retryIntent = { title: intent.title, artist: '', tokens: [intent.title] };
    const retried = pickResults([...retry.netease, ...retry.qq], retryIntent, limit);
    const retryHit = retried.results.find((r) => isArtistOriginal(r, intent));
    if (retryHit) {
      // 把命中歌手的那条顶到最前，其余不重复的跟在后面
      const rest = retried.results.filter(
        (r) => r !== retryHit && !results.some((x) => x.url === r.url)
      );
      results = [retryHit, ...rest].slice(0, limit);
      notice = [notice, `按“${query}”没搜到 ${intent.artist} 的原唱，已改用歌名搜索`]
        .filter(Boolean)
        .join('；');
    }
  }

  const notes = [notice, ...errors].filter(Boolean);
  if (!results.length) {
    return { results: [], notice: notes.join('；') || '没有歌名匹配的结果', degraded: true };
  }
  return { results, notice: notes.join('；') };
}

// ─────────────────────── 音乐卡片构造（关键） ───────────────────────
//
// 为什么要在这里生成卡片数据，以及为什么卡片一律用网易云渲染器：
//
// 1) SnowLuma 的 music 段会先调外部签名服务（默认 https://ss.xingzhige.com/music_card/card），
//    该服务目前返回 HTTP 500；失败后它退回"本地卡片"——用**调用方传入的**
//    title / url / image 拼 com.tencent.structmsg 卡片（见 snowluma/index.mjs
//    segmentToElement 的 "falling back to local card"）。
//    只传 type+id 时字段全空，QQ 只回一句"发送者版本过低，无法展示内容"。
//
// 2) 实测（本机）：type:'163' 的卡片 QQ 能正常渲染（标题、歌手、封面都对）；
//    而 type:'qq' 即使把 title/content/url/image 全填上，仍然渲染失败
//    （QQ 回"发送者版本过低"，签名服务对它另有要求）。
//    所以卡片统一走 163 渲染器：QQ音乐独占的歌，先去网易云找同一首拿它的 songId。
//    找不到就退回**没有卡片的文本**，绝不发一张渲染不出来的 qq 卡片。
//
// 3) 卡片里显示的歌名/歌手/封面仍来自选中的那条结果，只有链接指向的渲染平台不同。


/**
 * 把一条歌曲结果转成可直接发送的卡片数据。
 * 返回 { music, text }；music 为 null 时调用方发 text。
 *
 * ── 为什么只给网易云的歌发卡片 ──────────────────────────────────────
 * 卡片签名服务（ss.xingzhige.com/music_card/card）实测：
 *   type=163 → 返回完整的 com.tencent.music.lua 卡片 JSON，QQ 能正常渲染；
 *   type=qq  → 返回纯文本「关闭id解析功能」（服务方已关闭 QQ音乐解析）。
 * 所以 QQ音乐的歌发不出卡片。
 *
 * 曾试过把 QQ音乐的歌映射到网易云同一首再用 163 卡片发出去，但网易云对主流版权曲
 * （周杰伦《晴天/稻香/夜曲》…）只暴露翻唱，按歌名+歌手匹配会稳定落到同名翻唱上，
 * 点开是别人的版本 —— 那比没卡片更糟。所以这条映射整体放弃：
 * **宁可发准确的文本链接，也不发一张指向错误版本的卡片。**
 */
// ──────────────────────────── 歌词 ────────────────────────────
//
// 接口和兜底顺序取自 DSH skill `qq-agent-music` 的 scripts/music-search.js
// （references/search-and-lyrics.md 有完整说明）。要点：
//   网易云 /api/song/lyric（lv=1）返回带时间轴的 LRC；
//   QQ音乐 fcg_query_lyric_new.fcg 返回 **base64 的 LRC**，要解码。
//   逐级兜底：链接里能解析出平台 id 就直接用 → 否则按"歌名 歌手"搜网易云 → 再搜 QQ音乐。

/** 去掉 LRC 时间轴和重复行，得到纯文本歌词。 */
function stripLrc(lrc) {
  const seen = new Set();
  const out = [];
  for (const raw of String(lrc ?? '').split(/\r?\n/)) {
    const line = raw.replace(/\[[^\]]*\]\s*/g, '').trim();
    if (!line || seen.has(line)) continue;
    seen.add(line);
    out.push(line);
  }
  return out.join('\n');
}

/** 从歌曲链接里解析平台与 id：网易云 ?id= / QQ 音乐 songDetail/<mid>。 */
function parseSongRef(jumpUrl) {
  const u = String(jumpUrl ?? '');
  const ne = u.match(/music\.163\.com\/(?:#\/)?song\?[^#]*\bid=(\d+)/);
  if (ne) return { platform: 'netease', id: ne[1] };
  const qq = u.match(/y\.qq\.com\/n\/ryqq\/songDetail\/([A-Za-z0-9]+)/);
  if (qq) return { platform: 'qq', mid: qq[1] };
  return null;
}

async function fetchNeteaseLyrics(id) {
  const data = await getJson(`https://music.163.com/api/song/lyric?id=${encodeURIComponent(id)}&lv=1&kv=1&tv=-1`, {
    referer: 'https://music.163.com/'
  });
  const text = String(data?.lrc?.lyric ?? '');
  if (!text.trim()) throw new Error('接口没有返回歌词（可能是纯音乐/无版权）');
  return stripLrc(text);
}

async function fetchQQLyrics(mid) {
  const data = await getJson(
    `https://c.y.qq.com/lyric/fcgi-bin/fcg_query_lyric_new.fcg?songmid=${encodeURIComponent(mid)}&format=json`,
    { referer: 'https://y.qq.com/' }
  );
  const b64 = String(data?.lyric ?? '');
  if (!b64) throw new Error('接口没有返回歌词（可能是纯音乐/版权受限）');
  const text = stripLrc(Buffer.from(b64, 'base64').toString('utf8'));
  if (!text.trim()) throw new Error('歌词解码为空');
  return text;
}

/**
 * 取一首歌的歌词。
 * @param {{name?:string, artist?:string, url?:string}} ref
 * @returns {Promise<{platform:string, lyrics:string, title?:string}>}
 */
async function getLyrics({ name = '', artist = '', url = '' } = {}) {
  const attempts = [];
  const parsed = parseSongRef(url);
  if (parsed?.platform === 'netease') {
    attempts.push(async () => ({ platform: 'netease', lyrics: await fetchNeteaseLyrics(parsed.id) }));
  } else if (parsed?.platform === 'qq') {
    attempts.push(async () => ({ platform: 'qq', lyrics: await fetchQQLyrics(parsed.mid) }));
  }

  const kw = [name, artist].filter(Boolean).join(' ').trim();
  if (kw) {
    // 按名搜时走 searchMusic（原唱判定 + 平台偏好），而不是直接打搜索接口 ——
    // 否则「晴天 周杰伦」会落到翻唱版上，歌词与卡片指向的不是同一首歌。
    attempts.push(async () => {
      const { results } = await searchMusic(kw, 1);
      const hit = results[0];
      if (!hit) throw new Error('搜不到这首歌');
      if (hit.platform === 'netease') {
        return { platform: 'netease', lyrics: await fetchNeteaseLyrics(hit.id) };
      }
      return { platform: 'qq', lyrics: await fetchQQLyrics(hit.id) };
    });
  }
  if (!attempts.length) throw new Error('既没有可用链接也没有歌名，查不了歌词');

  const errors = [];
  for (const attempt of attempts) {
    try {
      const r = await attempt();
      if (r.lyrics) return r;
    } catch (error) {
      errors.push(String(error?.message ?? error));
    }
  }
  throw new Error(errors.join('；'));
}

function buildCard(song) {
  if (!song?.name) return null;
  const title = song.name;
  const artist = (song.artists || []).join(' / ');
  const desc = [artist, song.album].filter(Boolean).join(' · ');
  const text = `${title}${artist ? ` - ${artist}` : ''}${song.url ? `\n${song.url}` : ''}`;

  // 卡片只在"确实是网易云的歌"时给。网易云自己的 songId 就是卡片要的那个 id，无需映射。
  const usable = song.platform === 'netease' && song.id && song.kind === 'origin';
  if (!usable) {
    return { music: null, text, reason: song.platform === 'qq' ? 'QQ音乐的歌发不了卡片（签名服务已关闭 qq 解析）' : '不是可发卡片的原唱' };
  }

  return {
    music: {
      type: '163',
      id: String(song.id),
      title,
      content: desc,
      url: song.url,
      image: String(song.cover || '')
    },
    text
  };
}

function fallbackResults(query) {
  const base = { artists: [], album: '', durationSec: '', cover: '', kind: 'origin', popularity: 0 };
  return [
    { ...base, platform: 'netease', name: query, url: neteaseSearchUrl(query), searchUrl: neteaseSearchUrl(query) },
    { ...base, platform: 'qq', name: query, url: qqSearchUrl(query), searchUrl: qqSearchUrl(query) }
  ];
}


export { searchMusic, getLyrics, buildCard, fallbackResults, cleanQuery };
