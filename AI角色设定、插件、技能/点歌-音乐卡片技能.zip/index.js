// 点歌技能（0.3.1 版）——把 0.3.0 里那套音乐能力搬过来。
//
// 移植方式：算法层（music-core.mjs）是 0.3.0 那份的**原样复用**，这里只做包装：
//   music_search  → searchMusic + buildCard
//   music_send    → 两步发送 + 回读校验 + 重试 + 退化发文本
//   music_lyrics  → getLyrics
//
// 0.3.1 的接口和 0.3.0 不同，包装层是重写的：
//   · 工具用 setup(api).registerTool 注册（0.3.0 是改 tools.js 数组）
//   · 发消息用 ctx.sender / ctx.onebot（0.3.0 是我们自己加的 sendMusicCard）
//   · 没有全局 fetch 依赖问题（Node 20+ 自带）
//
// ── music_send 的两步发送（重要，别改回一步）────────────────────────────
// 第一步：把要说的话（say）用 sendTextBatch 单独发一条，replyToMessageId / atUserId
//         挂在这条文字上。
// 第二步：卡片自己单独发，**不带 reply 段**。
// 原因：reply 段和 music 段同处一条消息时，QQ 客户端优先渲染引用框、把卡片丢掉 ——
//       群友只看到"回复了某人"，卡片不见了。这就是原先"卡片被吞"的根因。
//       另：卡片也必须走 ctx.sender.sendMedia（而不是直接 onebot.sendSegments），
//       否则会跳过发送队列的限频 / 去重 / 留档。

import { searchMusic, getLyrics, buildCard } from './music-core.mjs';
// 直接读机器人配置：去重窗口要跟 sender 的判定口径一致，不能写死或读不存在的 ctx 字段。
// 失败时回退 8000，与 config.js 的 DEFAULT_CONFIG.send.dedupeWindowMs 保持一致。
async function dedupeWindowMs() {
  try {
    const { getConfig } = await import('../../src/config.js');
    const raw = getConfig()?.send?.dedupeWindowMs;
    const n = Number(raw);
    return Number.isFinite(n) && n > 0 ? n : 8000;
  } catch {
    return 8000;
  }
}

const CARD_ATTEMPTS = 2;           // 连首次在内最多发几次
const CARD_VERIFY_DELAY_MS = 1500; // 发完等多久回读
const CARD_GAP_MS = 900;           // 「先文字、再卡片」两步之间的间隔（别同一毫秒两条）

let apiRef = null;
const log = (...a) => (apiRef?.log ? apiRef.log(...a) : console.log('[music]', ...a));

/** 回读一条自己刚发的消息，判断音乐卡片渲染成功没有。 */
async function cardVerdict(ctx, messageId) {
  try {
    const msg = await ctx.onebot.call('get_msg', { message_id: Number(messageId) });
    const segs = Array.isArray(msg?.message) ? msg.message : [];
    const jsonSeg = segs.find((s) => s?.type === 'json');
    const payload = String(jsonSeg?.data?.data ?? '');
    if (jsonSeg && payload.includes('com.tencent.music.lua')) return 'ok';
    const text = segs.map((s) => String(s?.data?.text ?? '')).join(' ');
    if (text.includes('版本过低')) return 'failed';
    if (jsonSeg) return 'ok';
    return 'unknown';
  } catch {
    return 'unknown';   // 回读失败不误判成坏，否则白重试
  }
}

/**
 * 发一条 music 消息段。
 *
 * ── 为什么只传 type + id ──────────────────────────────────────────────
 * SnowLuma 的 segmentToElement（index.mjs music 分支）判断顺序是：
 *   usesCustomMusicData = (type === 'custom') || (!id && 有 url/audio/title/image/content)
 * 我们传的 type 恒为 '163' 且一定带 id，所以**永远走签名服务**，不会进本地卡片分支。
 * 签名服务（ss.xingzhige.com/music_card/card）实测正常：POST {type,id} →
 * 返回 app="com.tencent.music.lua" 的完整卡片。
 * 只有在签名服务失败时，SnowLuma 才退到 com.tencent.structmsg 本地卡片，而那张
 * QQ 渲染不出来（回"发送者版本过低"）—— 此时由下面回读校验识别，改发文本链接。
 *
 * ── 走 ctx.sender.sendMedia 而不是直接 onebot.sendSegments ────────────
 * 直接发会绕过发送队列的限频/去重/留档（sender.js 顶部明令禁止）。留档尤其重要：
 * 不留档的话，下一次运行不知道自己发过卡片，可能重复发。
 */
async function sendMusicSegment(ctx, music, options = {}) {
  const segs = [{ type: 'music', data: { type: String(music.type || '163'), id: String(music.id) } }];

  let last = null;
  let lastError = null;
  // 去重键按 dedupeWindowMs 分桶：同一个窗口内重复发同一首才挡掉（防模型重复调用），
  // 过了窗口就能再点同一首歌 —— 曲库就这么大，真人会反复点同一首。
  // 不分桶的话 sender 的窗口是"按时间判过期、按 500 条才清理"，同一首歌会被挡很久。
  const bucketMs = Math.max(1000, await dedupeWindowMs());
  const bucket = Math.floor(Date.now() / bucketMs);
  for (let attempt = 1; attempt <= CARD_ATTEMPTS; attempt++) {
    try {
      last = await ctx.sender.sendMedia(ctx.chatKey, segs, {
        label: `[音乐卡片:${music.title || music.id}]`,
        dedupeKey: `music:${music.type || '163'}:${music.id}:${bucket}`,
        replyToMessageId: options.replyToMessageId ?? null,
        atUserId: options.atUserId ?? null
      });
    } catch (error) {
      lastError = String(error?.message ?? error);
      // ── 区分"被去重跳过"和"真的没发出去" ──────────────────────────
      // 去重命中说明**同一张卡片刚刚已经发出去了**（sender 只在发送成功后才记入去重窗口），
      // 卡片就在群里。此时若走 cardFailed 分支会再补一条文字链接，群友会看到
      // "卡片 + 多余链接"。所以这里按成功返回，只是告诉模型别重复发。
      if (/刚刚发过|已跳过/.test(lastError)) {
        return { sent: true, cardOk: true, deduped: true, messageId: null };
      }
      // 其余（限频 / 传输失败）重试没有意义，交给调用方决定
      return { sent: false, cardOk: false, error: lastError };
    }
    const mid = last?.message_id;
    // 拿不到 message_id 就没法回读校验，只能当作发出去了
    if (mid === undefined || mid === null) return { sent: true, cardOk: false, messageId: null };
    await new Promise((r) => setTimeout(r, CARD_VERIFY_DELAY_MS));
    const verdict = await cardVerdict(ctx, mid);
    if (verdict !== 'failed') return { sent: true, cardOk: true, messageId: mid };
    if (attempt < CARD_ATTEMPTS) log(`音乐卡片渲染失败（发送者版本过低），重试第 ${attempt + 1} 次`);
  }
  // 消息确实发出去了，只是 QQ 渲染不出卡片 —— 不算"没发出去"，交给调用方补文本
  return { sent: true, cardOk: false, messageId: last?.message_id ?? null };
}

export function setup(api) {
  apiRef = api;

  // ── 搜歌 ──
  api.registerTool({
    id: 'music_search',
    name: '搜歌',
    description:
      '点歌第一步：按歌名（可带歌手）搜网易云 / QQ 音乐，返回最匹配的那首。' +
      '拿到结果后必须再调 music_send 把卡片发出去，不要自己拼链接。' +
      '只给歌名容易搜到同名的冷门版本，群友说了歌手就一起填。',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '歌名，可带歌手，例如「晴天」或「周杰伦 晴天」' },
        limit: { type: 'number', description: '最多返回几条候选，默认 3，最大 10' }
      },
      required: ['query']
    },
    async execute(ctx, args) {
      try {
        const query = String(args?.query ?? '').trim();
        if (!query) return { content: '错误：query（歌名）不能为空', isError: true };
        const limit = Math.min(10, Math.max(1, Math.round(Number(args?.limit) || 3)));

        const { results, notice } = await searchMusic(query, limit);
        if (!results.length) {
          return { content: JSON.stringify({ query, found: false, note: '两个平台都没搜到，让群友换个说法（带上歌手名）再试。' }) };
        }
        return {
          content: JSON.stringify(
            {
              query,
              found: true,
              notice: notice || undefined,
              results: results.map((r) => {
                const card = buildCard(r);
                return {
                  platform: r.platform === 'qq' ? 'QQ音乐' : '网易云',
                  name: r.name,
                  artists: r.artists,
                  album: r.album || undefined,
                  duration: r.durationSec || undefined,
                  kind: r.kind === 'cover' ? '翻唱/改编' : undefined,
                  card: card?.music ? card : null,
                  text: card?.text || r.url
                };
              })
            },
            null,
            1
          )
        };
      } catch (error) {
        return { content: `错误：点歌失败（${error?.message ?? error}）`, isError: true };
      }
    }
  });

  // ── 发卡片 ──
  api.registerTool({
    id: 'music_send',
    name: '发音乐卡片',
    description:
      '点歌第二步：把 music_search 拿到的 card 发到当前聊天，群友会看到一个能点开的音乐卡片。' +
      'card 原样传进来，不要改字段。' +
      '被艾特点歌、或你想带引用/@ 时，**先**把要说的话放进 say（它会作为独立一条文字消息发在卡片前面，' +
      '引用挂在这条文字上），卡片随后单独发出——卡片本身不能带引用，带了会被 QQ 吞掉。' +
      '卡片发不出去时会自动改发文本链接。',
    parameters: {
      type: 'object',
      properties: {
        card: { type: 'object', description: 'music_search 返回的 results[0].card，原样传进来' },
        say: { type: 'string', description: '可选：先单独发一条文字，会作为独立一条消息发在卡片之前。只要你打算带引用（replyToMessageId）或 @，就**必须**填这里——引用/@ 只能挂在这条文字上，卡片自己不能带引用，否则卡片会被 QQ 吞掉。' },
        replyToMessageId: { type: ['integer', 'string'], description: '可选：要引用的消息 id（聊天记录里的 #数字）。只在 say 非空时生效。' },
        atUserId: { type: ['integer', 'string'], description: '可选：要 @ 的 QQ 号。只在 say 非空时生效。' }
      },
      required: ['card']
    },
    async execute(ctx, args) {
      try {
        const card = args?.card;
        if (!card || typeof card !== 'object') {
          return { content: '错误：card 必须是 music_search 返回的 card 对象', isError: true };
        }
        const music = card.music || card;
        if (!music?.id) {
          return { content: '错误：card 缺少 id，请把 music_search 的 results[].card 原样传进来', isError: true };
        }

        // ── 第一步：文字引用回复 ──────────────────────────────────────
        //
        // 为什么必须和卡片分成两条消息（硬性约束，不是风格偏好）：
        // 引用段（reply）与 music 段同处一条消息时，QQ 客户端会优先渲染引用框、
        // 把卡片丢掉 —— 群友只看到"回复了某人"，卡片不见了。
        // 所以引用/@ 一律挂在**前面的文字**上，卡片自己干干净净单独发。
        // 原先把 reply/at/music 三段拼成一条消息，正是"卡片被吞"的根因。
        const say = String(args?.say ?? '').trim();
        const rid = args?.replyToMessageId ?? null;
        const at = args?.atUserId ?? null;
        let said = false;
        if (say) {
          try {
            await ctx.sender.sendTextBatch(ctx.chatKey, [say], { replyToMessageId: rid, atUserId: at });
            said = true;
            await new Promise((r) => setTimeout(r, CARD_GAP_MS));   // 两步之间留真人式间隔
          } catch (error) {
            log(`先发的文字没发出去（${error?.message ?? error}），继续发卡片`);
          }
        }

        // ── 第二步：发卡片 ────────────────────────────────────────────
        // say 为空（没发文字）时，引用/@ 才退而求其次挂在卡片上；发了文字就绝不重复挂。
        const r = await sendMusicSegment(ctx, music, said ? {} : { replyToMessageId: rid, atUserId: at });

        // 卡片没能渲染 → 补一条文本链接，别让群友干等
        if (!r.cardOk) {
          const text = String(card.text || '').trim();
          let fellBack = false;
          if (text) {
            try {
              await ctx.sender.sendTextBatch(ctx.chatKey, [text], {
                replyToMessageId: said ? null : rid
              });
              fellBack = true;
            } catch { /* 文本也没发出去，走下面的报错 */ }
          }
          const sentAny = said || r.sent;
          return {
            content: JSON.stringify({
              sent: sentAny,
              cardFailed: true,
              note: r.sent
                ? (fellBack
                  ? '卡片发出来了但 QQ 没能渲染，已经改成文本链接补发。不要再补发卡片，也不要解释成"版权问题"——直说卡片发不出来就行。'
                  : '卡片发出来了但 QQ 没能渲染，文本也没补出去。请自己用发送消息把 card.text 发出去。')
                : (fellBack
                  ? '卡片没能发出去，已经改成文本链接发出去了。不要再补发卡片。'
                  : '卡片没能发出去，文本也没发出去。请自己用发送消息把 card.text 发出去。')
            }),
            isError: !sentAny
          };
        }

        if (!r.deduped) {
          ctx.session?.sent?.push({
            type: 'music',
            text: `[音乐卡片:${music.title || music.id}]`,
            at: new Date().toLocaleTimeString('zh-CN', { hour12: false })
          });
        }
        return {
          content: JSON.stringify({
            sent: true,
            said,
            messageId: r.messageId ?? null,
            note: r.deduped
              ? '这张卡片刚刚已经发过了（去重跳过），群里已经有了，不要再发一次。'
              : '卡片已发送。不要输出"已发送"类汇报。'
          })
        };
      } catch (error) {
        return { content: `错误：音乐卡片发送失败（${error?.message ?? error}）`, isError: true };
      }
    }
  });

  // ── 查歌词 ──
  api.registerTool({
    id: 'music_lyrics',
    name: '查歌词',
    description:
      '查一首歌的纯文本歌词（已去掉时间轴）。群友问「XX 的歌词」「这首歌歌词」时用它。' +
      '歌名尽量带歌手，拿到的歌词才和 music_search 选中是同一版。' +
      '歌词几十行，挑最相关的一两段发，不要整首甩出去。',
    parameters: {
      type: 'object',
      properties: {
        name: { type: 'string', description: '歌名' },
        artist: { type: 'string', description: '可选：歌手名，能提高准确度' },
        url: { type: 'string', description: '可选：歌曲页链接（music_search 的 results[].url）' }
      }
    },
    async execute(ctx, args) {
      try {
        const name = String(args?.name ?? '').trim();
        const artist = String(args?.artist ?? '').trim();
        const url = String(args?.url ?? '').trim();
        if (!name && !url) return { content: '错误：至少给 name（歌名）或 url（歌曲链接）', isError: true };

        const r = await getLyrics({ name, artist, url });
        return {
          content: JSON.stringify(
            {
              name: name || undefined,
              artist: artist || undefined,
              source: r.platform === 'qq' ? 'QQ音乐' : '网易云',
              lines: String(r.lyrics || '').split('\n').length,
              lyrics: r.lyrics
            },
            null,
            1
          )
        };
      } catch (error) {
        return { content: `错误：没取到歌词（${error?.message ?? error}）`, isError: true };
      }
    }
  });

  log('点歌技能已注册（music_search / music_send / music_lyrics）');
}

export function available() {
  return true;
}
