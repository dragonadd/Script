/**
 * group-memory-sync —— 群聊记忆同步（API v1，确定性型插件）
 *
 * 解决什么：机器人在私聊里不知道群里刚发生了什么，于是总问「你们怎么都不理我」。
 * 这个插件按设定间隔，把每个群最近 N 条消息整理成「近况简报」，发到主人私聊；
 * 机器人此后在私聊里就能看到【群聊近况同步】，不会再张口就说“不知道”。
 *
 * 数据来源：data/messages/group_<群号>.json（宿主自己的消息存档，只读，不改写）。
 * 发送通道：onMessage 钩子里缓存的 ctx.sender（同一个 SendQueue，可发任意会话）。
 * 上次同步到哪条、最近一次简报，都存在插件自己的 storage 里，重启不丢。
 */
import fs from 'node:fs';
import path from 'node:path';
import { getConfig, DATA_DIR } from '../../src/config.js';
import { chatCompletion } from '../../src/llm.js';

let cfg = () => ({});
let log = () => {};
let warn = () => {};
let storage = null;
let sender = null;
let onebot = null;
let timer = null;
let startupTimer = null;
let busy = false;
const nameCache = new Map();

// api.storage 在部分宿主版本里没有（QQ Agent 0.4.0 的 createSkillApi 就没有）。
// 没有它时，lastRunAt / lastSync / latest 全部落不了盘 —— 表现是"每分钟同步一次、
// 每次都把同样的消息再发一遍"。所以这里做三层兜底：
//   1) 宿主给了 api.storage 就用它；
//   2) 没给就用 data 目录下的 JSON 文件（原子写，重启不丢）；
//   3) 内存里再留一份，连文件都写不了时至少不会每分钟重复发。
let memLastRunAt = 0;
const memLastSync = {};
let memLatest = null;

function fallbackStorage() {
  const dir = path.join(DATA_DIR, 'group-memory-sync');
  const file = path.join(dir, 'storage.json');
  let data = {};
  try {
    const parsed = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) data = parsed;
  } catch { data = {}; }
  const flush = () => {
    try {
      fs.mkdirSync(dir, { recursive: true });
      const tmp = `${file}.tmp`;
      fs.writeFileSync(tmp, JSON.stringify(data), 'utf8');
      fs.renameSync(tmp, file);
    } catch { /* 写不了就只留内存 */ }
  };
  return {
    get(key, dflt) { return Object.prototype.hasOwnProperty.call(data, key) ? data[key] : dflt; },
    set(key, value) { data[key] = value; flush(); }
  };
}

const clamp = (n, lo, hi, fallback) => {
  const v = Number(n);
  return Math.min(hi, Math.max(lo, Number.isFinite(v) ? v : fallback));
};

function settings() {
  const s = cfg() || {};
  return {
    enabled: s.enabled !== false,
    intervalMin: clamp(s.intervalMin, 5, 1440, 30),
    messageCount: clamp(s.messageCount, 10, 300, 80),
    groupIds: String(s.groupIds ?? '').split(/[,，\s]+/).map((x) => x.trim()).filter(Boolean),
    targetQQ: String(s.targetQQ ?? '').trim(),
    useLLM: s.useLLM !== false,
    maxChars: clamp(s.maxChars, 200, 2000, 700)
  };
}

function messagesDir() { return path.join(DATA_DIR, 'messages'); }

function listGroupIds() {
  try {
    return fs.readdirSync(messagesDir())
      .filter((f) => /^group_.+\.json$/.test(f))
      .map((f) => f.slice('group_'.length, -'.json'.length))
      .filter(Boolean);
  } catch (error) {
    warn(`读群列表失败：${error?.message ?? error}`);
    return [];
  }
}

function readGroupMessages(gid) {
  const file = path.join(messagesDir(), `group_${gid}.json`);
  const parsed = JSON.parse(fs.readFileSync(file, 'utf8'));
  const arr = Array.isArray(parsed) ? parsed : (Array.isArray(parsed?.messages) ? parsed.messages : []);
  return arr.filter((m) => m && !m.isPoke);
}

function fmtTime(ts) {
  const d = new Date(Number(ts) || 0);
  if (!Number.isFinite(d.getTime())) return '';
  const p = (n) => String(n).padStart(2, '0');
  return `${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

function fmtMessage(m) {
  const who = m.self ? '我' : (String(m.senderName || '').trim() || String(m.senderId || '未知'));
  const text = String(m.text ?? '').replace(/\s+/g, ' ').trim().slice(0, 200);
  return `[${fmtTime(m.ts)}] ${who}：${text}`;
}

function resolveTarget(s) {
  if (s.targetQQ) return s.targetQQ.replace(/[^\d]/g, '');
  try {
    const ids = String(getConfig()?.skills?.['owner-identity']?.ids ?? '')
      .split(/[,，\s]+/).map((x) => x.replace(/[^\d]/g, '')).filter(Boolean);
    return ids[0] || '';
  } catch { return ''; }
}

async function groupName(gid) {
  if (nameCache.has(gid)) return nameCache.get(gid);
  let name = `群 ${gid}`;
  try {
    const info = await onebot?.getGroupInfo?.(gid);
    const n = info?.group_name || info?.data?.group_name;
    if (n) name = String(n);
  } catch { /* 拿不到就用群号 */ }
  nameCache.set(gid, name);
  return name;
}

function lastSyncMap() {
  try {
    const v = storage?.get('lastSync', {});
    const base = (v && typeof v === 'object') ? v : {};
    return { ...base, ...memLastSync };
  } catch { return { ...memLastSync }; }
}
function writeLastSync(v) {
  for (const k of Object.keys(v || {})) memLastSync[k] = v[k];
  try { storage?.set('lastSync', { ...memLastSync }); } catch (e) { warn(`写同步位置失败：${e?.message ?? e}`); }
}
function lastRunAt() {
  let stored = 0;
  try { stored = Number(storage?.get('lastRunAt', 0)) || 0; } catch { stored = 0; }
  return Math.max(stored, memLastRunAt);
}
function setLastRunAt(v) {
  memLastRunAt = Number(v) || Date.now();
  try { storage?.set('lastRunAt', memLastRunAt); } catch { /* 忽略 */ }
}
function latest() {
  try {
    const v = storage?.get('latest', null);
    if (v && typeof v === 'object') return v;
  } catch { /* 忽略 */ }
  return memLatest;
}

async function summarize(name, lines, s, chatKey) {
  const joined = lines.join('\n');
  if (!s.useLLM) return joined.slice(-s.maxChars);
  const conf = getConfig();
  const api = conf?.api || {};
  if (!api.model || !api.baseUrl) return joined.slice(-s.maxChars);
  const messages = [
    { role: 'system', content: '你把群聊整理成给主人的近况简报。中文，客观，只写消息里真实出现的内容，不编造。' },
    {
      role: 'user',
      content: `群「${name}」最近的聊天记录：\n${joined.slice(-12000)}\n\n`
        + '请整理成 3~6 条要点：谁聊了什么、有什么值得记住的、有没有在找主人。'
        + '不要逐条复述，不要加评价。控制在 300 字内。'
    }
  ];
  try {
    const res = await chatCompletion({
      messages, temperature: 0.6, maxTokens: 500,
      skillContext: { api, model: api.model, messages, thinkingMode: 'off', chatKey }
    });
    const text = String(res?.message?.content ?? '').trim();
    return text || joined.slice(-s.maxChars);
  } catch (error) {
    warn(`AI 整理失败，改发原始摘要：${error?.message ?? error}`);
    return joined.slice(-s.maxChars);
  }
}

/**
 * 同步一次。
 * @returns {Promise<{ok:boolean, why?:string, skipped?:boolean, groups?:number, sent?:string}>}
 */
async function syncNow({ reason = 'timer', senderOverride = null } = {}) {
  if (busy) return { ok: false, why: '上一次同步还没结束' };
  busy = true;
  try {
    const s = settings();
    if (!s.enabled) return { ok: false, why: '插件已关闭' };
    const snd = (senderOverride && typeof senderOverride.sendTextBatch === 'function') ? senderOverride : sender;
    if (!snd) return { ok: false, why: '还没有发送通道（等群里或私聊来一条消息后再试）' };
    const targetQQ = resolveTarget(s);
    if (!targetQQ) return { ok: false, why: '找不到主人 QQ：请在插件设置里填 targetQQ' };
    const chatKey = `private:${targetQQ}`;

    const groups = s.groupIds.length ? s.groupIds : listGroupIds();
    const lastMap = lastSyncMap();
    const sections = [];
    const used = [];

    for (const gid of groups) {
      let all = [];
      try { all = readGroupMessages(gid); } catch { continue; }
      if (!all.length) continue;
      const since = Number(lastMap[gid]) || 0;
      let picked = since ? all.filter((m) => Number(m.ts) > since) : all.slice(-s.messageCount);
      if (!picked.length) continue;
      picked = picked.slice(-s.messageCount);
      const lines = picked.map(fmtMessage).filter(Boolean);
      if (!lines.length) continue;
      const name = await groupName(gid);
      const digest = await summarize(name, lines, s, chatKey);
      if (!digest) continue;
      sections.push(`■ ${name}\n${digest}`);
      used.push({ gid, picked });
    }

    if (!sections.length) {
      log(`本轮没有新消息（${reason}）`);
      setLastRunAt(Date.now());
      return { ok: true, skipped: true };
    }

    // 按群分段；超过 maxChars 就拆成多条，避免把后面的群整段截掉
    const header = '【群聊近况同步】';
    const chunks = [];
    let cur = header;
    for (const sec of sections) {
      const candidate = `${cur}\n\n${sec}`;
      if (cur.length > header.length && candidate.length > s.maxChars) {
        chunks.push(cur);
        cur = `${header}\n${sec}`;
      } else {
        cur = candidate;
      }
    }
    chunks.push(cur);
    try {
      await snd.sendTextBatch(chatKey, chunks);
    } catch (error) {
      warn(`发送到私聊失败：${error?.message ?? error}`);
      return { ok: false, why: `发送失败：${error?.message ?? error}` };
    }

    for (const { gid, picked } of used) {
      lastMap[gid] = Math.max(...picked.map((m) => Number(m.ts) || 0));
    }
    writeLastSync(lastMap);
    setLastRunAt(Date.now());
    const body = chunks.join('\n\n');
    const latestEntry = { text: body, at: Date.now(), groups: used.map((u) => u.gid) };
    memLatest = latestEntry;
    try { storage?.set('latest', latestEntry); } catch { /* 忽略 */ }
    log(`已同步 ${used.length} 个群到私聊 ${targetQQ}（${body.length} 字 / ${chunks.length} 条，${reason}）`);
    return { ok: true, sent: body, groups: used.length };
  } finally {
    busy = false;
  }
}

function registerTools(api) {
  api.registerTool({
    id: 'sync_now',
    name: '立刻同步群聊记忆',
    description: '把群聊最近的消息整理后立刻发到主人私聊。主人说「现在同步一下群里」「群里刚才聊什么」时使用。',
    category: 'utility',
    icon: '🔄',
    parameters: { type: 'object', properties: {} },
    async execute(ctx) {
      const r = await syncNow({ reason: 'tool', senderOverride: ctx?.sender });
      if (!r.ok) return { content: `同步失败：${r.why}`, isError: true };
      if (r.skipped) return { content: '这轮没有新消息，不需要同步。' };
      return { content: `已把 ${r.groups} 个群的近况同步到主人私聊。` };
    }
  });

  api.registerTool({
    id: 'group_memory',
    name: '最近的群聊记忆',
    description: '查看最近一次从群聊同步来的近况简报。主人问「群里刚才聊什么」「他们怎么不理我」时先查这个。',
    category: 'utility',
    icon: '🧠',
    parameters: { type: 'object', properties: {} },
    async execute() {
      const l = latest();
      if (!l?.text) return { content: '还没有同步过群聊记忆。可以说「同步一下群聊」让我现在整理。' };
      const when = new Date(Number(l.at) || Date.now()).toLocaleString('zh-CN');
      return { content: `最近一次同步（${when}）：\n${String(l.text).slice(0, 1200)}` };
    }
  });
}

export function setup(api) {
  if (typeof api?.config === 'function') cfg = api.config;
  if (typeof api?.log === 'function') log = api.log;
  if (typeof api?.warn === 'function') warn = api.warn;
  storage = (api?.storage && typeof api.storage.get === 'function') ? api.storage : fallbackStorage();
  registerTools(api);
  const s = settings();
  log(`群聊记忆同步已就绪｜每 ${s.intervalMin} 分钟｜每次 ${s.messageCount} 条｜`
    + `${s.groupIds.length ? `群 ${s.groupIds.join(',')}` : '全部群'}｜AI 整理：${s.useLLM ? '开' : '关'}`);
}

function stopTimers() {
  if (timer) { clearInterval(timer); timer = null; }
  if (startupTimer) { clearTimeout(startupTimer); startupTimer = null; }
}

export function activate() {
  stopTimers();
  timer = setInterval(() => {
    const s = settings();
    if (!s.enabled) return;
    if (Date.now() - lastRunAt() < s.intervalMin * 60000) return;
    syncNow({ reason: 'timer' }).catch((e) => warn(`定时同步异常：${e?.message ?? e}`));
  }, 60000);
  timer.unref?.();
  startupTimer = setTimeout(() => {
    const s = settings();
    if (!s.enabled) return;
    if (Date.now() - lastRunAt() < s.intervalMin * 60000) return;
    syncNow({ reason: 'startup' }).catch((e) => warn(`启动同步异常：${e?.message ?? e}`));
  }, 30000);
  startupTimer.unref?.();
}

export function deactivate() { stopTimers(); }
export function available() { return true; }

/** 排障/自测用：不依赖宿主也能跑一遍同步逻辑。 */
export const internals = { settings, syncNow, fallbackStorage };

export const hooks = {
  async onMessage(ctx = {}) {
    try {
      if (ctx.sender?.sendTextBatch) sender = ctx.sender;
      if (ctx.onebot) onebot = ctx.onebot;
    } catch (error) {
      warn(`onMessage 失败：${error?.message ?? error}`);
    }
  },

  async 'before-llm-messages'(ctx = {}) {
    try {
      const s = settings();
      if (!s.enabled) return;
      const targetQQ = resolveTarget(s);
      if (!targetQQ || String(ctx.chatKey || '') !== `private:${targetQQ}`) return;
      const l = latest();
      if (!l?.text) return;
      if (Date.now() - Number(l.at || 0) > 24 * 3600 * 1000) return;
      const messages = Array.isArray(ctx.messages) ? ctx.messages : [];
      const lastUser = [...messages].reverse().find((m) => m?.role === 'user');
      if (!lastUser) return;
      const userText = typeof lastUser.content === 'string' ? lastUser.content : '';
      if (!/群|他们|怎么不理|在干嘛|聊什么|不理我/.test(userText)) return;
      const line = `（你刚从群聊同步来的近况，别再说你不知道：${String(l.text).slice(0, 500)}）`;
      if (typeof lastUser.content === 'string') lastUser.content += `\n\n${line}`;
      else if (Array.isArray(lastUser.content)) lastUser.content.push({ type: 'text', text: line });
    } catch (error) {
      warn(`群聊记忆注入失败（不影响回话）：${error?.message ?? error}`);
    }
  }
};
