// 她自己的时间（插件版）
//
// 从"改核心 30 行"重构成插件：核心只留一个 requestProactiveWake() 入口，
// 什么时候叫、叫谁、多久叫一次，全在这里判断（纯本地计算，不花 token）。
//
// 判断链（任何一条不满足就不动手）：
//   总开关 → dryRun → 免打扰时段 → 今天次数 → 会话未读 → 静默时长 → 概率 → 起一轮
//
// 为什么放 plugins/ 而不是 skills/：这是**机械调度**，满足条件就该执行；
// 放 skills/ 会变成"模型可选调用的工具"，模型不调用就永远不会发生。
import fs from 'node:fs';
import path from 'node:path';
import { DATA_DIR } from '../../src/config.js';
import { logger } from '../../src/logger.js';

// GUI 版里 console.log 不会落盘，统一走项目 logger
const log = (msg, extra) => (extra === undefined ? logger.info('own-life', msg) : logger.info('own-life', msg, extra));
const warn = (msg) => logger.warn('own-life', msg);

const ID = 'own-life';
const STATE_FILE = path.join(DATA_DIR, 'own-life-plugin.json');

const DEFAULTS = {
  enabled: true,
  dryRun: false,
  targets: '',
  minGapMin: 180,
  maxGapMin: 360,
  idleMin: 180,
  quietStart: 3,
  quietEnd: 8,
  dailyCap: 3,
  probability: 60,
  checkIntervalMin: 10,
  promptSuffix: '【未读信息】（你自己的时间）现在没人找你，也没人在等你回话。\n'
    + '这段时间是你的：可以翻翻之前的聊天、想起点什么、写条日记（diary__write），或者干脆发会儿呆。\n'
    + '想说话就用 send_message 发一句（像突然想起来的那种，不要像播报）；不想说就安静结束，没人会怪你。'
};

// 核心桥接：动态 import + 容错（插件热重载时核心文件可能是旧版）
let bridge = { requestProactiveWake: null, listProactiveChatStates: null };
try {
  const core = await import('../../src/orchestrator.js');
  bridge = {
    requestProactiveWake: typeof core.requestProactiveWake === 'function' ? core.requestProactiveWake : null,
    listProactiveChatStates: typeof core.listProactiveChatStates === 'function' ? core.listProactiveChatStates : null
  };
} catch (error) {
  warn(`核心桥接导入失败（重启后恢复）：${error?.message ?? error}`);
}

const state = { api: null, timer: null, lastLog: '' };

const todayKey = () => new Date().toISOString().slice(0, 10);

function settings() {
  const raw = (() => { try { return state.api?.config?.() || {}; } catch { return {}; } })();
  const s = { ...DEFAULTS, ...raw };
  return {
    ...s,
    enabled: s.enabled !== false,
    dryRun: s.dryRun === true,
    targets: String(s.targets ?? '').split(/[,，\s]+/).map((x) => x.trim()).filter(Boolean),
    minGapMin: Math.max(10, Number(s.minGapMin) || DEFAULTS.minGapMin),
    maxGapMin: Math.max(30, Number(s.maxGapMin) || DEFAULTS.maxGapMin),
    idleMin: Math.max(10, Number(s.idleMin) || DEFAULTS.idleMin),
    quietStart: Math.min(23, Math.max(0, Number(s.quietStart) ?? DEFAULTS.quietStart)),
    quietEnd: Math.min(24, Math.max(0, Number(s.quietEnd) ?? DEFAULTS.quietEnd)),
    dailyCap: Math.max(1, Number(s.dailyCap) || DEFAULTS.dailyCap),
    probability: Math.min(100, Math.max(0, Number(s.probability) ?? DEFAULTS.probability)),
    checkIntervalMin: Math.max(1, Number(s.checkIntervalMin) || DEFAULTS.checkIntervalMin)
  };
}

function loadState() {
  try {
    const data = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    if (data?.day === todayKey()) return data;
  } catch { /* 没有/坏了都当今天没触发 */ }
  return { day: todayKey(), count: 0, lastAt: 0, lastChat: '' };
}

function saveState(data) {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(STATE_FILE, JSON.stringify(data, null, 1), 'utf8');
  } catch (error) {
    warn(`写状态失败：`, error?.message ?? error);
  }
}

function inQuietHours(s, now = new Date()) {
  const hour = now.getHours();
  const from = s.quietStart;
  const to = s.quietEnd;
  if (from === to) return false;
  return from < to ? (hour >= from && hour < to) : (hour >= from || hour < to);
}

/** 一次检查：挑一个会话，值得叫就叫醒她。 */
function tick() {
  const s = settings();
  if (!s.enabled) return;
  if (!bridge.requestProactiveWake || !bridge.listProactiveChatStates) {
    if (state.lastLog !== 'no-bridge') {
      log(`核心还没提供 requestProactiveWake（重启 QQ Agent 后生效）`);
      state.lastLog = 'no-bridge';
    }
    return;
  }
  if (inQuietHours(s)) return;

  const data = loadState();
  if (data.count >= s.dailyCap) return;

  const now = Date.now();
  const gapSinceLast = now - (Number(data.lastAt) || 0);
  if (gapSinceLast < s.minGapMin * 60000) return;

  const chats = bridge.listProactiveChatStates().filter((c) => c.kind === 'private');
  const allowed = chats.filter((c) => {
    if (s.targets.length && !s.targets.includes(String(c.chatKey).split(':')[1])) return false;
    if (Number(c.unread) > 0) return false;            // 人家刚说话，别插嘴
    if (c.running) return false;
    const idleMs = now - (Number(c.lastTs) || 0);
    return idleMs >= s.idleMin * 60000;
  });
  if (!allowed.length) return;

  // 越久没主动过，越容易被挑中：按 gap 长度加权
  const weights = allowed.map((c) => Math.max(1, now - (Number(data.lastAt) || 0) - s.minGapMin * 60000));
  const total = weights.reduce((a, b) => a + b, 0);
  let roll = Math.random() * total;
  let pick = allowed[allowed.length - 1];
  for (let i = 0; i < allowed.length; i += 1) {
    roll -= weights[i];
    if (roll <= 0) { pick = allowed[i]; break; }
  }

  if (Math.random() * 100 > s.probability) {
    log(`轮到 ${pick.chatKey}，但概率没中（${s.probability}%）`);
    return;
  }

  if (s.dryRun) {
    log(`[dryRun] 本会叫醒 ${pick.chatKey}（静默 ${Math.round((now - pick.lastTs) / 60000)} 分钟）`);
    return;
  }

  const r = bridge.requestProactiveWake(pick.chatKey, { promptSuffix: s.promptSuffix, reason: 'own-life' });
  if (r?.ok) {
    data.count += 1;
    data.lastAt = now;
    data.lastChat = pick.chatKey;
    saveState(data);
    log(`叫醒 ${pick.chatKey}（今天第 ${data.count}/${s.dailyCap} 次，静默 ${Math.round((now - pick.lastTs) / 60000)} 分钟）`);
  } else {
    warn(`唤起失败：${r?.error ?? '未知'}`);
  }
}

export function setup(api) {
  state.api = api;
  const s = settings();
  if (!s.enabled) {
    log('未启用（enabled=false）');
    return;
  }
  if (!bridge.requestProactiveWake) {
    warn('核心缺少 requestProactiveWake 导出 —— 重启 QQ Agent 后本插件才会真正工作');
  }
  clearInterval(state.timer);
  // 启动后先等 60 秒（别和启动流程抢资源），之后每 checkIntervalMin 分钟看一次
  state.timer = setInterval(tick, Math.max(1, s.checkIntervalMin) * 60000);
  state.timer.unref?.();
  log(`已启动：每 ${s.checkIntervalMin} 分钟检查一次，静默 ${s.idleMin} 分钟起、每天最多 ${s.dailyCap} 次、${s.quietStart}:00-${s.quietEnd}:00 不打扰`);
}

export function deactivate() {
  clearInterval(state.timer);
  state.timer = null;
}
