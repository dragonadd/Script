# 主动外交与 QQ 关系网

这是一个基于 QQ Agent 插件 API v1 的扩展。它把人物、群组、关系边和好友申请都绑定到**纯数字 QQ 号**，再让模型从公开群话题中提出外交候选。

## 默认行为

- 插件默认关闭。
- 默认只观察公开群互动、记录主题、列出候选和起草申请。
- 陌生人申请必须由本体私聊批准。
- 群友要满足观察期、分散互动、主题匹配、风险、冷却和额度门；默认仍需本体批准。
- `draft` 不会发送；`approve` 不等于发送；`send` 的成功只代表协议端适配器确认接收，不代表对方同意。
- 关系网和审计文件写在 `data/active-diplomacy/`，聊天原文不会写入关系网；主题和证据只保存短摘要或哈希。

## 重要限制：主动加好友接口

当前 QQ Agent/SnowLuma 文档只验证了 `set_friend_add_request`（处理**收到**的好友申请），没有验证统一的“主动发起好友申请”接口。因此本扩展没有把任何接口冒充成主动加好友：

1. 先在协议端确认真实动作名和参数。
2. 在设置里配置允许的适配器动作和参数模板。
3. 关闭演练模式并打开“允许交给好友申请适配器”。
4. 由本体批准后调用 `active-diplomacy__send`。

未配置适配器、接口返回错误或状态不明时，扩展会失败关闭并保留审计记录。

## 安装

把整个 `active-diplomacy/` 目录复制到 QQ Agent 的：

```text
<QQ Agent 安装目录>\resources\app\plugins\active-diplomacy\
```

插件目录需要与宿主的 `src/config.js`、`src` 目录处在同一个 `resources/app` 树下。QQ Agent 默认支持热重载，也可以重启后从“插件”页启用。

## 推荐启用顺序

1. 先只打开总开关，保持演练模式。
2. 在公开群里让模型记录真实主题，使用 `active-diplomacy__candidates` 查看门槛是否满足。
3. 在本体私聊查看 `active-diplomacy__graph`、`policy` 和 `candidates`。
4. 先手动批准一条申请，确认适配器参数只会调用协议端的主动申请动作。
5. 最后才考虑关闭演练模式；陌生人自动发送永远不开放。

## 工具

- `record_interaction`：记录公开群 QQ、主题和互动事实。
- `candidates`：列出候选与未通过原因。
- `draft`：创建申请草稿。
- `approve` / `deny`：本体私聊审批。
- `send`：调用显式配置的好友申请适配器。
- `refresh_contacts`：从好友列表事实确认 contact/friend 状态。
- `relation` / `graph` / `policy`：查看关系卡、图摘要和策略。
- `block`：本地阻断目标，取消未发送申请。

## 与现有插件的关系

它可以和 `private-group`、`privacy-gate`、`blacklist-gate`、`cross-chat-link`、`cross-memory`、`favor/bond` 一起使用，但本插件的关系图和发送门独立维护。隐私和黑名单能力缺失时，本插件按更严格策略工作。

项目中的 `notes/` 保存了 API 审阅、关系网设计和 DSH/DeepSeek 子任务记录。DeepSeek 只收到不含真实 QQ 号的通用设计要求。
