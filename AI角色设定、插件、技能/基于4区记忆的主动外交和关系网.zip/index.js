import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { DATA_DIR } from '../../src/config.js';

const PLUGIN_ID = 'active-diplomacy';
const SCHEMA_VERSION = 1;
const DATA_ROOT = path.join(DATA_DIR, PLUGIN_ID);
const GRAPH_FILE = path.join(DATA_ROOT, 'relations.json');
const AUDIT_FILE = path.join(DATA_ROOT, 'audit.jsonl');
const SALT_FILE = path.join(DATA_ROOT, 'entity-salt');
const QQ_RE = /^[1-9]\d{3,11}$/;
const MAX_TEXT = 180;
const MAX_TOPIC = 64;
const ALLOWED_ACTIONS = new Set([
  'send_friend_add_request',
  'send_friend_request',
  'add_friend',
  'create_friend_request'
]);
const SENSITIVE_RE = /(私聊|私信|秘密|密码|身份证|手机号|电话号码|住址|地址|住哪|钱|转账|银行卡|财务|线下见面|真实姓名|隐私|病史|未成年|裸照|色情)/i;

const DEFAULTS = {
  enabled: false,
  ownerQq: '',
  botQqs: '',
  allowOutboundFriendRequest: false,
  allowAutonomousSend: false,
  autoGroupApproval: false,
  dryRun: true,
  dailyLimit: 3,
  perGroupDailyLimit: 1,
  observationHours: 72,
  minInteractions: 3,
  minTopicMatches: 2,
  minScore: 70,
  maxRisk: 20,
  cooldownDays: 30,
  approvalTtlHours: 72,
  auditKeepDays: 180,
  friendRequestAction: '',
  friendRequestParamsTemplate: ''
};

let config = () => ({ ...DEFAULTS });
let log = () => {};
let warn = () => {};
let db = null;
let dbReadOnly = false;
let flushTimer = null;
let dirty = false;
let auditSincePrune = 0;
let entitySalt = null;

const now = () => Date.now();
const clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, Number.isFinite(Number(n)) ? Number(n) : lo));
const text = (v, max = 400) => String(v ?? '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim().slice(0, max);
const shortText = (v, max = MAX_TEXT) => text(v, max).replace(/\s+/g, ' ');
const normQq = (v) => {
  const s = String(v ?? '').replace(/\D/g, '');
  return QQ_RE.test(s) ? s : '';
};
const listQq = (v) => String(v ?? '').split(/[^0-9]+/).map(normQq).filter(Boolean).filter((x, i, a) => a.indexOf(x) === i);
const chatKeyOf = (ctx = {}) => String(ctx.chatKey || (ctx.kind && ctx.chatId ? `${ctx.kind}:${ctx.chatId}` : '')).trim();
const groupIdOf = (ctx = {}) => String(ctx.kind === 'group' ? ctx.chatId || '' : '').replace(/\D/g, '');
const maskQq = (qq) => {
  const s = normQq(qq);
  return s ? `${s.slice(0, 2)}****${s.slice(-2)}` : '未知QQ';
};
const hashText = (v) => crypto.createHash('sha256').update(String(v ?? ''), 'utf8').digest('hex').slice(0, 16);

function safeParse(raw, fallback) {
  try {
    const value = JSON.parse(raw);
    return value && typeof value === 'object' ? value : fallback;
  } catch {
    return fallback;
  }
}

function ensureDir() {
  fs.mkdirSync(DATA_ROOT, { recursive: true });
}

function readJson(file, fallback) {
  try { return safeParse(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, ''), fallback); } catch { return fallback; }
}

function atomicWrite(file, value) {
  if (dbReadOnly) return false;
  try {
    ensureDir();
    const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(value, null, 2), 'utf8');
    try { fs.renameSync(tmp, file); } catch {
      try { fs.rmSync(file, { force: true }); } catch { /* best effort */ }
      fs.renameSync(tmp, file);
    }
    return true;
  } catch (error) {
    warn(`关系网写入失败：${error?.message ?? error}`);
    return false;
  }
}

function atomicWriteText(file, value) {
  if (dbReadOnly) return false;
  try {
    ensureDir();
    const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
    fs.writeFileSync(tmp, String(value ?? ''), 'utf8');
    try { fs.renameSync(tmp, file); } catch {
      try { fs.rmSync(file, { force: true }); } catch { /* best effort */ }
      fs.renameSync(tmp, file);
    }
    return true;
  } catch (error) {
    warn(`关系网文本写入失败：${error?.message ?? error}`);
    return false;
  }
}

function freshDb() {
  return {
    schemaVersion: SCHEMA_VERSION,
    persons: {},
    groups: {},
    relations: {},
    requests: {},
    counters: { nextRequest: 1, observed: 0, drafted: 0, approved: 0, sent: 0, accepted: 0, declined: 0 },
    updatedAt: now()
  };
}

function ensureSalt() {
  if (entitySalt) return entitySalt;
  try {
    ensureDir();
    if (fs.existsSync(SALT_FILE)) {
      const raw = fs.readFileSync(SALT_FILE);
      if (raw.length >= 16) return (entitySalt = raw);
    }
    if (dbReadOnly) return (entitySalt = Buffer.from('active-diplomacy-read-only-salt'));
    entitySalt = crypto.randomBytes(32);
    fs.writeFileSync(SALT_FILE, entitySalt, { flag: 'wx' });
  } catch {
    entitySalt ||= Buffer.from('active-diplomacy-fallback-salt');
  }
  return entitySalt;
}

function entityId(qq) {
  return `u_${crypto.createHmac('sha256', ensureSalt()).update(normQq(qq)).digest('hex').slice(0, 12)}`;
}

function loadDb() {
  if (db) return db;
  const loaded = readJson(GRAPH_FILE, null);
  if (loaded && Number(loaded.schemaVersion) > SCHEMA_VERSION) {
    dbReadOnly = true;
    db = loaded;
    warn(`关系网版本 ${loaded.schemaVersion} 高于插件支持版本，已进入只读模式`);
    return db;
  }
  db = loaded && typeof loaded === 'object' ? {
    ...freshDb(),
    ...loaded,
    persons: loaded.persons && typeof loaded.persons === 'object' ? loaded.persons : {},
    groups: loaded.groups && typeof loaded.groups === 'object' ? loaded.groups : {},
    relations: loaded.relations && typeof loaded.relations === 'object' ? loaded.relations : {},
    requests: loaded.requests && typeof loaded.requests === 'object' ? loaded.requests : {},
    counters: { ...freshDb().counters, ...(loaded.counters || {}) }
  } : freshDb();
  ensureSalt();
  return db;
}

function markDirty() {
  dirty = true;
  if (flushTimer) return;
  flushTimer = setTimeout(() => {
    flushTimer = null;
    flushDb();
  }, 250);
  flushTimer.unref?.();
}

function flushDb() {
  if (!dirty || !db || dbReadOnly) return;
  dirty = false;
  db.updatedAt = now();
  atomicWrite(GRAPH_FILE, db);
}

function appendAudit(type, payload = {}) {
  if (dbReadOnly) return;
  try {
    ensureDir();
    const line = JSON.stringify({
      at: now(),
      type,
      ...payload
    });
    fs.appendFileSync(AUDIT_FILE, `${line}\n`, 'utf8');
    auditSincePrune += 1;
    if (auditSincePrune >= 50) pruneAudit();
  } catch (error) {
    warn(`审计写入失败：${error?.message ?? error}`);
  }
}

function pruneAudit() {
  auditSincePrune = 0;
  const keepDays = clamp(config().auditKeepDays, 7, 730);
  try {
    const cutoff = now() - keepDays * 86400000;
    const rows = fs.readFileSync(AUDIT_FILE, 'utf8').split(/\r?\n/).filter(Boolean)
      .map((line) => safeParse(line, null)).filter((row) => row && Number(row.at) >= cutoff);
    atomicWriteText(AUDIT_FILE, rows.map((row) => JSON.stringify(row)).join('\n') + (rows.length ? '\n' : ''));
  } catch { /* 审计清理失败不能影响外交流程 */ }
}

function owners() {
  return listQq(config().ownerQq);
}

function bots(ctx = {}) {
  const all = [...listQq(config().botQqs), normQq(ctx.selfId), normQq(ctx.onebot?.selfId)];
  return [...new Set(all.filter(Boolean))];
}

function ownerContext(ctx = {}) {
  const key = chatKeyOf(ctx);
  const id = normQq(ctx.chatId);
  return ctx.kind === 'private' && owners().some((qq) => key === `private:${qq}` || id === qq);
}

function ownerConfigured() { return owners().length > 0; }

function ownerOrAutoContext(ctx, req) {
  if (ownerContext(ctx)) return true;
  const c = config();
  return !!(req?.mode === 'auto_group' && c.allowAutonomousSend === true && c.autoGroupApproval === true);
}

function personTemplate(qq, kind = 'person') {
  const at = now();
  return {
    qq,
    entityId: entityId(qq),
    kind,
    displayNames: [],
    aliases: [],
    status: kind === 'owner' ? 'contact' : kind === 'bot' ? 'contact' : 'unknown',
    sources: [],
    groupIds: [],
    tags: [],
    topicSignals: [],
    trust: kind === 'owner' || kind === 'bot' ? 100 : 0,
    familiarity: kind === 'owner' || kind === 'bot' ? 100 : 0,
    reliability: kind === 'owner' || kind === 'bot' ? 100 : 0,
    privacy: kind === 'owner' || kind === 'bot' ? 'private_allowed' : 'unknown',
    ownerPermission: kind === 'owner' ? 'contact' : kind === 'bot' ? 'observe' : 'none',
    interactions: 0,
    groupInteractions: {},
    lastInteractionAt: 0,
    firstObservedAt: at,
    lastRequestAt: 0,
    lastDecisionAt: 0,
    cooldownUntil: 0,
    riskScore: 0,
    riskFlags: [],
    evidence: [],
    createdAt: at,
    updatedAt: at
  };
}

function ensurePerson(qq, kind = 'person') {
  const id = normQq(qq);
  if (!id) return null;
  loadDb();
  if (!db.persons[id]) {
    db.persons[id] = personTemplate(id, kind);
    db.counters.observed += 1;
    markDirty();
  } else if (kind === 'owner' || kind === 'bot') {
    db.persons[id].kind = kind;
    db.persons[id].status = kind === 'owner' ? 'contact' : db.persons[id].status;
  }
  return db.persons[id];
}

function syncProtectedNodes(ctx = {}) {
  for (const qq of owners()) ensurePerson(qq, 'owner');
  for (const qq of bots(ctx)) {
    if (!owners().includes(qq)) ensurePerson(qq, 'bot');
  }
}

function addName(person, name, source) {
  const value = shortText(name, 80);
  if (!value) return;
  const at = now();
  const existing = person.displayNames.find((x) => x.value === value && x.source === source);
  if (existing) existing.lastSeen = at;
  else person.displayNames.push({ value, source: source || 'unknown', firstSeen: at, lastSeen: at });
  if (!person.aliases.includes(value)) person.aliases.push(value);
  person.displayNames = person.displayNames.slice(-20);
  person.aliases = person.aliases.slice(-20);
}

function addSource(person, source) {
  if (!source?.type) return false;
  const normalized = {
    type: text(source.type, 32),
    chatKey: text(source.chatKey, 80),
    messageId: text(source.messageId, 80),
    at: Number(source.at) || now()
  };
  const key = `${normalized.type}|${normalized.chatKey}|${normalized.messageId}`;
  const exists = person.sources.some((x) => `${x.type}|${x.chatKey}|${x.messageId}` === key);
  if (!exists) person.sources.push(normalized);
  person.sources = person.sources.slice(-50);
  return !exists;
}

function ensureGroup(groupId, name = '') {
  const gid = String(groupId ?? '').replace(/\D/g, '');
  if (!gid) return null;
  loadDb();
  if (!db.groups[gid]) {
    db.groups[gid] = {
      groupId: gid,
      nameHistory: [],
      memberQqs: [],
      sourceConfidence: 0,
      lastScannedAt: 0,
      policy: 'observe',
      createdAt: now(),
      updatedAt: now()
    };
  }
  const group = db.groups[gid];
  const n = shortText(name, 100);
  if (n && !group.nameHistory.some((x) => x.value === n)) group.nameHistory.push({ value: n, at: now() });
  group.nameHistory = group.nameHistory.slice(-20);
  group.updatedAt = now();
  return group;
}

function addGroupMember(group, qq) {
  const id = normQq(qq);
  if (id && !group.memberQqs.includes(id)) group.memberQqs.push(id);
  group.memberQqs = group.memberQqs.slice(-5000);
}

function observePerson({ qq, displayName = '', sourceType = 'incoming', chatKey = '', messageId = '', groupId = '', topic = '', quality = 0, riskFlags = [], countInteraction = true, recordTopic = true, dedupe = false } = {}, ctx = {}) {
  const id = normQq(qq);
  if (!id) return { ok: false, error: 'QQ 号格式不合法' };
  syncProtectedNodes(ctx);
  const kind = owners().includes(id) ? 'owner' : bots(ctx).includes(id) ? 'bot' : 'person';
  const person = ensurePerson(id, kind);
  const at = now();
  addName(person, displayName, chatKey || sourceType);
  const sourceAdded = addSource(person, { type: sourceType, chatKey, messageId, at });
  const isNewEvidence = !dedupe || sourceAdded;
  const gid = String(groupId || '').replace(/\D/g, '');
  if (gid && isNewEvidence) {
    if (!person.groupIds.includes(gid)) person.groupIds.push(gid);
    const group = ensureGroup(gid);
    addGroupMember(group, id);
    group.sourceConfidence = Math.max(Number(group.sourceConfidence) || 0, 0.8);
    const e = person.groupInteractions[gid] || {
      count: 0,
      firstAt: at,
      lastAt: 0,
      topicMatches: 0,
      topics: []
    };
    e.count += 1;
    e.lastAt = at;
    e.firstAt ||= at;
    if (topic) {
      const t = shortText(topic, MAX_TOPIC);
      if (t && !e.topics.includes(t)) e.topics.push(t);
      e.topics = e.topics.slice(-20);
      e.topicMatches += 1;
    }
    person.groupInteractions[gid] = e;
  }
  if (countInteraction && isNewEvidence && (sourceType !== 'manual' || quality > 0)) person.interactions += 1;
  if (countInteraction && isNewEvidence) person.lastInteractionAt = at;
  person.firstObservedAt ||= at;
  if (topic && recordTopic && isNewEvidence) {
    const t = shortText(topic, MAX_TOPIC);
    const existing = person.topicSignals.find((x) => x.topic === t);
    if (existing) { existing.count += 1; existing.lastAt = at; }
    else person.topicSignals.push({ topic: t, count: 1, firstAt: at, lastAt: at });
    person.topicSignals = person.topicSignals.slice(-30);
  }
  if (Number(quality) > 0) person.reliability = clamp((Number(person.reliability) || 0) + clamp(quality, 0, 10), 0, 100);
  for (const flag of Array.isArray(riskFlags) ? riskFlags : []) {
    const f = shortText(flag, 50);
    if (f && !person.riskFlags.includes(f)) person.riskFlags.push(f);
  }
  person.updatedAt = at;
  if (person.status === 'unknown') person.status = kind === 'person' ? 'observed' : person.status;
  markDirty();
  return { ok: true, person };
}

function extractField(entry, keys) {
  for (const key of keys) {
    const value = entry?.[key];
    if (value != null && String(value).trim()) return value;
  }
  return '';
}

function entryQq(entry) {
  return normQq(extractField(entry, ['userId', 'user_id', 'senderId', 'sender_id', 'qq', 'senderQQ'])
    || entry?.sender?.user_id || entry?.sender?.userId || entry?.sender?.qq);
}

function entryName(entry) {
  return shortText(extractField(entry, ['nickname', 'senderName', 'sender_name'])
    || entry?.sender?.nickname || entry?.sender?.card || '', 80);
}

function entryText(entry) {
  return shortText(extractField(entry, ['text', 'content', 'raw_message', 'message']), 500);
}

function entryId(entry) {
  return text(extractField(entry, ['messageId', 'message_id', 'mid', 'id']), 80);
}

function observeTriggerEntries(payload = {}) {
  if (!config().enabled) return;
  const entries = Array.isArray(payload.triggerEntries) ? payload.triggerEntries : [];
  if (!entries.length) return;
  const ctx = payload;
  const chatKey = chatKeyOf(ctx);
  const gid = groupIdOf(ctx);
  let changed = false;
  for (const entry of entries.slice(-30)) {
    const qq = entryQq(entry);
    if (!qq || qq === normQq(ctx.selfId) || owners().includes(qq)) continue;
    const result = observePerson({
      qq,
      displayName: entryName(entry),
      sourceType: gid ? 'group_member' : 'incoming',
      chatKey,
        messageId: entryId(entry) || `h_${hashText(`${chatKey}|${entryText(entry)}`)}`,
        groupId: gid,
        dedupe: true
    }, ctx);
    changed ||= !!result.ok;
    // 只哈希文本，关系网不保存聊天原文；主题由模型通过 record_interaction 标注。
    if (result.ok && entryText(entry)) {
      const p = result.person;
      p.evidence = Array.isArray(p.evidence) ? p.evidence : [];
      const evidenceId = `e_${hashText(`${chatKey}|${entryId(entry) || entryText(entry)}|${entryText(entry)}`)}`;
      if (!p.evidence.some((x) => x.id === evidenceId)) p.evidence.push({ id: evidenceId, type: 'message', summaryHash: hashText(entryText(entry)), at: now(), weight: 0.1 });
      p.evidence = p.evidence.slice(-50);
      changed = true;
    }
  }
  if (gid) {
    const group = ensureGroup(gid, ctx.chatName);
    group.lastScannedAt = now();
    changed = true;
  }
  if (changed) markDirty();
}

function activeRequestsFor(qq) {
  loadDb();
  return Object.values(db.requests).filter((r) => r.targetQq === qq && ['draft', 'awaiting_owner', 'approved'].includes(r.state));
}

function latestSentAt(qq) {
  loadDb();
  return Object.values(db.requests)
    .filter((r) => r.targetQq === qq && ['sent', 'accepted', 'failed'].includes(r.state))
    .reduce((max, r) => Math.max(max, Number(r.sentAt || r.createdAt || 0)), 0);
}

function requestId() {
  loadDb();
  const n = Number(db.counters.nextRequest) || 1;
  db.counters.nextRequest = n + 1;
  return `r-${new Date().toISOString().replace(/[-:TZ.]/g, '').slice(0, 14)}-${String(n).padStart(4, '0')}`;
}

function scorePerson(person, groupId = '') {
  const c = config();
  const gid = String(groupId || '').replace(/\D/g, '');
  const e = gid ? person.groupInteractions?.[gid] : null;
  const topicMatches = e?.topicMatches || person.topicSignals.reduce((sum, x) => sum + Math.min(Number(x.count) || 0, 3), 0);
  const interactions = e?.count || person.interactions || 0;
  const firstAt = e?.firstAt || person.firstObservedAt || now();
  const ageHours = Math.max(0, (now() - firstAt) / 3600000);
  const topic = Math.min(35, topicMatches * 10 + (topicMatches >= Number(c.minTopicMatches || 2) ? 10 : 0));
  const quality = Math.min(20, interactions * 2);
  const familiarity = Math.min(15, ageHours / 24);
  const reliability = Math.min(15, (Number(person.reliability) || 0) / 7);
  const goal = topicMatches > 0 ? 15 : 0;
  return {
    total: Math.round(clamp(topic + quality + familiarity + reliability + goal, 0, 100)),
    topic: Math.round(topic),
    quality: Math.round(quality),
    familiarity: Math.round(familiarity),
    reliability: Math.round(reliability),
    goal: Math.round(goal),
    topicMatches,
    interactions,
    ageHours: Math.round(ageHours * 10) / 10
  };
}

function groupGate(person, groupId = '') {
  const c = config();
  const gid = String(groupId || '').replace(/\D/g, '');
  const e = gid ? person.groupInteractions?.[gid] : null;
  const score = scorePerson(person, gid);
  const reasons = [];
  if (!gid || !e) reasons.push('没有当前群的成员与互动证据');
  if (e && (now() - Number(e.firstAt || now())) < Number(c.observationHours || 72) * 3600000) reasons.push(`观察期不足 ${c.observationHours} 小时`);
  if (score.interactions < Number(c.minInteractions || 3)) reasons.push(`互动次数不足 ${c.minInteractions}`);
  if (score.topicMatches < Number(c.minTopicMatches || 2)) reasons.push(`主题匹配不足 ${c.minTopicMatches}`);
  if (score.total < Number(c.minScore || 70)) reasons.push(`候选分 ${score.total} 低于 ${c.minScore}`);
  if (Number(person.riskScore) > Number(c.maxRisk || 20)) reasons.push(`风险分 ${person.riskScore} 超过 ${c.maxRisk}`);
  if (person.riskFlags?.length) reasons.push(`存在风险标记：${person.riskFlags.slice(0, 3).join('、')}`);
  if (person.cooldownUntil > now()) reasons.push('仍在目标冷却期');
  if (activeRequestsFor(person.qq).length) reasons.push('已有未完成申请');
  return { ok: reasons.length === 0, reasons, score };
}

function requestCounts(groupId = '') {
  loadDb();
  const since = now() - 86400000;
  const sent = Object.values(db.requests).filter((r) => Number(r.sentAt || 0) >= since && ['sent', 'accepted'].includes(r.state));
  const gid = String(groupId || '').replace(/\D/g, '');
  return {
    global: sent.length,
    group: gid ? sent.filter((r) => String(r.source?.chatKey || '') === `group:${gid}`).length : 0
  };
}

function canSendByRate(req) {
  const c = config();
  const counts = requestCounts(req.source?.groupId || (String(req.source?.chatKey || '').match(/^group:(\d+)$/)?.[1] || ''));
  const reasons = [];
  if (counts.global >= Number(c.dailyLimit || 0)) reasons.push(`全局 24 小时额度已用满（${counts.global}/${c.dailyLimit}）`);
  if (req.source?.groupId && counts.group >= Number(c.perGroupDailyLimit || 0)) reasons.push(`本群 24 小时额度已用满（${counts.group}/${c.perGroupDailyLimit}）`);
  return { ok: reasons.length === 0, reasons, counts };
}

function requestSummary(req, full = false) {
  const person = loadDb().persons[req.targetQq];
  const score = person ? scorePerson(person, req.source?.groupId || '') : null;
  return {
    id: req.id,
    target: full ? req.targetQq : maskQq(req.targetQq),
    entityId: person?.entityId || entityId(req.targetQq),
    source: req.source,
    topic: req.topic,
    reason: req.reason,
    mode: req.mode,
    state: req.state,
    riskScore: req.riskScore,
    score,
    createdAt: req.createdAt,
    approvedAt: req.approvedAt || 0,
    sentAt: req.sentAt || 0,
    error: req.error || ''
  };
}

function parseTemplate(template, values) {
  const raw = String(template || '').trim();
  if (!raw) return { user_id: Number(values.qq), comment: values.comment };
  const replaced = raw.replace(/\{\{(qq|comment|sourceGroupId|requestId)\}\}/g, (_, key) => {
    const value = values[key] ?? '';
    return JSON.stringify(String(value)).slice(1, -1);
  });
  const parsed = safeParse(replaced, null);
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('好友申请参数模板不是合法 JSON 对象');
  return parsed;
}

function validAction(action) {
  const a = String(action || '').trim();
  return ALLOWED_ACTIONS.has(a) ? a : '';
}

function protectedTarget(qq, ctx = {}) {
  const id = normQq(qq);
  return !id || owners().includes(id) || bots(ctx).includes(id);
}

function redactPerson(person, full = false) {
  if (!person) return null;
  return {
    qq: full ? person.qq : maskQq(person.qq),
    entityId: person.entityId,
    kind: person.kind,
    status: person.status,
    displayNames: person.displayNames?.slice(-5) || [],
    groupIds: full ? person.groupIds : person.groupIds?.map((x) => `group:${maskQq(x)}`),
    topics: person.topicSignals?.slice(-8) || [],
    trust: person.trust,
    familiarity: person.familiarity,
    reliability: person.reliability,
    interactions: person.interactions,
    riskScore: person.riskScore,
    riskFlags: person.riskFlags,
    lastInteractionAt: person.lastInteractionAt,
    cooldownUntil: person.cooldownUntil,
    score: scorePerson(person, person.groupIds?.[0] || '').total
  };
}

function ownerOnly(ctx) {
  return ownerContext(ctx) ? null : { content: '这个关系网操作只在本体 QQ 的私聊里开放。', isError: true };
}

async function currentGroupHasMember(ctx, qq, groupId) {
  const gid = String(groupId || '').replace(/\D/g, '');
  if (!gid || !ctx?.onebot?.call) return false;
  try {
    const data = await ctx.onebot.call('get_group_member_list', { group_id: Number(gid) }, 8000);
    const members = Array.isArray(data) ? data : Array.isArray(data?.members) ? data.members : [];
    const ids = members.map((m) => normQq(m?.user_id ?? m?.userId)).filter(Boolean);
    if (!ids.includes(normQq(qq))) return false;
    const group = ensureGroup(gid, ctx.chatName);
    group.memberQqs = [...new Set([...group.memberQqs, ...ids])].slice(-5000);
    group.sourceConfidence = 1;
    group.lastScannedAt = now();
    markDirty();
    return true;
  } catch (error) {
    warn(`群成员事实查询失败：${error?.message ?? error}`);
    return false;
  }
}

function registerTool(api, def) {
  api.registerTool?.({ ...def, category: def.category || 'messaging' });
}

function registerTools(api) {
  registerTool(api, {
    id: 'record_interaction',
    name: '记录外交互动',
    icon: '🧭',
    description: '记录公开群里某个 QQ 号参与了什么主题和互动。看到明确的群友话题、@、回复或持续讨论时使用；只记录公开事实摘要，不要填私聊内容或敏感推断。记录本身不会发送好友申请。',
    parameters: {
      type: 'object',
      properties: {
        qq: { type: 'string', description: '发言者的 QQ 号，必须是纯数字。' },
        topic: { type: 'string', description: '公开群里真实出现的主题，例如“万智牌规则”或“插件开发”；不要填私聊或敏感主题。' },
        displayName: { type: 'string', description: '当前消息里的群昵称，可选。' },
        quality: { type: 'number', description: '互动质量 0~10：被回复/被@/持续讨论可给 1~3，不要凭空给高分。' },
        riskFlags: { type: 'array', items: { type: 'string' }, description: '确定存在的风险标记；不确定时留空。' }
      },
      required: ['qq', 'topic']
    },
    async execute(ctx, args) {
      if (!config().enabled) return { content: '主动外交当前关闭，没有记录。', isError: true };
      const qq = normQq(args?.qq);
      const gid = groupIdOf(ctx);
      if (!qq) return { content: 'QQ 号格式不合法。', isError: true };
      if (!gid || ctx.kind !== 'group') return { content: '只接受当前公开群里的互动记录；私聊内容不会写入外交主题。', isError: true };
      if (protectedTarget(qq, ctx)) return { content: '主人和本机机器人不会作为外交候选。', isError: true };
      const topic = shortText(args?.topic, MAX_TOPIC);
      if (!topic || SENSITIVE_RE.test(topic)) return { content: '主题为空或包含不应跨会话传播的敏感内容。', isError: true };
      const verified = await currentGroupHasMember(ctx, qq, gid);
      if (!verified) return { content: '没有从当前群成员接口确认这个 QQ 号，已拒绝记录。', isError: true };
      const result = observePerson({
        qq,
        displayName: args?.displayName,
        sourceType: 'group_member',
        chatKey: chatKeyOf(ctx),
        groupId: gid,
        topic,
        quality: clamp(args?.quality, 0, 10),
        riskFlags: Array.isArray(args?.riskFlags) ? args.riskFlags : []
      }, ctx);
      appendAudit('interaction_observed', { qq, entityId: result.person.entityId, groupId: gid, topicHash: hashText(topic), quality: clamp(args?.quality, 0, 10) });
      return { content: `已记录公开主题“${topic}”与 ${maskQq(qq)} 的群内互动。当前候选分 ${scorePerson(result.person, gid).total}；还不会发申请。` };
    }
  });

  registerTool(api, {
    id: 'candidates',
    name: '查看外交候选',
    icon: '🗺️',
    description: '查看关系网中适合继续观察或起草好友申请的人。主人私聊可见完整 QQ 号；群聊只返回脱敏结果。需要决定是否主动外交、查看申请门槛或解释为什么不能申请时使用。',
    parameters: {
      type: 'object',
      properties: {
        groupId: { type: 'string', description: '可选，限定某个群号；不传则查看全部群友候选。' },
        limit: { type: 'number', description: '返回数量，1~20，默认 10。' },
        includeBlocked: { type: 'boolean', description: '是否包含被阻断的人；默认 false。' }
      },
      required: []
    },
    async execute(ctx, args) {
      if (!config().enabled) return { content: '主动外交当前关闭。', isError: true };
      const full = ownerContext(ctx);
      const gid = String(args?.groupId || groupIdOf(ctx)).replace(/\D/g, '');
      if (args?.groupId && !full && gid !== groupIdOf(ctx)) return { content: '群聊里只能查看当前群的脱敏候选。', isError: true };
      syncProtectedNodes(ctx);
      const list = Object.values(loadDb().persons)
        .filter((p) => p.kind === 'person')
        .filter((p) => !gid || p.groupIds?.includes(gid))
        .filter((p) => args?.includeBlocked || !['blocked', 'hostile', 'declined'].includes(p.status))
        .map((p) => ({ p, gate: gid ? groupGate(p, gid) : { ok: false, reasons: ['需要指定群来判断观察期'], score: scorePerson(p, '') } }))
        .sort((a, b) => b.gate.score.total - a.gate.score.total || b.p.lastInteractionAt - a.p.lastInteractionAt)
        .slice(0, clamp(args?.limit, 1, 20));
      if (!list.length) return { content: '当前没有关系网候选。先在公开群里记录真实互动和主题。' };
      const lines = list.map(({ p, gate }) => {
        const id = full ? p.qq : maskQq(p.qq);
        const topics = (p.topicSignals || []).slice(-3).map((x) => x.topic).join('、') || '暂无主题';
        return `- ${id}（${p.entityId}）｜状态 ${p.status}｜分数 ${gate.score.total}｜互动 ${gate.score.interactions}｜主题 ${gate.score.topicMatches}｜${gate.ok ? '满足群友自动门槛' : gate.reasons.slice(0, 2).join('；')}｜${topics}`;
      });
      return { content: `候选 ${list.length} 人${gid ? `（群 ${gid}）` : ''}：\n${lines.join('\n')}\n\n提示：候选分只用于排序；陌生人不会自动通过，发送申请必须有批准记录。` };
    }
  });

  registerTool(api, {
    id: 'draft',
    name: '起草好友申请',
    icon: '✍️',
    description: '为公开群友或主人指定的陌生 QQ 号创建好友申请草稿。它只落盘，不发送；需要主题、来源、理由和可拒绝的透明文案。看到公开主题确实值得继续交流时使用。',
    parameters: {
      type: 'object',
      properties: {
        qq: { type: 'string', description: '目标 QQ 号。群聊中必须是当前群成员。' },
        topic: { type: 'string', description: '公开话题，例如“万智牌规则”；不要写私聊或敏感推断。' },
        reason: { type: 'string', description: '一句可审计的客观理由，说明为什么这个话题需要继续交流。' },
        message: { type: 'string', description: '透明、短、可拒绝的申请备注，最多 180 字，不冒充真人，不施压。' },
        mode: { type: 'string', enum: ['group_member', 'unknown'], description: '群友或陌生人。当前群里通常使用 group_member；陌生人只能在主人私聊起草。' }
      },
      required: ['qq', 'topic', 'reason', 'message', 'mode']
    },
    async execute(ctx, args) {
      if (!config().enabled) return { content: '主动外交当前关闭。', isError: true };
      const qq = normQq(args?.qq);
      const topic = shortText(args?.topic, MAX_TOPIC);
      const reason = shortText(args?.reason, MAX_TEXT);
      const message = shortText(args?.message, MAX_TEXT);
      const mode = args?.mode === 'unknown' ? 'unknown' : 'group_member';
      if (!qq || protectedTarget(qq, ctx)) return { content: '目标 QQ 号不合法，或目标是主人/本机机器人。', isError: true };
      if (!topic || !reason || !message) return { content: '申请必须包含主题、理由和文案。', isError: true };
      if (SENSITIVE_RE.test(topic) || SENSITIVE_RE.test(reason) || SENSITIVE_RE.test(message)) return { content: '申请内容包含敏感或私域信息，已拒绝起草。', isError: true };
      if (activeRequestsFor(qq).length) return { content: '这个 QQ 已有未完成的申请，不能重复起草。', isError: true };
      const gid = groupIdOf(ctx);
      if (mode === 'group_member') {
        if (!gid || ctx.kind !== 'group') return { content: '群友模式必须在当前群会话中起草。', isError: true };
        if (!(await currentGroupHasMember(ctx, qq, gid))) return { content: '当前群成员接口没有确认目标 QQ，已拒绝起草。', isError: true };
      } else if (!ownerContext(ctx)) {
        return { content: '陌生人模式只允许本体私聊起草。', isError: true };
      }
      const observed = observePerson({
        qq,
        sourceType: mode === 'group_member' ? 'group_member' : 'manual',
        chatKey: chatKeyOf(ctx),
        groupId: mode === 'group_member' ? gid : '',
        topic,
        countInteraction: false,
        recordTopic: false
      }, ctx);
      if (!observed.ok) return { content: observed.error, isError: true };
      const person = observed.person;
      if (person.status === 'blocked' || person.status === 'hostile' || person.riskFlags?.length) return { content: '目标处于阻断或风险状态，不能起草。', isError: true };
      if (person.cooldownUntil > now()) return { content: `目标仍在冷却期，直到 ${new Date(person.cooldownUntil).toLocaleString('zh-CN', { hour12: false })}。`, isError: true };
      const gidForScore = mode === 'group_member' ? gid : '';
      const gate = mode === 'group_member' ? groupGate(person, gidForScore) : { ok: false, reasons: ['陌生人默认必须主人审批'], score: scorePerson(person, '') };
      const auto = mode === 'group_member' && gate.ok && config().autoGroupApproval === true;
      const id = requestId();
      const req = {
        id,
        targetQq: qq,
        source: { type: mode === 'group_member' ? 'group_member' : 'unknown', chatKey: chatKeyOf(ctx), groupId: gidForScore, messageId: text(ctx?.triggerEntries?.at?.(-1)?.messageId || ctx?.triggerEntries?.at?.(-1)?.message_id, 80) },
        topic,
        reason,
        message,
        mode: auto ? 'auto_group' : mode,
        state: auto ? 'approved' : 'awaiting_owner',
        riskScore: Number(person.riskScore) || 0,
        policyVersion: 1,
        createdAt: now(),
        approvedAt: auto ? now() : 0,
        sentAt: 0,
        resultAt: 0,
        error: '',
        score: gate.score
      };
      loadDb().requests[id] = req;
      loadDb().counters.drafted += 1;
      if (auto) loadDb().counters.approved += 1;
      person.status = auto ? 'pending' : 'candidate';
      person.lastDecisionAt = now();
      markDirty();
      appendAudit('request_drafted', { requestId: id, qq, entityId: person.entityId, mode: req.mode, groupId: gidForScore, topicHash: hashText(topic), score: gate.score.total, autoApproved: auto });
      const full = ownerContext(ctx);
      return { content: `已创建申请 ${id}（目标 ${full ? qq : maskQq(qq)}，${auto ? '严格群友门槛通过，已自动批准' : '等待本体私聊批准'}）。候选分 ${gate.score.total}；${gate.ok ? '满足群友门槛' : gate.reasons.join('；')}。下一步只能在本体私聊调用 approve${auto ? ' 或 send' : ''}。` };
    }
  });

  registerTool(api, {
    id: 'approve',
    name: '批准好友申请',
    icon: '✅',
    description: '本体私聊批准一条已起草的好友申请。批准会锁定 QQ、主题、理由、文案和有效期，但不代表已经发送或对方已接受。群友不满足自动门槛时必须提供人工覆盖理由。',
    parameters: {
      type: 'object',
      properties: {
        requestId: { type: 'string', description: '申请编号，例如 r-20261027010101-0001。' },
        overrideReason: { type: 'string', description: '当群友门槛不满足时，主人给出的人工覆盖理由；满足门槛时可留空。' }
      },
      required: ['requestId']
    },
    async execute(ctx, args) {
      const denied = ownerOnly(ctx);
      if (denied) return denied;
      const id = text(args?.requestId, 80);
      const req = loadDb().requests[id];
      if (!req) return { content: '找不到这条申请。', isError: true };
      if (req.state !== 'awaiting_owner') return { content: `这条申请当前状态是 ${req.state}，不能重复批准。`, isError: true };
      if (now() - req.createdAt > Number(config().approvalTtlHours || 72) * 3600000) {
        req.state = 'expired'; req.resultAt = now(); markDirty();
        return { content: '申请草稿已过期，请重新起草。', isError: true };
      }
      const p = loadDb().persons[req.targetQq];
      const gate = req.mode === 'group_member' ? groupGate(p, req.source?.groupId) : { ok: false, reasons: ['陌生人默认需要人工审批'], score: scorePerson(p, '') };
      const override = shortText(args?.overrideReason, MAX_TEXT);
      if (!gate.ok && req.mode === 'group_member' && !override) return { content: `群友自动门槛未满足：${gate.reasons.join('；')}。如确定要人工批准，请填写 overrideReason。`, isError: true };
      req.state = 'approved';
      req.approvedAt = now();
      req.approval = { actor: owners()[0], overrideReason: override || '', at: req.approvedAt };
      if (p) { p.status = 'pending'; p.lastDecisionAt = req.approvedAt; p.ownerPermission = 'request'; p.updatedAt = req.approvedAt; }
      loadDb().counters.approved += 1;
      markDirty();
      appendAudit('request_approved', { requestId: id, qq: req.targetQq, entityId: p?.entityId, override: !!override, overrideHash: hashText(override) });
      return { content: `已批准 ${id}（目标 ${req.targetQq}）。批准只锁定申请，不代表已发送；在确认适配器和文案后再调用 send。` };
    }
  });

  registerTool(api, {
    id: 'deny',
    name: '拒绝好友申请',
    icon: '⛔',
    description: '本体私聊拒绝或取消一条外交申请，并给目标 QQ 设置冷却，防止模型反复起草。',
    parameters: {
      type: 'object',
      properties: {
        requestId: { type: 'string', description: '申请编号。' },
        reason: { type: 'string', description: '可选，拒绝原因；不保存聊天原文。' }
      },
      required: ['requestId']
    },
    async execute(ctx, args) {
      const denied = ownerOnly(ctx);
      if (denied) return denied;
      const req = loadDb().requests[text(args?.requestId, 80)];
      if (!req) return { content: '找不到这条申请。', isError: true };
      if (['sent', 'accepted'].includes(req.state)) return { content: '申请已经交给适配器，不能用拒绝撤回；请在 QQ 侧处理。', isError: true };
      req.state = 'rejected';
      req.resultAt = now();
      req.error = shortText(args?.reason, 120);
      const p = loadDb().persons[req.targetQq];
      if (p) { p.status = 'declined'; p.cooldownUntil = now() + Number(config().cooldownDays || 30) * 86400000; p.lastDecisionAt = now(); p.updatedAt = now(); }
      loadDb().counters.declined += 1;
      markDirty();
      appendAudit('request_denied', { requestId: req.id, qq: req.targetQq, entityId: p?.entityId, reasonHash: hashText(req.error) });
      return { content: `已拒绝 ${req.id}，目标 ${req.targetQq} 进入冷却。` };
    }
  });

  registerTool(api, {
    id: 'send',
    name: '发送好友申请',
    icon: '📨',
    description: '把一条已批准、未过期的申请交给显式配置的好友申请适配器。只在本体私聊使用；严格区分“适配器已确认接收”和“对方已同意”。适配器未配置或演练模式开启时不会发出真实申请。',
    parameters: {
      type: 'object',
      properties: { requestId: { type: 'string', description: '已批准申请编号。' } },
      required: ['requestId']
    },
    async execute(ctx, args) {
      const id = text(args?.requestId, 80);
      const req = loadDb().requests[id];
      if (!req) return { content: '找不到这条申请。', isError: true };
      if (!ownerOrAutoContext(ctx, req)) return { content: '发送好友申请只允许本体私聊；自动群友模式也必须显式打开。', isError: true };
      if (!config().enabled) return { content: '主动外交当前关闭。', isError: true };
      if (req.state !== 'approved') return { content: `申请当前状态是 ${req.state}，只有 approved 才能发送。`, isError: true };
      if (now() - Number(req.approvedAt || req.createdAt) > Number(config().approvalTtlHours || 72) * 3600000) {
        req.state = 'expired'; req.resultAt = now(); markDirty();
        return { content: '批准已过期，请重新起草和批准。', isError: true };
      }
      const p = loadDb().persons[req.targetQq];
      if (!p || p.status === 'blocked' || p.status === 'hostile' || p.riskFlags?.length) return { content: '目标已进入阻断或风险状态，拒绝发送。', isError: true };
      if (p.cooldownUntil > now()) return { content: '目标仍在冷却期，拒绝发送。', isError: true };
      const rate = canSendByRate(req);
      if (!rate.ok) return { content: `额度门拒绝：${rate.reasons.join('；')}`, isError: true };
      const action = validAction(config().friendRequestAction);
      if (!config().allowOutboundFriendRequest || !action) {
        return { content: '好友申请适配器未启用或动作未配置。当前版本不会把 set_friend_add_request 当作主动申请接口，也不会伪造成功。请先确认协议端的真实动作，再在设置里配置。', isError: true };
      }
      if (config().dryRun) {
        const params = parseTemplate(config().friendRequestParamsTemplate, { qq: req.targetQq, comment: req.message, sourceGroupId: req.source?.groupId || '', requestId: req.id });
        appendAudit('request_dry_run', { requestId: req.id, qq: req.targetQq, entityId: p.entityId, action, paramsHash: hashText(JSON.stringify(params)) });
        return { content: `演练模式：本来会调用 ${action}，参数摘要 ${hashText(JSON.stringify(params))}；没有发送真实申请。` };
      }
      let params;
      try { params = parseTemplate(config().friendRequestParamsTemplate, { qq: req.targetQq, comment: req.message, sourceGroupId: req.source?.groupId || '', requestId: req.id }); }
      catch (error) { return { content: `适配器参数模板错误：${error?.message ?? error}`, isError: true }; }
      try {
        const result = await ctx.onebot.call(action, params, 15000);
        req.state = 'sent';
        req.sentAt = now();
        req.resultAt = req.sentAt;
        req.adapter = { action, acknowledged: true, resultHash: hashText(JSON.stringify(result ?? null)) };
        p.status = 'pending';
        p.lastRequestAt = req.sentAt;
        p.cooldownUntil = req.sentAt + Number(config().cooldownDays || 30) * 86400000;
        loadDb().counters.sent += 1;
        markDirty();
        appendAudit('request_sent', { requestId: req.id, qq: req.targetQq, entityId: p.entityId, action, resultHash: req.adapter.resultHash });
        return { content: `适配器已确认接收申请 ${req.id}（目标 ${req.targetQq}）。这只表示协议端接收，不代表对方已经同意或成为好友。` };
      } catch (error) {
        req.state = 'failed';
        req.resultAt = now();
        req.error = shortText(error?.message ?? error, 160);
        p.cooldownUntil = now() + Math.min(86400000, Number(config().cooldownDays || 30) * 86400000);
        markDirty();
        appendAudit('request_failed', { requestId: req.id, qq: req.targetQq, entityId: p.entityId, action, errorHash: hashText(req.error) });
        return { content: `适配器调用失败，未确认申请已发送：${req.error}`, isError: true };
      }
    }
  });

  registerTool(api, {
    id: 'refresh_contacts',
    name: '刷新 QQ 联系人关系',
    icon: '🔄',
    description: '本体私聊调用，读取好友列表并把已确认的 QQ 节点标成 contact/friend。申请送达不等于接受；只有好友列表事实或主人明确确认才会写 accepted。',
    parameters: { type: 'object', properties: {}, required: [] },
    async execute(ctx) {
      const denied = ownerOnly(ctx);
      if (denied) return denied;
      if (!ctx.onebot?.call) return { content: '当前会话没有 OneBot 通道。', isError: true };
      try {
        const data = await ctx.onebot.call('get_friend_list', {}, 10000);
        const friends = Array.isArray(data) ? data : Array.isArray(data?.friends) ? data.friends : [];
        let changed = 0;
        for (const f of friends) {
          const qq = normQq(f?.user_id ?? f?.userId);
          if (!qq || protectedTarget(qq, ctx)) continue;
          const p = ensurePerson(qq, 'person');
          addName(p, f?.remark || f?.nickname, 'friend_list');
          p.status = 'contact';
          p.ownerPermission = 'contact';
          p.trust = Math.max(Number(p.trust) || 0, 35);
          p.updatedAt = now();
          const edge = `${owners()[0] || normQq(ctx.selfId)}|${qq}|friend`;
          loadDb().relations[edge] = { id: edge, from: owners()[0] || normQq(ctx.selfId), to: qq, type: 'friend', status: 'confirmed', confidence: 1, visibility: 'owner_only', updatedAt: now(), createdAt: loadDb().relations[edge]?.createdAt || now() };
          for (const req of Object.values(loadDb().requests)) {
            if (req.targetQq === qq && req.state === 'sent') { req.state = 'accepted'; req.resultAt = now(); loadDb().counters.accepted += 1; }
          }
          changed += 1;
        }
        markDirty();
        appendAudit('contacts_refreshed', { count: changed });
        return { content: `已刷新好友列表，确认 ${changed} 个 QQ 联系节点。好友列表事实才会标记 accepted；不在列表里的申请仍只是待回应。` };
      } catch (error) {
        return { content: `读取好友列表失败：${error?.message ?? error}`, isError: true };
      }
    }
  });

  registerTool(api, {
    id: 'relation',
    name: '查询关系卡',
    icon: '🪪',
    description: '查询一个 QQ 号在关系网里的状态、来源群、公开主题、信任和风险。主人私聊可见完整 QQ 号；其他会话只返回脱敏摘要。',
    parameters: { type: 'object', properties: { qq: { type: 'string', description: '目标 QQ 号。' } }, required: ['qq'] },
    async execute(ctx, args) {
      const qq = normQq(args?.qq);
      const p = qq ? loadDb().persons[qq] : null;
      if (!p) return { content: '关系网里还没有这个 QQ 号。', isError: true };
      const full = ownerContext(ctx);
      return { content: JSON.stringify(redactPerson(p, full), null, 2) };
    }
  });

  registerTool(api, {
    id: 'graph',
    name: '查看关系网摘要',
    icon: '🕸️',
    description: '本体私聊查看关系网统计、申请队列、群数量、风险节点和最近审计摘要；不在群里输出完整关系网。',
    parameters: { type: 'object', properties: {}, required: [] },
    async execute(ctx) {
      const denied = ownerOnly(ctx);
      if (denied) return denied;
      const d = loadDb();
      const persons = Object.values(d.persons);
      const requests = Object.values(d.requests);
      const pending = requests.filter((r) => ['awaiting_owner', 'approved', 'sent'].includes(r.state));
      const risk = persons.filter((p) => p.riskFlags?.length || p.status === 'blocked' || p.status === 'hostile');
      const lines = [
        `人物 ${persons.length}｜群 ${Object.keys(d.groups).length}｜关系边 ${Object.keys(d.relations).length}`,
        `申请：待批 ${requests.filter((r) => r.state === 'awaiting_owner').length}｜已批 ${requests.filter((r) => r.state === 'approved').length}｜已交适配器 ${requests.filter((r) => r.state === 'sent').length}｜已确认好友 ${requests.filter((r) => r.state === 'accepted').length}`,
        `风控节点 ${risk.length}｜只读模式 ${dbReadOnly ? '是' : '否'}｜适配器 ${validAction(config().friendRequestAction) || '未配置'}`
      ];
      if (pending.length) lines.push('最近申请：', ...pending.slice(-10).map((r) => `- ${r.id} ${r.targetQq} ${r.state} ${r.topic}`));
      return { content: lines.join('\n') };
    }
  });

  registerTool(api, {
    id: 'block',
    name: '阻断外交目标',
    icon: '🛑',
    description: '本体私聊将某个 QQ 号加入本插件的阻断状态，取消所有未发送申请并让后续候选、申请和发送都失败。它不会替代 blacklist-gate 的全局黑名单。',
    parameters: { type: 'object', properties: { qq: { type: 'string', description: '目标 QQ 号。' }, reason: { type: 'string', description: '阻断理由，可选。' } }, required: ['qq'] },
    async execute(ctx, args) {
      const denied = ownerOnly(ctx);
      if (denied) return denied;
      const qq = normQq(args?.qq);
      if (!qq || owners().includes(qq) || bots(ctx).includes(qq)) return { content: '不能阻断主人或本机机器人。', isError: true };
      const p = ensurePerson(qq, 'person');
      p.status = 'blocked';
      p.ownerPermission = 'none';
      p.riskFlags = [...new Set([...(p.riskFlags || []), 'owner_blocked'])];
      p.cooldownUntil = Number.MAX_SAFE_INTEGER;
      for (const r of Object.values(loadDb().requests)) {
        if (r.targetQq === qq && !['sent', 'accepted'].includes(r.state)) { r.state = 'cancelled'; r.resultAt = now(); }
      }
      markDirty();
      appendAudit('person_blocked', { qq, entityId: p.entityId, reasonHash: hashText(args?.reason) });
      return { content: `已阻断 ${qq}。后续外交流程会在本地门禁处拒绝；如需 QQ 全局屏蔽，请另行使用 blacklist-gate。` };
    }
  });

  registerTool(api, {
    id: 'policy',
    name: '查看外交策略',
    icon: '⚙️',
    description: '本体私聊查看主动外交的观察期、主题门槛、额度、演练模式和好友申请适配器状态。不要在群里复述内部设置。',
    parameters: { type: 'object', properties: {}, required: [] },
    async execute(ctx) {
      const denied = ownerOnly(ctx);
      if (denied) return denied;
      const c = config();
      return { content: [
        `总开关：${c.enabled ? '开' : '关'}｜演练：${c.dryRun ? '开' : '关'}`,
        `群友自动审批：${c.autoGroupApproval ? '开' : '关'}｜群友自动发送：${c.allowAutonomousSend ? '开' : '关'}`,
        `观察 ${c.observationHours} 小时｜互动 ≥${c.minInteractions}｜主题 ≥${c.minTopicMatches}｜候选分 ≥${c.minScore}｜风险 ≤${c.maxRisk}`,
        `额度：全局 ${c.dailyLimit}/日，单群 ${c.perGroupDailyLimit}/日；冷却 ${c.cooldownDays} 天；批准有效 ${c.approvalTtlHours} 小时`,
        `适配器：${validAction(c.friendRequestAction) || '未配置'}｜允许真实外发：${c.allowOutboundFriendRequest ? '是' : '否'}`
      ].join('\n') };
    }
  });
}

export function setup(api) {
  config = () => ({ ...DEFAULTS, ...(api.config?.() || {}) });
  log = api.log || (() => {});
  warn = api.warn || (() => {});
  loadDb();
  syncProtectedNodes();
  registerTools(api);
  log('主动外交与 QQ 关系网已加载（默认只观察/起草，真实外发需要显式适配器）');
}

export function available() {
  return { ok: true };
}

export const hooks = {
  'before-context': (payload = {}) => {
    try { observeTriggerEntries(payload); } catch (error) { warn(`外交观察失败：${error?.message ?? error}`); }
  },
  'before-tool': ({ toolName, argsRaw, ...ctx } = {}) => {
    const name = String(toolName || '');
    if (!name.endsWith('__send')) return;
    const args = typeof argsRaw === 'string' ? safeParse(argsRaw, {}) : (argsRaw || {});
    const req = loadDb().requests[text(args?.requestId, 80)];
    if (!req) return { block: true, reason: '主动外交申请不存在，不能发送' };
    if (!ownerOrAutoContext(ctx, req)) return { block: true, reason: '主动外交发送只允许本体私聊或显式自动群友策略' };
    if (!config().enabled) return { block: true, reason: '主动外交总开关已关闭' };
    if (req.state !== 'approved') return { block: true, reason: `申请状态为 ${req.state}，未批准` };
  },
  'after-response': ({ session } = {}) => {
    // 只记录会话有无发言，不把正文写入关系网；完整消息仍由核心会话存档管理。
    if (!config().enabled || !session?.chatKey || !Array.isArray(session.sent) || !session.sent.length) return;
    const gid = String(session.chatKey).match(/^group:(\d+)$/)?.[1];
    if (!gid) return;
    const at = now();
    const group = ensureGroup(gid);
    group.updatedAt = at;
    markDirty();
  }
};

export function deactivate() {
  if (flushTimer) { clearTimeout(flushTimer); flushTimer = null; }
  flushDb();
}

export function dispose() {
  if (flushTimer) { clearTimeout(flushTimer); flushTimer = null; }
  flushDb();
  db = null;
  entitySalt = null;
  dirty = false;
}

export const internals = {
  normalizeQq: normQq,
  maskQq,
  scorePerson,
  groupGate,
  parseTemplate,
  freshDb,
  loadDb,
  resetForTest() {
    db = freshDb(); dbReadOnly = false; dirty = false;
  }
};
